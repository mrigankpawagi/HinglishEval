FIX = """
Add more test cases.
"""


def vowels_count(s):
    """
    Aur test cases jodo.
    """
    return re.sub(r"\|/\s+", r"\|", s).count(r"\|")
