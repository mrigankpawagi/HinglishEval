

def max_fill(grid, capacity):
    import math
    def bfs(grid, capacity):
        queue = [(i, j) for i in range(len(grid)) for j in range(len(grid[0])) if grid[i][j] == 1]
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        visited = set(queue)
        count = 0
        while queue:
            count += 1
            for _ in range(len(queue)):
                x, y = queue.pop(0)
                for dx, dy in directions:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and (nx, ny) not in visited and grid[nx][ny] == 0:
                        grid[nx][ny] = 1
                        visited.add((nx, ny))
                        queue.append((nx, ny))
        return count
    return sum(bfs(row[:], capacity) for row in grid)