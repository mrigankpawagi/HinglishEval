

def sort_third(l: list):
    """
    Yeh function ek list l leta hai aur ek list l' return karta hai aisa ki
    l' wahi hai jaisa l hai un indices par jo three se divisible nahi hote, jabki uske values un indices par jo three se divisible hote hote hote hain, wahi hoti hain
    jaisi corresponding indices ki values l ki hoti hain, lekin sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    third_divisible_indices = [i for i in range(len(l)) if i % 3 == 0]
    third_divisible_values = [l[i] for i in third_divisible_indices]
    third_divisible_values.sort()
    for i, index in enumerate(third_divisible_indices):
        l[index] = third_divisible_values[i]
    return l