

def is_multiply_prime(a):
    """
    A function that returns true if the given number is a product of exactly three prime numbers, and false otherwise.
    The input (a) should be less than 100.
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True
    prime_factors = []
    for i in range(2, a):
        if a % i == 0 and is_prime(i):
            prime_factors.append(i)
            if len(prime_factors) > 3:
                return False
    return len(prime_factors) == 3