

def vowels_count(s):
    """
    Count the number of vowels in a given string.
    Args:
    s (str): The input string to count vowels in.
    Returns:
    int: The number of vowels in the input string.
    """
    vowels = 'aeiouAEIOU'
    return sum(1 for char in s if char in vowels)