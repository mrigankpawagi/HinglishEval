
def get_closest_vowel(word):
    vowels = "aeiouAEIOU"
    closest_vowel = ""
    for char in word:
        if char in vowels:
            if closest_vowel == "":
                closest_vowel = char
            else:
                if char == closest_vowel:
                    continue
                else:
                    closest_vowel = char
    return closest_vowel