
def starts_one_ends(n):
    """
    Diye gaye positive integer n ke liye, n-digit wale positive integers ki ginti return karo jo 1 se start hote hain ya 1 pe end hote hain.
    """
    result = []
    for i in range(1, 10**n):
        if i % 10 == 0 or i // 10 == 0:
            result.append(i)
    return result