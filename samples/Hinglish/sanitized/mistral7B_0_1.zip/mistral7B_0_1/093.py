
def encode(message):
    """
    Ek function likho jo ek message leta hai, aur usko aise encode karta hai 
    ki wo saare letters ki case ko swap kar deta hai, saare vowels ko 
    unke aage wale 2nd letter se replace kar deta hai english alphabet mein. 
    Sirf letters maan lo. 
    Udaharan:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = 'aeiou'
    result = ''
    for char in message:
        if char.isalpha():
            if char.islower():
                result += chr(ord(char) + 13)
            elif char.isupper():
                result += chr(ord(char) - 13)
            else:
                result += char
        elif char in vowels:
            result += chr(ord(char) + 2)
        else:
            result += char
    return result