
def tri(n):
    """
    Sabhi ko Fibonacci sequence ke baare mein pata hai, yeh mathematicians