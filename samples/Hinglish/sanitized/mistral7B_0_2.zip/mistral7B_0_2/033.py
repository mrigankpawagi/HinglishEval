
def sort_third(l: list):
    """
    This function takes a list l and returns a new list l' such that:
    l' is the same as l for indices that are not divisible by three,
    but for indices that are divisible by three, l' contains the values from l
    in the same order as the corresponding indices in l, but sorted.
    """
    l_copy = l.copy()
    i = 0
    while i < len(l_copy):
        if i % 3 == 0:
            l_copy[i:i+3] = sorted(l_copy[i:i+3])
        i += 1
    return l_copy