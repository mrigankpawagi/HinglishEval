
def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """
    Input list `numbers' ke har do consecutive elements ke beech mein ek number 'delimeter' insert karo.
    """
    return [numbers[i] for i in range(len(numbers)) if i % 2 == 0] + \
           [delimeter] + \
           [numbers[i] for i in range(len(numbers)) if i % 2 != 0]