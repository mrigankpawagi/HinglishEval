
def prod_signs(arr):
    if not arr:
        return None
    return np.prod(np.sign(np.array(arr))) * np.prod(arr)