
from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    """
    String ki list se, sabse lamba string return karo. Agar same length ke multiple strings ho to pehla string return karo. Agar input list khali ho to None return karo.
    """
    if not strings:
        return None
    return max(strings, key=len)