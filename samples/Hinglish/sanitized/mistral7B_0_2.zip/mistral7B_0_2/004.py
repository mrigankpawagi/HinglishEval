
from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    """
    Calculate the Mean Absolute Deviation for the given list of numbers.
    Mean Absolute Deviation is the average absolute difference between each element and the mean:
    MAD = average | x - x_mean |
    """
    return sum(abs(x - np.mean(numbers)) for x in numbers) / len(numbers)