
def order_by_points(nums):
    # Use a list comprehension to calculate the sum of digits for each number and create a new list with the number and its sum as tuples. Then sort the list based on the first element (number) and second element (sum of digits) using key function.
    return sorted(nums, key=lambda x: (x, sum(int(digit) for digit in str(abs(x)))))