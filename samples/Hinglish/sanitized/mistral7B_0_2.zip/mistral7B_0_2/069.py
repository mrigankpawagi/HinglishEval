
def search(lst):
    max_num = max(lst)
    max_num_frequency = lst.count(max_num)
    return max_num if max_num_frequency > lst.count(0) else -1