
def largest_smallest_integers(lst):
    negatives = [i for i in lst if i < 0]
    positives = [i for i in lst if i > 0]
    if not negatives and not positives:
        return (None, None)
    if not negatives:
        return (None, min(positives))
    if not positives:
        return (max(negatives), None)
    return (max(negatives), min(positives))