
def move_one_ball(arr):
    """
    ...
    """
    if not arr:
        return True
    count = 0
    while True:
        last = arr.pop()
        arr.append(last)
        if not any(arr[i] > arr[i+1] for i in range(len(arr)-1)):
            break
        count += 1
    return count >= len(arr)