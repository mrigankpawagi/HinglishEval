
def is_prime(num):
    """
    Checks if a number is prime.
    """
    if num < 2:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

def skjkasdkd(lst):
    prime_num = max(lst)
    while not is_prime(prime_num):
        prime_num -= 1
    prime_digit_sum = sum(int(digit) for digit in str(prime_num))
    return prime_digit_sum