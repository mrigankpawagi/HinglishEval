
def max_fill(grid, capacity):
    import math
    def fill_wells(grid, capacity):
        total_water = 0
        for row in grid:
            for cell in row:
                if cell > 0:
                    water_needed = min(capacity, cell)
                    total_water += water_needed
                    cell -= water_needed
        return total_water
    num_iterations = math.ceil(sum(sum(row) for row in grid) / capacity)
    return int(num_iterations * fill_wells(grid, capacity))