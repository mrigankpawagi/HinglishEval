
from typing import List

def all_prefixes(string: str) -> List[str]:
    """
    Input string ke sabhi prefixes ko shortest se longest tak, list mei return karo
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return list(reversed(map(lambda prefix, s: prefix, ([''] + list(map(lambda i: string[:i+1], range(len(string))))), [string])))