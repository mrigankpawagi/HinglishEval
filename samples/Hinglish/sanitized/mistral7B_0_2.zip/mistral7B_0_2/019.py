
from typing import List

def sort_numbers(numbers: str) -> str:
    """
    Input is a space-delimited string containing numbers from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return a string with numbers sorted in ascending order
    """
    numbers_list = numbers.split()
    sorted_numbers = ' '.join(sorted(numbers_list))