
def common(l1: list, l2: list):
    """
    Do lists ke liye sorted unique common elements return karo.
    """
    set1 = set(l1)
    set2 = set(l2)
    common_set = set1.intersection(set2)
    common_list = list(common_set)
    return common_list