
from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    """
    Filter the given list to keep only integers
    """
    return list(filter(isinstance, values, (int,)))