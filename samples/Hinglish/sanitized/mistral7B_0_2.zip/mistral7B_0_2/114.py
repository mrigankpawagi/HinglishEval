
def minSubArraySum(nums):
    # Initialize variables
    min_sum = float('inf')
    start = 0
    current_sum = 0
    # Iterate through the array
    for end in range(len(nums)):
        current_sum += nums[end]
        # Update minimum sum if current sum is less than previous minimum sum or if we have a new non-empty sub-array
        if current_sum < min_sum or (start == end and current_sum < min_sum):
            min_sum = current_sum
            result_start = start
        # Move the start pointer if the sum becomes greater than the current minimum sum
        if current_sum > min_sum:
            current_sum -= nums[start]
            start += 1
    # Return the minimum sum sub-array
    return sum(nums[result_start:end+1])