
def pluck(arr):
    even_nodes = [i for i, x in enumerate(arr) if x % 2 == 0]
    if not even_nodes:
        return []
    return [even_nodes[0], arr.index(arr[0])]