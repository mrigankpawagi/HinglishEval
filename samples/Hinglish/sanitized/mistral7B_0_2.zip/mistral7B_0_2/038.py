

def encode_cyclic(s: str):
    """
    Teen characters ke groups ko cycle karke encoded string return karo.
    """
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)

def decode_cyclic(s: str):
    """
    teen characters ke groups ko cycle karke encoded string return karta hai.
    """
    groups_size = 3
    encoded_len = len(s)
    groups = [s[i:i+groups_size] for i in range(0, encoded_len, groups_size)]
    decoded_groups = [group[::-1] if len(group) > groups_size else group for group in groups]
    return "".join(decoded_groups)