
def double_the_difference(lst):
    """
    ...
    """
    return sum(i**2 for i in lst if i.isdigit() and i%2 != 0) * 2