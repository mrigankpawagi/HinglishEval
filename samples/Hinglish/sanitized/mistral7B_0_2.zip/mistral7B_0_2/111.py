
def histogram(test):
    if not test:
        return {}
    count = {}
    for char in test.lower().split():
        if char in count:
            count[char] += 1
        else:
            count[char] = 1
    return dict(sorted(count.items(), key=lambda item: item[1], reverse=True))