
def get_closest_vowel(word):
    vowels = "aeiouAEIOU"
    index = len(word)
    for i in range(len(word) - 1):
        if word[i] in vowels and word[i+1] not in vowels:
            index = i
            break
    return word[index] if index < len(word) else ""