
def unique_digits(x):
    """
    Return a list of unique digits in x, sorted in increasing order and without even digits.
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    return list(filter(lambda num: all(d % 2 for d in list(str(num))), x)) or []