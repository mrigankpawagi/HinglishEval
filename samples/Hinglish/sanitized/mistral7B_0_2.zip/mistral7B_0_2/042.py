
def incr_list(l: list):
    """
    Elements ko 1 se badhakar wala list return karo.
    """
    [i += 1 for i in l]
    return l