
from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """
    Check if there are any two numbers in the given list that are closer than the given threshold.
    """
    return len([num for num in numbers if abs(num - numbers[0]) <= threshold]) > 1