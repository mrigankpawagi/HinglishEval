
def is_equal_to_sum_even(n):
    """
    Evaluate if number n can be exactly represented as the sum of 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def even_sum(target):
        for i in range(0, target, 2):
            for j in range(i+2, target+1, 2):
                if target == i + j + sum(range(i+2, j, 2)):
                    return True
        return False
    return even_sum(n)