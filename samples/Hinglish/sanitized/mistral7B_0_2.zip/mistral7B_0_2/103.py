
def rounded_avg(n, m):
    total = (n + sum(range(1, m + 1))) // 2
    avg = total // (m + 1)
    return bin(int(round(avg * (m + 1)))).replace("0b", "") if n <= m else -1