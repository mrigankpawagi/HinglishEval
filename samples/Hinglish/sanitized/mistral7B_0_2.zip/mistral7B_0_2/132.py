
def is_nested(string):
    if not string or string.count('[') != string.count(']'):
        return False
    stack = []
    for char in string:
        if char == '[':
            stack.append(char)
        elif char == ']':
            if not stack or stack.pop() != '[':
                return False
    return not stack