
def fib4(n: int):
    if n <= 3:
        return 0
    fib_seq = [0, 0, 2] + [0] * (n - 3)
    return fib_seq[n]