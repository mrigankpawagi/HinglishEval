
import string

def encode(message):
    """
    A function that takes a message as input, and encodes it by swapping case of all letters, replacing all vowels with the second letter following them in the English alphabet. Only letters are considered.
    Example:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = string.ascii_lowercase[0:5]
    encoded_message = ""
    for char in message:
        if char.isalpha():
            if char.islower():
                encoded_message += char.upper()
            elif char.isupper():
                encoded_message += char.lower()
            else:
                encoded_message += char
        else:
            encoded_message += char
    for i in range(len(message)):
        if message[i].lower() in vowels:
            if i < len(message) - 1:
                encoded_message = encoded_message[:i+1] + string.ascii_lowercase[string.ascii_lowercase.index(message[i].lower())+2] + encoded_message[i+1:]
    return encoded_message