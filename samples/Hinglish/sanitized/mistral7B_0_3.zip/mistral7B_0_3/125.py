
def split_words(txt):
    words = txt.split()
    if not words:
        words = [c for c in txt if c.isalpha() if ord(c) % 2 == 1]
        return len(words) if not words else [words[i] for i in range(len(words)) if i % 2 == 0]
    return words