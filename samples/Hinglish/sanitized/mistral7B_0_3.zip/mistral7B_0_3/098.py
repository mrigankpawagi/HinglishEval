
def count_upper(s):
    """
    Count the number of uppercase vowels at even indices in the given string s.
    Jaise ki:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    vowels = set('AEIOU')
    count = 0
    for i, char in enumerate(s.upper()):
        if i % 2 == 0 and char in vowels:
            count += 1
    return count