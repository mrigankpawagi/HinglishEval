
def change_base(x: int, base: int) -> str:
    if base < 2 or base > 10:
        raise ValueError("Base must be between 2 and 10")
    digits = "0123456789ABCDEF"
    result = []
    while x != 0:
        x, remainder = divmod(x, base)
        result.append(digits[remainder])
    return "".join(result[::-1])