
def check_dict_case(dict):
    """
    Check if all keys in the dictionary are either lower case or upper case strings.
    If the given dictionary is empty, the function should return False.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    all_lower = all(isinstance(key, str) and key.islower() for key in dict.keys())
    all_upper = all(isinstance(key, str) and key.isupper() for key in dict.keys())
    return all_lower or all_upper