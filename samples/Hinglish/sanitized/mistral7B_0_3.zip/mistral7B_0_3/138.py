
def is_equal_to_sum_even(n):
    """
    Evaluate if the given number n can be exactly the sum of 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def is_even(num):
        return num % 2 == 0
    def find_combinations(target, current_sum, current_combination):
        if current_sum > target:
            return
        if current_sum == target:
            return current_combination
        for i in range(2, int(n**0.5) + 1):
            if is_even(i) and not i in current_combination:
                new_combination = current_combination + (i,)
                find_combinations(target, current_sum + i, new_combination)
                find_combinations(target, current_sum, new_combination)
    return any(find_combinations(n, 0, ()) for _ in range(n//2))