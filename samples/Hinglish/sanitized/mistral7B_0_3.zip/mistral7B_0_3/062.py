
def derivative(xs: list):
    """
    xs ek polynomial ke coefficients ko represent karte hain.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Is polynomial ka derivative same form mein return karo.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    result = []
    for i in range(1, len(xs)):
        coefficient = xs[i]
        power = i
        new_coefficient = coefficient * power
        result.append(new_coefficient)
    result.insert(0, 0)  # Add 0 as the first coefficient (for the constant term)
    return result