
from typing import List

def parse_music(music_string: str) -> List[int]:
    """
    This function takes a string as input that represents musical notes in a special ASCII format.
    The function's job is to parse the string and return a list of integers that correspond to the duration of each note in beats.
    Here is a legend:
    'o' - whole note, which lasts for four beats
    'o|' - half note, which lasts for two beats
    '.|' - quater note, which lasts for one beat
    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    notes_dict = {'o': 4, 'o|': 2, '.|': 1}
    notes_list = []
    for note in music_string:
        if note in notes_dict:
            notes_list.append(notes_dict[note])
        elif note == '|':
            notes_list.append(notes_list.pop())
    return notes_list