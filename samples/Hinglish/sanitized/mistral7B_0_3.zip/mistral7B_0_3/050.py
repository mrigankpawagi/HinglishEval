
def encode_shift(s: str):
    """
    Shifts each character in the alphabet 5 places to the right and returns the encoded string.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s if ch.isalpha()])

def decode_shift(s: str):
    """
    Shifts each character in the alphabet 5 places to the left and returns the decoded string.
    """
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s if ch.isalpha()]