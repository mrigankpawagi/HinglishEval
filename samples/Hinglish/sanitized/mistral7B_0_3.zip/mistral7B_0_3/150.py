
def x_or_y(n, x, y):
    """
    A simple program that returns the value of x if n is a prime number and the value of y otherwise.
    Example:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    """
    if isprime(n):
        return x
    else:
        return y