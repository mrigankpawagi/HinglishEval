
def encrypt(s):
    """
    A function that takes a string as an argument and returns an encrypted string
    where alphabets are rotated by two places.
    """
    encrypted_string = ""
    for char in s:
        if char.isalpha():
            ascii_offset = ord('a')
            new_ascii = (ord(char) - ascii_offset + 2) % 26 + ascii_offset
            encrypted_string += chr(new_ascii)
        else:
            encrypted_string += char
    return encrypted_string