
def sorted_list_sum(lst):
    """
    Function that accepts a list of strings as a parameter,
    removes strings with odd lengths,
    and returns the resulted list sorted in ascending order based on the length of the words,
    and alphabetically if the lengths are the same.
    The list always contains strings and never numbers,
    and duplicates can occur.
    The order of the list should be based on the rule mentioned above,
    and the function should return the list sorted in ascending order.
    It is assumed that all words have the same length.
    For example:
    assert list_sort(["aa", "a", "aaa"]) => ["aa"]
    assert list_sort(["ab", "a", "aaa", "cd"]) => ["ab", "cd"]
    """
    # Filter out strings with odd lengths
    filtered_lst = [word for word in lst if len(word) % 2 == 0]
    # Sort the filtered list based on the length of the words and alphabetically if the lengths are the same
    sorted_lst = sorted(filtered_lst, key=len)
    # Sort the list again alphabetically if all words have the same length
    if len(sorted_lst) > 1 and len(sorted_lst[0]) == len(sorted_lst[-1]):
        sorted_lst.sort()
    return sorted_lst