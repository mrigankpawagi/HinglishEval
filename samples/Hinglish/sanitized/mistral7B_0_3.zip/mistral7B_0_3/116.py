
def sort_array(arr):
    """
    Sorts an array of non-negative integers in ascending order based on the count of ones in their binary representation.
    If the count of ones is the same, sort the numbers based on their decimal value.
    """
    def count_ones(num):
        count = 0
        while num > 0:
            num &= (num - 1)
            count += num
        return count
    def sort_by_ones_count(a, b):
        return cmp(count_ones(a), count_ones(b)) if count_ones(a) != count_ones(b) else cmp(a, b)
    arr.sort(key=sort_by_ones_count)
    return arr