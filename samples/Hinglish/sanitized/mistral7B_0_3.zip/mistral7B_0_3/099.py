
def closest_integer(value):
    """
    A function that takes a string value representing a number and returns the closest integer.
    If the number is between two integers, round towards the integer that is further from zero.
    Example
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15
    Note:
    Rounding away from zero means if the given number is between two integers, return the integer that is further from zero.
    For example, closest_integer("14.5") should return 15 and closest_integer("-14.5") should return -15.
    """
    number = float(value)
    if number > 0:
        return math.ceil(number)
    else:
        return math.floor(number)