
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Count the number of vowels in a given string.
    """
    vowels = "aeiouAEIOU"
    count = sum(1 for char in s if char in vowels)
    return count