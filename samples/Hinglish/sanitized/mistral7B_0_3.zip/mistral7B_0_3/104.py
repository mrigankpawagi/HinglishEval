
def unique_digits(x):
    """
    Given a list of positive integers x, return a sorted list of those integers where no even digits are present.
    Note: The returned list should be sorted in increasing order.
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    return sorted([num for num in x if all(digit % 2 != 0 for digit in list(str(num)))])