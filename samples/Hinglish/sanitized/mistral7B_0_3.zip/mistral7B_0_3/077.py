
def iscube(a):
    """
    A function that takes an integer and returns True if the integer is a cube of another integer.
    Note: It is assumed that the input will always be valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    """
    for i in range(1, int(a**(1/3))+1):
        if i**3 == a:
            return True
    return False