
def fib4(n: int):
    """
    Fib4 number sequence is a sequence similar to the Fibbonacci sequence, defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    This function computes the n-th element of the Fib4 sequence efficiently without using recursion.
    """
    fib_sequence = [0, 0, 2, 0]
    if n < 4:
        return fib_sequence[n]
    for i in range(4, n+1):
        fib_sequence.append(fib_sequence[i-1] + fib_sequence[i-2] + fib_sequence[i-3] + fib_sequence[i-4])
    return fib_sequence[n]