
def add(lst):
    """
    A non-empty list of integers is given as lst. Add even elements at odd indices.
    Example:
        add([4, 2, 6, 7]) ==> 2
    """
    return sum(i for i, num in enumerate(lst) if i % 2 == 1 and num % 2 == 0)