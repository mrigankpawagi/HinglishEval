
def numerical_letter_grade(grades):
    letter_grades = ['E', 'D-', 'D+', 'D', 'D', 'C-', 'C', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A', 'A+']
    GPA_threshold = [0.0, 0.7, 1.0, 1.3, 1.7, 2.0, 2.3, 2.7, 3.0, 3.3, 3.7, float('inf')]
    result = []
    for gpa in grades:
        for i in range(len(GPA_threshold) - 1):
            if gpa >= GPA_threshold[i] and gpa < GPA_threshold[i + 1]:
                result.append(letter_grades[i])
                break
    return result