
def count_up_to(n):
    """
    A function that takes a non-negative integer and returns an array containing the prime numbers less than or equal to n.
    """
    primes = [2]
    for num in range(3, n + 1):
        is_prime = True
        for potential_divisor in primes:
            if num % potential_divisor == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(num)
    return primes