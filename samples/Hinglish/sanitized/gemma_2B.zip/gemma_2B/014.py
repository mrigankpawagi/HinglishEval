from typing import List


def all_prefixes(string: str) -> List[str]:
    """
    Input string ke sabhi prefixes ko shortest se longest tak, list mei return karo
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    result = []
    for i in range(len(string)):
        for s in all_prefixes(string[:i]):
            result.append(s)
    return result