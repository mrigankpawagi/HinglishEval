
def hex_key(num):
    """
    Aapko ek function likhna hai jo ek hexadecimal number ko string ke roop mein leta hai aur ginata hai ki kitne hexadecimal digits prime hain (prime number, ya prime, ek natural number hota hai jo 1 se bada hota hai aur do chote natural numbers ka product nahi hota).
    Hexadecimal digits hote hain 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F.
    Prime numbers hote hain 2, 3, 5, 7, 11, 13, 17,...
    To aapko ye determine karna hai ki nimn digits ki sankhya kitni hai: 2, 3, 5, 7, B (=decimal 11), D (=decimal 13).
    Note: aap maan sakte hain ki input hamesha sahi ya empty string hoga, aur symbols A,B,C,D,E,F hamesha uppercase mein honge.
    Examples:
    Agar num = "AB" hai to output 1 hona chahiye.
    Agar num = "1077E" hai to output 2 hona chahiye.
    Agar num = "ABED1A33" hai to output 4 hona chahiye.
    Agar num = "123456789ABCDEF0" hai to output 6 hona chahiye.
    Agar num = "2020" hai to output 2 hona chahiye.
    """
    alphabet_digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    numToDigits = {n:{n for n in alphabet_digits if n >= num}}
    letters = alphabet_digits[0] + alphabet_digits[-1]
    for i in range(9):
        num = alphabet_digits[i]
        prefix = letters + num
        numToDigits[prefix] = dict.fromkeys([prefix for n in prefix if n >= num], prefix)
    for n in alphabet_digits:
        numToDigits[n] = {n:n}
    digits = alphabet_digits[:num]
    for i in range(9,num):
        alpha = alphabet_digits[i-9]
        beta = alphabet_digits[i-8]
        if digits[-i]+alpha+beta in numToDigits.keys():
            numToDigits[digits[-i]+alpha+beta].update(digits[-(i-8):-(i-9)])
        else:
            numToDigits[digits[-i]+alpha+beta] = numToDigits[digits[-(i-9):-(i-8)]]
    digits = alphabet_digits[i-1]
    if digits[-1]+digits[-2] in numToDigits.keys():
        nums = numToDigits[digits[-1]+digits[-2]].keys()
        nums = [int(a[1:-1]) for a in nums]
        return len(set(nums))
    else:
        nums = numToDigits[digits[-1]]
        return len(set(nums[:3]))