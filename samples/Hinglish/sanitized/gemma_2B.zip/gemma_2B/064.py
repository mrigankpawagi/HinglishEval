
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Aur test cases jodo.
    """
    vowel_dict = {
     'A' : 'a',
     'E': 'e',
     'I': 'i',
     'O': 'o',
     'U': 'u'}
    count = 0
    for i in s:
        if i in 'A' or i in 'E' or i in 'I' or i in 'O' or i in 'U':
            count += 1