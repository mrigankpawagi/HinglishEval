

def truncate_number(number: float) -> float:
    """
    Diye gaye positive floating point number ko hum integer part (diye gaye number se chota sabse bada integer) aur decimals 
    (hamesha 1 se chota bacha hua part) mein decompose kar sakte hain.
    Number ka decimal part return karo.
    >>> truncate_number(3.5)
    0.5
    """
    if number % 1 == 0:
        return 0.0
    # decimal part of a floating point number
    # the value can be 0 or 1
    decimal = (number % 1)
    decimal *= 10**float(len(str(decimal)))
    integer_part = int(number)
    # replace decimals with 0's 
    integer_part = int(integer_part * (10**len(str(decimal)))) 
    # return the integer part 
    return integer_part