

def count_distinct_characters(string: str) -> int:
    """
    Ek string di gayi hai, pata karo ki usme kitne alag-alag characters (case ki parwah kiye bina) hain
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    chars = list(string.lower())  # lowe kar liya karne me hai
    count = 0
    for i in range(0,len(chars)):
        c = chars[i].lower()  # same thing
        for j in range(i+1,len(chars)):
            d = chars[j].lower()
            if c != d:  # same thing
                continue
            else:
                count += 1
    return count