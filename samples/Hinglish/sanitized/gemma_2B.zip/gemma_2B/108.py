
def count_nums(arr):
    """
    Ek function likho count_nums jo ek array of integers leta hai aur return karta hai
    un elements ki sankhya jinka digits ka sum > 0 hota hai.
    Agar koi number negative hai, to uska pehla signed digit negative hoga:
    jaise ki -123 ke signed digits hote hai -1, 2, aur 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    import math
    d={}
    #for i in range(10):
       # d[i]=[]
    '''
    for i in arr:
        if i<0:
            continue
        else:
            j=1
            while(i>=0):
                j=i%10
                add=0
                while(add<j and i>=0):
                    add=add+i%10
                    i=i//10
                if not((isinstance(add,int))or (not all(isinstance(e,int)for e in add))):
                    continue
                else:
                    d[j]+=add
                    i=i//10
    '''
    for _id,_val in enumerate(arr):
        for i,_char in enumerate(str(_val)):
            try:
                if i==_id and (_char not in "-0123456789"):
                    _val=-_val
            except:
                pass
            try:
                _char=int(i)
                if _char not in "-0123456789":
                    _val=-_val
                d[int(_char)]+=_val
            except:
                j=1
                while len(str(_val))>-_id and j<_char:
                    add=0
                    while add<_char and i<_id:
                        add+=_val%10
                        _val=_val//10
                    if add not in "0123456789":
                        d[j]+=_val
                        _val=_val//10
                    j+=1
    print(d)
    ans=0
    for i,_val in enumerate(d.values()):
        if d[i]>0:
            ans+=i
    return ans