

def common(l1: list, l2: list):
    """
    Do lists ke liye sorted unique common elements return karo.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]
    """
    common=[]
    dic = {}
    for i in l2:
        if not i in dict:
            dict[i]=l2.count(i)
    l1_unique = list(set([n for n in l1 if l1.count(n) == 1]))
    l2_unique = list(set([n for n in l2 if l2.count(n) == 1]))
    print(l1_unique)
    print(l2_unique)
    for i in l2_unique:
        if i in dict:
            for j in l1_unique:
                if i == j and l1.count(j)!=l2.count(j):
                    l1.remove(j)
                    del dict[i]
    l1 = sorted(l1)
    l2=[v for k, v in dic.items()]
    for i in l2: 
        l1.remove(i)
        l1.sort()
    return l1