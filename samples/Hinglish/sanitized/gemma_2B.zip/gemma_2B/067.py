
def fruit_distribution(s,n):
    """
    Is task mein, aapko ek string di jayegi jo ek fruit basket mein distribute kiye gaye apples aur oranges ki sankhya ko darshati hai. Ye basket mein apples, oranges, aur mango fruits hote hain. Diye gaye string se jo total number of oranges aur apples ko darshati hai aur ek integer jo basket mein total fruits ki sankhya ko darshati hai, use use karke basket mein mango fruits ki sankhya return karo.
    Jaise ki:
    fruit_distribution("5 apples and 6 oranges", 19) ->19 - 5 - 6 = 8
    fruit_distribution("0 apples and 1 oranges",3) -> 3 - 0 - 1 = 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 100 - 2 - 3 = 95
    fruit_distribution("100 apples and 1 oranges",120) -> 120 - 100 - 1 = 19
    """
    # Write your code here
    # string ko space se separate krega, jo basket ke fruits ko divide karega
    # jo baar koi fruit ke chakkar ko leke paise mein se divide karega
    # baar baar apple use ko divide karega to banana k liye
    # baar baar apple usse baat karega
    fruit = s.split(' ')
    total_mango_fruits = sorted([int(x) for x in fruit]).pop()
    total_fruits = float(total_mango_fruits)
    a = [int(x) for x in fruit]
    b = sorted(a)
    apples = total_ mangoes / b[1]
    for x in range(1, len(b) - 1):
        if a[x] == b[1] and a[x + 1] <= a[x]:
            c = b[1] - a[x]
            b[1] = c
            a[x+1] = a[x + 1] - c
            b[1] = b[1] - c
            a[x] = a[x] - c
    for b in range(2, len(b)):
        total_ mangoes = sorted([a[x] for x in b]).pop()
        if total_ fruits >= total_ mangoes:
            break
    else:
        print(0)
        return
    d = []
    for x in b:
        d.append(x)
    return print(total_ fruits - apples - (total_ mangoes * d[1]))