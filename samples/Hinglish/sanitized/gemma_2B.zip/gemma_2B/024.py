

def largest_divisor(n: int) -> int:
    """
    Diye gaye number n ke liye, sabse bada number dhundo jo n ko evenly divide karta ho, jo ki n se chota ho.
    >>> largest_divisor(15)
    5
    """
    ans = 1
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            ans = max(ans, max(n // i, i))
    ans = max(ans, n % ans) if n % ans != 0 else ans
    return ans