
def starts_one_ends(n):
    """
    Diye gaye positive integer n ke liye, n-digit wale positive integers ki ginti return karo jo 1 se start hote hain ya 1 pe end hote hain.
    """
    ret = []
    for i in range(10):
        if is_one_digit_one_start_one_end(i):
            ret.append(i)
    if len(ret) == 0:
        return 0
    return int("".join(str(i) for i in ret))