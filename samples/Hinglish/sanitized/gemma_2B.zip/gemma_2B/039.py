

def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    c = int(n)*2
    while True:
        for i in range(2, int(n/2)+1):
            a = c//i
            if (a**2)%c!=c%a and a==c//a:
                return(a)
        if c%2!=c or c%3!=c or c%5!=c:
            for j in range(6,c,5):
                if 0 not in (c%j):
                    return(c)
                if c%j and j==c//j:
                    for i in range(2,int(c/j)+1):
                        if (i**2)%c!=c%i:
                            return(i)
    return(c)