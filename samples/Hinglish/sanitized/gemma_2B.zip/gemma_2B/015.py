

def string_sequence(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    # Here we will use the modulo (%) operator.
    # In order to see the differences between how we return using ternary conditional operators,
    # you'll want to put the conditional operator right on the line following the return statement
    # without any intermediate print statements.
    # Note: we're using a space for our "numbers" here. If you replace that with a 1,
    # you have our 0,3,6,9,12,15!
    return str(n) if n <= 1 else f'{'' if n % 3 else string_sequence(n - 1):6}{string_sequence(n - 1)}'
    # if n <= 1:
    #     return ''.join(' ' * (6-len(str(n)))) + str(n)
    # return string_sequence(n-1) + ''.join(((x if x % 3 else ',') for x in (3*list(range(n-1)))))
    # return string_sequence(n) if n % 3 == 0 else string_sequence(n-1) + (',' if n %3 else '') + string_sequence(n-1)