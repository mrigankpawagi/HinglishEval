

def encode_cyclic(s: str):
    """
    Teen characters ke groups ko cycle karke encoded string return karo.
    """
    # Strings ko groups mein split karo. Sabki length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # Har group ke elements ko cycle karo. Jabtak group mei elements 3 se kam na ho.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    teen characters ke groups ko cycle karke encoded string return karta hai.
    """
    # Group ke element jo cyclic huye hai kyu ke lekin cycle ki repeat nai jana chahiye, 
    # unhe iske head me add karta hai.
    groups = []
    for group_string in s.strip().split(" "):
        if len(group_string) == 3:
            groups.append("".join([group_string[1:-1], group_string[0]]))
        elif len(group_string) == 5:
            groups.append("".join([["$", "$", "$"], [group_string[0], group_string[2], group_string[4]]]))
        elif len(group_string) == 7:
            # Group-wise reverse
            groups.append(list(zip(*reversed(list(zip(*reversed(group_string))))))))
        # Group length > 7
        else:
            groups.append((group_string[0], group_string[1:], group_string[-1]))
    # Group ko reverse ho kar return karta hai.
    return " ".join("".join(group[::-1]).strip() for group in groups[-1] if len(group) > 0 for group in groups)