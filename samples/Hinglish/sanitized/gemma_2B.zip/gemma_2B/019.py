from typing import List


def sort_numbers(numbers: str) -> str:
    """
    Input ek space-delimited string hai jisme 'zero' se 'nine' tak ke numerals hain.
    Valid choices 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' aur 'nine' hain.
    Return karo string ko jisme numbers smallest se largest tak sorted honge
    >>> sort_numbers('three one five')
    'one three five'
    """
    numbers = numbers.split(' ')                   #: Split String at space bar
    numbers = [int(s) for s in numbers]                 #: Convert String to Numeric
    nums_dict = dict.fromkeys(range(10), 0) #: Dictionary having key as numeral value and sum of its corresponding to its key- value
    counter = range(0, 10)                               #: Initialize counter varaible as range(10)-1 (from 0 to 9)
    for num in numbers:
        nums_dict[num] += 1
    sorted_dict = {key: val for key, val in sorted(nums_dict.items(), key=lambda item: (item[1], item[0]), reverse=True)}
    sorted_numbers = list(sorted_dict.keys())
    return ' '.join(sorted_numbers)