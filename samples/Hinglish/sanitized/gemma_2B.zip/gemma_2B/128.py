
def prod_signs(arr):
    """
    Aapko ek array arr diya gaya hai integers ka aur aapko return karna hai 
    integers ke magnitudes ka sum jo multiplied hoga har number ke signs ka product se
    jo array me diye gaye hain, jo ki 1, -1 ya 0 se represent kiya gaya hai.
    Note: Agar arr khali hai to None return karo.
    Udaharan:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    products = []
    for n in arr:
        if n == 1:
            products.append(1)
        elif n == -1:
            products.append(-1)
        elif n == 0:
           products.extend([0, 0])
    for n in arr:
        counter = 0
        for p in products:
            if p*n == 1:
                counter = counter + 1
            elif p*n == -1:
                counter = counter -1
    if counter%2 == 1:
        return -1
        else:
            return products