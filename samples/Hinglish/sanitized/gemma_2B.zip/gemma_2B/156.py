
def int_to_mini_roman(number):
    """
    Diye gaye positive integer ko uska roman numeral equivalent ke roop mein string ke roop mein prapt karo,
    aur ise lowercase mein return karo.
    Restrictions: 1 <= num <= 1000
    Udaharan:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    digits = [
        'I', 'V', 'X', 'L', 'C', 'D', 'M',
        'I', 'V', 'X', 'L', 'C', 'D', 'M'
    ]
    num_tens = [
        4, 5, 6, 7, 8, 9, 4, 5, 6,
        7, 8, 9, 4, 5, 6, 7, 8, 9
    ]
    num_hundreds = [
        , 1, 2, 3, 4, 5, 10, 20, 30,
        40, 50, 100, 200, 300, 400, 500
    ]
    result = ''   # this will hold the resultant string
    # this loop will take care of handling the individual digits
    # the base case is when the number is 1.
    for i in range(1, number-1):
        result += digits[i]
    # we are doing 2nd level for loop here because if number's digit is less than 4,
    # it is easier than 4. It also handles case when number starts with a 2 digit number.
    # For example 26 = 2*10+6
    for i in range(2, number):
        if i // 10 <= num_tens[i]:
            result += digits[i]
        else:
            result += digits[i//10] + digits[i%10]
    return result.lower()