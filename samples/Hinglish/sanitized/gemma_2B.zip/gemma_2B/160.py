
def do_algebra(operator, operand):
    """
    Do lists diye gaye hain, operator aur operand. Pehla list basic algebra operations ka hai, aur 
    dusra list integers ka hai. Diye gaye do lists ka use karke algebraic 
    expression banaye aur is expression ka evaluation return kare.
    Basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    Udaharan:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    Dhyan de:
        Operator list ki length operand list ki length se ek kam hoti hai.
        Operand ek non-negative integers ki list hoti hai.
        Operator list me kam se kam ek operator hota hai, aur operand list me kam se kam do operands hote hain.
    """
    basic_algebra_ops = [
        '+',
        '*',
        '-',
        '/',
        **
    ]
    if operator in basic_algebra_ops:
        operand = list(map(int, operand))
        if len(operand) < 2:
            raise ValueError
        if len(operand[0]) == len(operand[1]):
            raise ValueError
        try:
            result = operand[0]
            for i in range(len(operand)):
                result = eval(result + ' ' + operand[i] + ' ' + operator[i] + '(' +
                               str(operand[0]).lstrip('-') + ')')
        except SyntaxError as e:
            raise e
        except ZeroDivisionError as e:
            raise e
        except TypeError as e:
            raise e
        if str(result) == 'nan':
            raise SyntaxError("No solution.")
        return int(float(result))
    try:
        return eval(operand)
    except SyntaxError as e:
        raise e