
def can_arrange(arr):
    """
    Ek function banaiye jo ek element ka sabse bada index return kare jo
    usse turant pichle element se bada ya barabar nahi ho. Agar
    aisa koi element nahi hai, to -1 return kare. Diye gaye array me
    duplicate values nahi hogi.

    Udaharan:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    # Write your code here.
    if len(arr) == 1:
        return 0
    if len(arr) == 2:
        return 1
    if len(arr) == 3:
        return 2
    if len(arr) == 4:
        return 3
    if len(arr) == 5:
        return 4
    if len(arr) == 6:
        return 5
    if len(arr) == 7:
        return 6
    if len(arr) == 8:
        return 7
    if len(arr) == 9:
        return 8
    if len(arr) == 10:
        return 9
    if len(arr) == 11:
        return 10
    if len(arr) == 12:
        return 11
    if len(arr) == 13:
        return 12
    if len(arr) == 14:
        return 13
    if len(arr) == 15:
        return 14
    if len(arr) == 16:
        return 15
    if len(arr) == 17:
        return 16
    if len(arr) == 18:
        return 17
    if len(arr) == 19:
        return 18
    if len(arr) == 20:
        return 19
    if len(arr) == 21:
        return 20
    if len(arr) == 22:
        return 21
    if len(arr) == 23:
        return 22
    if len(arr) == 24:
        return 23
    if len(arr) == 25:
        return 24
    if len(arr) == 26:
        return 25
    if len(arr) == 27:
        return 26
    if len(arr) == 28:
        return 27
    if len(arr) == 29:
        return 28
