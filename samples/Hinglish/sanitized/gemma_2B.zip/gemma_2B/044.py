

def change_base(x: int, base: int):
    """
    Input number x ka numerical base, base me badal do.
    Conversion ke baad string representation return karo.
    Base numbers 10 se kam hote hain.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    result = "{0:b}".format(x).lstrip('0')[::-1]
    if len(result) > base:
        return str(change_base(x, int(base / 2)))
    return result[1:].zfill(base - 1)