
def fix_spaces(text):
    """
    Diye gaye string text mein, saare spaces ko underscores se replace karo,
    aur agar ek string mein 2 se zyada consecutive spaces ho,
    toh saare consecutive spaces ko - se replace karo.
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    if len(text) == 0:
        return text 
    else:
        if text[-4:]==" ".join(text.split()):
            text = "-".join(text.split())
        elif " " not in text:
            return text
        s = "_".join([x if x == " " else x for x in text[1:-4]])
        if len(s)==5:
            return s
        else:
            if not s[0] == text[0]:
                return "_" +text[0]+"_".join(s[1:])
            else:
                return text