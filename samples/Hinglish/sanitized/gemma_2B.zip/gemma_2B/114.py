
def minSubArraySum(nums):
    """
    Ek integer array nums diya gaya hai, usme se kisi bhi non-empty sub-array ka minimum sum dhundho.
    Udaharan
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    answ = nums[0]
    for i in range(1, len(nums)):
        nums[i] = nums[i] + nums[i - 1]
    for i in range(1, len(nums)):
        if nums[i] < answ:
            answ = nums[i]
    return answ