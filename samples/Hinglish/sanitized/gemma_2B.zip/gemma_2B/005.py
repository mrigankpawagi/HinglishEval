from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """
    Input list `numbers' ke har do consecutive elements ke beech mein ek number 'delimeter' insert karo.
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    count: List[int] = [0]
    for num in numbers:
        if num % delimeter == 0:
            if count[0] == 0:
                count = [num]
            else:
                count[-1] = num
        else:
            count.append(num)
    return count