

def fib(n: int):
    """
    n-th Fibonacci number return karo.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    a = 1
    if n >=0:
        for i in range(n):
             a = b
             b = a+ b
    return b