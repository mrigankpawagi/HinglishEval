
def simplify(x, n):
    """
    Aapka task hai ek function implement karna jo expression
    x * n ko simplify karega. Yeh function True return karega agar x * n ka evaluation ek whole number hota hai aur False
    otherwise. Dono x aur n, fraction ka string representation hai, aur inka format aisa hota hai,
    <numerator>/<denominator> jahan dono numerator aur denominator positive whole numbers hote hain.
    Aap maan sakte hain ki x, aur n valid fractions hain, aur inka denominator zero nahi hota.
    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    # Complete this function
    f_r = float_to_fraction(x)
    d_r = float_to_fraction(n)
    if (d_r == 0):
        return False
    #if numerator and denominator are whole number and have no common factors
    if (is_fraction(n, f_r) and is_fraction(x, n) and is_whole_number(n) and is_simple_num(f_r) and is_simple_num(n) ):
        return True
    else:
        return False