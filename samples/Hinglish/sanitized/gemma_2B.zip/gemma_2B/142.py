


def sum_squares(lst):
    """
    "
    Ye function ek integers ki list lega. List ke saare entries ke liye, function integer entry ko square karega agar uska index 3 ka 
    multiple hai aur cube karega agar uska index 4 ka multiple hai aur 3 ka multiple nahi hai. Function un entries ko change nahi 
    karega jinki indexes 3 ya 4 ka multiple nahi hai. Phir function saare entries ka sum return karega. 
    Examples:
    Agar lst = [1,2,3] hai to output 6 hona chahiye
    Agar lst = []  hai to output 0 hona chahiye
    Agar lst = [-1,-5,2,-1,-5]  hai to output -126 hona chahiye
    """
    sum, sq, cube = 0, 0, 0
    n = len(lst)
    for i in range(0, n):
        if i % 3 == 0:    # index 3 ko multiple karega
            sum += lst[i] ** 2           # cube karega
        if i % 4 == 0:        # index 4 ko multiple karega
            sum += lst[i] ** 3       # square karega
        if i % 3 != 0 and i % 4 != 0: # index 3, 4 ko multiple nahi hai. Phir apni cube bhi likh dena
            cube += lst[i]           # cube likhna
    return sum