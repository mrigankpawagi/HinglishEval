
def is_nested(string):
    """
    Ek function banao jo sirf square brackets wala string input ke roop mein leta hai.
    Function tabhi True return karega jab valid subsequence of brackets ho 
    jisme kam se kam ek bracket nested ho.
    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    """
    brackets = string.replace('[', '(').replace(']', ')')
    #brackets=[brackets.index(x) for x in brackets if x == '('] is more efficient.
    #print(brackets)
    if len(brackets) == 0:
        return False
    else:
        for i in brackets:
            print(i)
            if i == 0:
                return False
            elif brackets[i-1] == "[" and brackets[i] == "]":
                return True
        return False