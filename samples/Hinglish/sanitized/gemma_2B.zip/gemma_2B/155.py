
def even_odd_count(num):
    """
    Ek integer diya gaya hai. Ek tuple return karo jo even aur odd digits ki sankhya ko kramashah darshata hai.
     Udaharan:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    # your code here
    digits = str(num)
    result = []
    for digit in digits:
        if int(digit)%2 ==0:
            result.append(1)
        else:
            result.append(0)
    return  result