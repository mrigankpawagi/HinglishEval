
def next_smallest(lst):
    """
    Aapko ek list di gayi hai integers ki.
    Ek function likho next_smallest() jo list ka 2nd sabse chhota element return kare.
    Agar aisa koi element nahi hai to None return kare.
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """    
    if not isinstance(lst, list):
        return None
    if len(lst) == 1:
        return lst[0]
    min_ele = min(lst[1:], key=lst.index)
    return lst[0] if min_ele == lst[0] else min_ele