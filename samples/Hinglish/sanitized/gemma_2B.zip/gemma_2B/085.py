
def add(lst):
    """
    Ek non-empty list di gayi hai integers ki lst. Add karo even elements ko jo odd indices pe hai.
    Udaharan:
        add([4, 2, 6, 7]) ==> 2
    """
    k = 0
    if len(lst) == 0:
        return None
    for i in range(len(lst)):
        if (lst[k] % 2 == 0 or k == 0) and (lst[i] % 2 == 0 or i == len(lst) - 1):
            lst[k] += lst[i]
            k += 1
    return lst