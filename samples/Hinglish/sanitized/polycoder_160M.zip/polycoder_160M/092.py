
def any_int(x, y, z):
    """
    Ek function banao jo 3 numbers leta hai.
    Agar koi ek number doosre do numbers ka sum ho, aur saare numbers integers ho, toh true return kare.
    Kisi bhi aur case mein false return kare.
    
    Udaharan
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
    """
    if x == y:
        if z in ("z", "a") or x in ("y", "p"):  # True or False
            if x == y:
                if z == y:  # Return false by default to False
                    if z < self.a or z > self.a-1 ** 2  # if Z is equal to or lesser than a 1, return the result.
                        return True
                    if x < self.a or x > self.a-1 ** 3  # if X is greater than a 1, return the result.
                        return False
                elif x > self.a or x < self.a-1 ** 4  # if X is greater than or less than a 1, return the result.
                    if x < self.a or x > self