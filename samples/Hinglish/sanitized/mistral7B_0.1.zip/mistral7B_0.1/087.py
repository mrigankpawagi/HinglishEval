
def get_row(lst, x):
    """
    Aapko ek 2 dimensional data diya gaya hai, ek nested lists ke roop mein,
    jo matrix ke saman hai, lekin, matrices ke unique,
    har row mein alag number of columns ho sakte hain.
    Diye gaye lst, aur integer x, list mein integers x ko dhundho,
    aur tuples ki list return karo, [(x1, y1), (x2, y2) ...] aisa ki
    har tuple ek coordinate ho - (row, columns), shuru karte hue 0 se.
    Coordinates ko pehle rows ke hisaab se ascending order mein sort karo.
    Saath hi, row ke coordinates ko columns ke hisaab se descending order mein sort karo.
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """
    def get_row_helper(lst, x):
        row_coordinates = []
        column_coordinates = []
        for i, row in enumerate(lst):
            if x in row:
                row_coordinates.append(i)
                for j, element in enumerate(row):
                    if element == x:
                        column_coordinates.append(j)
        row_coordinates.sort()
        column_coordinates.sort(reverse=True)
        return [(i, j) for i, j in zip(row_coordinates, column_coordinates)]
    return get_row_helper(lst, x)