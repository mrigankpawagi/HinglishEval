
def do_algebra(operator, operand):
    """
    Do lists diye gaye hain, operator aur operand. Pehla list basic algebra operations ka hai, aur 
    dusra list integers ka hai. Diye gaye do lists ka use karke algebraic 
    expression banaye aur is expression ka evaluation return kare.
    Basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    Udaharan:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    Dhyan de:
        Operator list ki length operand list ki length se ek kam hoti hai.
        Operand ek non-negative integers ki list hota hai.
        Operator list me kam se kam ek operator hota hai, aur operand list me kam se kam do operands hote hain.
    """
    if len(operator) != len(operand):
        raise ValueError("Operator list ki length operand list ki length se ek kam hota hai.")
    for i in range(len(operator)):
        if not isinstance(operator[i], (int, float)) or not isinstance(operand[i], (int, float)):
            raise TypeError("Operator list me kam se kam ek operator hota hai, aur operand list me kam se kam do operands hote hain.")
    result = eval(''.join(operator) + ' '.join(map(str, operand)))
    return result