
def minPath(grid, k):
    def dfs(grid, visited, current, path):
        if len(path) == k:
            return
        for i in range(len(grid)):
            for j in range(len(grid[0])):
                if not visited[i][j] and grid[i][j] != current:
                    visited[i][j] = True
                    path.append(grid[i][j])
                    dfs(grid, visited, current, path)
                    visited[i][j] = False
                    path.pop()
    visited = [[False for _ in range(len(grid[0]))] for _ in range(len(grid))]
    path = []
    dfs(grid, visited, 0, path)
    return path