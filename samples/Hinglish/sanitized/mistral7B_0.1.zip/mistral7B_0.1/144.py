
def simplify(x, n):
    """
    Aapka task hai ek function implement karna jo expression
    x * n ko simplify karega. Yeh function True return karega agar x * n ka evaluation ek whole number hota hai aur False
    otherwise. Dono x aur n, fraction ka string representation hai, aur inka format aisa hota hai,
    <numerator>/<denominator> jahan dono numerator aur denominator positive whole numbers hote hain.
    Aap maan sakte hain ki x, aur n valid fractions hain, aur inka denominator zero nahi hota.
    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    if x.isdigit() and n.isdigit():
        x, n = int(x), int(n)
        if x * n % 1 == 0:
            return True
        else:
            return False
    elif x.isdigit() and n.isalpha():
        x, n = int(x), n
        if x * n % 1 == 0:
            return True
        else:
            return False
    elif x.isalpha() and n.isdigit():
        x, n = x, int(n)
        if x * n % 1 == 0:
            return True
        else:
            return False
    else:
        return False