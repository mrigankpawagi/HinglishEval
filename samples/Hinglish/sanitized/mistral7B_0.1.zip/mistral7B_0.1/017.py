
from typing import List

def parse_music(music_string: str) -> List[int]:
    notes = ['o', 'o|', '.|']
    note_counts = []
    for note in music_string.split():
        if note in notes:
            if note == 'o':
                note_counts.append(4)
            elif note == 'o|':
                note_counts.append(2)
            else:
                note_counts.append(1)
    return note_counts