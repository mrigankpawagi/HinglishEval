
def encrypt(s):
    """
    Ek function banaiye encrypt jo ek string ko argument ke roop mein leta hai aur
    ek encrypted string return karta hai jisme alphabet ko rotate kiya gaya ho.
    Alphabet ko aise rotate karna chahiye ki letters 
    do se multiply kiye gaye do places ke neeche shift ho jaye.
    Jaise ki:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    encrypted = ""
    for char in s:
        if char.isalpha():
            shifted_char = chr(((ord(char) - 97 + 2) % 26) + 97)
            if char.islower():
                shifted_char = shifted_char.lower()
            else:
                shifted_char = shifted_char.upper()
            encrypted += shifted_char
        else:
            encrypted += char
    return encrypted