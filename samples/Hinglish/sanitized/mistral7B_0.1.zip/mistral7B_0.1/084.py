
def solve(N):
    """
    Diye gaye positive integer N ka, uske digits ka total sum binary mein return karo.
    Udaharan
        Agar N = 1000 hai, to digits ka sum hoga 1 aur output honi chahiye "1".
        Agar N = 150 hai, to digits ka sum hoga 6 aur output honi chahiye "110".
        Agar N = 147 hai, to digits ka sum hoga 12 aur output honi chahiye "1100".
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         binary number ka ek string
    """
    def sum_digits(n):
        sum = 0
        while n > 0:
            sum += n % 10
            n //= 10
        return sum
    def to_binary(n):
        binary = ""
        while n > 0:
            binary += str(n % 2)
            n //= 2
        return binary[::-1]
    return to_binary(sum_digits(N))