
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_numbers = min(numbers, key=lambda x: min(abs(x - numbers[0]), abs(x - numbers[-1]))) if numbers else (None, None)
    return tuple(sorted([numbers[numbers.index(closest_numbers)], closest_numbers]))