
def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero ek integers ki list ko input ke roop mein leta hai.
    Yeh True return karta hai agar list mein do alag elements hote hain jo
    zero ke barabar sum karte hain, aur anyatha False.
    """
    return len(set(x for a in l for x in (a, a+1) if not x == 0)) % 2 == 0 and all(map(lambda x: 0 in l[::l.index(x)+1], l))