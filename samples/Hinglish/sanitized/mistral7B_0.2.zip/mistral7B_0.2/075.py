
def is_multiply_prime(a):
    """
    A function that returns True if the given number is the product of three prime numbers,
    and False otherwise. This function should only be called when (a) is less than 100.
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True
    return all(map(is_prime, prime_factors(a)))