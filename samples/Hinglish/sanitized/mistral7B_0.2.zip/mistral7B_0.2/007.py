
from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """
    Filter the given list of strings to include only those strings that contain the given substring
    """
    return [s for s in strings if substring in s]