
def is_palindrome(text: str):
    """
    Checks if the given string is a palindrome.
    :param text: The input string.
    :return: True if the string is a palindrome, False otherwise.
    """
    return text == text[::-1]