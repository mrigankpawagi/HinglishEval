
def max_element(l: list):
    """
    List mein se maximum element return karo.
    """
    return max(l)