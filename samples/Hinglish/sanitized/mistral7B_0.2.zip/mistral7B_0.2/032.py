
def find_zero(xs: list):
    """
    Polynomial ko zero point find karo.
    return the root of the polynomial equation xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    def poly(x):
        return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])
    return newton_raphson(poly, 1)