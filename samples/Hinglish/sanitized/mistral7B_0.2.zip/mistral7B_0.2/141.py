
import re

def file_name_check(file_name):
    """
    Ek function banao jo ek string leta hai jisme file ka naam hota hai, aur return karta hai
    'Yes' agar file ka naam valid hai, aur 'No' agar nahi.
    """
    pattern = r"^[a-zA-Z][a-zA-Z0-9._]+([.][a-zA-Z0-9]{2,})$"
    if re.match(pattern, file_name):
        return "Yes"
    else:
        return "No"