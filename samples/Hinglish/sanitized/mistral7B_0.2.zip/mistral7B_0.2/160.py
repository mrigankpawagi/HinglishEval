
def do_algebra(operator, operand):
    """
    Do lists of algebra operations and operands. The first list contains basic algebra operations,
    and the second list contains integers. Use the given lists to create an algebraic expression
    and evaluate it.
    Basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** )
    Example:
    operator = ['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    Pay attention:
        The length of the operator list is one less than the length of the operand list.
        The operand list contains at least one non-negative integer.
        The operator list contains at most one operator, and the operand list contains at most two operands.
    """
    if len(operator) != len(operand) - 1:
        raise ValueError("Invalid length of operator and operand lists")
    expression = operand[0]
    for i in range(len(operator)):
        if i % 2 == 0:
            expression = eval(f"{expression} {operator[i]} {operand[i+1]}")
        else:
            expression = eval(f"{expression} {operand[i+1]} {operator[i]}")
    return expression