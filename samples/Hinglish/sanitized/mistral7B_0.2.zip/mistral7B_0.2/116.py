
def sort_array(arr):
    arr.sort(key=lambda x: (bin(abs(x))[2:], -abs(x)) if x < 0 else bin(x)[2:])