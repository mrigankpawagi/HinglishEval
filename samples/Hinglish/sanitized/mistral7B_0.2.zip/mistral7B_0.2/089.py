
def encrypt(s):
    result = ""
    for char in s:
        ascii_value = ord(char)
        new_ascii_value = (ascii_value - ord('a') + 2) % 26 + ord('a')
        result += chr(new_ascii_value)
    return result