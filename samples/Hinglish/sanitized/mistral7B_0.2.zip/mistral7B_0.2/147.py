
def get_max_triples(n):
    a = [i * i - i + 1 for i in range(1, n+1)]
    return len([triple for i, j, k in itertools.combinations(range(len(a)), 3) if a[i] + a[j] + a[k] % 3 == 0 and i < j < k])