
def can_arrange(arr):
    max_elem = max(arr)
    idx = arr.index(max_elem)
    if arr[idx:] == [elem for elem in arr if elem < max_elem]:
        return idx
    else:
        return -1