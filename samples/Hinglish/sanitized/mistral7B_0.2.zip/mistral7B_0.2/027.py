
def flip_case(string: str) -> str:
    """
    Diye gaye string ke liye, lowercase characters ko uppercase me flip karo.
    Uppercase characters ko lowercase me flip karo.
    >>> flip_case('Hello')
    'hELLO'
    """
    return string.lower() if string.isupper() else string.upper()