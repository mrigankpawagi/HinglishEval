
def sorted_list_sum(lst):
    lst.sort(key=lambda x: (len(x), x))
    return [sum(map(ord, i)) for i in lst if len(i) % 2 != 0]