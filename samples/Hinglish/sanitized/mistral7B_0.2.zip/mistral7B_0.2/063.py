
def fibfib(n: int):
    if n <= 2:
        return 0
    return sum(fibfib(i) for i in range(n-2, -1, -1))