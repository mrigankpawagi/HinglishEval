
def will_it_fly(q, w):
    if len(q) == 0:
        return True
    total = sum(q)
    if total > w or (total + len(q) // 2) % 2 != 0:
        return False
    return _will_it_fly_helper(q, w, total // 2)