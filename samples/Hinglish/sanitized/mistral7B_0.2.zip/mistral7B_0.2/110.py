
def exchange(lst1, lst2):
    result = all(lst1[i] == lst2[i] or (lst1[i] % 2 == 0 and lst2[i] % 2 != 0) for i in range(len(lst1)))
    return "YES" if result else "NO"