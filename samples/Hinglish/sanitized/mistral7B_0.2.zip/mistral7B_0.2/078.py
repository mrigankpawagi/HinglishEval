
def hex_key(num):
    hex_to_decimal = {"0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "A": 10, "B": 11, "C": 12, "D": 13, "E": 14, "F": 15}
    prime_digits_count = 0
    for digit in num[::-1]:  # reverse iteration
        decimal_value = hex_to_decimal[digit]
        if isprime(decimal_value):
            prime_digits_count += 1
    return prime_digits_count