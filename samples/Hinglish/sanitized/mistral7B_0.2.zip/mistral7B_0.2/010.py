
def make_palindrome(string: str) -> str:
    """
    Diye gaye string ko check karo ki woh palindrome hai ya nahi. Agar nahi hai to use given string as base and create palindrome version of it.
    """
    if is_palindrome(string):
        return string
    mid = len(string) // 2
    left = 0
    right = len(string) - 1
    while left < mid:
        if string[left] != string[right]:
            string = string[:left] + string[right] + string[left:]
            left = 0
            right = len(string) - 1
        else:
            left += 1
            right -= 1
    return string