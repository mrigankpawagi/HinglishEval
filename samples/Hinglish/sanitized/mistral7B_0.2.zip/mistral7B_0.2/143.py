
def words_in_sentence(sentence):
    words = sentence.split()
    prime_words = [word for word in words if all(i % int(w) for i in range(2, int(1)+10) if int(w) > 1)]
    return " ".join(prime_words)