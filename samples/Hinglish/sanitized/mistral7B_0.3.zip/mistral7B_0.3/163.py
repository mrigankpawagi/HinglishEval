
def generate_integers(a, b):
    """
    Given positive integers a and b, return the even digits in ascending order between a and b.
    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    return sorted(set(range(a, b+1)) & set(filter(lambda x: x % 2 == 0, str(range(a, b+1)))))