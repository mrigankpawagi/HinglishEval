
def largest_divisor(n: int) -> int:
    for i in range(1, n):
        if n % i == 0 and i < n:
            return i
    return n