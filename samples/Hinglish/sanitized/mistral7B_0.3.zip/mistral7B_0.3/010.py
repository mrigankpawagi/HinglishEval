
def make_palindrome(string: str) -> str:
    """
    If the given string is not a palindrome, return the reversed string.
    If the given string is already a palindrome, return the same string.
    """
    if string == string[::-1]:
        return string
    else:
        return string[::-1]