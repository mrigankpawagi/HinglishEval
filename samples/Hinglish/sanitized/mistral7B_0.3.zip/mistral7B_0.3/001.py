
import re

def separate_paren_groups(paren_string: str) -> List[str]:
    """
    ...
    """
    # Use regular expressions to find all balanced groups of parentheses
    matches = re.findall(r'\(([^()]*)\)', paren_string)
    # Remove the outer parentheses from the matches
    result = [m[1] for m in matches]
    return result