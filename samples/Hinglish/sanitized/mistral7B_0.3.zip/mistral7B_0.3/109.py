
def move_one_ball(arr):
    """
    ...
    """
    n = len(arr)
    for _ in range(n-1):
        if arr[i] > arr[i+1] for i in range(n-1):
            arr.append(arr.pop(0))
            if all(arr[i] <= arr[i+1] for i in range(n)):
                return True
    return len(arr) == 0