
def is_multiply_prime(a):
    """
    A function that returns True if the given number is the product of three prime numbers and False otherwise.
    The given number should be less than 100.
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    if a < 2 or a > 99:
        return False
    for num in range(2, int(a**0.3) + 1):
        if a % num == 0:
            return False
    for num in range(int(a**0.3) + 1, int(a**0.5) + 1):
        if a % num == 0 and a % (a // num) == 0:
            return False
    for num in range(int(a**0.5) + 1, 101):
        if a % num == 0 and a % (a // num) != 0:
            return False
    return a == 2 or a == 3 or a == 5 or a == 7 or a == 11 or a == 13 or a == 17 or a == 19 or a == 23 or a == 29 or a == 31 or a == 37 or a == 41 or a == 43 or a == 47 or a == 53 or a == 59 or a == 61 or a == 67 or a == 71 or a == 73 or a == 79 or a == 83 or a == 89 or a == 97