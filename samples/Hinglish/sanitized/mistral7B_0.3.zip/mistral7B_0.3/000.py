
from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """
    Check if there are any two numbers in the given list that are closer than the specified threshold.
    """
    return any(abs(num1 - num2) <= threshold for num1, num2 in zip(numbers, numbers[1:])) or (numbers and abs(numbers[0] - numbers[1]) <= threshold)