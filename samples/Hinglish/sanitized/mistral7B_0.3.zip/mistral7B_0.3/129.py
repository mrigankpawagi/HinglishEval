
from collections import deque
from itertools import permutations

def minPath(grid, k):
    N = len(grid)
    visited = [[False] * N for _ in range(N)]
    paths = []
    def dfs(cell, path, remaining):
        if len(path) == k:
            paths.append(path)
            return
        for next_cell in get_neighbors(cell):
            if not visited[next_cell[0]][next_cell[1]] and grid[next_cell[0]][next_cell[1]] in remaining:
                visited[next_cell[0]][next_cell[1]] = True
                dfs(next_cell, path + [grid[next_cell[0]][next_cell[1]]], remaining - {grid[next_cell[0]][next_cell[1]]})
                visited[next_cell[0]][next_cell[1]] = False
    for i in range(N):
        for j in range(N):
            dfs((i, j), [grid[i][j]], set(range(1, N * N + 1)))
    def lexicographically_smaller(path1, path2):
        for i in range(min(len(path1), len(path2))):
            if path1[i] < path2[i]:
                return True
            if path1[i] > path2[i]:
                return False
        return len(path1) < len(path2)
    return min(paths, key=lambda path: tuple(path))