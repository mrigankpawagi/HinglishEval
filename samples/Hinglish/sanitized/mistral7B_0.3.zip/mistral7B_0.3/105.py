
def by_length(arr):
    """
    Sort the given array of integers, reverse the sorted array, and replace each digit with its corresponding name.
    If the array is empty, return an empty array. Ignore any odd numbers in the array.
    """
    digits = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
    digits_mapping = dict((digit, i) for i, digit in enumerate(digits))
    sorted_arr = sorted([num for num in arr if 0 < num < 10])
    reversed_arr = sorted_arr[::-1]
    result = []
    for num in reversed_arr:
        if num in digits_mapping:
            result.append(digits[digits_mapping[num]])
        else:
            result.append('Unknown')
    return result