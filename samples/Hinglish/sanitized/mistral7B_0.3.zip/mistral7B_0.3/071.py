
def triangle_area(a, b, c):
    """
    Given the lengths of the three sides of a triangle, return the area of the triangle rounded off to 2 decimal points if the triangle is valid.
    Return -1 if the triangle is not valid (i.e., if any two sides do not satisfy the triangle inequality).
    A triangle is valid only when the sum of any two sides is greater than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    """
    if a + b > c and b + c > a and a + c > b:
        s = (a + b + c) / 2
        return round((s * (s - a) * (s - b) * (s - c)) ** 0.5, 2)
    else:
        return -1