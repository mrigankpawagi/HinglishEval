
def pluck(arr):
    even_values = [i for i in arr if i % 2 == 0]
    if not even_values:
        return []
    return min(enumerate(even_values), key=lambda x: x[1])