
def decode_cyclic(s: str):
    """
    Teen characters ke groups ko cycle karke encoded string return karta hai.
    """
    # Har group ko 3 se pehle sehna.
    groups = [s[i:i+3] for i in range(0, len(s), 3)]
    # Har group ke last 2 elements ko pehle sehna. Jabtak group mei elements 3 se kam na ho.
    groups = [group[1:] + group[0] if len(group) > 2 else group for group in groups]
    return "".join(groups)