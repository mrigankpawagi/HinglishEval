
planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]

def bf(planet1, planet2):
    """
    Function to find the planets between two given planets in our solar system.
    Returns a tuple of planets whose orbits are between the orbits of the given planets, sorted in order of their distance from the sun.
    Returns an empty tuple if the given planets are not valid planet names.
    """
    if planet1 not in planets or planet2 not in planets:
        return tuple()
    index1 = planets.index(planet1)
    index2 = planets.index(planet2)
    return tuple(sorted(set(x for i in range(index1, index2 + 1) for x in planets[i])) if index1 < index2 else tuple(sorted(set(x for i in range(index2, index1 - 1, -1) for x in planets[i]))))