
def modp(n: int, p: int):
    """
    2^n modulo p return karo (numerics ka dhyan rakho).
    """
    if n == 0:
        return 1
    elif n % 2 == 0:
        return (modp(n // 2, p) ** 2) % p
    else:
        return (modp(n - 1, p) * n) % p