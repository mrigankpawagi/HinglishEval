
def compare(game, guess):
    assert len(game) == len(guess), "Both arrays should have the same length"
    result = [abs(game[i] - guess[i]) for i in range(len(game))]
    return result