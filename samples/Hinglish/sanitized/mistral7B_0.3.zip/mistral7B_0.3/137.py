
def compare_one(a, b):
    """
    A function that takes real numbers represented as integers, floats, or strings and returns the larger variable in the type it was given.
    If the values are equal, return None.
    Note: If a real number is represented as a string, it may contain a floating point . or ,.
    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if a > b:
            return a
        elif a < b:
            return b
        else:
            return None
    elif isinstance(a, str) and isinstance(b, (int, float)):
        if float(a) > b:
            return a
        elif float(a) < b:
            return b
        else:
            return None
    elif isinstance(a, (int, float)) and isinstance(b, str):
        if a > float(b):
            return a
        elif a < float(b):
            return b
        else:
            return None
    elif isinstance(a, str) and isinstance(b, str):
        if float(a) > float(b):
            return a
        elif float(a) < float(b):
            return b
        else:
            return None