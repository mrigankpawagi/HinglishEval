
def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    fib_sequence = [0, 1]
    primes = [2]
    while len(fib_sequence) < n:
        next_fib = fib_sequence[-1] + fib_sequence[-2]
        if is_prime(next_fib):
            primes.append(next_fib)
            fib_sequence.append(next_fib)
        else:
            fib_sequence.append(next_fib)
    return fib_sequence[n - 1]