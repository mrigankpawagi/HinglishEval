
def is_palindrome(text: str):
    """
    Checks if the given string is a palindrome
    """
    return text == text[::-1]