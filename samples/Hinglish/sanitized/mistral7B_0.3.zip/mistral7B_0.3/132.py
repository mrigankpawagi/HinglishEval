
import re

def is_nested(string):
    """
    A function that takes a string as input containing only square brackets.
    The function returns True if the string contains a valid subsequence of brackets,
    where at least one bracket is nested.
    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    """
    pattern = r'\[(?P<brackets>[^[]*)\]'
    matches = re.finditer(pattern, string)
    for match in matches:
        if not is_balanced(match.group('brackets')):
            return True
    return False