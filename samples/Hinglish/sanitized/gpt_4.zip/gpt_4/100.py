def make_a_pile(n):
    if n % 2 == 0:
        return [i for i in range(n, n + n, 2)]
    else:
        return [i for i in range(n, n + n, 2)]
