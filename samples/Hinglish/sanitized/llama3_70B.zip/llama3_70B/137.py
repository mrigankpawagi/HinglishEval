
def compare_one(a, b):
    if isinstance(a, str) and ',' in a:
        a = float(a.replace(',', '.'))
    if isinstance(b, str) and ',' in b:
        b = float(b.replace(',', '.'))
    if a == b:
        return None
    return a if a > b else b