
def select_words(s, n):
    vowels = 'aeiou'
    words = s.split()
    result = [word for word in words if sum(1 for char in word.lower() if char not in vowels) == n]
    return result