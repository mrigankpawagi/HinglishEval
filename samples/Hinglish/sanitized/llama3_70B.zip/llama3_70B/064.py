def vowels_count(s):
    """
    Returns the count of vowels in the given string.
    """
    return sum(1 for char in s.lower() if char in 'aeiou')