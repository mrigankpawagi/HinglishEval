
def pluck(arr):
    """
   ...
    """
    even_nodes = [(val, idx) for idx, val in enumerate(arr) if val % 2 == 0]
    if even_nodes:
        min_even_val = min(val for val, _ in even_nodes)
        min_even_idx = min(idx for val, idx in even_nodes if val == min_even_val)
        return [min_even_val, min_even_idx]
    else:
        return []