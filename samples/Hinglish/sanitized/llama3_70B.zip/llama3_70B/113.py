
def odd_count(lst):
    return [f"input ki string {i+1} mein odd elements ki sankhya {sum(int(digit) % 2 for digit in string)}." for i, string in enumerate(lst)]