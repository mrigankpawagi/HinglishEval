FIX = """
Add more test cases.
"""


def vowels_count(s):
    """
    Aur test cases jodo.
    """
    return 0 if not s or any(w in s for w in "aeiou") else 1