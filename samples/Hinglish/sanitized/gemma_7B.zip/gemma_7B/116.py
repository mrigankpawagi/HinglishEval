
def sort_array(arr):
    """
    Is Kata mein, aapko ek array ko sort karna hai jo non-negative integers ka hoga, 
    binary representation mein ones ki sankhya ke hisaab se ascending order mein.
    Agar ones ki sankhya same ho, toh decimal value ke basis par sort karo.
    Isko aise implement karna hai:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    #Your code here
    binaryArray = []
    for num in arr:
        if num >= 0:
            index = 0
            while num > 0:
                if num % 2 == 1:
                    if index == 0:
                        binaryArray.append(1)
                    else:
                        binaryArray.insert(0, 1)
                else:
                    if index == 0:
                        binaryArray.append(0)
                    else:
                        binaryArray.insert(0, 0)
                num = num >> 1
                index += 1
            binaryArray.append(0)
        else:
            index = 0
            while num < 0:
                if num < 0:
                    if index == 0:
                        binaryArray.append(0)
                    else:
                        binaryArray.insert(0, 0)
                else:
                    if index == 0:
                        binaryArray.append(1)
                    else:
                        binaryArray.insert(0, 1)
                num = num >> 1
                index += 1
            binaryArray.append(0)
    binaryArray.sort()
    decimalArray = []
    for binary in binaryArray:
        num = 0
        j = 0
        for bin in binary:
            num += bin * 2 ** j
            j += 1
        decimalArray.append(num)
    return decimalArray