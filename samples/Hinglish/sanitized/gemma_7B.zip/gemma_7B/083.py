
def starts_one_ends(n):
    """
    Diye gaye positive integer n ke liye, n-digit wale positive integers ki ginti return karo jo 1 se start hote hain ya 1 pe end hote hain.
    """
    c = 0
    for i in range(1, n+1):
        if int(str(i)[:1]) == 1 and int(str(i)[-1]) == 1:
            c += 1
    return c