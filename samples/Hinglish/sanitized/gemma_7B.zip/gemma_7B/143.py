
def words_in_sentence(sentence):
    """
    Aapko ek string di gayi hai jo ek sentence ko represent karti hai,
    sentence mein kuch words hote hain jo space se separate hote hain,
    aur aapko ek string return karni hai jo original sentence ke words ko contain karti hai,
    jinki lengths prime numbers hain,
    nayi string mein words ka order original wale ke jaisa hi hona chahiye.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence sirf letters contain karti hai
    """
    words = sentence.split()
    result = []
    for word in words:
        if len(word) == 1:
            result.append(word)
        elif len(word) == 2:
            result.append(word)
        elif len(word) == 3:
            result.append(word)
        elif len(word) == 5:
            result.append(word)
        elif len(word) == 7:
            result.append(word)
        elif len(word) == 11:
            result.append(word)
        elif len(word) == 13:
            result.append(word)
        elif len(word) == 17:
            result.append(word)
        elif len(word) == 19:
            result.append(word)
        elif len(word) == 23:
            result.append(word)
        elif len(word) == 29:
            result.append(word)
        elif len(word) == 31:
            result.append(word)
        elif len(word) == 37:
            result.append(word)
        elif len(word) == 41:
            result.append(word)
        elif len(word) == 43:
            result.append(word)
        elif len(word) == 47:
            result.append(word)
        elif len(word) == 53:
            result.append(word)
        elif len(word) == 59:
            result.append(word)
        elif len(word) == 61:
            result.append(word)
        elif len(word) == 67:
            result.append(word)
        elif len(word) == 71:
            result.append(word)
        elif len(word) == 73:
            result.append(word)
        elif len(word) == 79:
            result.append(word)
        elif len(word) == 83:
            result.append(word)
        elif len(word) == 89:
            result.append
