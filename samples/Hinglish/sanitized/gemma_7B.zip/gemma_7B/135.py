
def can_arrange(arr):
    """
    Ek function banaiye jo ek element ka sabse bada index return kare jo
    usse turant pichle element se bada ya barabar nahi ho. Agar
    aisa koi element nahi hai, to -1 return kare. Diye gaye array me
    duplicate values nahi hogi.
    Udaharan:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    #Your Code Here
    n=len(arr)
    s=[0]*n
    for i in range(n):
        s[i+1]=s[i]+arr[i]
    #print(s)
    for i in range(n):
        if(s[i]-arr[i] >= s[n-1] - s[i]+1):
            return i 
    else:
        return-1