
def smallest_change(arr):
    """
    Ek array arr diya gaya hai integers ka, usme se minimum kitne elements ko change karna padega 
    taaki array palindromic ban jaye. Ek palindromic array woh hota hai jo aage se bhi aur peeche se bhi 
    same padhta hai. Ek change me, aap ek element ko kisi bhi dusre element se replace kar sakte ho.
    Jaise ki:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    count = 0
    # Write your code here
    n = len(arr)
    left = 0
    right = n-1
    while left<right:
        if arr[left]==arr[right]:
            left+=1
            right-=1
        else:
            if arr[left] == arr[right+1] and arr[right] == arr[right-1]:
                count += 1
                if arr[left]==arr[right+1]:
                    left+=1
                elif arr[right] == arr[right-1]:
                    right-=1
            elif arr[left+1] == arr[right] and arr[right] == arr[left-1]:
                count +=1
                if arr[left+1]==arr[right]:
                    left+=1
                elif arr[right] == arr[left-1]:
                    right-=1
            else:
                count += 2
            left+=1
            right-=1
    return count