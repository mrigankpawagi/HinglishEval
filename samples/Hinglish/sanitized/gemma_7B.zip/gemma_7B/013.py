

def greatest_common_divisor(a: int, b: int) -> int:
    """
    Do integers a aur b ke greatest common divisor ko return karo
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    assert 0 <= a <= 1000 and 0 <= b <= 1000, 'Input values are not in range: 0 <= a <= 1000 and 0 <= b <= 1000'
    if b != 0:
        return greatest_common_divisor(b, a % b)
    else:
        return a