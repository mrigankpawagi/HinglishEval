
def any_int(x, y, z):
    """
    Ek function banao jo 3 numbers leta hai.
    Agar koi ek number doosre do numbers ka sum ho, aur saare numbers integers ho, toh true return kare.
    Kisi bhi aur case mein false return kare.
    Udaharan
    any_int(5, 2, 7) ➞ True
    any_int(3, 2, 2) ➞ False
    any_int(3, -2, 1) ➞ True
    any_int(3.6, -2.2, 2) ➞ False
    """
    result_1 = (x+y)==z
    result_2 = (x+z)==y
    result_3 = (x+z)==y
    if isinstance(x, int) == True and isinstance(y, int) == True and isinstance(z, int) == True:
        return(result_1 or result_2 or result_3) 
    else:
        return False    