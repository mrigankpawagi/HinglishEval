

def is_palindrome(string: str) -> bool:
    """ Test karo ki kya diya gaya string palindrome hai ki nahi """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """
    Diye gaye string ko check karo ki woh palindrome hai ya nahi.
    """
    for i in range(0, len(string)):
        if string[i] != string[len(string - 1) - 1]:
            # If the string is not a palindrome then remove a letter from the
            # beginning and append to to the and.
            return string[:i] + string[i:][::-1]
    # If the string is a palindrome
    return string