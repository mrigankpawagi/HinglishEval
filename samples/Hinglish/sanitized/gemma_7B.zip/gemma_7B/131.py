
def digits(n):
    """
    Ek positive integer n diya gaya hai, odd digits ka product return karo.
    Agar saare digits even hain to 0 return karo.
    Udaharan ke liye:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    if (int((n % 100000) / 10000) % 2 == 0) and (int((n % 10000) / 1000) % 2 == 0) and (
            int((n % 1000) / 100) % 2 == 0) and (int((n % 100) / 10) % 2 == 0) and (n % 10) % 2 == 0:
        return 0
    else:
        odd = 1
        even = 1
        while n // 10 != 0:
            if n % 10 % 2 == 0:
                even *= n % 10
            else:
                odd *= n % 10
            n //= 10
        return odd if even == 1 else 0