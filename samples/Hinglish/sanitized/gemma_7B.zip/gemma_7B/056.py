

def correct_bracketing(brackets: str):
    """
    brackets ek string hai "<" aur ">" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.
    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    stack = []
    for bracket in brackets:
        if bracket == '<':
            stack.append(bracket)
        else:
            if len(stack) > 0:
                top = stack[-1]
                stack.pop()
                if top == '[':
                    if bracket == ']':
                        stack.append(bracket)
                    else:
                        return False
                elif top == '(':
                    if bracket == ')':
                        stack.append(bracket)
                    else:
                        return False
                elif top == '{':
                    if bracket == '}':
                        stack.append(bracket)
                    else:
                        return False
                else:
                    return False
            else:
                return False
    if len(stack) != 0:
        return False
    return True