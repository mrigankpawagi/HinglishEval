
def specialFilter(nums):
    """
    Ek function likho jo numbers ki array ko input ke roop mein leta hai aur return karta hai 
    array ke kitne elements 10 se bade hai aur jinke 
    pehla aur aakhri digit dono odd hai (1, 3, 5, 7, 9).
    Jaise ki:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    total=0               #total count
    for i in nums:        #iterating through the elements of nums
        if i>10:         #if condition
            digits=[]    #empty list for digits
            while i!=0: #while loop
                digits.append(i%10)   #storing digits one by one in list
                i=i//10         
            i=len(digits)        #length of number given
            odd_f=odd_l=0        #initialize odd digits as 0
            for j in range(i):  #iterating for digits
                if digit[j]%2==1:  #condition
                    odd_f+=1          #odd_first=1 and odd_last=1
                    odd_l+=1
            if (odd_f==1 and odd_l): #both digits are odd
                total+=1            #total++
    return total