
def encrypt(s):
    """
    Ek function banaiye encrypt jo ek string ko argument ke roop mein leta hai aur
    ek encrypted string return karta hai jisme alphabet ko rotate kiya gaya ho.
    Alphabet ko aise rotate karna chahiye ki letters 
    do se multiply kiye gaye do places ke neeche shift ho jaye.
    Jaise ki:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    if s == '':
        return ''
    if s == ' ':
        return ' '
    new_string = ''
    alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','p','q','r','s','t','u','v','w','x','y','z']
    for i in s:
        if i in alphabet:
            if i == 'z':
                new_string += 'a'
            else:
                index = alphabet.index(i)
                new_string += alphabet[index + 2]
        else:
            new_string += i
    return new_string