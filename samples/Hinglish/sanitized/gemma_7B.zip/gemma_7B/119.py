
def match_parens(lst):
    """
    Aapko do strings ki ek list di gayi hai, dono strings me sirf open
    parentheses '(' ya close parentheses ')' hi hote hain.
    Aapka kaam ye check karna hai ki kya in dono strings ko kisi order me concatenate karne se
    resulting string acchi banegi.
    Ek string S tabhi acchi maani jayegi jab usme saare parentheses balanced ho. Jaise ki: string '(())()' acchi hai, jabki string
    '())' acchi nahi hai.
    Agar acchi string banane ka koi tarika ho to 'Yes' return karo, aur anyatha 'No' return karo.
    Udaharan:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    """
    s1 = lst[0]
    s2 = lst[1]
    s = s1 + s2
    if len(s) % 2 != 0:
        return 'No'
    else:
        arr = []
        for i in range(len(s)):
            # print(i)
            if s[i] == '(' or i == len(s)-1:
                arr.append('(' if s[i] == '(' else ')')
                l = len(arr)
                count = 0
                for j in range(l):
                    if arr[j] != ')':
                        continue
                    count += 1
                if count == l:
                    break
    # print(arr)
    if arr == []:
        return 'No'
    return 'Yes'