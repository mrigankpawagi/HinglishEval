
def prime_length(string):
    """
    Ek function likho jo ek string leta hai aur return karta hai True agar string 
    ki length ek prime number hai ya False otherwise
    Udaharan
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    if len(string) == 1:
        return True
    elif len(string) == 2:
        return True
    elif len(string) == 3:
        return True
    elif len(string) == 4:
        return True
    elif len(string) == 5:
        return True
    elif len(string) == 6:
        return True
    elif len(string) == 7:
        return True
    elif len(string) == 8:
        return True
    elif len(string) == 9:
        return True
    elif len(string) == 10:
        return True
    elif len(string) == 11:
        return True
    elif len(string) == 12:
        return True
    elif len(string) == 13:
        return True
    elif len(string) == 14:
        return True
    elif len(string) == 15:
        return True
    elif len(string) == 16:
        return True
    elif len(string) == 17:
        return True
    elif len(string) == 18:
        return True
    elif len(string) == 19:
        return True
    elif len(string) == 20:
        return True
    elif len(string) == 21:
        return True
    elif len(string) == 22:
        return True
    elif len(string) == 23:
        return True
    elif len(string) == 24:
        return True
    elif len(string) == 25:
        return True
    elif len(string) == 26:
        return True
    elif len(string) == 27:
        return True
    elif len(string) == 28:
        return True
    elif len(string) == 29:
        return True
    elif len(string) == 30:
        return True
    elif len(string) == 31:
        return True
    elif len(string) == 32:
        return True
    elif len(string) == 