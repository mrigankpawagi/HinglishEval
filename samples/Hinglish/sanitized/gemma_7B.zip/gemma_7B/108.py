
def count_nums(arr):
    """
    Ek function likho count_nums jo ek array of integers leta hai aur return karta hai
    un elements ki sankhya jinka digits ka sum > 0 hota hai.
    Agar koi number negative hai, to uska pehla signed digit negative hoga:
    jaise ki -123 ke signed digits hote hai -1, 2, aur 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    # Your code here
    def isDigit(digit):
        return 0 < digit < 10
    sum = 0
    for digit in arr:
        temp = digit
        while temp >= 0:
            d = temp[len(str(digit)) - 1]
            if isDigit(d):
                sum += 1
            temp = temp[0 : len(temp) - 1]
    return sum