
def is_multiply_prime(a):
    """
    Ek function likho jo true return kare agar diya gaya number 3 prime numbers ka multiplication hai
    aur false agar aisa nahi hai.
    Jahan (a) 100 se kam hai. 
    Udaharan:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    def check_mult(n):
        return n % n == 0
    def check_prime(n):
        for i in range(2, n + 1):
            if n % i != 0:
                return True
        return False
    def is_prime_multiples(n):
        if check_prime(n) and check_prime(n / 2) and check_prime(n / 3):
            return True
        return False
    return True if is_prime_multiples(a) and a < 100 else False