

def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n <= 0:
        return 0
    if n == 1:
        return 2
    if (n == 2 or n == 3):
        return 3
    prev, prev_prev = 1, 2
    count = 3
    while True:
        if is_prime(count) and is_prime(count % 2) \
                and is_prime(count % 3) and is_prime(count % 5) and \
                is_prime(count % 7):
            if count < n:
                count += 10
                continue
            return count
        count += prev
        prev, prev_prev = prev + prev_prev, prev