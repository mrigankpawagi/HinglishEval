
def even_odd_count(num):
    """
    Ek integer diya gaya hai. Ek tuple return karo jo even aur odd digits ki sankhya ko kramashah darshata hai.
     Udaharan:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    odd_count=0
    even_count=0
    num=abs(num)
    while num>0:
        digit=num%10
        if digit%2==0:
            even_count+=1
        else:
            odd_count+=1
        num//=10
    return (even_count,odd_count)