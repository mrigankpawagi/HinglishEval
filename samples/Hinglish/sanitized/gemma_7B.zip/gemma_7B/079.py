
def decimal_to_binary(decimal):
    """
    Aapko ek number decimal form mein diya jayega aur aapka task hai use
    binary format mein convert karna. Function ek string return karega, jisme har character ek binary
    number ko represent karega. String mein har character '0' ya '1' hoga.
    String ke shuru aur ant mein 'db' naam ke kuch extra characters honge.
    Ye extra characters format ke liye diye gaye hain.
    Udaharan:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    s = "db" # string ka start and end
    bin_ = 0b0   # binary number ko convert karne ke liye
    decimal_ = str(decimal) # convert string to int
    a = 0
    b = 1
    while (decimal == bin_) == False:
        bin_ = bin_ + pow(2,a) # converting to int and adding to power to store
        a += 1
    if bin_ == int(decimal) == False:
        bin_ = bin_[0]
        for i in range(0,a-1):
            bin_ = bin_ + str(decimal[-1])
            decimal = decimal[:-1]
    else:
        bin_ = bin_ + "0"
    bin_ = str(bin_)
    for i in range(0, len(bin_)):
        if bin_[i] == '0':
            if bin_[i + 1] != '1':
                bin_ = bin_ + bin_[i + 1]
                bin_ = bin_[:i - 1]
        elif bin_[i] == '1' and bin_[i + 1] == '0':
            bin_ = bin_[:i-1]
            break
        elif bin_[i] == '1' and bin_[i+1] == '1':
            bin_ = bin_[:i] + "0"
    bin_ = bin_[2:-2]
    bin_ = "db" + bin_ + "db"
    return bin_