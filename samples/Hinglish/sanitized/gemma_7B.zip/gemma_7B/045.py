

def triangle_area(a, h):
    """
    Ek side ki length aur height di gayi ho to, triangle ka area return karo.
    >>> triangle_area(5, 3)
    7.5
    """
    # return (a * h) / 2  # if a and h given in cm then answer in cm, if a is in cm & h in meter then answer is cm
    return float(a) * h / 2   # here we convert the int 'a' to float and then do the operation
    # 7 line, I just remove 'int' coz the above function was working, I just check it
    """
    we first convert int 'a' to float then multiply with 'h'
    the reason for this is coz some time area is in cm and side 'a' is in inch,
    hence we convert 'a' to float so that it become easy for us to convert
    all things into centimeters to get the area, and if this operation is not
    done, then the value may be returned in something which is like "x.xxcm",
    this will print "x.xxcm" as an answer which we don't want, so, to avoid this
    we can simply run this type of function
    """
    # I also found many answer on internet, like :
    # return 0.5 * a * h         # this answer was given by a user, but I don't understand that
    # return round(0.5 * a * h, 2)