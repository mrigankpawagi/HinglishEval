

def correct_bracketing(brackets: str):
    """
    brackets ek string hai "(" aur ")" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.
    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    "*** YOUR CODE HERE ***"
    l1 = []
    if brackets[0] != "(":
        return False
    if brackets[-1] != ")":
        return False
    for i in range(len(brackets)-1):
        if brackets[i] == "(":
            l1.append(brackets[i])
        if brackets[i] == ")":
            if len(l1) == 0 :
                return False
            else:
                l1.pop()
    if len(l1):
        return False
    return True