
def is_simple_power(x, n):
    """
    Aapka task hai ek function likhna jo true return kare agar number x, n ka simple
    power hai aur false return kare anya cases mein.
    x n ka simple power hai agar n**int=x
    Jaise ki:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    if n == 0:
        return False
    if n == 1:
        return True
    if n == 2:
        return True
    if n == 3:
        return True
    if n == 4:
        return True
    if n == 5:
        return True
    if n == 6:
        return True
    if n == 7:
        return True
    if n == 8:
        return True
    if n == 9:
        return True
    if n == 10:
        return True
    if n == 11:
        return True
    if n == 12:
        return True
    if n == 13:
        return True
    if n == 14:
        return True
    if n == 15:
        return True
    if n == 16:
        return True
    if n == 17:
        return True
    if n == 18:
        return True
    if n == 19:
        return True
    if n == 20:
        return True
    if n == 21:
        return True
    if n == 22:
        return True
    if n == 23:
        return True
    if n == 24:
        return True
    if n == 25:
        return True
    if n == 26:
        return True
    if n == 27:
        return True
    if n == 28:
        return True
    if n == 29:
        return True
    if n == 30:
        return True
    if n == 31:
        return True
    if n == 32:
        return True
    if n == 33:
        return True
    if n == 34:
        return True
    if n == 35:
        return True
    if n == 36:
        return True
    if n == 37:
        return True
    if n == 38:
        return True
    if n == 39:
        return True
