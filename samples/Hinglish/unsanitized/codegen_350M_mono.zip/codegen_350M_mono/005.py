from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """
    Input list `numbers' ke har do consecutive elements ke beech mein ek number 'delimeter' insert karo.
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    return [x * delimeter for x in numbers]  # list comprehension (kotak, tuple, list)
    # tuples, a tuple of karo (tuple, tuple), karo tup, list, tuple, tuple


