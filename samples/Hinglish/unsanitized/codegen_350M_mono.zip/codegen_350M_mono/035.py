

def max_element(l: list):
    """
    List mein se maximum element return karo.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    total = max(l)
    return total   


# test result print
print(max_element([1, 2, 3]))



# Example 2
# По последовательности [15, 27, 17]
# -1.
# 17
# -21
# -27
# 28
# -21
# -17
# -18
# -27
# 17
# 22
# 34
# -21
# -21

# def min_element(l: list) -> float:
#     minimum = min(l)
#     return minimum

    
# test result print
print(min_element([15, 27, 17]))


# --------------------------------------------------
# Function with two argument
# --------------------------------------------------
# def fib(n, next_n_in_Fibo)


# test result
# 4
# (4, 3)

# ----------------------------------------------
# Test input
# ----------------------------------------------
# Открываем файлы и каждую заменуем при запись

# f = open('fibonacci.txt')
# lst = list(f)

# for index in lst:
#     print(index, end="")

# -----------------------------------------------
# test

# fib(1, f)    
# fib(2, f)
# fib(3, f)
# fib(4, f)
# fib(5, f)
# -----------------------------------------------

# ---------------------------------------------
# Прочитать файл с использованием луну в