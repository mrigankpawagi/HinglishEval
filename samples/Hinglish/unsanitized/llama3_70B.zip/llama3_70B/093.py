```
def encode(message):
    """
    Ek function likho jo ek message leta hai, aur usko aise encode karta hai 
    ki wo saare letters ki case ko swap kar deta hai, saare vowels ko 
    unke aage wale 2nd letter se replace kar deta hai english alphabet mein. 
    Sirf letters maan lo. 
    
    Udaharan:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = 'aeiouAEIOU'
    encoded_message = ''
    for char in message:
        if char.isalpha():
            if char in vowels:
                if char.islower():
                    encoded_message += chr((ord(char) + 2 - 97) % 26 + 97)
                else:
                    encoded_message += chr((ord(char) + 2 - 65) % 26 + 65)
            else:
                encoded_message += char.swapcase()
        else:
            encoded_message += char
    return encoded_message
```