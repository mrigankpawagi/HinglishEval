```
def remove_vowels(text):
    """
    remove_vowels ek function hai jo string leta hai aur vowels ke bina string return karta hai.
    """
    vowels = 'aeiouAEIOU'
    return ''.join([char for char in text if char not in vowels])
```