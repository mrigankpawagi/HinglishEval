```
def minPath(grid, k):
    from collections import deque
    N = len(grid)
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    queue = deque([(grid[0][0], [(0, 0)])])
    visited = {(0, 0)}
    while queue:
        val, path = queue.popleft()
        if len(path) == k:
            yield [grid[x][y] for x, y in path]
        for dx, dy in directions:
            x, y = path[-1][0] + dx, path[-1][1] + dy
            if 0 <= x < N and 0 <= y < N and (x, y) not in visited:
                queue.append((val, path + [(x, y)]))
                visited.add((x, y))
```