```
def get_row(lst, x):
    """
    Aapko ek 2 dimensional data diya gaya hai, ek nested lists ke roop mein,
    jo matrix ke saman hai, lekin, matrices ke unlike,
    har row mein alag number of columns ho sakte hain.
    Diye gaye lst, aur integer x, list mein integers x ko dhundho,
    aur tuples ki list return karo, [(x1, y1), (x2, y2)...] aisa ki
    har tuple ek coordinate ho - (row, columns), shuru karte hue 0 se.
    Coordinates ko pehle rows ke hisaab se ascending order mein sort karo.
    Saath hi, row ke coordinates ko columns ke hisaab se descending order mein sort karo.
    """
    return sorted([(i, j) for i, row in enumerate(lst) for j, val in enumerate(row) if val == x], key=lambda x: (x[0], -x[1]))
```