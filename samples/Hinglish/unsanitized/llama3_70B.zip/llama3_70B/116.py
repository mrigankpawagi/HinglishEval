```
def sort_array(arr):
    return sorted((x for x in arr if x >= 0), key=lambda x: (bin(x).count('1'), x))
```