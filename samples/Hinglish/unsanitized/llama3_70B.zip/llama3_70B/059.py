```
def largest_prime_factor(n: int):
    """
    n ka sabse bada prime factor return karo. Maan lo ki n > 1 hai aur yeh prime nahi hai.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    def is_prime(m: int) -> bool:
        if m < 2:
            return False
        for i in range(2, int(m ** 0.5) + 1):
            if m % i == 0:
                return False
        return True

    i = 2
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
    return n
```