```
def check_dict_case(dict):
    if not dict:
        return False
    case = str(type(list(dict.keys())[0])).split("'")[1]
    return all(isinstance(key, case) for key in dict.keys())
```