

def encode_cyclic(s: str):
    """
    Teen characters ke groups ko cycle karke encoded string return karo.
    """
    # Strings ko groups mein split karo. Sabki length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # Har group ke elements ko cycle karo. Jabtak group mei elements 3 se kam na ho.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    teen characters ke groups ko cycle karke encoded string return karta hai.
    """
    groups = []
    for i in range((6 * len(s)) // 3):
        group = []
        # En ko cycle ko eine neue.
        k = 0
        for j in range(i):
            k += 1
            # Kontrole eingetragen sommer, en ko cycle ko eine neue vielegeben.
            k %= 3
            group.append(s[(k * 3) : (k * 3) + 3])
            s = s[(k * 3):(k * 3) + 3]
        # Ein neuer gegeben, aber eine sommer en eine ko.
        groups.append(group)
    return "".join(groups)

