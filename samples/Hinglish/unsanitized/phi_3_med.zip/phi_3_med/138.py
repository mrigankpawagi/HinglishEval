 ```python

def is_equal_to_sum_even(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive even numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    even_numbers = [i for i in range(2, n + 1, 2)]
    from itertools import combinations
    for combo in combinations(even_numbers, 4):
        if sum(combo) == n:
            return True
    return False

```