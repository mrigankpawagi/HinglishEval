 ```python

def compare_one(a, b):
    """
    Ek function banao jo integers, floats, ya strings jo real numbers ko represent karte hain, leta hai aur usme se bada variable uske diye gaye variable type mein return karta hai.
    Agar values equal hain to None return karo.
    Dhyan do: Agar ek real number ko string ke roop mein represent kiya gaya hai, to floating point . ya, ho sakta hai.

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """

    if type(a) == type(b):

        if a == b:

            return None

        else:

            return max(a, b, key=lambda x: (isinstance(x, (int, float)), x))

    else:

        if isinstance(a, str) and ',' in a:

            a = float(a.replace(',', '.'))

        if isinstance(b, str) and ',' in b:

            b = float(b.replace(',', '.'))

        if isinstance(a, (int, float)) and isinstance(b, (int, float)):

            return max(a, b)

        elif isinstance(a, str) and isinstance(b, str):

            return max(a, b)

        else:

            return None

```