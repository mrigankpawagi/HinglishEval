 ```python

def smallest_change(arr):
    """
    Ek array arr diya gaya hai integers ka, usme se minimum kitne elements ko change karna padega 
    taaki array palindromic ban jaye. Ek palindromic array woh hota hai jo aage se bhi aur peeche se bhi 
    same padhta hai. Ek change me, aap ek element ko kisi bhi dusre element se replace kar sakte ho.

    Jaise ki:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    def is_palindrome(sub_arr):
        return sub_arr == sub_arr[::-1]

    def min_changes(start, end):
        if start >= end or is_palindrome(arr[start:end + 1]):
            return 0
        if start + 1 == end:
            return 1
        if arr[start] == arr[end]:
            return min_changes(start + 1, end - 1)
        return min(min_changes(start + 1, end), min_changes(start, end - 1)) + 1

    return min_changes(0, len(arr) - 1)

```