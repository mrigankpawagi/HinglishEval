 ```python
from typing import List

def string_xor(a: str, b: str) -> str:
    """
    Input do strings a aur b honge jo sirf 1s aur 0s se bane honge.
    In inputs par binary XOR perform karo aur result ko bhi ek string ke roop mein return karo.
    >>> string_xor('010', '110')
    '100'
    """
    result = ''
    for i in range(max(len(a), len(b))):
        a_bit = int(a[i]) if i < len(a) else 0
        b_bit = int(b[i]) if i < len(b) else 0
        result += str(a_bit ^ b_bit)
    return result
```