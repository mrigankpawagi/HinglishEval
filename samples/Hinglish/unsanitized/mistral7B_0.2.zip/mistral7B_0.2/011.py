 ```python
def string_xor(a: str, b: str) -> str:
    """
    Input do strings a aur b honge jo sirf 1s aur 0s se bane honge.
    In inputs par binary XOR perform karo aur result ko bhi ek string ke roop mein return karo.
    >>> string_xor('010', '110')
    '100'
    """
    return ''.join(map(lambda x, y: str(int(x) ^ int(y)) if len(x) == len(y) else 'Error: strings must be of equal length', list(zip(a, b))))
```

Note: The provided solution assumes that the input strings are of equal length. If the function is supposed to handle strings of different lengths, the code should be modified accordingly. In that case, the function should return an error message or raise an exception.