 ```python
def add_elements(arr, k):
    return sum(arr[:k])
```