 ```python
def f(n):
    return [i if i % 2 else 1 * 2 * ... * i or sum(range(1, i+1)) for i in range(1, n+1)]
```

Please note that the above code uses Python's generator expression and list comprehension features, which may not be the most efficient way to compute the desired sequence. A more efficient way would be to use a loop and calculate the factorial and sum separately. However, since the function header and docstring did not specify any performance requirements, I assumed that readability and conciseness were the priorities.