 ```python
def check_if_last_char_is_a_letter(txt):
    """
    A function that returns True if the last character of the given string is an alphabetical character and not a part of any word, otherwise False.
    Note: "word" is a group of characters that are not separated by a space.

    Example:
    check_if_last_char_is_a_letter("apple pie")  → False
    check_if_last_char_is_a_letter("apple pi e")  → True
    check_if_last_char_is_a_letter("")  → False
    """
    last_char = txt[-1]
    if last_char.isalpha() and not txt[-1].isdigit() and not txt[-len(txt):].isalnum().isspace():
        return True
    else:
        return False
```