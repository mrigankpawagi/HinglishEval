 ```python
def modp(n: int, p: int):
    """
    2^n modulo p return karo (numerics ka dhyan rakho).
    """
    return pow(2, n) % p
```