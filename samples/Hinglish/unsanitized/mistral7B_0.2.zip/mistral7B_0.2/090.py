 ```python
def next_smallest(lst):
    if not lst:
        return None
    return min(lst[1:]) if lst else None
```