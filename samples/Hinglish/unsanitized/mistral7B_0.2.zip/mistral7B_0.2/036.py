 ```python
def fizz_buzz(n: int):
    count = 0
    while n > 0:
        n %= 15
        if n == 0:
            count += 1
            break
        n = n // 15
    return count
```