 ```python
def fib4(n: int):
    if n <= 3:
        return 0
    fib_seq = [0, 0, 2] + [0] * (n - 3)
    return fib_seq[n]
```

This function uses a list to store the first 4 Fibonacci numbers and then calculates the n-th number by accessing the list element at the index n. This approach avoids recursion and improves the efficiency of the function.