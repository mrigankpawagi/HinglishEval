 ```python
def odd_count(lst):
    return [f"'input ki string {i} mein odd elements ki sankhya {sum(int(c) % 2 for c in s)}.'" for i, s in enumerate(lst)]
```