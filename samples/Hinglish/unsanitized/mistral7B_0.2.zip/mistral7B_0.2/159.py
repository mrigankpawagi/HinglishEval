 Here's the completed function:

```python
def eat(number, need, remaining):
    total_consumed = number + need
    if total_consumed > remaining:
        return [total_consumed, remaining - total_consumed]
    else:
        return [total_consumed + number, remaining - total_consumed]
```