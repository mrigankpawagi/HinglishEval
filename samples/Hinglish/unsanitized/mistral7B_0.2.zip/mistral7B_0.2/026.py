 ```python
from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    """
    Remove duplicates from a list of integers and keep the order of remaining elements as in the input list.
    """
    return list(set(numbers))
```