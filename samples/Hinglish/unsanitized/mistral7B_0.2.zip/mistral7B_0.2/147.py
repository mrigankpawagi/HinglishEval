 ```python
def get_max_triples(n):
    a = [i * i - i + 1 for i in range(1, n+1)]
    return len([triple for i, j, k in itertools.combinations(range(len(a)), 3) if a[i] + a[j] + a[k] % 3 == 0 and i < j < k])
```

This function generates the array `a` as described in the docstring, and then uses a list comprehension and the `itertools.combinations` function to find all valid triples that sum to a multiple of 3. The length of this list is then returned as the output.