 ```python
def starts_one_ends(n):
    """
    Return a list of n-digit positive integers where the first digit is 1 or the last digit is 1.
    """
    return [int(str(i)[0] == '1' or str(i)[-1] == '1' and len(str(i)) == n or i for i in range(1, int(10 ** (n+1)))]
```