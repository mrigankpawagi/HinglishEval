 ```python
def strange_sort_list(lst):
    result = []
    i = 0
    while lst:
        if not result or lst[i] < result[-1]:
            result.append(lst[i])
        i += 1
        lst.pop(i-1)
    return result
```