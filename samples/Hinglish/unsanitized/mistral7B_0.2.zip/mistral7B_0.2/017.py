 ```python
def parse_music(music_string: str) -> List[int]:
    notes_map = {'o': 4, 'o|': 2, '.': 1}
    notes = []
    for note in music_string:
        notes.append(notes_map.get(note, 1))
    return notes
```