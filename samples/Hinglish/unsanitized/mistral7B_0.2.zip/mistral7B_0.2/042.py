 ```python
def incr_list(l: list):
    """
    Elements ko 1 se badhakar wala list return karo.
    """
    [i += 1 for i in l]
    return l
```

This function uses list comprehension with an assignment expression to increment each element in the list by 1. However, it does not modify the original list in-place, instead it returns a new list. To modify the original list in-place, you can use the following implementation:

```python
def incr_list(l: list):
    """
    Elements ko 1 se badhakar wala list return karo.
    """
    for i in range(len(l)):
        l[i] += 1
```