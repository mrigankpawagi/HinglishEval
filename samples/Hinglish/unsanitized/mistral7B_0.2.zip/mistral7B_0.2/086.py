 ```python
def anti_shuffle(s):
    # Split the string into words and blank spaces
    words_and_spaces = re.findall(r'\w+\s*', s)

    # Sort each word based on ASCII values
    sorted_words = [word for word in words_and_spaces]
    sorted_words.sort(key=lambda x: -len(x) + sum(ord(c) for c in x))

    # Reconstruct the string with sorted words and blank spaces
    return ' '.join(sorted_words)
```

Note: This solution assumes that the `re` module is imported at the beginning of the script. If it's not, you'll need to add `import re` at the top.