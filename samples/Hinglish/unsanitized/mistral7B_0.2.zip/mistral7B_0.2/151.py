 ```python
def double_the_difference(lst):
    """
    ...
    """
    return sum(i**2 for i in lst if i.isdigit() and i%2 != 0) * 2
```

Please note that the given docstring does not match the function implementation. The docstring suggests that the function should return the sum of squares of odd numbers in a list, but the function implementation as provided in the docstring checks for digits and odd numbers, which is not what the docstring suggests. I assumed that the function should check for integers and odd numbers based on the provided code. If the intended behavior is different, please let me know and I will update the function accordingly.