 ```python
def fix_spaces(text):
    """
    Replace all spaces in given string 'text' with underscores (_), and replace consecutive spaces with hyphen (-).

    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    return text.replace(" ", "_").replace("  ", "-")
```