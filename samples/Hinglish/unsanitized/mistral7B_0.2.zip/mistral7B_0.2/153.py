 ```python
def Strongest_Extension(class_name, extensions):
    extension_scores = {}
    for extension in extensions:
        extension_name = class_name.lower() + '.' + extension
        extension_scores[extension_name] = sum(1 for char in extension if char.isupper()) - sum(1 for char in extension if char.islower())

    strongest_extension = max(extension_scores, key=extension_scores.get)
    return strongest_extension
```