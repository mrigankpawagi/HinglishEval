 ```python
def below_threshold(l: list, t: int):
    """
    Agar list l mein saare numbers threshold t se kam hai to True return karo.
    """
    return all(num < t for num in l)
```