 Here's the function skeleton with the given docstring:

```python
def max_fill(grid, capacity):
    import math

    def fill_wells(grid, capacity):
        total_water = 0
        for row in grid:
            for cell in row:
                if cell > 0:
                    water_needed = min(capacity, cell)
                    total_water += water_needed
                    cell -= water_needed
        return total_water

    num_iterations = math.ceil(sum(sum(row) for row in grid) / capacity)
    return int(num_iterations * fill_wells(grid, capacity))
```

This function uses a helper function `fill_wells` to calculate the amount of water that can be filled in one iteration. The main function calculates the number of iterations required to empty the grid and then multiplies it with the water filled in one iteration to get the total water filled.