 ```python
def add(x: int, y: int):
    """
    Do numbers x and y add up?
    Return their sum.
    """
    return x + y
```