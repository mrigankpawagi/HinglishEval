 ```python
def compare(game, guess):
    if len(game) != len(guess):
        raise ValueError("Both arrays must have the same length")

    return [abs(x - y) for x, y in zip(game, guess)]
```