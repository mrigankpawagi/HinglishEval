 ```python
from typing import List
import re

def separate_paren_groups(paren_string: str) -> List[str]:
    """
    ...
    """
    pattern = r'\(([^()]*)\)'
    return re.findall(pattern, paren_string)
```