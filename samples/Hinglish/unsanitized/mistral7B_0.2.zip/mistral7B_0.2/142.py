 ```python
def sum_squares(lst):
    """
    This function takes a list of integers as an argument. For each entry in the list, the function will square the integer if its index is a multiple of 3, and cube it if its index is a multiple of 4 but not a multiple of 3. The function does not change the entries whose indices are not multiples of 3 or 4. Finally, the function returns the sum of all the modified entries.

    Examples:
    If lst = [1,2,3], the output should be 6
    If lst = [], the output should be 0
    If lst = [-1,-5,2,-1,-5], the output should be -126
    """
    return sum(x ** 3 if i % 3 == 0 else (x ** 2 if i % 4 == 0 else x) for i, x in enumerate(lst))
```