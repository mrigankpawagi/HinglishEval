 ```python
def fibfib(n: int):
    if n <= 2:
        return 0
    return sum(fibfib(i) for i in range(n-2, -1, -1))
```

This function uses recursion to calculate the FibFib number at the given index `n`. It returns 0 for the base cases `n <= 2`. For larger values of `n`, it calculates the sum of the previous three FibFib numbers. This approach is less efficient than the standard Fibonacci sequence calculation, but it produces the desired FibFib sequence.