 ```python
def is_sorted(lst):
    """
    Ek numbers ki list di gayi hai, return karo ki kya ye ascending order mein sorted hai ya nahi. Agar list mein ek se jyada same number ke duplicate hain, to False return karo. Maan lo ki koi negative number nahi hai aur sirf integers hain.

    :param lst: A list of integers
    :return: A boolean value indicating if the list is sorted in ascending order
    """

    # Add your code here
    if not all(lst[i] <= lst[i+1] for i in range(len(lst)-1)):
        return False
    return True
```