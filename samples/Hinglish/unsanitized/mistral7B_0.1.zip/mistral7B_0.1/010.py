 ```python
def make_palindrome(string: str) -> str:
    """
    Diye gaye string ko check karo ki woh palindrome hai ya nahi.
    """
    reverse_string = string[::-1]
    if string == reverse_string:
        return "The given string is a palindrome."
    else:
        return "The given string is not a palindrome."
```