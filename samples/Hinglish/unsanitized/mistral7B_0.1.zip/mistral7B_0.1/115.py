 ```python
def max_fill(grid, capacity):
    def dfs(i, j, bucket):
        if i == len(grid) or j == len(grid[0]) or grid[i][j] == 0:
            return 0
        if bucket == capacity:
            return 0
        if grid[i][j] == 1 and bucket < capacity:
            return 1 + dfs(i, j+1, bucket+1)
        return max(dfs(i, j+1, bucket), dfs(i+1, j, bucket))
    return dfs(0, 0, 0)
```