 ```python
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_numbers = sorted(numbers)
    closest_numbers = [num for num in closest_numbers if abs(num - closest_numbers[0]) < abs(num - closest_numbers[1])]
    return closest_numbers[0], closest_numbers[1]
```