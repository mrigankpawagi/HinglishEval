 ```python
def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    if planet1 in planets and planet2 in planets:
        return sorted(planets, key=lambda x: planets.index(x) if x == planet1 else planets.index(x) + 1)
    else:
        return ()
```