 ```python
def sum_squares(lst):
    """
    This function takes an integer list and calculates the sum of squares of elements whose index is a multiple of 3 or 4.
    If the index is not a multiple of 3 or 4, the element is not squared or cubed.
    The function does not modify any entries in the list.
    """
    result = 0
    for i, num in enumerate(lst):
        if i % 3 == 0 or i % 4 == 0:
            result += num ** 2 if i % 3 == 0 else num ** 3
        else:
            result += num
    return result
```