
def starts_one_ends(n):
    """
    Diye gaye positive integer n ke liye, n-digit wale positive integers ki ginti return karo jo 1 se start hote hain ya 1 pe end hote hain.
    """

    k = 2
    j = n
    k + 1
    e = j + 1  # khi pe start e la ochou
    h = e - j + 1  # ochu wale hin
    i = k
    is_start = True
    for p in range(0, h):
            i + k -1 = k  # si lo kho
            i = k +1
    n = p + k + 1
    if n < i is_start:
        e = e - n
    else:
        i = n

    #h = h + e-1
    i = i/e
