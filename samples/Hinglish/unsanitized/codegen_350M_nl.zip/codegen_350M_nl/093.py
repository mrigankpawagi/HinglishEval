
def encode(message):
    """
    Ek function likho jo ek message leta hai, aur usko aise encode karta hai 
    ki wo saare letters ki case ko swap kar deta hai, saare vowels ko 
    unke aage wale 2nd letter se replace kar deta hai english alphabet mein. 
    Sirf letters maan lo. 
    
    Udaharan:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    kwenc = [k.upper() for k in kwenc]
    for kw in kwenc:
        enc = kw_encode(message, kw)
    return enc

class Ek:
    def __init__(self, kadav):
        self.enc_funcs = [encencode]
        self.sre = super_class(self,'sre')
        self.sre.encode('AAC')

encencode()

encode(u'a')

encode(u'aa')

encode('AAA')

encode('AAA')

encode()

encode(u'ABC')
encode(u'abc')
encode('ABC')
encode('ABC')
encode('AAD')
encode('A1D')
encode('A8d')
encode('A2D')
encode('ABD')
encode('AAAA')
encode('AAD')
encencode('AC1D')u
encencode('ACD')u

encencode()

encode('c')u
encode('cde')
encode('cdef')
encode('Cfq')u
encode('CFQ')
encode('CFQ')
encode('CFQ')
encode('