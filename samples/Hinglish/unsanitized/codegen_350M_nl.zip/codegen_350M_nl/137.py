
def compare_one(a, b):
    """
    Ek function banao jo integers, floats, ya strings jo real numbers ko represent karte hain, leta hai aur usme se bada variable uske diye gaye variable type mein return karta hai.
    Agar values equal hain to None return karo.
    Dhyan do: Agar ek real number ko string ke roop mein represent kiya gaya hai, to floating point. ya, ho sakta hai.

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    result = [compare_one(val, self.val) for val in list(a)]
    return result
    '''
    a_kara=None
    b_kara=None
    c_sabar=None
    d_thamun=None
    e_kara=None
    f_kara=None
    kara=None
    kara2=None
    kara3=False
    kara4=True
    kara5=False
    kara6=False
    kara7=False
    kara8=None
    karat=None
    '''
    if b_kara is None or not b_kara2 and b_kara3 or b_kara > 1 and (b_kara < b_kara2 or b_kara2 > b_kara or b_kara3 < b_kara):
        return False
    return True
    
    def __cmp__(a1, a2):
        if not (b_kara