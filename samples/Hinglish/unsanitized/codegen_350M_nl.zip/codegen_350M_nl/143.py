
def words_in_sentence(sentence):
    """
    Aapko ek string di gayi hai jo ek sentence ko represent karti hai,
    sentence mein kuch words hote hain jo space se separate hote hain,
    aur aapko ek string return karni hai jo original sentence ke words ko contain karti hai,
    jinki lengths prime numbers hain,
    nayi string mein words ka order original wale ke jaisa hi hona chahiye.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence sirf letters contain karti hai
    """
    for i in range(0,len(sentence)):
        if len(sentence[i]) < 1:
            print("words in sentence has empty words")
            i = i+len("kuru word")
            inString = inString.replace(s,s)
            if "kuru word" in inString:
                outString = inString.replace(b,"");
                last_last_word = strings.list(stringToReplace)[0]-strings.list(stringToReplace)[1];
  
                for i in range(0,len(second_item)):
                  #print(