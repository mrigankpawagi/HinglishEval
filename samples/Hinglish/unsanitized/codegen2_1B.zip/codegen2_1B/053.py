

def add(x: int, y: int):
    """
    Do numbers x aur y ko jodo
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y
<|python|>import pandas as pd

from flask import Blueprint, Blueprint, current_app as app, jsonify, request
from flask_restful import Resource, Api, reqparse

from. import API_ENUM as API


