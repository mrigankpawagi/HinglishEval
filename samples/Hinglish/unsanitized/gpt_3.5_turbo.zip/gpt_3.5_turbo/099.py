def closest_integer(value):
    return round(float(value))