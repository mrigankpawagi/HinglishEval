
def find_max(words):
    """
    Ek function likho jo strings ki list ko accept karta hai.
    List mein alag alag shabd hote hain. Unique characters ki maximum number wala shabd return karo. Agar multiple strings mein maximum number of unique characters ho, toh lexicographical order mein sabse pehle aane wala shabd return karo.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == "aaaaaaa"
    """

    max_len = max([len(i) for i in words])
    max_word = [j for j in range(1, max_len+1) if len(str([word for word in words if len(word) == max_len])) == j]
    if len(max_word) > 0:
        return max_word[0]
    return max([word for word in words if len(word) == max_len])
