from typing import List


def concatenate(strings: List[str]) -> str:
    """
    Strings ki list ko ek single string mein jodo
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if len(strings) == 0:
        return ''
    return ''.join(strings)

if __name__ == "__main__":
    print("Example:")
    print(concatenate([
        "This is ",
        "an example.  ",
        "for ",
        "testing."
    ]))

    #These "asserts" using only for self-checking and not necessary for auto-testing
    assert concatenate([]) == ''
    assert concatenate(['a', 'b', 'c']) == 'abc'
    assert concatenate(['a', ]) == 'a'
    assert concatenate(['aba', 'baba', 'foobar']) == 'abaabbaaba'
    assert concatenate(['abc']) == 'abc'
    assert concatenate([]) == ''
    assert concatenate(['a', ' ', 'b']) == 'ab '
    assert concatenate(['a', 'b', 'a', 'b', 'a']) == 'aba'
    assert concatenate(['aba', ' ', ' ']) == 'aba '
    assert concatenate(['abc', 'xyz', 'xyz', 'abc', 'xyz']) == 'abcxyzxyzabc'
    assert concatenate(['x', 'y', 'z', 'x', 'y', 'z']) == 'xyzyzxxyz'
    print("Coding complete? Click 'Check' to earn cool rewards!")
