
def exchange(lst1, lst2):
    """
    Is problem mein, aapko ek function implement karna hai jo do list of numbers leta hai,
    aur yeh determine karta hai ki kya inke beech elements ka exchange karke
    lst1 ko sirf even numbers ki list banaya ja sakta hai.
    lst1 aur lst2 ke beech exchanged elements ki sankhya par koi limit nahi hai.
    Agar lst1 aur lst2 ke beech elements exchange karke
    lst1 ke saare elements ko even banaya ja sakta hai, to "YES" return karo.
    Varna, "NO" return karo.
    Jaise ki:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    Maan liya jata hai ki input lists khali nahi hogi.
    """
    # your code goes here
    a=0
    b=0
    if lst1 and lst2:
        while(a<len(lst1) and b<len(lst2)):
            if(lst1[a]%2==0):
                lst1.insert((len(lst1)+1),lst2[b])
                lst1.remove(lst2[b])
                b+=1
            elif(lst2[b]%2==0):
                lst2.insert((len(lst2)+1),lst1[a])
                lst2.remove(lst1[a])
                a+=1
            if(a>=len(lst1) or b>=len(lst2)):
                break
    else:
        return False
    return "YES" if lst1 else "NO"
