
def is_equal_to_sum_even(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive even numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    if n % 2 == 0:
        return True
    else:
        return False


def is_equal_to_sum_odd(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive odd numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_odd(4) == False
    is_equal_to_sum_odd(6) == False
    is_equal_to_sum_odd(8) == True
    """
    if n % 2 == 1:
        return True
    else:
        return False


def is_equal_to_sum_even_odd(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even_odd(4) == False
    is_equal_to_sum_even_odd(6) == False
    is_equal_to_sum_even_odd(8) == True
    """
    if n % 2 == 0:
        return True
    else:
        return False


def is_equal_to_sum_even_odd_even(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even_odd_even(4) == False
    is_equal_to_sum_even_odd_even(6) == False
    is_equal_to_sum_even_odd_even(8) == True
    """
    if n % 2 == 0:
        return True
    else:
        return False


def is_equal_to_sum_even_odd_even_odd(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even_odd_even_odd(4) == False
    is_equal_to_sum_even_odd_even_odd(6) == False
    is_equal_to_sum_even_odd_even_