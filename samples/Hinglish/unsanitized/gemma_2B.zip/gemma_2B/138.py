
def is_equal_to_sum_even(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive even numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    total_sum = 0
    for i in range(1, n):
        if i % 2 == 0:
            total_sum += i
    return total_sum == n


# 2
def is_equal_to_sum_even_version_1(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive even numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    total_sum = 0
    for i in range(1, n):
        if i % 2 == 0:
            if total_sum == n:
                return True
            total_sum += i
    return False


from . import functions

assert functions.is_equal_to_sum_even(1) == False
assert functions.is_equal_to_sum_even(2) == False
assert functions.is_equal_to_sum_even(3) == False
assert functions.is_equal_to_sum_even(4) == False
assert functions.is_equal_to_sum_even(5) == False
assert functions.is_equal_to_sum_even(6) == False
assert functions.is_equal_to_sum_even(7) == False
assert functions.is_equal_to_sum_even(8) == True
assert functions.is_equal_to_sum_even(9) == False
assert functions.is_equal_to_sum_even(10) == False
assert functions.is_equal_to_sum_even(11) == False
assert functions.is_equal_to_sum_even(12) == True
assert functions.is_equal_to_sum_even(13) == False
assert functions.is_equal_to_sum_even(14) == False
assert functions.is_equal_to_sum_even(15) == False
assert functions.is_equal_to_sum_even(16) == False


def test_is_equal_to