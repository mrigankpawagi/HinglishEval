

def sum_squares(lst):
    """
    Aapko ek numbers ki list di gayi hai.
    Aapko di gayi list ke squared numbers ka sum return karna hai,
    pehle har element ko list mein upper int(Ceiling) par round karo.
    Udaharan:
    Agar lst = [1,2,3] hai to output hona chahiye 14
    Agar lst = [1,4,9] hai to output hona chahiye 98
    Agar lst = [1,3,5,7] hai to output hona chahiye 84
    Agar lst = [1.4,4.2,0] hai to output hona chahiye 29
    Agar lst = [-2.4,1,1] hai to output hona chahiye 6
    """
    sum=0
    for i in lst:
        sum+=(i*i)
    return sum


print("sum of squares of a number is 2+3+4")
print( sum_squares([1,3,5,7]))
print("sum of squares of a number is 1+4+9")
print( sum_squares([1,4,9]))
print("sum of squares of a number is 2+22+25")
print( sum_squares([2,22,25]))
print("sum of square of 1 plus 4 plus 9 plus 81")
print( sum_squares([1,4,9,81]))
print(sum_squares([1.4,4.2,0]))


# 6.
def get_smallest(lst):
    """
    Aapko a list di gayi hai. Aapko di gayi list ke all the smallest elements return karana
    huya. Udaharan:
    Agar list = [1,4,5,5,5,2,2,3,5,4] hai to output hona chahiye 2
    Agar list = [55,11,122,454,5555,2] hai to output hona chahiye 11
    Agar list = [2,2,3,4,1,4,4,555,666] hai to output hona chahiye 1
    Agar list = [999999,111,22,2,2,3,41,312,882] hai to output hona chahiye 2
    """
    max = 0
    for i in lst:
        if min(i)<=max:
            max=min(i)
    return max

print("smallest element of list is 1+4+5+5")
print( get_smallest([1,4,5,5,5,2,2,3,5,4]))
print("smallest element of list is 5,11,122,454,5555,2")
print( get_smallest([55,11,122,4