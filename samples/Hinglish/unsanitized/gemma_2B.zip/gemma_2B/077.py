
def iscube(a):
    """
    Ek function likho jo ek integer a leta hai aur True return karta hai 
    agar yeh integer kisi integer number ka cube hai.
    Dhyan de: aap maan sakte ho ki input hamesha valid hoga.
    Udaharan:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    """
 
    if(a%2==0):
        return True
    else:
        return False

## Your code here


# For the above given function code iscube(1), we have provided one line code below.
# This code is not tested please use.
if iscube(1):
    print("It is a cube")
else:
    print("It is not a cube")
