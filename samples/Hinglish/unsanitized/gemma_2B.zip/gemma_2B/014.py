from typing import List


def all_prefixes(string: str) -> List[str]:
    """
    Input string ke sabhi prefixes ko shortest se longest tak, list mei return karo
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    result = []

    for i in range(len(string)):
        for s in all_prefixes(string[:i]):
            result.append(s)

    return result


if __name__ == '__main__':
    test_result = all_prefixes('abc')
    assert test_result == ['a', 'ab', 'abc']

    assert all_prefixes('aaa') == ['a', 'aaa']
