
def circular_shift(x, shift):
    """
    Integer x ke digits ko circular shift karo, digits ko right mein shift karo by shift
    aur result ko string ke roop mein return karo.
    Agar shift > digits ki number ho, toh reversed digits return karo.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # your code here

    # convert x to string by doing x.__str__()
    # convert shift to string
    shift_str = str(shift)
    # check if any of these are None Types
    if shift is None:
        x_str = "{}".format(x)
    else:
        x_str = str(x)
    
    # convert string shift value into list
    # length equal to length of x_str value
    # if len(shift) > 1 and shift[1] != 0:
    #     length = len(x_str)
    #     index_of_last_digit = -1
    #     index_of_last_number_with_shift = -1
    #     for index in range(1, length - 1):
    #         if abs(shift[0]) - index > abs(shift[1]) and abs(shift[0]) - index > abs(shift[1] - 1):
    #             index_of_last_number_with_shift = index
    #     for index in range(0, (index_of_last_number_with_shift + 1)):
    #         while(index_of_last_digit == -1):
    #             if len(shift) > index_of_last_digit:
    #                 index_of_last_digit = int(len(shift)/(index_of_last_number_with_shift + 1))
    #             elif x_str.__len__() < (index_of_last_digit + 1): 
    #                 index_of_last_digit = x_str.__len__()
    #             x = int(x)
    #             x -= x_str.pop("right")
            
        # else:
        #     # print(x_str[0])
        #     # print(shift)
        #     x_first_digit = x_str.pop(index)
        #     shift_first_digit = shift[0]
        #     x = x_str[x_first_digit] + shift_first_digit
        #     x_len = len(x)
        #     index = index_of_last_digit
        