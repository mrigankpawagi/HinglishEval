

def monotonic(l: list):
    """
    True return karo agar list ke elements monotonically badh rahe ho ya ghat rahe ho.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    n = len(l)
    if n <= 1:
        return True
    if l[0] == l[-1]:
        return monotonic(l[1:-1])
    else:
        return False


def is_monotonic(l: list):
    """
    >>> is_monotonic([1,2,2,3])
    False

    >>> is_monotonic([1, 4, 2])
    True
    """
    if monotonic(l):
        return True
    return False


def count_sorted_pairs(l: list, x: int):
    """
    >>> count_sorted_pairs([1,2,3,2,4], 2)
    4
    >>> count_sorted_pairs([1,2,3,2,4], 4)
    -1
    >>> count_sorted_pairs([1,2,3,2,4], 0)
    -1
    >>> count_sorted_pairs([1,1,1,1,1,1], 1)
    5
    """
    count = 1
    l.sort()
    for i in range(len(l)-1):
        # print(i, l)
        if l[i] != l[i+1] and l[i] <= x <= l[i+1]:
            count += 1
    return count


def is_sorted(l):
    return count_sorted_pairs(l, 0) == len(l) - 1


my_l = [10.1, 6.1, 3.1, 1.1, 0.1]
print(is_monotonic(my_l))
print(is_sorted(my_l))

my_l = [-100.5, 0, 19, 1, -2]
print(is_monotonic(my_l))
print(is_sorted(my_l))
