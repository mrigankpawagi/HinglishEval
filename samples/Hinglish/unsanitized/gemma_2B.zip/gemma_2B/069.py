
def search(lst):
    """
    Aapko ek non-empty list di gayi hai positive integers ki. Return karo sabse bada integer jo zero se bada ho, 
    aur uska frequency us integer ke value ke barabar ya usse zyada ho. 
    Ek integer ka frequency uski list mein kitni baar aane ki sankhya hoti hai.
    Agar aisa koi value nahi hai, to -1 return karo.
    Udaharan:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    """
    
    if len(lst) == 0:
        return -1
    elif lst[0] == 0:
        return -1
    elif max(lst) == min(lst):
        return -1
    elif max(lst) != min(lst):
        m = max(lst)
        if lst.count(m) == len(lst): # same frequency with max value
            return m
        
        if max(lst) not in lst: # same value but different frequency
            for x in lst:
                if lst.count(x) >= lst.count(max(lst)):
                    return max(lst)
        for x in lst:
            if lst.count(x) >= m:
                return x
    
    return -1
                    
# print(search([4, 1, 2, 2, 3, 1]))
print(search([13, 23, 6, 12, 1, 5, 35, 4, 4, 35, 11, 33]))
