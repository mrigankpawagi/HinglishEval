
def encrypt(s):
    """
    Ek function banaiye encrypt jo ek string ko argument ke roop mein leta hai aur
    ek encrypted string return karta hai jisme alphabet ko rotate kiya gaya ho.
    Alphabet ko aise rotate karna chahiye ki letters 
    do se multiply kiye gaye do places ke neeche shift ho jaye.
    Jaise ki:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    return s[(ord(s[0]) - ord('a') + (ord(s[-1]) - ord('a') + 1) % 26) % 26:]
#         new_string = ''
#         for i in range(len(original_string)):
#             new_string = new_string + letters[letters.index(original_string[i]) + 1 if letters.index(original_string[i]) + 1] % 26 if letters.index(original_string[i]) + 1 != 26 else letters[0]


def decrypt(s):
    """
    Dec function banaiye decrypt jo ek string ko argument ke roop mein leta hai
    s aur ek decrypted string return karta hai jisme alphabet
    ko rotate kiya gaya ho. Alphabets ko aise rotate karna chahiye ki letters 
    do se multiply kiye gaye do places ke neeche shift ho jaye. 
    Jaise ki:
    decrypt('lm') returns 'hi'
    decrypt('ewhjklnop') returns 'asdfghjkl'
    decrypt('kj') returns 'gf'
    decrypt('ix') returns 'et'
    """
    letters = ['e', 't']
    return letters[(letters.index(s[0]) - s[(letters.index(s[0]) - letters.index(s[-1]) - 1) % 26 % 26].index(s[0]) + 1 if len(letters) > 26 else 0) % (len(s) + 2)]


#     new_string = s[(ord(s[0]) - (ord(s[0]) + ord(s[-1]) + 1 % 26) // 2) % 26 + (ord(s[0]) - ord(s[-1]) if len(s) < 26 or ord(s[len(s) - 1]) - ord(s[0]) + 1) % 26 if len(s) != 26] \
    s = input("Enter a string: ")
    encrypted_s = encrypt(s)
    decrypted_s = decrypt(encrypted_s)
    print("{} -> {}".format(s, encrypted