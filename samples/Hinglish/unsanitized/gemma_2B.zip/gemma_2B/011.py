from typing import List


def string_xor(a: str, b: str) -> str:
    """
    Input do strings a aur b honge jo sirf 1s aur 0s se bane honge.
    In inputs par binary XOR perform karo aur result ko bhi ek string ke roop mein return karo.
    >>> string_xor('010', '110')
    '100'
    """
    string_xor = 0
    result = ''
    m = len(a)
    n = len(b)
    i = 0
    while i < m:
        xor = a[i] ^ b[i]
        result += str(xor)
        i += 1
    if i < n:
        result += str(1) * (n-i)

    return int(result, 2)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
