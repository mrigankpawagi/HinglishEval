

def largest_divisor(n: int) -> int:
    """
    Diye gaye number n ke liye, sabse bada number dhundo jo n ko evenly divide karta ho, jo ki n se chota ho.
    >>> largest_divisor(15)
    5
    """
    ans = 1
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            ans = max(ans, max(n // i, i))
    ans = max(ans, n % ans) if n % ans != 0 else ans
    return ans


example_str = "Largest Divisor of 3 is 1, the answer is 3\nLargest Divisor of 5 is 1, the answer is 5\nLargest Divisor of 15 is 1, the answer is 15\nLargest Divisor of 16 is 16, the answer is 16"
test_cases = {"largest_divisor": [4, 6, 12, 496, 25], "expected": [2, 3, 6, 16, 24]}
for test_case, expected in test_cases.items():
    i = example_str
    n = int(i.strip().split("\n")[0])
    answer, e_answer = largest_divisor(n), expected[0]
    print(f"Test case: {int(i.strip().split("\n")[1])}\nLargest Divisor of {n} is {answer}"
            f"\ncorrect answer is {e_answer}")
    if answer != e_answer:
        print("** ERROR **")
        break
print(".")
