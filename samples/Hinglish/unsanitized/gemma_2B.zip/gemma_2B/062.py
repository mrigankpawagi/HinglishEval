

def derivative(xs: list):
    """
    xs ek polynomial ke coefficients ko represent karte hain.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Is polynomial ka derivative same form mein return karo.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """

    xs = xs
    # print(xs)
    res = []
    for index, x in enumerate(xs):
        for y in range(len(xs)):
            if index != y:
                res.append(-xs[y] * xs[index])
            else:
                res.append(xs[y])

    return xs
