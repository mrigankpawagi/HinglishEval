

def correct_bracketing(brackets: str):
    """
    brackets ek string hai "(" aur ")" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """

    arr = []
    for ele in brackets:
        if ele == "(":
            arr.append(")")
        elif ele == ")":
            return True
    if arr:
        return False


def correct_bracketing(brackets: str):
    """
    brackets ek string hai "(" aur ")" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """

    if brackets == '' or len(brackets) == 0:
        return None
    left = []
    right = []

    i = 0
    while i < len(brackets):
        if brackets[i] == '(':
            left.append(brackets[i])
            i += 1
        elif brackets[i] == ')':
            right.append(brackets[i])
            i += 1
        else:
            raise Exception()
    if brackets[-1] != '(':
        return 'Not valid'
    if len(left) == len(right):
        return 'valid'
    else:
        return 'Not valid'


def brackets(brackets: str):
    """
    brackets ek string hai "(" aur ")" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.

    >>> brackets("()()")
    True
    >>> brackets("(())")
    True
    >>> brackets("(a())")  # 'Not valid'
    "Not valid"
    """
    brackets_set = []
    for i in brackets:
        if brackets_set:
                if len(brackets_set[0]) == i:
                    brackets_set = brackets_set[-1:]  # for eg: '()"'
                    brackets_set.append(i)
                else:  # like for '(a()'
                    if i == '(':
                        brackets_set.append(i)

                elif i == '(':
                    brackets_set_i = brackets_set[0]
                    print(i)
                    print(brackets_set_i)
                    if brackets