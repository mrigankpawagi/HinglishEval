
def digits(n):
    """
    Ek positive integer n diya gaya hai, odd digits ka product return karo.
    Agar saare digits even hain to 0 return karo.
    Udaharan ke liye:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    if n % 2 != 0 and len(list(str(n))) != 1:
        return 1 * n
    elif n == 1 and len(list(str(n))) == 1:
        return 1
    return 0


def main():
    print(digits(1))
    print(digits(2))
    print(digits(4))
    print(digits(235))


if __name__ == '__main__':
    main()
