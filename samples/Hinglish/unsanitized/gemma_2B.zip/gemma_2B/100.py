
def make_a_pile(n):
    """
    Ek positive integer n diya gaya hai, aapko n levels ki ek pile of stones banani hai.
    Pehle level me n stones honge.
    Agla level stones ka number hoga:
        - agla odd number agar n odd hai.
        - agla even number agar n even hai.
    Har level me stones ki sankhya ko ek list me return karo, jaha index
    i ki element level (i+1) me stones ki sankhya ko darshata hai.

    Udaharan:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    if n%2 and n > 1:
        return [n+1] + make_a_pile(n-1)
    elif 2 * n%2 == 0 and n > 1:
        return [n-1] + make_a_pile(n-1)
    else:
        return [0] + make_a_pile(n-1) + [n]


def pile_height(pile):
    """
    Ek pile diya gaya hai, aapko n elements aariyegi pile.
    Pile me nth element kya hai?

    Udaharan:
    >>> pile_height([4, 6])
    6
    """
    if pile[0]:
        return pile[0]
    return 0


def get_the_bottom_stone(pile, index):
    """
    Ek pile diya gaya hai, aapko n elements aariyegi pile.
    Gyauna stone aapko return karane hai paheere ke liye.
    Pile me to 0th element hoga, koi liye na.
    Udaharan:
    >>> get_the_bottom_stone([2, 5, 2], 0)
    2
    """
    if index == len(pile)-1:
        return None

    curr_stone = pile[-1] if len(pile) else 0
    next_stone = pile[index] if index < len(pile)-1 else curr_stone

    # Agar stones ke number ko ab hi badalna ho, toh toh
    if next_stone > curr_stone:
        return pile[index]

    return pile[index] + get_the_bottom_stone(pile[0:-1], index + 1)

print(get_the_bottom_stone([2, 5]))
