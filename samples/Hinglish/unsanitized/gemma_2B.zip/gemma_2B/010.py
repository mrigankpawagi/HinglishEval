

def is_palindrome(string: str) -> bool:
    """ Test karo ki kya diya gaya string palindrome hai ki nahi """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """
    Diye gaye string ko check karo ki woh palindrome hai ya nahi.
    """
    return string * 2 if is_palindrome(string) else string


def reverse_sring(string: str) -> str:
    return string[::-1]


if __name__ == '__main__':
    """
    for i in range(int(input())):
        string = input()
        print(f'Is palindrome: {is_palindrome(string)}')
        print(f'Reversed string: {reverse_sring(string)}')
        print(f'Palindromic for string {make_palindrome(string)}: {is_palindrome(make_palindrome(string))}')
    """
    print(make_palindrome('abc'))
