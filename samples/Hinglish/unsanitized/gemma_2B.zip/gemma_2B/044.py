

def change_base(x: int, base: int):
    """
    Input number x ka numerical base, base me badal do.
    Conversion ke baad string representation return karo.
    Base numbers 10 se kam hote hain.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    result = "{0:b}".format(x).lstrip('0')[::-1]
    if len(result) > base:
        return str(change_base(x, int(base / 2)))
    return result[1:].zfill(base - 1)


def is_base_num_correct(x: int, base: int):
    """
    Input numerical base me badalane ka option.
    Base numbers 10 se kam hote hain.
    Input x num ka numerical base.
    Return yes/no ko is_base_num_correct ke liye
    """
    return len(change_base(x, base)) == 1


def printall():
    result = []
    for base in range(2, 11):
        for i in range(2, 1001):
            num = int(change_base(i, base))
            if is_base_num_correct(num, base):
                result = change_base(i, base)
    return result


printall()
