

def median(l: list):
    """
    List l ke elements ka median return karo.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l.sort(reverse = True)

    def swap(i: int, j: int):
        (l[i], l[j]) = (l[j], l[i])
    
    def median_loop(l: [int] = [], k: int = 1)->int:
        if len(l) < 1:
            return float(None)
        
        s = 0
        e = len(l) - 1
        while e - s > 2:
            if k > float(e - s) / 6:
                s = (e + s) // 2
            elif k < float(e - s) / 6:
                e = (e + s) // 2
            else:
                break
            
        r = [(float(e - s) / 6, e) if e > s else (float(e - s) / 6, s)]
        r[0][0] = float(1 - r[0][0])
         
        if r[1][0] <= r[0][0] or l[s] <= l[e] or l[e] <= l[r[1][1]]:
            j = r[1][0]
        else:
            j = r[1][1]
        return l[j]

    return median_loop(l = l)
