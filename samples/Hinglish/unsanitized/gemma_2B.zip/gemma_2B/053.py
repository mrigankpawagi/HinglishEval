

def add(x: int, y: int):
    """
    Do numbers x aur y ko jodo
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y

"""
>>> r = add(3, 4)
3
>>> r
7
"""

def mul(x: int, y: int) -> int:
    "Do times x and y"
    """times is the name of the function here"""
    return x * y


def devide(x:int, y:int) -> int:
    """devide x/y"""
    return x/y

def negate(x: int) -> int:
    """negative a number"""
    """ x * 0 or 'x' in y """
    if type(x) != str:
        return -x

mul(10, 2)


# mul(10, 2)


# add(5, 4)


def square(v: int) -> int:
    """square a number"""
    return v * v
