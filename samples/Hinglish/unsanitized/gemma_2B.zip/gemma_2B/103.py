
def rounded_avg(n, m):
    """
    Aapko do positive integers n aur m diye gaye hain, aur aapka task hai n se lekar m tak ke integers ka
    average compute karna (n aur m ko bhi include karte hue). 
    Answer ko nearest integer tak round karo aur usko binary mein convert karo.
    Agar n m se bada hai, to -1 return karo.
    Udaharan:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    n_c, m_c = round(n, 1), round(m, 1)
    if(n_c==m_c):
        return str(n_c)
    elif(n_c > m_c):
        return 0
    else:
        return -1

def main():
    print(rounded_avg(5, 10))
    print(rounded_avg(33, 15))
    print(rounded_avg(50, 80))

if __name__ == '__main__':
    main()
