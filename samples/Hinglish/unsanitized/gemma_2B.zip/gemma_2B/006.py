from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """
    Is function ka input ek string hota hai jisme multiple groups hote hain jo nested parentheses se alag kiye gaye hote hain spaces ke dwara.
    Har group ke liye, sabse gehri level ki nesting of parentheses ka output do.
    Jaise ki, (()()) ka maximum do levels ki nesting hoti hai jabki ((())) ki teen hoti hai.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    parses = []
    for parenStr in paren_string:
        if parenStr == ')':
            return parses
        stack = []
        for level in parenStr:
            if level == '(':
                stack.append(level)
            elif level == ')':
                parens = stack.pop()
                if parens != '(':
                    parses.append(int(len(stack)))
    return parses


def parse_nested_parens_solution_2(paren_st: str) -> List[int]:
    """
    Method based approach.
    It is slow to handle 0 cases. For 0, it just returns []
    """
    # return [] if no parentheses left to evaluate
    if not paren_st:
        return []
    parses_list = []
    leftStack = []
    for paren in paren_st:
        if paren == '(':
            leftStack.append(paren)
        else:
            if len(leftStack) == 0:
                return []
            else:
                leftStack.pop()
                parses_list.append(int(len(leftStack)))
    if not leftStack:
        return parses_list
    else:
        return []


def is_balanced_expr(expr: str) -> bool:
    """
    Returns a boolean based on if expression is balanced
    """
    parenStack = []
    for paren in expr:
        if paren == '(':
            parenStack.append(paren)
        elif paren == ')':
            if not parenStack:
                return False
            parenStack.pop()
    if not parenStack: # This is because if parentesis are not matched then we can not apply this condition
        return True
    return False


test_cases = [
    '((()))', # True
    '(()()))', # True
    '(()((())))', # True
    '((())', # False
    '(())', # False
]
for _test_case, correct_answer in test_cases:
    """
    The test cases do not use the 'is_balanced_expr' function.
    Rather, they contain values that can be parsed from your result
    string. If the result contains a space,