
def largest_smallest_integers(lst):
    """
    Ek function banao jo ek tuple (a, b) return kare, jahan 'a' negative integers ka sabse bada hai, aur 'b' positive integers ka sabse chota hai ek list mein.
    Agar koi negative ya positive integers nahi hai, to unhe None ke roop mein return karo.

    Udaharan:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    """

    negative_numbers = []
    postive_numbers = []

    for x in lst:
        if x >= 0:
            postive_numbers.append(x)
        else:
            negative_numbers.append(x)

    if len(negative_numbers) == 0:
        return None

    if len(negative_numbers) < len(postive_numbers):
        return smallest, negative_numbers[0]
    else:
        return largest, negative_numbers[0]


def main():
    print(largest_smallest_integers([1, 4, -3, 0, 3, 7, 5]))
    print(largest_smallest_integers([2, 4, 1, 3, 5, 7]))
    print(largest_smallest_integers([]))
    print(largest_smallest_integers([0]))


if __name__ == "__main__":
    main()


"""
T-O(n)
    a,b = largest_smallest_integers(lst):
           |    l1    |  l2   |  l3   |     x             |
           | |  v    |v      | v     |    v               |
    l1 = (negative_numbers[0], x[0])
        (0, 1)
        (0, -3)
        (0, 4)
        (0, 3)
       (0, 7)
       (0, 5)

    l2 = (negative_numbers[j], x[-j]) 
         -3 | a    |  c        x       |    v         |    v
         | |   v  |  v         |   v        |    v        |
    c = (0, 1)
        (0, -3)
        (0, 4)
        (0, 3)
    a = (0, 7)
        (0, 1)
        (0, -3)
        (0, 4)
        (0, 5)

    l3 = (b, x[-j])
          3 | b    |  d         x        |    v        |    v
          | |   v  |  