
def smallest_change(arr):
    """
    Ek array arr diya gaya hai integers ka, usme se minimum kitne elements ko change karna padega 
    taaki array palindromic ban jaye. Ek palindromic array woh hota hai jo aage se bhi aur peeche se bhi 
    same padhta hai. Ek change me, aap ek element ko kisi bhi dusre element se replace kar sakte ho.

    Jaise ki:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

#         for i in range(0,len(arr)):
#             for j in range(i,len(arr)):
#                 for k in range(i+1,j):
#                     if arr[i]==arr[j]==arr[k]:
#                 break


    minDiff=len(arr)
    for i in range(0,len(arr)):
        for j in range(i+1,len(arr)):
            for k in range(j,len(arr)):
                if arr[i]==arr[j]==arr[k]:


def largest_palindrome(arr):
    """
    Ek array arr diya gaya hai integers ka, usme se maximum kitne elements ko palindrome ban jaye.
    Ek palindrome element yeh hai jo aage se bhi aur peeche se bhi same padhta hai.
    """
    #         return 'palindrome element : {}'.format(i,j)
      
    res=''
    for i in range(0,len(arr)):
        l=0
        h=len(arr)-1
        while(l<=h):
            mid=(l+h)//2
            if i==arr.index(arr[mid]):
                return arr[mid]
            elif arr[mid]!=arr[i]:
                return str(0)+" "
            elif arr[i]>arr[mid]:
                h=mid-1
            else:
                l=mid+1
    return str(0)+" "

#         for i in range(0,len(arr)):
#             for j in range(0,i):
#                 if arr[i]==arr[j]:
#                     break

if __name__=='__main__':
    n=int(input())
    for i in range(0,n):
        arr1=list(map(int,input().split()))
