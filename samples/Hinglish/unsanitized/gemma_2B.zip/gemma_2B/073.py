def smallest_change(arr):
    """
    Ek array arr diya gaya hai integers ka, usme se minimum kitne elements ko change karna padega
    taaki array palindromic ban jaye. Ek palindromic array woh hota hai jo aage se bhi aur peeche se bhi
    same padhta hai. Ek change me, aap ek element ko kisi bhi dusre element se replace kar sakte ho.

    Jaise ki:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    # Write your code here
    # print(arr)
    # print(arr.count(arr[0]))
    # print(arr.count(arr[1]))
    # print(arr.count(arr[2]))
    # print(arr.count(arr[3]))
    # print(arr.count(arr[4]))
    # print(arr.count(arr[5]))
    # print(arr.count(arr[6]))
    # print(arr.count(arr[7]))
    # print(arr.count(arr[8]))
    # print(arr.count(arr[9]))
    # print(arr.count(arr[10]))
    # print(arr.count(arr[11]))
    # print(arr.count(arr[12]))
    # print(arr.count(arr[13]))
    # print(arr.count(arr[14]))
    # print(arr.count(arr[15]))
    # print(arr.count(arr[16]))
    # print(arr.count(arr[17]))
    # print(arr.count(arr[18]))
    # print(arr.count(arr[19]))
    # print(arr.count(arr[20]))
    # print(arr.count(arr[21]))
    # print(arr.count(arr[22]))
    # print(arr.count(arr[23]))
    # print(arr.count(arr[24]))
    # print(arr.count(arr[25]))
    # print(arr.count(arr[26]))
    # print(arr.count(arr[27]))
    # print(arr.count(arr[28]))
    # print(arr.count(arr[29]))
    # print(arr.count(arr[30]))
    # print(arr.count(arr[31]))
    # print(arr.count(arr[32]))
    # print(arr.count(arr[33]))
    # print(arr.count(arr[34]))
    # print(arr.count(arr[35]))
    # print
