

def flip_case(string: str) -> str:
    """
    Diye gaye string ke liye, lowercase characters ko uppercase me aur uppercase characters ko lowercase me flip karo.
    >>> flip_case('Hello')
    'hELLO'
    """
    return list(string).replace(' ','').lower().title()


# 3. Implement this function with loops and without changing the arguments passed in the parameter.

def flip_case_2(string: str) -> str:
    """
    Function that can convert a given string to title case.
    >>> flip_case_2('caIn')
    'Caption'
    """
    title_case = []  # <---
    final_title = []  # <---
    title = []
    for char in string:
        if char.islower() and char != ' ' and title == []:  # <---
            title.append(char.upper())
        elif char.isupper():  # <---
            final_title = final_title[:] + title, [char]
        else:
            final_title = final_title[:] + title + [' ']
            title = [char]
        
    final_string = ''.join(final_title)  # <---
    return final_string

if __name__ == '__main__':
    flip_case()
