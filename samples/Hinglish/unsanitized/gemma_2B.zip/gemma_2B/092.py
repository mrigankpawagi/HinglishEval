
def any_int(x, y, z):
    """
    Ek function banao jo 3 numbers leta hai.
    Agar koi ek number doosre do numbers ka sum ho, aur saare numbers integers ho, toh true return kare.
    Kisi bhi aur case mein false return kare.
    
    Udaharan
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
    """


# Code goes here  
def is_prime(n):
    for i in range(2, n):
        if (n % i) == 0:
            return False
    return True            

def sum_of_digits(n):
    sum = 0
    while True:
        if len(str(n)) > 1:
            sum += int(n % 10)
            n = (n - n % 10) // 10
        else:
            return sum

def solution(n):
    
    if n < 4:
        return int(n ** 0.5)
    elif is_prime(n) == True:
        return is_prime(sum_of_digits(n))
    else:
        return -1

print(solution(2))
