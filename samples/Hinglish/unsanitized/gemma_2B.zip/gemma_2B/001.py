from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """
    Is function ka input ek string hota hai jisme multiple groups hote hain nested parentheses ke. Aapka goal hai
    un groups ko alag alag strings me separate karna aur unki list return karni hai.
    Separate groups balanced hote hain (har open brace sahi se close hota hai) aur ek dusre ke andar nested nahi hote
    Input string me koi bhi spaces ko ignore karo.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    list_res = []
    stack = []
    for i in range(len(paren_string)):
        if paren_string[i] == '(':
            stack.append(i)
        elif paren_string[i] == ')':
            if len(stack):
                ind = stack[-1]
                left_bracket_index = paren_string.index(')', ind + 1)
                stack.pop()
                start_index = left_bracket_index
                end_index = paren_string.index('(', left_bracket_index + 1)#start_index = ind + 1
                if paren_string[start_index:end_index] == '()':
                    list_res.append(paren_string[start_index:end_index + 2])
                else:
                    list_res.append(
                        '(' + paren_string[ind:ind + left_bracket_index + 1] + ')')
                    for i in range(end_index-ind):
                        list_res.append(paren_string[ind:ind + 1 + i])
                    list_res.append(paren_string[ind + left_bracket_index + 1:end_index])
                if left_bracket_index+1 == len(paren_string):
                    list_res.append(')')
            else:
                list_res.append(')')
    return list_res
    # return list_res
separate_paren_groups('( ) (( ))')
# separate_paren_groups('(())()())')
# separate_paren_groups('()())')
