
def is_sorted(lst):
    """
    Ek numbers ki list di gayi hai, return karo ki kya ye ascending order mein sorted hai ya nahi. Agar list mein ek se jyada same number ke duplicate hain, to False return karo. Maan lo ki koi negative number nahi hai aur sirf integers hain.

Udaharan
is_sorted([5]) ➞ True
is_sorted([1, 2, 3, 4, 5]) ➞ True
is_sorted([1, 3, 2, 4, 5]) ➞ False
is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    """


    #Your code goes here

# test_1 = [5]
# test_2 = [1, 2, 3, 4, 5]
# test_3 = [1, 3, 2, 4, 5]
# test_4 = [1, 2, 3, 4, 5, 6]
# test_5 = [1, 2, 3, 4, 5, 6, 7]
# test_6 = [1, 2, 3, 4, 5, 6, 7]
# test_7 = [1, 3, 2, 4, 5, 6, 7]
# test_8 = [1, 2, 2, 3, 3, 4]

# test_1 = test_1[0]
# test_2 = test_2[0]
# test_3 = test_3[0]
# test_4 = test_4[0]
# test_5 = test_5[0]
# test_6 = test_6[0]
# test_7 = test_7[0]
# test_8 = test_8[0]

# print( is_sorted(test_1)) #➞ True
# print( is_sorted(test_2)) #➞  True
# print( is_sorted(test_3)) #➞  True
# print( is_sorted(test_4)) #➞  False
# print( is_sorted(test_5)) #➞ True
# print( is_sorted(test_6)) #➞ True
# print( is_sorted(test_7)) #➞  True
# print( is_sorted(test_8)) #➞  False
