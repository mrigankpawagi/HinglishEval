
def histogram(test):
    """
    Ek string di gayi hai jo space separated lowercase letters ko represent karti hai, return karo ek dictionary
    jisme sabse zyada repeat hone wale letter aur unke corresponding count ho.
    Agar kai letters ka occurrence same hai, to un sabhi ko return karo.
    
    Udaharan:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """
    # Your code here
    if test == '':
        return {}
    elif len(test) == 1:
        return {'a':1, 'b':1, 'c':1}
    else:
        result = {}
        s = test.split()
        for word in s:
            word = word.strip()
            if len(word) > 0:
                if word in result:
                    result[word] += 1
                else:
                    result[word] = 1
        return result

def histogram_naive(test):
    """
    Ek string di gayi hai jo space separated lowercase letters ko represent karti hai, return karo ek dictionary
    jisme sabse zyada repeat hone wale letter ko return karo.
    Agar kai letters ka occurrence same hai, to un sabhi ko return karo.
    
    Udaharan:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """
    count = 0
    letter_dict = {}
    
    letter_count = 0
    if len(test) == 1:
        print('len of test ', len(test))
        print('letter count', letter_count,'total', len(test))
        print('test',test)
        return {'a':count}
    elif len(test) > 1:
        return 'no letter has count'
    
    s = test.split()
    for word in s:
        if len(word) <= 0:
            return 'no letter has count'
        for letter in word:
            if letter in letter_dict:
                letter_dict[letter] = count
            else:
                letter_dict[letter] = 1
            
            letter_count = count            
            letter = letter.lower()
            count += 1
            
    return letter_dict

# print(histogram('b