
def compare(game,guess):
    """
    Mujhe lagta hai hum sabko woh ehsaas yaad hoga jab kisi besabri se intezaar karne wale event ka result finally pata chalta hai. Us samay jo aapke feelings aur vichar hote hain, unhe note down karna aur compare karna zaroori hota hai.
    Aapka task hai yeh determine karna ki kya ek vyakti ne kisi matches ke results ko sahi tara se guess kiya hai ya nahi.
    Aapko do arrays diye jayenge scores aur guesses ke, jinka length equal hoga, jahan har index ek match ko dikhata hai. 
    Wapas ek array return karo jiska length same ho, jo denote karta hai ki har guess kitna off tha. Agar unhone sahi guess kiya hai,
    toh value 0 hogi, aur agar nahi, toh value guess aur score ke beech ka absolute difference hoga.
    
    
    Udaharan:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    if game == guesses:
        a=[]
        for i in range(len(game)):
            if game[i]==guess[i]:
                a.append(0)
            else:
                b=abs(guess[i]-game[i])
                a.append(b)
        return a
    else:
        print("Invalid scores")
        return(0,0,)



def getScores(game):
  scores=[]
  for i in range(len(game)):
    scores.append(0)
    for j in range(len(game)):
      if game[i] == game[j]:
        scores[i]=scores[i]+1
  return scores

def getGuesses(guess):
  guesses=[]
  for k in range(len(guess)):
    guesses.append(0)
  
  return guesses

def main():
  """
  Main function to run the code
  """


  player_names = ["A","B","C","D","E","F"]
  colors = ["R","B","G","O","Y","D"]
  game = [100,100,90,85,70,65]
  guesses = [10,9,8,7,6,5,4,3,2,1,0]
  
  # getScores(game)
  guesses = [50,20,12,11,8,7,6,1,0,-1]
  
  # getScores(guesses)
  print("Scores are:")  print(getScores(game))  print("Guesses are:")  print(getGuesses(guess))


main()
