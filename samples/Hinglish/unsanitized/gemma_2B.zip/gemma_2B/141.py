
def file_name_check(file_name):
    """
    Ek function banao jo ek string leta hai jisme file ka naam hota hai, aur return karta hai
    'Yes' agar file ka naam valid hai, aur 'No' agar nahi.
    Ek file ka naam tabhi maana jayega jab saare neeche diye gaye conditions meet ho:
    - File ke naam me teen se zyada digits ('0'-'9') nahi hone chahiye.
    - File ke naam me sirf ek dot '.' hona chahiye.
    - Dot se pehle ka substring khali nahi hona chahiye, aur uska shuruat latin alphabet ('a'-'z' aur 'A'-'Z') se hona chahiye.
    - Dot ke baad ka substring inme se ek hona chahiye: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (naam latin alphabet letter se shuru hona chahiye)
    """
    if "-" in file_name:
        return "No"
    try:
        file_name_list = file_name.split('.')
        if file_name_list[0] == "": # a line which is starting with space or any special char, so if line is empty so it will come back to a space and it will never come back to the condition when we are checking the list of files , so it will never come back to this conditions.
            return "No"
        for i in range(len(file_name_list)):
            if file_name_list[i-1].isdigit():
                return "No"
            if file_name_list[i].isalpha():
                return "No"
            if file_name_list[i].lower() == "txt":
                return "No"
            if file_name_list[i].lower() == "exe":
                return "No"
            if file_name_list[i].lower() == "dll":
                return "No"
        return "Yes"
    except Exception as e:
        return "No"


print(file_name_check("example.txt"))
