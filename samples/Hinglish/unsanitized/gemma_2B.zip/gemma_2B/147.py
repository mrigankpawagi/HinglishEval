
def get_max_triples(n):
    """
    Aapko ek positive integer n diya gaya hai. Aapko ek integer array a banani hai jiski length n ho.
    Har i (1 ≤ i ≤ n) ke liye, a[i] ka value hoga i * i - i + 1.
    Return karo triples (a[i], a[j], a[k]) ka number jahan a[i] + a[j] + a[k] 3 ka multiple ho aur i < j < k ho.

    Udaharan :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        Sirf ek valid triple hai (1, 7, 13).
    """
    # Write your code here
    if n <= 1:
        print(0)
        return
    arr = [1, 1, 1]
    ans = 0
    for i in range(2, n):
        for j in range(n, i - 1, -1):
            arr[i] = j * j - j + i
        if arr[i] % 3 == 0 and i > 2 < j < n:
            ans += 1
    print(ans)


def reverse_string(s):
    # code here
    return s[::-1]


# reverse_string('xyz') # xyz
# reverse_string('apple') # 'leapoopl'
# reverse_string("a") # "a"

# Problem 2
def calculate(n, k):
    if n == 1 or 1 > k or k > n * n:
        return False
    i = n
    numsum = 0
    while numsum + i <= k:
        numsum = numsum + i
        i = i - 1
    return numsum == k


def check_palindrome(string):
    for i in range(len(string) // 2):
        if string[i] != string[len(string) - i - 1]:
            return False
    return True


# Problem 3 : reverse_string() me palindrome number banaya hai
# Problem 4 : Palindrome Check : string of lenth n, check ka value palindrome ?
