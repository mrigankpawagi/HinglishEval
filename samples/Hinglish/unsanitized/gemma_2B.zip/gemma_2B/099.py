
def closest_integer(value):
    """
    Ek function banaiye jo ek value (string) leta hai jo ek number represent karta hai
    aur uska sabse close integer return karta hai. Agar number do integers ke beech 
    samanantar hai, toh use zero se door round karo.

    Udaharan
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Dhyan Dijiye:
    Zero se door round karne ka matlab hai ki agar diya gaya number do integers ke beech 
    samanantar hai, toh aapko woh integer return karna chahiye jo zero se sabse door hai. 
    Jaise ki closest_integer("14.5") ko 15 return karna chahiye aur closest_integer("-14.5") 
    ko -15 return karna chahiye.
    """
    number_value = float(value)

    # ek integer ko integer return karne ka matlab hai ki woh integer hai 
    // isse value ke andar ek zero hoti hai, so use number_value.round(0) karna chaiye
    # jab tak number_value jo integer ni hota hai, unhone to abhi ek decimal ho sakti hai

    nearest_integer = number_value.round(0)

    current_smallest = float('inf')
    smallest_value = float('-inf')

    if number_value < 0:
        return nearest_integer

    for i in range(10):
        diffrence = number_value - nearest_integer
        abs_diffrence = abs(diffrence)

        if diffrence < 0 and abs_diffrence < current_smallest:
            current_smallest = abs_diffrence
            smallest_value = nearest_integer
        elif diffrence > 0 and abs_diffrence < current_smallest:
            current_smallest = abs_diffrence
            smallest_value = nearest_integer
        else: 
            return nearest_integer

    return smallest_value

print("result:", closest_integer(4.5))
