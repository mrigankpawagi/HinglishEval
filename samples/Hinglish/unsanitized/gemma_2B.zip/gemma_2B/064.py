
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Aur test cases jodo.
    """
    vowel_dict = {
     'A' : 'a',
     'E': 'e',
     'I': 'i',
     'O': 'o',
     'U': 'u'}

    count = 0
    
    for i in s:
        if i in 'A' or i in 'E' or i in 'I' or i in 'O' or i in 'U':
            count += 1
    

if __name__ == '__main__':
    assert vowels_count('') == 0, FIX
    s = "Mississippi"

    assert vowels_count(s) == 4, FIX
