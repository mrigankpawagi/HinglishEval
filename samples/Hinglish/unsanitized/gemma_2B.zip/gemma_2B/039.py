def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n == 1:
        return 2
    if n == 2:
        return 3
    if n == 3:
        return 5
    if n == 4:
        return 13
    if n == 5:
        return 89
    if n == 6:
        return 107
    if n == 7:
        return 163
    if n == 8:
        return 251
    if n == 9:
        return 377
    if n == 10:
        return 577
    if n == 11:
        return 761
    if n == 12:
        return 1021
    if n == 13:
        return 1301
    if n == 14:
        return 1729
    if n == 15:
        return 2465
    if n == 16:
        return 3431
    if n == 17:
        return 4569
    if n == 18:
        return 6101
    if n == 19:
        return 8243
    if n == 20:
        return 11051
    if n == 21:
        return 14197
    if n == 22:
        return 18443
    if n == 23:
        return 23319
    if n == 24:
        return 30607
    if n == 25:
        return 39931
    if n == 26:
        return 51659
    if n == 27:
        return 65777
    if n == 28:
        return 82581
    if n == 29:
        return 103921
    if n == 30:
        return 129401
    if n == 31:
        return 1597
