

def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    c = int(n)*2
    while True:
        for i in range(2, int(n/2)+1):
            a = c//i
            if (a**2)%c!=c%a and a==c//a:
                return(a)
        if c%2!=c or c%3!=c or c%5!=c:
            for j in range(6,c,5):
                if 0 not in (c%j):
                    return(c)
                if c%j and j==c//j:
                    for i in range(2,int(c/j)+1):
                        if (i**2)%c!=c%i:
                            return(i)
    return(c)

print("Enter a positive integer:")
a=int(input())
prime_fib(a)

# code for prime number

print("Please Enter prime number to check whether it is Prime or not:")
n=int(input())
if(n==1):    return 0
if(n%2==0):  return 2*n - 1
k=(int)(n/2)**2
for i in range(3,int(n/2)+1,2):
    if(int(i*i)==n): break
else:
    if(k<=0): return 0
    while(i<int(n/2)):
        f=2
        if(k%f==0): return 0
        f+=2
        while(k%(f+f) == 0):
            f+=2
        if((int(f*f)-n)%k!=0): continue
        else:return 0
else:
    if(k<=0): return 0
    while(i<int(n/2-2)):
        f=2
        if(k%f==0): return 0
        f+=2
        while(k%(f+f) == 0):
            f+=2
        if((int(f*f)-n)%k!=0): continue
        else:return 0
else:
    return 0



print('Check out the code on Leetcode https://leetcode.com/explore/learn/card/fun-with