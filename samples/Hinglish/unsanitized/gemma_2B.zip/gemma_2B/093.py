
def encode(message):
    """
    Ek function likho jo ek message leta hai, aur usko aise encode karta hai 
    ki wo saare letters ki case ko swap kar deta hai, saare vowels ko 
    unke aage wale 2nd letter se replace kar deta hai english alphabet mein. 
    Sirf letters maan lo. 
    
    Udaharan:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    converted_message = ''
    for charecter in message:
        if charecter == charecter.upper():
           converted_message = converted_message + charecter[1]
        else:
            converted_message = converted_message + charecter[0]
    return converted_message

def decode(message):
    """
    Ek function likho jo aise decode karta hai ki uske bare me ek message likha hai, 
    vaale ko aise swap kar deta hai agar saare vowels hindustan mein hote hai, 
    kisi letter ko unke aage wale english alphabet mein replace kar deta hai. 
    Sirf letters maan lo. 
    
    Udaharan:
    >>> decode('tHKS KS C MGSSCGG')
    'This is a message'
    >>> decode('tGST')
    'test'
    """
    converted_message = ''
    for charecter in message:
        if charectar == charectar.upper():
           converted_message = converted_message + charecter[0]
        else:   
            converted_message = converted_message + charecter[1]
    return converted_message
            

    

# print(decode(encode('test'))==('tHKS KS C MGSSCGG',))
    

def english_letters():
    list_of_letters = []
    upper_English_Letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    for letter in upper_English_Letters:
        list_of_letters.append(letter)
    return list_of_letters

def replace_vowels_with_new_letters(all_letters_list, replaced_letters):
    
    for letter in all_letters_list:
        letter = letter[0]
        if letter in replaced_letters:    
            all_letters_list.insert(all_letters_list.index(letter) +