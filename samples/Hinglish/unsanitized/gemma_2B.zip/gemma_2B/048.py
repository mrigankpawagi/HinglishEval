

def is_palindrome(text: str):
    """
    Diye gaye string ko check karta hai ki kya yeh palindrome hai
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    
    text_list = text.split(' ')
    text = [x for x in text_list if len(x)!=1]
    sorted_text = ''.join(text)

    return sorted_text==sorted_text[::-1]


def solution(text: str) -> bool:
    if not text:
        return True
    else:
        return is_palindrome(text)
