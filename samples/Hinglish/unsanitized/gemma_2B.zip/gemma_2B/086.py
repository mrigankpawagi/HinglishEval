
def anti_shuffle(s):
    """
    Ek function likho jo ek string leta hai aur uska ordered version return karta hai.
    Ordered version of string, woh string hoti hai jahan saare words (space se separated)
    ko ek naye word se replace kiya jata hai jahan saare characters ko 
    unke ascii value ke basis pe ascending order mein arrange kiya jata hai.
    Dhyan do: Aapko words aur blank spaces ki order sentence mein maintain karni chahiye.

    Jaise ki:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """
    s1 = s.split(" ")
    s2 = []
    for i in s1:
        s3 = []
        for j in range(0, len(i)):
            s3.append(str((ord(i[j]))))
        if i != '':
            s2.append("".join(s3))
    new_s2 = ""
    for k in range(0, len(s2)):
        try:
            new_s2 = new_s2 + s2[k] + " "
        except:
            new_s2 = new_s2 + s2[k]
    return new_s2
