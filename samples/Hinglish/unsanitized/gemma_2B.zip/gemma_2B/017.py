from typing import List


def parse_music(music_string: str) -> List[int]:
    """
    Is function ka input ek string hai jo musical notes ko ek special ASCII format mein represent karta hai.
    Aapka kaam hai is string ko parse karna aur ek integers ki list return karna jo correspond karti hai ki har note kitne beats tak chalta hai.

    Yaha ek legend hai:
    'o' - whole note, jo four beats tak chalta hai
    'o|' - half note, jo two beats tak chalta hai
    '.|' - quater note, jo one beat tak chalta hai

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    # aek list return karde hai jo 1 ek beat tak chaleyga aur jo note ek beat tak chalu hai
    notes: List[int] = []
    # agar list mein ek character bhi nahi hai to return karo
    if not music_string:
        return notes
    first = True
    for c in music_string[:-1]:
        if(not first):
            notes.append(c)  # ek note kaa ek beat chala ga
            notes.append(c)  # ek beat se pehle se ek note chalaga
        else:
            first = False

    notes.append(music_string[-1])  # last element ke note ek beat se pehle se note chala hoga
    return notes


if __name__ == "__main__":
    print(parse_music("o o| .| o| o| .| .| .| .| o o"))
