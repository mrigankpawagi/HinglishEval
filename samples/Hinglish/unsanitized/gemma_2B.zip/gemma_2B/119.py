
def match_parens(lst):
    """
    Aapko do strings ki ek list di gayi hai, dono strings me sirf open
    parentheses '(' ya close parentheses ')' hi hote hain.
    Aapka kaam ye check karna hai ki kya in dono strings ko kisi order me concatenate karne se
    resulting string acchi banegi.
    Ek string S tabhi acchi maani jayegi jab usme saare parentheses balanced ho. Jaise ki: string '(())()' acchi hai, jabki string
    '())' acchi nahi hai.
    Agar acchi string banane ka koi tarika ho to 'Yes' return karo, aur anyatha 'No' return karo.

    Udaharan:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    """

    def _match(s, pattern):
        for a, b in zip(pattern, s[::-1]):
            if a == '(':
                if b != ')':
                    return False
        return True

    return [_match(left, right) or _match(right, left) for left, right in zip(lst, lst[::-1])]


# Another way to solve the problem using stacks ... 
def stack_based(lst):
    stacks = []
    for i in range(len(lst)):
        if not stacks:
            stacks.append((i, lst[i]))
        else:
            while stacks and stacks[-1][1] < lst[i]:
                top = stacks.pop()
                if top[1] == '(' and lst[i] == ')':
                    return True
                else:
                    stacks.append(top)
            if not stacks or stacks[-1][1] != '(' or lst[i] not in '()':
                return False
            stacks.append((i, lst[i]))
    while stacks:
        top = stacks.pop()
        if top[1] == '(' and lst[i] == ')':
            return True
    return False
