from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """
    Diye gaye input numbers ki list ke liye, dataset ka Mean Absolute Deviation calculate karo.
    Mean Absolute Deviation woh average absolute difference hota hai jo har element aur ek centerpoint (is case mein mean) ke beech hota hai:
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    try:
        mean_value = sum(numbers) / (len(numbers))
        return sum(abs(elem - mean_value) for elem in numbers) / (len(numbers))
    except ZeroDivisionError:
        return float("inf")


mean_absolute_deviation([2.3, 4.5, 7.0, -2.0])
mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
mean_absolute_deviation([2.0, 3.1, 1.5, 4.6])
mean_absolute_deviation([3.14, 2.7, 99])
mean_absolute_deviation([0])
mean_absolute_deviation([-550])
