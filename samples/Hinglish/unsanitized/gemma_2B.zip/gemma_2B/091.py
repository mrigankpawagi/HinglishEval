
def is_bored(S):
    """
    Aapko ek string di jayegi jisme words honge, aur aapka task hai ginna ki kitne boredoms hai. Ek boredom woh sentence hota hai jo "I" word se start hota hai.
    Sentences ko '.' , '?' ya '!' se alag kiya jata hai.
   
    Udaharan ke liye:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
 
    # Your code here
    i = 0
    arr=[]
    
    for i in range(0,len(S)):
        if(i > 0 and S[i - 1] != '.':
            if (S[i] == '.' or S[i] == '?' or S[i] == '!'):
                arr.append(0)
            else:
                print(0)
                return(0)
    if not(arr):
        return 0
    else:
        print("I")
        return arr.count("I")




# Time complexity = O(n)
# Space complexity = O(n)


if __name__ == '__main__':
    S = input()
    res = is_bored(S)
    print(res)
