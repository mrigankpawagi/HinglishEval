

def is_prime(n):
    """
    Agar diya gaya number prime hai to true return karo, aur anyatha false.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if n < 2:
        return False
    for i in range(2, n//2+1):
        if n%i==0:
            return False
    return True
#_______________________________________________________________#

def count_primes(max_num):
    """return the number of primes <= to maximum number given

    >>> count_primes(2)
    0
    >>> count_primes(7)
    2
    >>> count_primes(10)
    3
    >>> count_primes(200)
    22
    >>> count_primes(1234)
    18
    """
    x=range(2,max_num+1)
    if list(x)!=x:
        return len(x)
    else:
        return 0
#_______________________________________________________________#
