
def x_or_y(n, x, y):
    """
    Ek simple program jo n ek prime number hone par x ka value return karega aur anyatha y ka value return karega.

    Udaharan:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    """
    # code goes here
    if n == 0:
        return "Invalid"
    elif n < 0:
        return "Invalid"
    elif x > 0:
        if n % x == 0:
            return x
        else:
            return y
    elif n < x:
        return y
    else:
        return x


assert x_or_y(15, 8, 5) == 5
assert x_or_y(25, 4, 2) == 4
assert x_or_y(0, 3, 13) == 3
