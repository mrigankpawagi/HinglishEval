

def sort_even(l: list):
    """
    Yeh function ek list l leta hai aur ek list l' return karta hai aisa ki
    l' l ke odd indices ke saath identical hota hai, jabki uske even indices ke values
    l ke even indices ke values ke barabar hoti hai, lekin sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    l_sorted = sorted(l)
    return [l_sorted[x] for x in range(len(l)) if x % 2 == 0]


def sort(l):
    """
    Same as sort_even function, difference is that
    here we sort even index values.
    """
    l_sorted = sorted(l)
    return [l_sorted[x] for x in range(len(l)) if x % 2 == 1]


def solve(n, s1):
    """
    Here we don't have to return anything, but, the program
    must write all solution in the first n lines, and if the
    first n lines are not sufficient to solve the problem,
    output some meaningful message from the next line(s).
    This also helps testers to see that we didn't just return
    an empty string!
    >>> 0<=n<=1000
    >>> 0<=s1.count(" ")<=n
    >>> 0<=s1.count(",")<=n
    >>> "a b c d e f g h i j l m n o p q " <= s1 <= "a b c d e f g h i j l m n o p q "
    ""
    ""
    ""
    ""
    ["" ]
    ""
    >>> print("Hello HackerRankers")
    "Hello HackerRankers"
    "Hello HackerRankrs"
    "Hello HackerRankress"
    "Hello HackerRankressh"
    "Hello HackerRankresshey"
    "Hello HackerRankressheyr"
    "Hello HackerRankressheyre"
    "Hello HackerRankressheyres"
    ""
    """
    l = s1.split()
    even_l = sort_even(l)
    odd_l = sort(l)

    i = 0
    while i < len(l) and i < n:

        even_l.append(l[i])
        i+=1

    if len(even_l) != n:
        print("Empty")
    else:
        print(" ".join(even_l))
