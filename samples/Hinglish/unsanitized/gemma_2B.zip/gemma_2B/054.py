

def same_chars(s0: str, s1: str):
    """
    Dekho ki do shabd me same characters hai ya nahi.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    s0 = list(s0)
    s1 = list(s1)
    s0.sort()
    s1.sort()

    if s0 == s1:
        return True
    else:
        return False


def same_chars_solution(s1, s2):
    """
    Dekho ki isme shabd idhar bhi same characters hai ya nahi.
    >>> same_chars_solution('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars_solution('abcd', 'dddddddabc')
    True
    >>> same_chars_solution('dddddddabc', 'abcd')
    True
    >>> same_chars_solution('eabcd', 'dddddddabc')
    False
    >>> same_chars_solution('abcd', 'dddddddabce')
    False
    >>> same_chars_solution('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    return s1 == s2


def compare(s1, s2):
    """
    Dekho ki isme both two shabd idhar bhi same characters hai y nahi.
    >>> same_chars_solution('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars_solution('abcd', 'dddddddabc')
    False
    >>> compare('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> compare('abcd', 'dddddddabce')
    False
    >>> compare('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    if type(s1) is not str or type(s2) is not str:
        return False
    if len(s1) != len(s2):
        return False
    s1 = s1.upper()
    s2 = s2.upper()

    if ''.join(set(s1)) == ''.join(set(s2)):
        return True
    else:
        return False


def test():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test()
