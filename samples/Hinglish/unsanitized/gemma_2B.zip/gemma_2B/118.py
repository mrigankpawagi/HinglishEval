
def get_closest_vowel(word):
    """
    Aapko ek word diya gaya hai. Aapka task hai right side se dekhte hue us vowel ko dhundna hai jo 
    do consonants ke beech mein hai (case sensitive).
    
    Shuruat aur ending mein jo vowels hain unka count nahi hoga. Agar aapko koi bhi vowel upar diye gaye 
    condition ke hisaab se nahi mila toh khali string return karo. 

    Aap maan sakte ho ki diya gaya string sirf English letters se bana hua hai.

    Udaharan:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    # Implement your logic here
    count = 0
    vowels = str.maketrans("qwe", "qrur")
    vowel_count = len(list("qwe".translate(vowels)))
    c = 0
    for i in word:
        if (i.lower() in "aeiou").lower() and (c + 1 < word):
            c += 1
            if (list(i) in list("aeiou".translate(vowels))):
                vowel_count -= 1
        else:
            if vowel_count == 0:
                return word[0:2]  # Case-sensitive
                break
        count += 1
    return ""


# Input and Output:
if __name__ == "__main__":
    # These "asserts" using only for self-checking and not necessary for auto-testing
    assert get_closest_vowel("ab") == "", "Example 1"
    assert get_closest_vowel("ab") == "", "Example 2"
    assert get_closest_vowel("ab") == "", "Example 3"
    assert get_closest_vowel("qweasd") == "a", "Example 4 with 2 vowels"
    assert get_closest_vowel("qwe") == "a", "Example 4 with 1 vowel"
    assert get_closest_vowel("full") == "U", "Example 5"
    assert get_closest_vowel("Yogurt") == "u", "Example 6"
    print("Coding complete? Click 'Check' to review your tests and earn cool rewards!")
