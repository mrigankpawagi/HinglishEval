
def even_odd_count(num):
    """
    Ek integer diya gaya hai. Ek tuple return karo jo even aur odd digits ki sankhya ko kramashah darshata hai.

     Udaharan:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    # your code here
    digits = str(num)
    result = []
    for digit in digits:
        if int(digit)%2 ==0:
            result.append(1)
        else:
            result.append(0)
    return  result


# ##################################### 
###################################### 
######################################

def even_odd_even(num):
    """
    Ek integer diya gaya hai. Ek tuple return karo jo even, odd, even digit ki sankhya ko kramashah darshata hai.

    Udaharan:
        even_odd_even(-12) ==> (1, 1, 1)
        even_odd_even(123) ==> (0, 1, 0)
    """


    # your code here
    digits = str(num)
    result = []
    for digit in digits:
        if int(digit)%2 ==0:
            result.append(1)
        else:
            result.append(0)
            if len(digit) == 1:
                result = [0, 0, 0, 1]
    return result

# ##################################### 
######################################

def is_palindrome(num):
    """
    Ek integer diya gaya hai. Ek Boolean return karo jo num ko palindrome karoge ko darshta hai.

    Udaharan:
        is_palindrome (-404) ==> False
        is_palindrome (0) ==> True
    """

