
def sort_array(arr):
    """
    Is Kata mein, aapko ek array ko sort karna hai jo non-negative integers ka hoga, 
    binary representation mein ones ki sankhya ke hisaab se ascending order mein.
    Agar ones ki sankhya same ho, toh decimal value ke basis par sort karo.

    Isko aise implement karna hai:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    binary_to_decimal = {x: y for x, y in zip(reversed(arr), range(len(arr)))}
    return [x for x in reversed(arr) if binary_to_decimal[x]]


arr1 = [1, 2, 4, 6, 2, 7, 3, 8, 4, 5]
arr2 = [24, 43, 45, 3, 20, 22, 7, 30, 8, 9, 1, 2]
print(sort_array(arr1))
print(sort_array(arr2))

"""
Aapko print krne ke liye first hai [1, 2, 4, 6, 2, 7, 3, 8, 4, 5] aur [24, 43, 45, 3, 20, 22, 7, 30, 8, 9, 1, 2]
to yeh solve krne ko diya.
"""

def sort_array(arr):
    result = sorted(arr, key=lambda x: len("".join(reversed(list(str(x))))) if arr[-1] > arr[0] else None)
    return result
