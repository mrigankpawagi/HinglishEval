
def order_by_points(nums):
    """
    Ek function likho jo diye gaye integers ki list ko unke digits ka sum ke hisaab se ascending order mein sort kare.
    Dhyan do: agar kuch items ke digits ka sum similar ho, 
    toh unhe original list ke index ke basis par order karo.

    Jaise ki:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    return sorted(nums, key=lambda x: str(x).replace('-','')))

print(order_by_points([1, 11, -1, -11, -12]))


from itertools import count
def longest_repeating_substring(s):
    """
    Ek function likho jo ye solve karke leaye ga ki 
    ki s mein leaye gaye characters aane wale character ke count ka result 
    maximum value ke baare mein tell kare jo baad me isko aane walo chain jo maximum value 
    main baad mein aane wale character me ho jaayega.
    """
    
    # s= "ABABABABABA"
    
    if not s:
        return "empty string"
    
    s1 = sorted(list(set(s)))[:-1]
    
    max_len = len(s1)
    prefix = s1[0]
    suffix = s1[-1]
    
    i = 0
    for i in count():
        if s1[i] == prefix and s1[i + 1] == suffix:
            break
    
    a = 1
    while True:
        
        for i in count():
            
            if s1[i] == prefix and s1[i + prefix.count(prefix)] == suffix:
                break
            else:
                if i == len(s1) - 1:
                    return prefix + s1[i + max_len]
                else:
                    prefix = s1[i + prefix.count(prefix)]
                    suffix = s1[i + prefix.count(prefix) + suffix.count(suffix)]
        
        a +=1
            
        if a == 5:
            return "Nothing repeat the character"
            break

# S="ABABABABABA"
# S= "ABABABA" # Output= 2
# S="ABABABAB" # Output= 5

print(longest_repeating_substring("ABABABAB") ) # output= 5

print(longest_repeating_substring("ABABABA")) # output= 2

print(longest_repeating_substring("ABABABABABC