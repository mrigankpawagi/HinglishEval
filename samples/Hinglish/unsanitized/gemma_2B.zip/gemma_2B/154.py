
def cycpattern_check(a , b):
    """
    Aapko 2 words diye gaye hain. Aapko True return karna hai agar dusra word ya uske kisi bhi rotation ko pehle word ke substring mein milta hai
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True
    """
    #code goes threre  
    str_a = a
    count1 = 0
    for i in range(len(str_a)):
        count1 += 1
        l = str_a[:i]
        l1 = ''.join( sorted( l ) )
        r = ''.join( sorted( str_a[i+1:]  )  )
        print (l ) 
        print (r )
        print (l1) 
        print (r1)
        if (l1 and r1):
            return True
        else:
            if (str_a[l1] == str_a[i] or str_a[r1] == str_a[i]) :
                return False
            else :
                return False 
      
      
# Main ###
if __name__ == '__main__':
    l = raw_input()
    r = raw_input()
    a = cycpattern_check(l ,r)
    print ("1234- "+str(a))
 
        

#Optimal solution
# if __name__ == '__main__':
#     s1= raw_input().strip()
#     s2 = raw_input().strip()
#     length = len(s1)
#     if(len(s2) > len(s1)):
#         print("Impossible")
  

#Optimal solution
# if __name__ == '__main__':
#     l = raw_input()
#     r = raw_input()
#     x = list(l)
#     y = list(r)
#     if ((y[0] >= 'a'and y[0] <= 'z')or(y[0] >= 'A'and y[0] <= 'Z')):
#         if(len(y)> len(l)):
#           print(False)
#         else:
#           x = sorted(list(l))
#           ans = y  
#           for i in range(0,len(x)):
#              if(x[i] == y[0]):
#                  ans = list(set( ans  ))
#                  if (ans not in sorted(list(l))):
#                      print (False)