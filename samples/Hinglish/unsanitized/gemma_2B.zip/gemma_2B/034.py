

def unique(l: list):
    """
    Ek list mein sorted unique elements return karo
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    l.sort()
    return [ i for i in l if i == l.pop()]
    
    pass



def get_unique_elements(l: list):
    """
    Ek list mein sorted unique elements return karo
    >>> get_unique_elements([1,1,1,2,3,4,4])
    [1,2,3,4]
    """

    l.sort()
    return [ i for i in l if i == l.pop()]
    pass
    
    
def count_unique_elements(l: list):
    return len([i for i in l if l.count(i) != 1])
