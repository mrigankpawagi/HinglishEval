

def strlen(string: str) -> int:
    """
    Diye gaye string ki length return karo
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)


def find_largest_number(n: int) -> int:
    """
    Bolu kucen sayi ve return
    >>> find_largest_number(3)
    3
    >>> find_largest_number(98324)
    98324
    """
    return n


def add_two_number(num1: int, num2: int) -> int:
    """
    Acilan iki sayi topla(max 9 deger)
    >>> add_two_number(1,2)
    3
    >>> add_two_number(2,3)
    5
    """
    return num1 + num2


def find_missing(numbers: list) -> int:
    """
    Bolu kucen sayi return
    >>> numbers=[1,5,2,3]
    >>> find_missing(numbers)
    4
    >>> numbers=[1,5,2,4,3,5]
    >>> find_missing(numbers)
    3
    """
    if len(numbers) == 0:
        return numbers
    if len(numbers) == 1:
        return numbers + 1
    numbers.sort()
    return numbers[-1]
