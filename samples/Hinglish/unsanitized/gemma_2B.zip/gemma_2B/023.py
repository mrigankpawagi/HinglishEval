

def strlen(string: str) -> int:
    """
    Diye gaye string ki length return karo
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)


def is_palindrome(string: str) -> bool:
    """
    Diye gaye string palindrome hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay hay