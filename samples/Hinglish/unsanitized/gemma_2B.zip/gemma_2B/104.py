
def unique_digits(x):
    """
    Diye gaye positive integers ki list x me Woh saare elements ki sorted list return karo jisme koi bhi even digit nahi hai.

    Dhyan de: Return ki gayi list ko increasing order me sort kiya jana chahiye.
    
    Jaise ki:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    y=[x]
    y.sort()
    k=0
    # while(y[k+1]-y[k+2])%2!=0:
    if y[k+1]%2:
        y.remove(y[k+1])
    return y
x=[1,52,22,10]
assert unique_digits(x) == [1, 52, 22]
