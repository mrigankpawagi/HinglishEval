
def add_elements(arr, k):
    """
    Ek non-empty array of integers arr aur ek integer k diya gaya hai, pehle k elements mein se jinme maximum do digits hai unka sum return karo.

    Udaharan:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """
    
    # add_1_digit solutions
    max_sum = int(arr[0])
    arr = arr[1:]
    
    
    
    # first add two number's digits
    for i in range(len(arr)):
        curr_sum = arr[i] * 10
        curr_sum += arr[i + 1]
        if str(curr_sum)[0] == str(max_sum)[0]:
            return max_sum
        else:
            continue

    # if not two element is there in given elements
    if len(arr) > 1:
        max_sum = min(arr[: k]) ** 2
        arr2 = arr[:]
        for i  in range(k + 1):
            arr2[i] = arr2[i] * 10
        curr_sum = (arr2[0] + arr2[k]) * 10 
        for i in range(k):
            curr_sum += arr2[i + 1]
        max_sum = int(max_sum ** 2)
        if curr_sum != float('inf'):
            return curr_sum

    raise RuntimeError('Error')
