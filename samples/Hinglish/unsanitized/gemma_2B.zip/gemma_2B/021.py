from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """
    Diye gaye numbers ki list (kam se kam do elements ki) par ek linear transform apply karo,
    aisa ki sabse chota number 0 ban jaye aur sabse bada number 1 ban jaye
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    biggest = max(numbers)

    numbers_copy = numbers.copy()

    for i in range(len(numbers_copy)):
        numbers_copy[i] = numbers_copy[i] / biggest

    return numbers_copy


def linear_transform(numbers: List[float]) -> List[float]:
    """
    Diye gaye numbers ki list par linear transform apply karo

    >>> linear_transform([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 1.0, 1.25, 1.50, 1.75]

    >>> linear_transform([1.0, 100.0, 2.0, 100.0])
    [0.0, 1.0, 0.25, 1.0]
    """

    mean = sum(numbers) / len(numbers)

    return [(float(number) - mean) / max(numbers) for number in numbers]


def square_transform(numbers: List[float]) -> List[float]:
    """
    Diye gaye numbers ki list par square transform apply karo

    >>> square_transform([1.0, 100.0, 1.0, 1.0])
    [1.0, 100.0, 1.0, 1.0]

    >>> square_transform([1.0, 1.0, 1.0, 100.0])
    [1.0, 1.0, 1.0, 100.0]
    """

    return [number*number for number in numbers]


if __name__ == "__main__":
    # Testing
    print(rescale_to_unit([1.0, 2.0, 3.0]))
    print(linear_transform([1.0, 2.0, 3.0, 4.0, 5.0]))
    assert square_transform([1.0, 1.0, 1.0, 100.0]) == [1.0, 1.0, 1.0, 100.0