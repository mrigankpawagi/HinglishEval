def skjkasdkd(lst):
    """
    Aapko ek list di gayi hai integers ki.
    Aapko sabse bada prime value dhundna hai aur uske digits ka sum return karna hai.

    Udaharan:
    Agar lst = [0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3] hai to output hona chahiye 10
    Agar lst = [1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1] hai to output hona chahiye 25
    Agar lst = [1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3] hai to output hona chahiye 13
    Agar lst = [0,724,32,71,99,32,6,0,5,91,83,0,5,6] hai to output hona chahiye 11
    Agar lst = [0,81,12,3,1,21] hai to output hona chahiye 3
    Agar lst = [0,8,1,2,1,7] hai to output hona chahiye 7
    """
    # Your code here
    # print(lst)
    # print(lst.count(1))
    # print(lst.count(2))
    # print(lst.count(3))
    # print(lst.count(4))
    # print(lst.count(5))
    # print(lst.count(6))
    # print(lst.count(7))
    # print(lst.count(8))
    # print(lst.count(9))
    # print(lst.count(0))
    # print(lst.count(10))
    # print(lst.count(11))
    # print(lst.count(12))
    # print(lst.count(13))
    # print(lst.count(14))
    # print(lst.count(15))
    # print(lst.count(16))
    # print(lst.count(17))
    # print(lst.count(18))
    # print(lst.count(19))
    # print(lst.count(20))
    # print(lst.count(21))
    # print(lst.count(22))
    # print(lst.count(23))
    # print(lst.count(24))
    # print(lst.count(25))
    # print(lst.count(26))
    # print(lst.count(27))
    # print(lst.count(28))
    # print(lst.count(29))
    # print(lst.count(30))
    # print(lst.count(31))
    # print(lst.count(32))
    # print(lst.count(33))
    # print(lst.count(34))
    # print(lst.count(35))
    # print(lst.count(36))
    # print(lst.count(37))
    # print(lst.count(38))
    # print(lst.count(39))
    # print(lst.count(40))
    # print(lst.count(41))
    # print(
