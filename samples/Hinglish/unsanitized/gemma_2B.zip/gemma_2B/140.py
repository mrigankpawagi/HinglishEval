
def fix_spaces(text):
    """
    Diye gaye string text mein, saare spaces ko underscores se replace karo,
    aur agar ek string mein 2 se zyada consecutive spaces ho,
    toh saare consecutive spaces ko - se replace karo.
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    if len(text) == 0:
        return text 
    else:
        if text[-4:]==" ".join(text.split()):
            text = "-".join(text.split())
        elif " " not in text:
            return text
        s = "_".join([x if x == " " else x for x in text[1:-4]])
        if len(s)==5:
            return s
        else:
            if not s[0] == text[0]:
                return "_" +text[0]+"_".join(s[1:])
            else:
                return text
        
        

testcases = [
    ('Example', 'Example'),
    ('Example 1', 'Example_1'),
    (' Example 2', '_Example_2'),
    (' Example   3', '_Example-3'),
    
    ('0012       3', '0012_3'),
    ('0012       3123123', '0012 _3123123'),
    ('0       3123123', '-0_3123123'),
    ('0-1       3123123', '-0_1_3123123'),
    ('0      9000000       13212', '0-9000000_13212'),
    ('01       3123       1', '-0_1_3123_1'),
    ('0       -1       2123', '0-11_-11_2123'),
    ('010121       3   1', '-01_10121_3_1'),
    ('001      12       3123', '_001_12_3123'),
]
import sys
for (case, expected) in testcases:
    result = fix_spaces(case)
    print(int(result== expected) )
if __name__ == '__main__':
    print ("*** Ok  ***")
