 Here is the Python function that matches your requirements:

```python
import re

def remove_vowels(text):
    """
    remove_vowels ek function hai jo string leta hai aur vowels ke bina string return karta hai.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    vowels = set('aeiouAEIOU')
    return re.sub('[aeiouAEIOU]', '', text)
```

This function uses the `re` module to remove all vowels from the input string. The `re.sub()` function replaces all occurrences of vowels with an empty string, effectively removing them. The `set()` function is used to create a set of vowels for easier matching with the `re.sub()` function.