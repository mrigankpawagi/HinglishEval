 Here is the Python function that implements the required behavior:

```python
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """
    Finds two closest numbers from the given numbers list.
    """
    if len(numbers) < 2:
        raise ValueError("The list must contain at least two numbers.")

    min_diff = float('inf')
    closest_numbers = (None, None)

    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            diff = abs(numbers[i] - numbers[j])
            if diff < min_diff:
                min_diff = diff
                closest_numbers = (numbers[i], numbers[j])

    return closest_numbers
```

This function iterates through all pairs of numbers in the input list and finds the pair with the smallest difference. It then returns the two numbers as a tuple in ascending order. If there are multiple pairs with the same smallest difference, it chooses any one of them.