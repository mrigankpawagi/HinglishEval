 Here is the Python function that matches the provided docstring:

```python
def sort_even(l: list):
    """
    This function takes a list l and returns a new list l' such that:
    l' contains the elements of l at odd indices, but sorted, while the elements
    at even indices of l' are the same as the elements at even indices of l,
    but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    odd_indices = l[1::2]
    even_indices = l[0::2]
    odd_sorted = sorted(odd_indices)
    even_sorted = sorted(even_indices)
    return odd_sorted + even_sorted[::-1]
```

This function first separates the odd and even indices of the input list, sorts the odd indices, and then reverses the sorted even indices to maintain the original order of even indices in the output list. The function then concatenates the sorted odd indices and reversed even indices to form the final output list.