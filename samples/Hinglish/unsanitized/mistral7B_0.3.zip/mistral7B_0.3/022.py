 Here is the completed function:

```python
from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    """
    Filter the given Python values list to only include integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    return list(filter(lambda x: isinstance(x, int), values))
```

This function uses a lambda function to check if each element in the input list is an integer, and then uses the built-in `filter()` function to filter out the non-integer elements. The filtered list is then converted back to a list using the `list()` function.