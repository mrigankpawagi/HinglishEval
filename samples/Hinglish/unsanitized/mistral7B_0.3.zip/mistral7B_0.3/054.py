 Here is the Python function that matches the given docstring:

```python
def same_chars(s0: str, s1: str):
    """
    Check if two strings have the same characters.
    """
    return set(s0) == set(s1)
```

This function creates a set of characters from both strings and compares them using the `==` operator. If the sets are equal, it means both strings have the same characters, and the function returns `True`. Otherwise, it returns `False`.