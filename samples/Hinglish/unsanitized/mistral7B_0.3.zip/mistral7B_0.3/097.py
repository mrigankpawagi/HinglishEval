 Here is the completed function:

```python
def multiply(a, b):
    """
    Do integers ka input lekar unke unit digits ka product return karega ye function.
    Maan lo ki input hamesha valid hoga.
    Udaharan:
    multiply(148, 412) ka return hoga 16.
    multiply(19, 28) ka return hoga 72.
    multiply(2020, 1851) ka return hoga 0.
    multiply(14,-15) ka return hoga 20.
    """
    return (a % 10) * (b % 10)
```

This function calculates the product of the unit digits of the two input integers. It does this by taking the modulus of each number with 10 to get the unit digit, and then multiplying the two unit digits together.