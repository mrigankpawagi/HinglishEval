 Here is the Python function that fulfills the given docstring:

```python
def encrypt(s):
    """
    A function that takes a string as an argument and returns an encrypted string
    where alphabets are rotated by two places.
    """
    encrypted_string = ""
    for char in s:
        if char.isalpha():
            ascii_offset = ord('a')
            new_ascii = (ord(char) - ascii_offset + 2) % 26 + ascii_offset
            encrypted_string += chr(new_ascii)
        else:
            encrypted_string += char
    return encrypted_string
```

This function iterates through each character in the input string. If the character is an alphabet, it calculates the new ASCII value by adding 2 to the current ASCII value, subtracting the ASCII offset of 'a', and taking the modulus of 26 to ensure the new ASCII value stays within the range of ASCII values for lowercase letters. If the character is not an alphabet, it simply adds it to the encrypted string without modification.