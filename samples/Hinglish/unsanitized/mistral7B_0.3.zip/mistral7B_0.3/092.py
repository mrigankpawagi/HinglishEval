 Here is the completed Python function:

```python
def any_int(x, y, z):
    """
    A function that takes 3 numbers.
    If one number is the sum of the other two numbers and all numbers are integers, then return True.
    Return False for any other case.

    Examples
    any_int(5, 2, 7) ➞ True

    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True

    any_int(3.6, -2.2, 2) ➞ False
    """
    return (x == y + z) and (isinstance(x, int) and isinstance(y, int) and isinstance(z, int))
```

This function checks if one number is the sum of the other two numbers and if all numbers are integers. If both conditions are met, it returns True; otherwise, it returns False.