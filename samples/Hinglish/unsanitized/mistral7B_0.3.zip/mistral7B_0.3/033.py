 Here is the Python function that meets the requirements:

```python
def sort_third(l: list):
    """
    This function takes a list l and returns a new list l' such that:
    l' contains the elements from l at indices where the element is not divisible by 3,
    and the elements from l at indices where the element is divisible by 3 are replaced with the corresponding indices' values from l, sorted.
    """
    divisible_by_three = [i for i, x in enumerate(l) if x % 3 == 0]
    sorted_indices = sorted(divisible_by_three)
    non_divisible_by_three = [l[i] for i in [x for x in range(len(l)) if x not in divisible_by_three]]
    return non_divisible_by_three + [l[i] for i in sorted_indices]
```

This function first creates a list of indices that are divisible by 3, then sorts those indices. It then creates a list of elements from the original list at indices that are not divisible by 3. Finally, it combines the two lists by appending the sorted indices' values to the non-divisible-by-three list.