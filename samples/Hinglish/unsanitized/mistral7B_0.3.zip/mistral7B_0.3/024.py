 Here is the completed function:

```python
def largest_divisor(n: int) -> int:
    for i in range(1, n):
        if n % i == 0 and i < n:
            return i
    return n
```

This function iterates through numbers from 1 to n, checks if the current number evenly divides n, and if so, returns it. If no such number is found, it returns n itself.