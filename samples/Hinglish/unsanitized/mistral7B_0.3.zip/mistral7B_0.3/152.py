 Here is the Python function that follows the given docstring:

```python
def compare(game, guess):
    assert len(game) == len(guess), "Both arrays should have the same length"
    result = [abs(game[i] - guess[i]) for i in range(len(game))]
    return result
```

This function takes two lists (arrays) as input, `game` and `guess`, and returns a new list with the same length. Each element in the returned list represents the absolute difference between the corresponding elements in the `game` and `guess` lists. If the guess was correct, the value will be 0; otherwise, it will be the absolute difference between the game and guess scores.