 Here is the Python function that fulfills the given docstring:

```python
def select_words(s, n):
    words = s.split()
    result = []
    for word in words:
        if len(word) == n and all(char.isalpha() and not char.isupper() for char in word):
            result.append(word)
    return result
```

This function splits the input string into words, iterates through each word, checks if the word has the desired length (n) and consists only of lowercase letters (consonants), and appends the word to the result list if it meets the criteria. Finally, it returns the result list.