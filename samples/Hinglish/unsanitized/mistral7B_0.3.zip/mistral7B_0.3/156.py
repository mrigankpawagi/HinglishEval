 Here is the implementation of the function `int_to_mini_roman`:

```python
def int_to_mini_roman(number):
    """
    Convert a positive integer to its equivalent string representation in mini-Roman numerals,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    True
    >>> int_to_mini_roman(152) == 'clii'
    True
    >>> int_to_mini_roman(426) == 'cdxxvi'
    True
    """
    roman_dict = {1: 'i', 5: 'v', 10: 'x', 50: 'l', 100: 'c', 500: 'd', 1000: 'm'}
    result = []
    for num, roman in roman_dict.items():
        while number >= num:
            number -= num
            result.append(roman)
    return ''.join(reversed(result))
```

This function uses a dictionary to map numbers to their corresponding Roman numerals. It then iterates through the dictionary in descending order of the numbers and appends the corresponding Roman numeral to the result list as many times as possible until the number becomes smaller than the current number in the dictionary. Finally, it joins the result list in reverse order and returns the result.