 Here is the Python function that meets the requirements:

```python
def sort_array(arr):
    """
    Sorts an array of non-negative integers in ascending order based on the count of ones in their binary representation.
    If the count of ones is the same, sort the numbers based on their decimal value.
    """

    def count_ones(num):
        count = 0
        while num > 0:
            num &= (num - 1)
            count += num
        return count

    def sort_by_ones_count(a, b):
        return cmp(count_ones(a), count_ones(b)) if count_ones(a) != count_ones(b) else cmp(a, b)

    arr.sort(key=sort_by_ones_count)
    return arr
```

This function first defines two helper functions: `count_ones` to count the number of ones in a binary representation of a number, and `sort_by_ones_count` to compare two numbers based on the count of ones in their binary representation. The main `sort_array` function then sorts the input array using the `sort_by_ones_count` function as the sort key.