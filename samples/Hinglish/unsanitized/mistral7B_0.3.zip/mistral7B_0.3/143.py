 Here is the completed Python function:

```python
def words_in_sentence(sentence):
    words = sentence.split()
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
    result = []
    for word in words:
        if len(word) in primes:
            result.append(word)
    return " ".join(result)
```

This function splits the input sentence into words, creates a list of prime numbers up to 97, iterates through the words, checks if their length is a prime number, and appends them to a new list. Finally, it joins the words in the new list with spaces and returns the result.