 Here is the Python function with the implementation:

```python
def move_one_ball(arr):
    """
    ...
    """
    n = len(arr)
    for _ in range(n-1):
        if arr[i] > arr[i+1] for i in range(n-1):
            arr.append(arr.pop(0))
            if all(arr[i] <= arr[i+1] for i in range(n)):
                return True
    return len(arr) == 0
```

This function uses a loop to perform right shift operations on the given array. It checks if the array is in non-decreasing order after each operation. If the array becomes sorted, it returns True. If the loop completes without the array becoming sorted and the array is empty, it also returns True.