 Here is the completed function:

```python
def string_sequence(n: int) -> str:
    return " ".join(str(i) for i in range(n))
```

This function generates a string with numbers from 0 to n-1, separated by spaces. The `join` function is used to concatenate the numbers into a single string.