 Here is the completed function:

```python
def unique_digits(x):
    """
    Given a list of positive integers x, return a sorted list of those integers where no even digits are present.

    Note: The returned list should be sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    return sorted([num for num in x if all(digit % 2 != 0 for digit in list(str(num)))])
```

This function uses a list comprehension to create a new list containing only the numbers from the input list `x` that do not have any even digits. The `all(digit % 2 != 0 for digit in list(str(num)))` part checks if all digits of the number are odd. The `sorted` function is then used to sort the resulting list in increasing order.