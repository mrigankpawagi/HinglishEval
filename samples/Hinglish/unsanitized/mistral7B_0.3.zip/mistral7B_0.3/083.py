 Here is the completed function:

```python
def starts_one_ends(n):
    """
    Diye gaye positive integer n ke liye, n-digit wale positive integers ki ginti return karo jo 1 se start hote hain ya 1 pe end hote hain.
    """
    numbers = []
    for i in range(10**(n-1), 10**n):
        if str(i)[0] == '1' or str(i)[-1] == '1':
            numbers.append(i)
    return numbers
```

This function generates numbers from 10^(n-1) to 10^n, converts them to strings, checks if the first or last digit is 1, and if so, appends the number to the `numbers` list. Finally, it returns the list of numbers that meet the criteria.