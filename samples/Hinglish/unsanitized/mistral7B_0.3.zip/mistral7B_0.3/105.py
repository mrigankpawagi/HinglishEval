 Here is the completed Python function:

```python
def by_length(arr):
    """
    Sort the given array of integers, reverse the sorted array, and replace each digit with its corresponding name.
    If the array is empty, return an empty array. Ignore any odd numbers in the array.
    """
    digits = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
    digits_mapping = dict((digit, i) for i, digit in enumerate(digits))
    sorted_arr = sorted([num for num in arr if 0 < num < 10])
    reversed_arr = sorted_arr[::-1]
    result = []
    for num in reversed_arr:
        if num in digits_mapping:
            result.append(digits[digits_mapping[num]])
        else:
            result.append('Unknown')
    return result
```

This function first filters out any numbers outside the range 1-9, sorts the remaining numbers, reverses the sorted list, and then replaces each number with its corresponding name. If there are any numbers that are not in the range 1-9, they will be replaced with 'Unknown'. If the input array is empty, the function will return an empty list.