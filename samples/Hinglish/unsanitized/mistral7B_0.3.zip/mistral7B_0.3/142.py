 Here is the completed Python function:

```python
def sum_squares(lst):
    """
    This function takes a list of integers. The function will square an integer entry if its index is a multiple of 3, and cube it if its index is a multiple of 4 and not a multiple of 3. The function will not change entries whose indexes are not multiples of 3 or 4. Finally, the function will sum all the entries and return the result.

    Examples:
    If lst = [1,2,3], the output should be 6
    If lst = [], the output should be 0
    If lst = [-1,-5,2,-1,-5], the output should be -126
    """
    result = 0
    for i, num in enumerate(lst):
        if i % 3 == 0:
            result += num ** 2
        elif i % 4 == 0 and i % 3 != 0:
            result += num ** 3
    return result
```

This function iterates through the list, checks if the index of each number is a multiple of 3 or 4, and squares or cubes the number accordingly. It then sums up all the squared or cubed numbers and returns the result.