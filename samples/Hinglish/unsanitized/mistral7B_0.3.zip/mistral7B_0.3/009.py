 Here is the implementation of the `rolling_max` function:

```python
from typing import List

def rolling_max(numbers: List[int]) -> List[int]:
    """
    Generate a list of rolling maximum elements from the given list of integers.
    """
    rolling_maximum = []
    current_max = numbers[0]
    for num in numbers[1:]:
        current_max = max(num, current_max)
        rolling_maximum.append(current_max)
    return rolling_maximum
```

This function uses a sliding window approach to find the rolling maximum. It initializes the current maximum with the first number in the list and then iterates through the rest of the numbers, updating the current maximum and appending it to the result list.