 Here is the completed function with additional test cases:

```python
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Count the number of vowels in a given string.
    """
    vowels = "aeiouAEIOU"
    count = sum(1 for char in s if char in vowels)
    return count

# Test cases
assert vowels_count("hello") == 3
assert vowels_count("Python") == 2
assert vowels_count("aeiou") == 5
assert vowels_count("") == 0
assert vowels_count("12345") == 0
```

This function counts the number of vowels in a given string and includes both lowercase and uppercase vowels. The test cases cover strings with different lengths, including empty strings and strings containing only numbers.