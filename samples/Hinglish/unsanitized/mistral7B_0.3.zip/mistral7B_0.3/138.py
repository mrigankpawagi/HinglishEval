 Here is the Python function that fulfills the given docstring:

```python
def is_equal_to_sum_even(n):
    """
    Evaluate if the given number n can be exactly the sum of 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def is_even(num):
        return num % 2 == 0

    def find_combinations(target, current_sum, current_combination):
        if current_sum > target:
            return
        if current_sum == target:
            return current_combination
        for i in range(2, int(n**0.5) + 1):
            if is_even(i) and not i in current_combination:
                new_combination = current_combination + (i,)
                find_combinations(target, current_sum + i, new_combination)
                find_combinations(target, current_sum, new_combination)

    return any(find_combinations(n, 0, ()) for _ in range(n//2))
```

This function uses recursion to find all possible combinations of 4 positive even numbers that sum up to the given number `n`. It first checks if the current sum is equal to `n` or exceeds it, and if it's equal, it returns the current combination. If the current sum is less than `n`, it iterates through all even numbers from 2 to the square root of `n` and checks if the number is not already in the current combination. If it's not, it creates a new combination and calls the `find_combinations` function recursively with the updated current sum and combination. The outer loop runs the function for all possible combinations of 2 even numbers, ensuring that the remaining 2 even numbers will also be even. Finally, the `any` function checks if any of the combinations found sum up to `n`, and returns `True` if so.