 ```python
def pluck(arr):
    even_values = [i for i in arr if i % 2 == 0]
    if not even_values:
        return []
    return min(enumerate(even_values), key=lambda x: x[1])
```

This function first filters the array to only include even values. If there are no even values, it returns an empty list. Otherwise, it finds the minimum tuple (value, index) from the filtered list using the `min()` function with a custom comparison function `lambda x: x[1]` that sorts the tuples by their second element (index). This ensures that the function returns the even value with the smallest index.