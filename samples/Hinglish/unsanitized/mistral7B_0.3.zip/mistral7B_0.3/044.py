 Here is the implementation of the `change_base` function in Python:

```python
def change_base(x: int, base: int) -> str:
    if base < 2 or base > 10:
        raise ValueError("Base must be between 2 and 10")

    digits = "0123456789ABCDEF"
    result = []

    while x != 0:
        x, remainder = divmod(x, base)
        result.append(digits[remainder])

    return "".join(result[::-1])
```

This function converts an integer `x` from a given base to another base. It raises a `ValueError` if the base is not between 2 and 10. The conversion is done using the division and modulo operations, and the result is stored in reverse order. Finally, the result is joined into a single string and returned.