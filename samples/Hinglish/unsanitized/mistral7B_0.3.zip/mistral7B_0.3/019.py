 Here is the completed function:

```python
from typing import List
from collections import OrderedDict

def sort_numbers(numbers: str) -> str:
    """
    Input ek space-delimited string hai jisme 'zero' se 'nine' tak ke numerals hain.
    Valid choices 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' aur 'nine' hain.
    Return karo string ko jisme numbers smallest se largest tak sorted honge
    >>> sort_numbers('three one five')
    'one three five'
    """
    numbers_dict = OrderedDict(sorted(
        [(num, i) for i, num in enumerate(['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'])]))
    sorted_numbers = [numbers_dict[num] for num in numbers.split()]
    return ' '.join(sorted_numbers)
```

This function uses an OrderedDict to store the numbers in the correct order, then iterates through the input string, looking up each number in the OrderedDict and replacing it with the sorted index. Finally, it joins the sorted indices back into a string and returns it.