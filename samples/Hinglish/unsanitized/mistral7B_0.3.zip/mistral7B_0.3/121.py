 Here is the completed function:

```python
def solution(lst):
    """
    Ek non-empty list di gayi hai integers ki, return karo sum of all odd elements jo even positions pe hain.

    Udaharan
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    return sum(i for i, pos in enumerate(lst) if i % 2 == 0 and i % 3 == 1)
```

This function uses a generator expression to iterate through the list, checking if the index (position) is even and the number is odd. If both conditions are met, it adds the number to the sum. The `sum()` function then calculates the total sum of the odd numbers at even positions.