 Here is the Python function that fulfills the given docstring:

```python
def largest_smallest_integers(lst):
    """
    A function that returns a tuple (a, b) where 'a' is the largest negative integer and 'b' is the smallest positive integer in the given list. If there are no negative or positive integers, return None for both.

    Example:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    """
    neg_max = None
    pos_min = None

    for num in lst:
        if num < 0 and neg_max is None or num < neg_max:
            neg_max = num

        if num > 0 and pos_min is None or num < pos_min:
            pos_min = num

    return neg_max, pos_min
```

This function iterates through the given list and keeps track of the largest negative number (`neg_max`) and the smallest positive number (`pos_min`). If no negative or positive numbers are found, both `neg_max` and `pos_min` will remain `None`.