 Here is the completed function:

```python
def check_dict_case(dict):
    """
    Check if all keys in the dictionary are either lower case or upper case strings.
    If the given dictionary is empty, the function should return False.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    all_lower = all(isinstance(key, str) and key.islower() for key in dict.keys())
    all_upper = all(isinstance(key, str) and key.isupper() for key in dict.keys())
    return all_lower or all_upper
```

This function checks if all keys in the given dictionary are either lower case or upper case strings. If there are keys that are neither lower case nor upper case, the function returns False. If all keys are either lower case or upper case, the function returns True. If the dictionary is empty, the function also returns False.