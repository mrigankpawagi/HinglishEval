 Here is the solution for the function `minSubArraySum`:

```python
def minSubArraySum(nums):
    """
    Find the minimum sum of any non-empty sub-array in the given integer array nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    min_so_far = float('inf')
    current_sum = 0

    for num in nums:
        current_sum += num
        if current_sum < min_so_far:
            min_so_far = current_sum
        if current_sum < 0:
            current_sum = 0

    return min_so_far
```

This function iterates through the given array and keeps track of the minimum sum found so far and the current sum. If the current sum is less than the minimum sum found so far, it updates the minimum sum. If the current sum becomes negative, it resets the current sum to 0. The function returns the minimum sum found.