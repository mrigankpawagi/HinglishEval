 Here is the completed function:

```python
def even_odd_count(num):
    """
    Given an integer, return a tuple that shows the count of even and odd digits in the number.

    Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    count_even, count_odd = 0, 0
    while num > 0:
        digit = num % 10
        if digit % 2 == 0:
            count_even += 1
        else:
            count_odd += 1
        num //= 10
    return count_even, count_odd
```

This function calculates the count of even and odd digits in a given number by iterating through the digits from the least significant digit to the most significant digit. It uses a while loop to iterate through the digits and a conditional statement to check if the current digit is even or odd. The count of even and odd digits is stored in separate variables, and the function returns a tuple containing the counts at the end.