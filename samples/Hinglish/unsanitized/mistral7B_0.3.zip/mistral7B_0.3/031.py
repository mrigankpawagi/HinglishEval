 Here is the implementation of the `is_prime` function in Python:

```python
def is_prime(n):
    """
    Agar diya gaya number prime hai to true return karo, aur anyatha false.
    """
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
```

This function checks if a number is prime by iterating through all numbers up to the square root of the given number and checking if the number is divisible by any of them. If the number is not divisible by any of them, it is considered prime. The function returns `False` for numbers less than or equal to 1, as they are not considered prime numbers.