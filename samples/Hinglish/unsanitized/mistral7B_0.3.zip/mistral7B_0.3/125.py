 ```python
def split_words(txt):
    words = txt.split()
    if not words:
        words = [c for c in txt if c.isalpha() if ord(c) % 2 == 1]
        return len(words) if not words else [words[i] for i in range(len(words)) if i % 2 == 0]
    return words
```

This function first splits the input string by whitespace. If the resulting list is empty, it checks if the input string contains only alphabetic characters. If so, it returns the count of odd-indexed lowercase letters. If the list of words is not empty, it returns the list of words.