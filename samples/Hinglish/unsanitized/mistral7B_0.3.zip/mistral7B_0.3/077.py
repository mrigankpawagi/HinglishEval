 Here is the completed function:

```python
def iscube(a):
    """
    A function that takes an integer and returns True if the integer is a cube of another integer.
    Note: It is assumed that the input will always be valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    """
    for i in range(1, int(a**(1/3))+1):
        if i**3 == a:
            return True
    return False
```

This function checks if the input number `a` is a cube by iterating through numbers from 1 to the cube root of `a` and comparing each cube with `a`. If it finds a match, it returns `True`, otherwise it returns `False`.