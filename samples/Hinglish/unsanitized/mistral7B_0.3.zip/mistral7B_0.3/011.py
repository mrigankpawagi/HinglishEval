 Here is the completed function:

```python
from typing import List

def string_xor(a: str, b: str) -> str:
    """
    Input do strings a aur b honge jo sirf 1s aur 0s se bane honge.
    In inputs par binary XOR perform karo aur result ko bhi ek string ke roop mein return karo.
    >>> string_xor('010', '110')
    '100'
    """
    return ''.join(str(int(a[i]) ^ int(b[i])) for i in range(len(a)))
```

This function performs bitwise XOR operation on the two input strings and returns the result as a string. The `^` operator is used for bitwise XOR in Python. The `join()` function is used to combine the results of the XOR operation into a single string. The `int()` function is used to convert each character (either '0' or '1') into its corresponding integer value before performing the XOR operation.