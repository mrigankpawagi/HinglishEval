 Here is the completed function:

```python
from typing import List

def concatenate(strings: List[str]) -> str:
    """
    Strings ki list ko ek single string mein jodo
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(strings)
```

This function uses the `join()` method to concatenate the strings in the list. The `join()` method takes a string as an argument and returns a new string where each element of the list is replaced by the given string. In this case, we are using an empty string as the separator, so the elements of the list are joined together without any spaces.