 Here is the Python function for the given problem statement. The function uses BFS (Breadth-First Search) algorithm to find the minimum number of times the bucket needs to be filled.

```python
from collections import deque

def max_fill(grid, capacity):
    m, n = len(grid), len(grid[0])
    visited = [[False] * n for _ in range(m)]
    queue = deque()
    water_filled = 0

    for i in range(m):
        for j in range(n):
            if grid[i][j] == 1 and not visited[i][j]:
                queue.append((i, j))
                visited[i][j] = True
                water_filled += 1
                break

    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    while queue:
        size = len(queue)
        for _ in range(size):
            x, y = queue.popleft()
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if 0 <= nx < m and 0 <= ny < n and not visited[nx][ny] and grid[nx][ny] == 1:
                    queue.append((nx, ny))
                    visited[nx][ny] = True
                    grid[nx][ny] = 0

        water_to_extract = math.inf
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1:
                    water_to_extract = min(water_to_extract, visited[i][j])

        if water_to_extract > 0:
            for i in range(m):
                for j in range(n):
                    if grid[i][j] == 0:
                        if visited[i][j] >= water_to_extract:
                            grid[i][j] = 1 - water_to_extract
                            visited[i][j] -= water_to_extract
                        else:
                