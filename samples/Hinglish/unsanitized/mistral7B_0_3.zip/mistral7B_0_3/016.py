 Here is the Python function that counts the distinct characters in a given string, ignoring case:

```python
from collections import Counter

def count_distinct_characters(string: str) -> int:
    """
    Ek string di gayi hai, pata karo ki usme kitne alag-alag characters (case ki parwah kiye bina) hain
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(Counter(string.lower()))
```

This function uses the `Counter` class from the `collections` module to count the occurrences of each character in the input string, converting it to lowercase to ignore case. The `len()` function is then used to get the number of distinct characters by counting the number of unique entries in the counter.