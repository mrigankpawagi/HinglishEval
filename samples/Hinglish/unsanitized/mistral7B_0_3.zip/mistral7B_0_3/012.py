 Here is the completed function:

```python
from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    """
    String ki list se, sabse lamba string return karo. Agar same length ke multiple strings ho to pehla string return karo. Agar input list khali ho to None return karo.
    >>> longest([])
    None
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None
    max_length = max(len(string) for string in strings)
    max_strings = [string for string in strings if len(string) == max_length]
    return max_strings[0] if max_strings else strings[0]
```

This function first checks if the input list is empty and returns `None` if it is. Then it finds the maximum length of any string in the list. After that, it creates a new list containing only the strings with the maximum length. If there are multiple strings with the maximum length, it returns the first one. If there are no strings with the maximum length, it returns the first string in the list.