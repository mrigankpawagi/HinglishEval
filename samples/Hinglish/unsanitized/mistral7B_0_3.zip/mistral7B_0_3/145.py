 Here is the Python function that sorts the list of integers based on the sum of their digits in ascending order, maintaining the original order for numbers with the same sum of digits:

```python
def order_by_points(nums):
    """
    A function that sorts a list of integers based on the sum of their digits in ascending order, maintaining the original order for numbers with the same sum of digits.

    Returns:
        A sorted list of integers based on the sum of their digits.
    """
    from functools import reduce
    from operator import add

    def digit_sum(n):
        return sum(int(digit) for digit in str(abs(n)))

    sorted_nums = sorted(nums, key=digit_sum, cmp=lambda x, y: cmp(x, y) if digit_sum(x) != digit_sum(y) else cmp(nums.index(x), nums.index(y)))

    return sorted_nums
```

This function uses the `functools.reduce` and `operator.add` functions to calculate the sum of digits for each number, and the `sorted` function with a custom comparison function to sort the list based on the sum of digits and the original index.