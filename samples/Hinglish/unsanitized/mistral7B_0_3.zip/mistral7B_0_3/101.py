 Here is the completed function:

```python
def words_string(s):
    """
    Aapko ek string di jayegi jisme words commas ya spaces se separated honge. Aapka task hai
    string ko words mein split karna aur words ki array return karna.

    Jaise ki:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    return s.split(',') + s.split(' ')
```

This function uses the `split()` method of strings to separate the input string into a list of words. It splits the string twice, once by commas and once by spaces, and then combines the resulting lists using the `+` operator. This ensures that words separated by spaces are not missed.