 Here is the completed function:

```python
def total_match(lst1, lst2):
    """
    A function that accepts two string lists and returns a list containing all characters from the first list that are not in the second list.
    If both lists contain the same number of characters, return the first list.

    Example:
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    """
    result = [x for x in lst1 if x not in set(lst2)]
    return result if result else lst1
```

This function uses a list comprehension to create a new list containing all elements from `lst1` that are not in `lst2`. It then checks if the resulting list is empty, and if so, it returns `lst1`.