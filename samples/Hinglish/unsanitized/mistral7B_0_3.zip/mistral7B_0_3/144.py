 Here is the Python function that meets the given requirements:

```python
def simplify(x, n):
    """
    Aapka task hai ek function implement karna jo expression
    x * n ko simplify karega. Yeh function True return karega agar x * n ka evaluation ek whole number hota hai aur False
    otherwise. Dono x aur n, fraction ka string representation hai, aur inka format aisa hota hai,
    <numerator>/<denominator> jahan dono numerator aur denominator positive whole numbers hote hain.

    Aap maan sakte hain ki x, aur n valid fractions hain, aur inka denominator zero nahi hota.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    x_num, x_denom = map(int, x.split('/'))
    n_num, n_denom = map(int, n.split('/'))

    return x_num * n_denom == n_num * x_denom or x_num * n_denom // gcd(x_num, x_denom) * (x_denom // gcd(x_num, x_denom)) == n_num * n_denom

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a
```

This function first splits the input strings into their numerator and denominator, then converts them into integers. It then checks if the product of the numerators is equal to the product of the denominators, which would mean the simplified expression is a whole number. If not, it calculates the greatest common divisor (gcd) of the numerator and denominator, and checks if the product of the simplified numerator and denominator is equal to the product of the original numerator and denominator divided by the gcd. If this condition is met, the function returns True, indicating that the simplified expression is a whole number.