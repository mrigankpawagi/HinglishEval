 Here is the completed function:

```python
def is_simple_power(x, n):
    """
    Aapka task hai ek function likhna jo true return kare agar number x, n ka simple
    power hai aur false return kare anya cases mein.
    x n ka simple power hai agar n**int=x
    Jaise ki:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    import math
    return math.isclose(n**math.floor(math.log(x, n)), 1)
```

This function uses the `math.log()` and `math.isclose()` functions to calculate the logarithm of x with base n and check if it is a whole number multiplied by n, which would mean that x is a simple power of n. The `math.floor()` function is used to round down the logarithm to the nearest integer. The `math.isclose()` function is used to account for floating-point precision errors.