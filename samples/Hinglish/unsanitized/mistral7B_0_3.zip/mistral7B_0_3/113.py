 Here is the completed Python function:

```python
def odd_count(lst):
    """
    Given a list of strings, each containing only digits, return a list.
    Each element of the output should be "the number of odd elements in the input string i replaced with the i'th string's number of odd digits."

    >>> odd_count(['1234567'])
    ["input string 4 contains 4 odd digits."]
    >>> odd_count(['3',"11111111"])
    ["input string 1 contains 1 odd digit.",
     "input string 8 contains 8 odd digits."]
    """
    result = []
    for i, s in enumerate(lst):
        odd_count_in_s = sum(1 for c in s if int(c) % 2 != 0)
        result.append(f"input string {i+1} contains {odd_count_in_s} odd digits.")
    return result
```

This function iterates through the input list, calculates the number of odd digits in each string, and appends the result to the output list. The output is then returned.