 Here is the completed function:

```python
import re

def fruit_distribution(s, n):
    """
    This function takes a string that represents a fruit basket and an integer that represents the total number of fruits in the basket. The string contains the number of apples and oranges. The function returns the number of mangoes in the basket.
    """
    fruits = re.findall(r'(\d+) (apples|oranges)', s)
    apples, oranges = map(int, fruits[0])
    total_fruits = n - apples - oranges
    return total_fruits
```

This function uses regular expressions to find the number of apples and oranges in the string, and then calculates the number of mangoes by subtracting the number of apples, oranges, and the given total from the total number of fruits.