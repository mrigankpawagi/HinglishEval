 Here is the completed function:

```python
def add(lst):
    """
    A non-empty list of integers is given as lst. Add even elements at odd indices.

    Example:
        add([4, 2, 6, 7]) ==> 2
    """
    return sum(i for i, num in enumerate(lst) if i % 2 == 1 and num % 2 == 0)
```

This function uses a generator expression to iterate through the list and its indices, and it checks if the index is odd, and the number is even. If both conditions are met, it adds the number to the sum. The `sum()` function then calculates the total sum of the even numbers at odd indices.