 Here is the Python function that follows the given docstring:

```python
def digits(n):
    """
    Ek positive integer n diya gaya hai, odd digits ka product return karo.
    Agar saare digits even hain to 0 return karo.
    Udaharan ke liye:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    product = 1
    for digit in str(n):
        if int(digit) % 2 != 0:
            product *= int(digit)
    return product if product else 0
```

This function converts the input number into a string, then iterates through each digit. If the digit is odd, it multiplies the current product by the digit. If all digits are even, the product will be 0, and the function returns 0. Otherwise, it returns the calculated product.