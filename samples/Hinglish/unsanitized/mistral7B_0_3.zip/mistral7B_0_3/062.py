 Here is the Python function for calculating the derivative of a polynomial given its coefficients:

```python
def derivative(xs: list):
    """
    xs ek polynomial ke coefficients ko represent karte hain.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Is polynomial ka derivative same form mein return karo.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    result = []
    for i in range(1, len(xs)):
        coefficient = xs[i]
        power = i
        new_coefficient = coefficient * power
        result.append(new_coefficient)
    result.insert(0, 0)  # Add 0 as the first coefficient (for the constant term)
    return result
```

This function calculates the derivative of a polynomial by iterating through the coefficients and creating a new list with the derivative coefficients. The derivative of a polynomial is calculated using the formula: `(n+1) * coefficient * x^n`, where `n` is the power of the term and `coefficient` is the coefficient of the term. The first coefficient (the constant term) is set to 0 since it does not have a derivative.