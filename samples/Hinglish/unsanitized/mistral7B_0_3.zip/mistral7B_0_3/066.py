 Here is the completed function:

```python
def digitSum(s):
    """
    Task
    Ek function likho jo ek string ko input ke roop mein leta hai aur sirf upper characters'
    ASCII codes ka sum return karta hai.

    Udaharan:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    return sum(ord(c) for c in s if c.isupper())
```

This function uses a generator expression to iterate over the input string `s`, and for each character `c`, it checks if `c` is an uppercase character using the `isupper()` method. If `c` is an uppercase character, it calculates the ASCII code of `c` using the `ord()` function and adds it to the sum. The `sum()` function then computes the total sum of the ASCII codes.