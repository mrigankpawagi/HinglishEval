 Here is the Python function that removes duplicates from a list of integers, maintaining the original order:

```python
from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    """
    Ek integers ki list se, saare elements hata do jo ek se zyada baar occur karte hain.
    Bache hue elements ka order input ke jaisa hi rakho.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    return list(set(numbers))
```

The `set()` function in Python removes duplicates from the list, and the `list()` function converts the set back into a list to maintain the original order.