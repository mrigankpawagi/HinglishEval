 Here is the completed function:

```python
def prod_signs(arr):
    """
    Aapko ek array arr diya gaya hai integers ka aur aapko return karna hai
    integers ke magnitudes ka sum jo multiplied hoga har number ke signs ka product se
    jo array me diye gaye hain, jo ki 1, -1 ya 0 se represent kiya gaya hai.
    Note: Agar arr khali hai to None return karo.

    Udaharan:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr:
        return None

    product = 1
    for num in arr:
        product *= (1 if num > 0 else -1 if num < 0 else 1)
    return product * sum(arr)
```

This function first checks if the array is empty and returns `None` if it is. Then it initializes a product variable to 1. It iterates through the array, multiplying the product by the sign of each number (1 for positive numbers, -1 for negative numbers, and no change for zero). Finally, it multiplies the product by the sum of the magnitudes of the numbers in the array and returns the result.