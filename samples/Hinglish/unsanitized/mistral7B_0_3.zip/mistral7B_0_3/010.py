 Here is the completion for the `make_palindrome` function:

```python
def make_palindrome(string: str) -> str:
    """
    If the given string is not a palindrome, return the reversed string.
    If the given string is already a palindrome, return the same string.
    """
    if string == string[::-1]:
        return string
    else:
        return string[::-1]
```

This function checks if the given string is a palindrome. If it is, it returns the original string. If it isn't, it returns the reversed string.