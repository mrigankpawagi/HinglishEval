 Here is the Python function that meets the requirements:

```python
def next_smallest(lst):
    """
    Aapko ek list di gayi hai integers ki.
    Ek function likho next_smallest() jo list ka 2nd sabse chhota element return kare.
    Agar aisa koi element nahi hai to None return kare.

    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    if not lst:
        return None
    else:
        lst.sort()
        return lst[1] if lst[1] != lst[0] else None
```

This function first checks if the list is empty and returns `None` if it is. Otherwise, it sorts the list and returns the second element if it is smaller than the first one. If the second element is the same as the first one, it returns `None`.