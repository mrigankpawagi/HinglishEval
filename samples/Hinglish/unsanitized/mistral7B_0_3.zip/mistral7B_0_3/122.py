 Here is the completed Python function:

```python
def add_elements(arr, k):
    """
    Ek non-empty array of integers arr aur ek integer k diya gaya hai, pehle k elements mein se jinme maximum do digits hai unka sum return karo.

    Udaharan:

        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24 # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """
    return sum(sorted(arr)[:k] if len(sorted(arr, key=len))[-1] <= 2 else sorted(arr)[:k-1] + [sorted(arr, key=len)[-1]])
```

This function first sorts the array in ascending order based on the number of digits. Then, it checks if the maximum number of digits in the array is less than or equal to 2. If so, it returns the sum of the first k elements. If not, it returns the sum of the first k-1 elements plus the maximum number in the array, which has more than 2 digits.