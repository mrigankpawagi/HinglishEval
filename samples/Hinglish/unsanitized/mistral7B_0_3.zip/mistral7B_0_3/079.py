 Here is the completed function:

```python
def decimal_to_binary(decimal):
    """
    Aapko ek number decimal form mein diya jayega aur aapka task hai use
    binary format mein convert karna. Function ek string return karega, jisme har character ek binary
    number ko represent karega. String mein har character '0' ya '1' hoga.

    String ke shuru aur ant mein 'db' naam ke kuch extra characters honge.
    Ye extra characters format ke liye diye gaye hain.

    Udaharan:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    binary = bin(decimal)[2:]
    return 'db' + binary.zfill(15) + 'db'
```

This function converts the given decimal number to binary and adds the required 'db' characters at the beginning and end of the binary string. The `zfill(15)` function is used to ensure that the binary string has a length of 15 characters by filling it with leading zeros if necessary.