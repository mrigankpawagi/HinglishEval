 Here is the completed function for Mean Absolute Deviation (MAD) in Python:

```python
from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    """
    Calculate the Mean Absolute Deviation for the given input numbers list.
    Mean Absolute Deviation is the average absolute difference between each element and the mean:
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    n = len(numbers)
    if n == 0:
        raise ValueError("List cannot be empty")

    mean = sum(numbers) / n
    deviations = [abs(x - mean) for x in numbers]
    return sum(deviations) / n
```

This function calculates the Mean Absolute Deviation (MAD) for a given list of numbers. It first checks if the list is empty, and if so, raises a ValueError. Then it calculates the mean of the numbers, creates a list of absolute deviations, calculates the sum of the deviations, and finally returns the average of the deviations.