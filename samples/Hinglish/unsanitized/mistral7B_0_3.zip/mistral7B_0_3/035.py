 Here is the completed function:

```python
def max_element(l: list):
    """
    List mein se maximum element return karo.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    return max(l)
```

The `max()` function in Python returns the largest item in an iterable or the largest of two or more arguments, so it's perfect for this task.