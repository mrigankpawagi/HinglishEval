 Here is the implementation of the `modp` function in Python:

```python
def modp(n: int, p: int):
    """
    2^n modulo p return karo (numerics ka dhyan rakho).
    """
    if n == 0:
        return 1
    elif n % 2 == 0:
        return (modp(n // 2, p) ** 2) % p
    else:
        return (modp(n - 1, p) * n) % p
```

This function calculates 2^n modulo p using the exponentiation by squaring method. It handles the case when n is 0 and returns 1, as per the given examples. The function also handles the case when n is odd by multiplying n with the result of the recursive call with (n-1) and taking the modulo of p.