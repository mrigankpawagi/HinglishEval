 Here is the completed function:

```python
def strlen(string: str) -> int:
    """
    Diye gaye string ki length return karo
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)
```

This function uses the built-in `len()` function in Python to calculate the length of the given string. The `len()` function returns the number of items in an object (in this case, a string).