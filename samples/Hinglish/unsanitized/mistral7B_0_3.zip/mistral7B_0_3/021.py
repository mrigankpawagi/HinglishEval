 Here is the completed function:

```python
from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    """
    Apply a linear transform to the given numbers list (at least two elements) such that the smallest number becomes 0 and the largest number becomes 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    min_num = min(numbers)
    max_num = max(numbers)
    return [(x - min_num) / (max_num - min_num) for x in numbers]
```

This function first finds the minimum and maximum numbers in the input list, then calculates the scaling factor for each number by subtracting the minimum value and dividing by the range (maximum - minimum). The result is a new list where all numbers are scaled between 0 and 1.