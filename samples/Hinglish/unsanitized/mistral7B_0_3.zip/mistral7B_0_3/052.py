 Here is the completed function:

```python
def below_threshold(l: list, t: int):
    """
    Agar list l mein saare numbers threshold t se kam hai to True return karo.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return all(num < t for num in l)
```

The `all()` function in Python returns `True` if all elements in the iterable (in this case, the list `l`) are true (i.e., non-zero). By using a generator expression (`num < t for num in l`), we create an iterable that yields `True` for each number in the list that is less than `t`, and `False` otherwise. The `all()` function then checks if all the yielded values are `True`, and returns `True` if they are, and `False` otherwise. This way, the function returns `True` if all numbers in the list are less than the threshold, and `False` otherwise.