 Here is the Python function that meets the given requirements:

```python
def intersection(interval1, interval2):
    """
    Determine if the length of the intersection of two given intervals is a prime number.
    """
    start, end = sorted([interval1, interval2])
    if end[0] < start[1] or start[0] > end[1]:
        return "NO"

    intersection_length = (min(end[0], end[1]) - max(start[0], start[1])) + 1
    if intersection_length == 0:
        return "NO"

    is_prime = True
    for i in range(2, int(intersection_length) ** 0.5 + 1):
        if intersection_length % i == 0:
            is_prime = False
            break
    return "YES" if is_prime else "NO"
```

This function first checks if the two intervals intersect by comparing their start and end points. If they don't intersect, it returns "NO". If they do intersect, it calculates the length of the intersection and checks if it's equal to 0 (in which case it returns "NO"). Then, it checks if the length is prime by iterating through numbers up to the square root of the length and checking if the length is divisible by any of them. If it's prime, it returns "YES"; otherwise, it returns "NO".