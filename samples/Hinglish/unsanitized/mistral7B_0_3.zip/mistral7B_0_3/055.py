 Here is the implementation of the Fibonacci function:

```python
def fib(n: int):
    """
    n-th Fibonacci number return karo.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n <= 1:
        return n
    else:
        return fib(n-1) + fib(n-2)
```

This function uses recursion to calculate the n-th Fibonacci number. If `n` is less than or equal to 1, it returns `n` itself, as the first two numbers in the Fibonacci sequence are 0 and 1. For larger values of `n`, it calculates the Fibonacci number by adding the previous two Fibonacci numbers.