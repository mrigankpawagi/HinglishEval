 Here is the Python function that fulfills the given docstring:

```python
def specialFilter(nums):
    """
    A function that takes a list of numbers as input and returns the count of elements that are greater than 10 and have an odd first and last digit.
    """
    return sum(1 for num in nums if 10 < num and (num // 10 % 2 == 1) and (num % 10 % 2 == 1))
```

This function uses a generator expression to iterate through the input list and checks if each number is greater than 10, has an odd first digit (`num // 10 % 2 == 1`), and an odd last digit (`num % 10 % 2 == 1`). The `sum()` function is then used to count the number of such elements.