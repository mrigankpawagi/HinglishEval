 Here is the completed function:

```python
def is_bored(S):
    """
    Aapko ek string di jayegi jisme words honge, aur aapka task hai ginna ki kitne boredoms hai. Ek boredom woh sentence hota hai jo "I" word se start hota hai.
    Sentences ko '.' , '?' ya '!' se alag kiya jata hai.

    Udaharan ke liye:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    bored_count = 0
    for i in range(len(S)):
        if i > 0 and S[i-1] in ['.', '?', '!'] and S[i] == 'I':
            bored_count += 1
    return bored_count
```

This function iterates through the input string and checks if there is a space (indicating a new sentence) followed by an "I" character. If such a condition is met, it increments the bored count. Finally, it returns the total count of bored sentences.