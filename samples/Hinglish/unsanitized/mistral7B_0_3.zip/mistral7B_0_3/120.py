 Here is the Python function that meets the requirements:

```python
def maximum(arr, k):
    arr.sort(reverse=True)
    return arr[:k]
```

This function first sorts the given array in descending order using the `sort()` method. Then it returns the first `k` elements of the sorted array using slicing.