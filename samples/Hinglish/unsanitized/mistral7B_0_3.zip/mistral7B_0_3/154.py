 Here is the Python function with the implementation as per the given docstring:

```python
def cycpattern_check(a, b):
    """
    Aapko 2 words diye gaye hain. Aapko True return karna hai agar dusra word ya uske kisi bhi rotation ko pehle word ke substring mein milta hai
    """
    a += a
    return b in a
```

This function first concatenates the input string `a` with itself, effectively creating all possible rotations of `a`. Then it checks if the input string `b` is present in the extended string `a`. If `b` is found, the function returns `True`, otherwise it returns `False`.