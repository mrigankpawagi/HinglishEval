 Here is the Python function that matches the given docstring:

```python
def f(n):
    """
    Function f that takes n as a parameter and returns a list of size n,
    such that the index i element's value is i! if i is even,
    or the sum of numbers from 1 to i otherwise.
    i's factorial is the multiplication of numbers from 1 to i (1 * 2 * ... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    result = [0] * n
    for i in range(n):
        if i % 2 == 0:
            result[i] = 1 if i == 0 else result[i - 1] * i
        else:
            result[i] = sum(range(1, i + 1))
    return result
```

This function initializes a list with zeros of length `n`, then iterates through the list, calculating the factorial for even indices and the sum of numbers from 1 to `i` for odd indices. The `sum(range(1, i + 1))` function calculates the sum of numbers from 1 to `i`.