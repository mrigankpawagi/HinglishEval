 Here is the Python function that meets the given requirements:

```python
def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    fib_sequence = [0, 1]
    primes = [2]

    while len(fib_sequence) < n:
        next_fib = fib_sequence[-1] + fib_sequence[-2]
        if is_prime(next_fib):
            primes.append(next_fib)
            fib_sequence.append(next_fib)
        else:
            fib_sequence.append(next_fib)

    return fib_sequence[n - 1]

def is_prime(n: int) -> bool:
    """
    Checks if a number is prime.
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True
```

The `prime_fib` function generates a sequence of Fibonacci numbers and checks if each number is prime. If a number is both Fibonacci and prime, it is returned as the n-th prime Fibonacci number. The `is_prime` function checks if a given number is prime.