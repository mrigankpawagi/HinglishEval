 Here is the completed function:

```python
def truncate_number(number: float) -> float:
    """
    This function takes a positive floating point number and decomposes it into an integer part (the largest integer smaller than the given number) and decimal part (always less than 1 and remaining part after integer part).
    The function returns the decimal part.
    >>> truncate_number(3.5)
    0.5
    """
    return number - int(number)
```

This function works by subtracting the integer part of the number from the original number, effectively returning the decimal part.