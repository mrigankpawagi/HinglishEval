 Here is the implementation of the `largest_prime_factor` function:

```python
def largest_prime_factor(n: int):
    """
    n ka sabse bada prime factor return karo. Maan lo ki n > 1 hai aur yeh prime nahi hai.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    def is_prime(num):
        if num <= 1:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True

    factors = []
    for i in range(2, n + 1):
        if n % i == 0:
            factors.append(i)

    for factor in factors:
        if is_prime(factor):
            return factor
```

This function first defines a helper function `is_prime` to check if a number is prime. Then it iterates through all possible factors of the input number `n` and checks if any of them are prime. If it finds a prime factor, it returns that factor. If no prime factors are found, it means `n` is prime itself, and the function should return `n`. However, the test cases provided do not cover this edge case.