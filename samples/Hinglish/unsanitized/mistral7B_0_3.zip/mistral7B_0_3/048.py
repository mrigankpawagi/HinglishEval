 Here is the Python function for checking if a string is a palindrome:

```python
def is_palindrome(text: str):
    """
    Checks if the given string is a palindrome
    """
    return text == text[::-1]
```

This function checks if the string is equal to its reverse by using the slicing operator `[::-1]`. If the string is equal to its reverse, it means the string is a palindrome and the function returns `True`. Otherwise, it returns `False`.