 Here is the completed function for the given docstring:

```python
def median(l: list):
    """
    List l ke elements ka median return karo.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    sorted_l = sorted(l)
    n = len(sorted_l)
    if n % 2 == 0:
        return (sorted_l[n//2 - 1] + sorted_l[n//2]) / 2
    else:
        return sorted_l[n//2]
```

This function first sorts the input list and then calculates the median based on whether the list has an even or odd number of elements. If the list has an even number of elements, it returns the average of the two middle elements. If the list has an odd number of elements, it returns the middle element.