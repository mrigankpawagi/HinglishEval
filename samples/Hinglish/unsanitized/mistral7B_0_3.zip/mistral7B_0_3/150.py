 Here is the completed function:

```python
def x_or_y(n, x, y):
    """
    A simple program that returns the value of x if n is a prime number and the value of y otherwise.

    Example:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    """
    if isprime(n):
        return x
    else:
        return y

def isprime(n):
    """
    Checks if a number is prime.

    Example:
    for isprime(7) == True
    for isprime(15) == False
    """
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
```

I've added an `isprime` function to check if the given number `n` is prime. The `x_or_y` function now calls the `isprime` function to determine whether it should return `x` or `y`.