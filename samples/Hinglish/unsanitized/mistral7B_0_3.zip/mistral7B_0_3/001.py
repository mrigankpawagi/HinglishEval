 Here is the Python function that separates the parentheses groups:

```python
import re

def separate_paren_groups(paren_string: str) -> List[str]:
    """
    ...
    """
    # Use regular expressions to find all balanced groups of parentheses
    matches = re.findall(r'\(([^()]*)\)', paren_string)

    # Remove the outer parentheses from the matches
    result = [m[1] for m in matches]

    return result
```

This function uses the `re.findall()` function to find all balanced groups of parentheses in the input string. It then removes the outer parentheses from the matches and returns the result as a list. The regular expression `\(([^()]*)\)` matches any group of parentheses that are balanced and do not contain any other parentheses. The `[^()]` part of the regular expression matches any character except for parentheses.