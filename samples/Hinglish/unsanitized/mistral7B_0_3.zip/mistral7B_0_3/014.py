 Here is the completed function:

```python
from typing import List

def all_prefixes(string: str) -> List[str]:
    """
    Input string ke sabhi prefixes ko shortest se longest tak, list mei return karo
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    prefixes = []
    for i in range(len(string) + 1):
        prefix = string[:i]
        prefixes.append(prefix)
    return prefixes
```

This function generates all prefixes of the given string by iterating over the string and appending substrings of increasing length to a list. The base case is an empty string, which is also a prefix. The function returns the list of all prefixes in the order of increasing length.