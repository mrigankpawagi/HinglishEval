
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Aur test cases jodo.
    """

    return len(s) - s.count('o') - s.count('e')
