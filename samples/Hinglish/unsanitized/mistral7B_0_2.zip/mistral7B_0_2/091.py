 ```python
def is_bored(S):
    boredoms_count = 0
    words = S.split('. ') if S.endswith('.') else S.split('! ') if S.endswith('!') else S.split('? ') else S.split()
    for word in words:
        if word.startswith('I '):
            boredoms_count += 1
    return boredoms_count
```