 ```python
def make_a_pile(n):
    pile = []
    level = n
    while level > 0:
        pile.append(level)
        if level % 2 == 0:
            level += 1
        else:
            level += 2
    return pile
```