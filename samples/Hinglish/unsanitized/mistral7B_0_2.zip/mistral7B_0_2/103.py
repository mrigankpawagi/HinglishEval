 ```python
def rounded_avg(n, m):
    total = (n + sum(range(1, m + 1))) // 2
    avg = total // (m + 1)
    return bin(int(round(avg * (m + 1)))).replace("0b", "") if n <= m else -1
```

This function calculates the average of the numbers from `n` to `m` (inclusive), rounds it to the nearest integer, and converts it to binary. If `n` is greater than `m`, it returns `-1`. Note that the `sum` function is used to calculate the sum of numbers from `1` to `m`. The `//` operator is used for integer division. The `round` function is used to round the average, and the `bin` function is used to convert the rounded integer to binary. The leading "0b" in the binary string is removed using the `replace` method.