 ```python
def will_it_fly(q, w):
    if len(q) == 0:
        return True

    total = sum(q)

    if total > w or (total + len(q) // 2) % 2 != 0:
        return False

    return _will_it_fly_helper(q, w, total // 2)


def _will_it_fly_helper(q, w, target):
    if len(q) == 0:
        return False

    if q[0] > w or target < q[0]:
        return False

    return _will_it_fly_helper(q[1:], w, target - q[0]) or _will_it_fly_helper(q[1:], w, target)
```

This function uses recursion to check if the given list `q` can be balanced and its total sum is less than or equal to the given weight `w`. The helper function `_will_it_fly_helper` checks if the subarray from the second element to the end can be balanced and its total sum is less than or equal to the remaining weight.