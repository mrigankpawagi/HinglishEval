 Here's the completed function:

```python
def truncate_number(number: float) -> float:
    """
    Take a positive floating point number and decompose it into its integer part (the largest integer less than or equal to the number)
    and decimal part (the fractional part, which is always less than 1).

    Return the decimal part.
    >>> truncate_number(3.5)
    0.5
    """
    return number - int(number)
```

Note: The function should return the decimal part of the number, not the integer part as stated in the docstring. The provided solution returns the correct decimal part.