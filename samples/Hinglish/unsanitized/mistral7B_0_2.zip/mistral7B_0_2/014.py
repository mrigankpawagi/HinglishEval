 ```python
from typing import List

def all_prefixes(string: str) -> List[str]:
    """
    Input string ke sabhi prefixes ko shortest se longest tak, list mei return karo
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return list(reversed(map(lambda prefix, s: prefix, ([''] + list(map(lambda i: string[:i+1], range(len(string))))), [string])))
```

This function uses list comprehension, map, lambda functions, and reversed to generate all the prefixes of the given string and return them in a list. The order of the prefixes is reversed to get the shortest prefix first.