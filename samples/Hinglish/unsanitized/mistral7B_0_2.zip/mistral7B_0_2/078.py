 ```python
def hex_key(num):
    hex_to_decimal = {"0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "A": 10, "B": 11, "C": 12, "D": 13, "E": 14, "F": 15}
    prime_digits_count = 0
    for digit in num[::-1]:  # reverse iteration
        decimal_value = hex_to_decimal[digit]
        if isprime(decimal_value):
            prime_digits_count += 1
    return prime_digits_count

# helper function for checking prime numbers
def isprime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
```

Note: I added a helper function `isprime` to check prime numbers. The main function `hex_key` uses this helper function to determine the prime digits count in the given hexadecimal number.