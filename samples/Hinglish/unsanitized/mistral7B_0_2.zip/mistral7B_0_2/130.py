 ```python
def tri(n):
    if n <= 0:
        return []
    elif n == 1:
        return [3]
    else:
        sequence = [3]
        if n % 2 == 0:
            sequence.append(1)
            sequence.append(sum(sequence[-2:]))
            for _ in range(n - 3):
                sequence.append(sequence[-1] + sequence[-2] + sequence[-3])
        else:
            sequence.append(sum(sequence[-2:]))
            for _ in range(n - 3):
                sequence.append(sequence[-1] + sequence[-2] + sequence[-3])
                sequence.append(sequence[-1] + sequence[-2])
        return sequence
```