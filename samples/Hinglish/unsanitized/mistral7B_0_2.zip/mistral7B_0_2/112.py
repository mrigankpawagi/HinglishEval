 ```python
def reverse_delete(s, c):
    s = s.replace(c, '', count=len(s.count(c)))  # Delete all occurrences of 'c' from 's'
    return s, s == s[::-1]  # Check if the reversed string is equal to the original string
```