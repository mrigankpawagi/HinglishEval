 ```python
def change_base(x: int, base: int):
    """
    Input number x in base 10, output number in base 'base'.
    Return string representation of the converted number.
    Base numbers should be less than 10.
    """

    def to_digit(remainder):
        if remainder >= 10:
            return str(remainder - 10)[2:]
        return str(remainder)

    if x == 0:
        return "0"

    result = ""
    while x != 0:
        x, digit = divmod(x, base)
        result += to_digit(digit)

    return result[::-1]
```