 ```python
def order_by_points(nums):
    # Use a list comprehension to calculate the sum of digits for each number and create a new list with the number and its sum as tuples. Then sort the list based on the first element (number) and second element (sum of digits) using key function.
    return sorted(nums, key=lambda x: (x, sum(int(digit) for digit in str(abs(x)))))
```

This function calculates the sum of digits for each number in the list and sorts the list based on the sum of digits in ascending order. If there are numbers with the same sum of digits, they will be ordered based on their original index in the input list.