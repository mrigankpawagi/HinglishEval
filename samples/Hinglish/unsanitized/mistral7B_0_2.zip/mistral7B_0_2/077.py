 ```python
def iscube(a):
    """
    A function that takes an integer a and returns True if it is a cube number.
    Note: You may assume that the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    """
    return a >= 0 and a == int(pow(int(pow(abs(a), 0.5)), 3))
```