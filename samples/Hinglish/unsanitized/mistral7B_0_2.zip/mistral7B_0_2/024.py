 ```python
def largest_divisor(n: int) -> int:
    i = 1
    while n % i != 0:
        i += 1
    return i
```