 ```python
def fruit_distribution(s, n):
    # Parse the number of apples and oranges from the string
    fruits = s.split(" and ")[-1].split(" ")
    apples = int(fruits[0])
    oranges = int(fruits[1])

    # Calculate the number of mangoes
    return n - apples - oranges
```