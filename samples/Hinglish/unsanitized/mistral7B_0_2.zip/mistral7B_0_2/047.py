 ```python
def median(l: list):
    """
    List l ke elements ka median return karo.
    """
    l.sort()
    length = len(l)
    mid = length // 2
    if length % 2 == 0:
        return (l[mid - 1] + l[mid]) / 2
    else:
        return l[mid]
```
This function first sorts the list and then calculates the median based on the length of the list. If the length is even, it returns the average of the middle two elements. Otherwise, it returns the middle element.