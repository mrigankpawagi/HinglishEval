 ```python
def right_angle_triangle(a, b, c):
    """
    Trikon ke three sides lengths diye gaye hain. Agar ye three sides an equal triangle make, i.e. one side is a right angle (or 90 degrees), then return True, otherwise False.
    A right angle triangle is that in which one angle is a right angle (or 90 degrees).
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    """
    return (a**2 + b**2 == c**2 or b**2 + c**2 == a**2 or c**2 + a**2 == b**2)
```
This function checks if the given sides `a`, `b`, and `c` form a right angle triangle by checking if the sum of the squares of any two sides is equal to the square of the third side.