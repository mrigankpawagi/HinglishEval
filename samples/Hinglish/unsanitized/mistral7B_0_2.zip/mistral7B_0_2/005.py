 ```python
def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """
    Input list `numbers' ke har do consecutive elements ke beech mein ek number 'delimeter' insert karo.
    """
    return [numbers[i] for i in range(len(numbers)) if i % 2 == 0] + \
           [delimeter] + \
           [numbers[i] for i in range(len(numbers)) if i % 2 != 0]
```

This function uses list comprehension to create a new list with the given behavior. It first creates a list with every second element from the input list, then adds the delimiter, and finally adds every other element from the input list.