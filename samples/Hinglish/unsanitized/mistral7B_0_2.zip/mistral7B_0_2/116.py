 ```python
def sort_array(arr):
    arr.sort(key=lambda x: (bin(abs(x))[2:], -abs(x)) if x < 0 else bin(x)[2:])
```

This function uses the `sort` method with a custom `key` function to sort the array based on the given conditions. The `key` function returns a tuple for each element, where the first element is the binary representation of the absolute value of the number without the leading '0b' and the second element is a negative sign for negative numbers. The sorting is done in ascending order based on these tuples.