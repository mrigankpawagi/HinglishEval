 ```python
def split_words(txt):
    words = txt.split() if txt else txt.split(',')[0:26]  # Split by whitespace if no commas or empty string, else split by commas and take first 26 elements
    return words if txt else [chr(i) for i in range(ord('a'), ord('z')+1) if ord('a') + i % 2 != ord(txt[i])]  # Return list of words if given, else return list of odd-order lowercase letters in given string
```

This function first checks if the given string `txt` contains any whitespace or commas. If it does, it splits the string by whitespace and returns the resulting list. If not, it assumes that the string is meant to represent a sequence of odd-order lowercase letters, and returns a list of those letters.