 ```python
def derivative(xs: list):
    n = len(xs)
    return [(i+1)*xs[i] for i in range(n)] if n else [0]
```