 ```python
def vowels_count(s):
    """
    Count the number of vowels in a given string.

    Parameters:
    s (str): The input string.

    Returns:
    int: The number of vowels in the string.
    """
    vowels = "aeiouAEIOU"
    return sum(s.count(v) for v in vowels)
```