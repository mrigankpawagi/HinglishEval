 ```python
def digits(n):
    """
    Ek positive integer n diya gaya hai, odd digits ka product return karo.
    Agar saare digits even hain to 0 return karo.
    Udaharan ke liye:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    return functools.reduce(lambda x, y: x * (y % 2), list(str(n).digits()), 1) if int(n) > 0 else 0
```

This function uses the `functools.reduce` function to calculate the product of odd digits and a lambda function to check if the digit is odd. The `list(str(n).digits())` converts the integer `n` to a list of digits as strings, and `functools.reduce` applies the lambda function to the list. If the number `n` is negative, the function returns 0.