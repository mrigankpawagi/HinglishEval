 ```python
def sorted_list_sum(lst):
    lst.sort(key=lambda x: (len(x), x))
    return [sum(map(ord, i)) for i in lst if len(i) % 2 != 0]
```

Please note that the function name `sorted_list_sum` is misleading as it does not return the sum of the sorted list but instead returns a list of sums of odd-length strings in the sorted list. If the actual requirement is to sum the sorted list, the function name and the implementation should be adjusted accordingly.