 ```python
def special_factorial(n):
    """
    Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    only if n > 0

    This function will take an integer input and return its special factorial.
    """

    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n-1)

    return factorial(n)
```

Here's the helper function `factorial` to calculate the factorial of a given number. The `special_factorial` function uses this helper function to calculate the Brazilian factorial.