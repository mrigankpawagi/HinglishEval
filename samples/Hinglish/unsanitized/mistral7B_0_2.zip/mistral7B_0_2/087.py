 ```python
def get_row(lst, x):
    row = [i for i in lst if i and i[0] == x]
    if not row:
        return []

    coordinates = [(i.index(x), i.index(row[0].index(x) if row[0].index(x) else 0)) for i in row]
    coordinates.sort(key=lambda coord: (coord[0], -coord[1]))

    return coordinates
```