 ```python
def encode(message):
    vowels = "aeiouAEIOU"
    encoded_message = ""
    for char in message:
        if char.isalpha():
            if char in vowels:
                index = vowels.index(char)
                encoded_message += chr(ord(char.lower()) + ord('a') - ord(vowels[index]))
            else:
                encoded_message += char
        else:
            encoded_message += char
    return encoded_message
```