 ```python
def decode_shift(s: str):
    """
    Har character ko alphabet mein 5 shifts se pehle wapas bring jao.
    """
    return "".join([chr(((ord(ch) - 5) % 26) + ord("a")) for ch in s])
```