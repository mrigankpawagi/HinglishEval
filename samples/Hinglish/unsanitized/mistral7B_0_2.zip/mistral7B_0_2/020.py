 ```python
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    closest_numbers = min(numbers, key=lambda x: min(abs(x - numbers[0]), abs(x - numbers[-1]))) if numbers else (None, None)
    return tuple(sorted([numbers[numbers.index(closest_numbers)], closest_numbers]))
```

This function finds the closest pair of numbers in the given list and returns them as a tuple. It uses the `min` function with a lambda function as the key to find the number that is closest to the smallest and largest number in the list. The pair of closest numbers is then returned in sorted order. If the list is empty, the function returns `(None, None)`.