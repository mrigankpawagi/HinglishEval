 ```python
def greatest_common_divisor(a: int, b: int) -> int:
    """
    Do integers a and b's greatest common divisor be returned
    """
    while a != b:
        a, b = min(a, b), a % b
    return a
```