 ```python
def get_odd_collatz(n):
    sequence = [n]
    while n not in [1, -1]:
        if n % 2 == 0:
            n = int(n / 2)
        else:
            n = 3 * n + 1
        sequence.append(n)
    return list(filter(lambda x: x % 2 != 0, sequence))
```