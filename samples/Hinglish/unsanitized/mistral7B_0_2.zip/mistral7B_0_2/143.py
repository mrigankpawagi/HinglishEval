 ```python
def words_in_sentence(sentence):
    words = sentence.split()
    prime_words = [word for word in words if all(i % int(w) for i in range(2, int(1)+10) if int(w) > 1)]
    return " ".join(prime_words)
```

This function first splits the given sentence into words using the `split()` method. Then, it filters out the words whose lengths are not prime numbers using a list comprehension. Finally, it returns a string of the prime-length words, with the same order as in the original sentence, by joining them with a space using the `join()` method.