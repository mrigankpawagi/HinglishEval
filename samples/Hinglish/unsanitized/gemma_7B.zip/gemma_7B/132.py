
def is_nested(string):
    """
    Ek function banao jo sirf square brackets wala string input ke roop mein leta hai.
    Function tabhi True return karega jab valid subsequence of brackets ho 
    jisme kam se kam ek bracket nested ho.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    """
    return False


def check(st):
    stack = []
    ans = False
    for c in st:
        if c == "]":
            stack.append(c)
        else:
            stack.pop()
        if not len(stack):
            ans = True
            break
    return ans


if __name__ == "__main__":

    st = "[]]([][][]][)"
    print(check(st))
