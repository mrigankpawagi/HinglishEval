
def search(lst):
    """
    Aapko ek non-empty list di gayi hai positive integers ki. Return karo sabse bada integer jo zero se bada ho, 
    aur uska frequency us integer ke value ke barabar ya usse zyada ho. 
    Ek integer ka frequency uski list mein kitni baar aane ki sankhya hoti hai.
    Agar aisa koi value nahi hai, to -1 return karo.
    Udaharan:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    """

    max_num = -1
    count = 0

    max_found = False
    num_found = False

    for num in lst:
        if num == 0:
            continue
        if not max_found:
            max_num = num
            max_found = True
            count = 1
        elif num == max_num:
            count += 1
        elif num > max_num:
            count = 1
            max_num = num
            num_found = True

    if max_num != -1 and count > max_num:
        if num_found:
            return max_num
        else:
            return -1
    else:
        return max_num


if __name__ == "__main__":

    lst = [4, 1, 2, 2, 3, 1]
    assert search(lst) == 2, "first test should be 2"
    assert search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3, "search should be 3"
    assert search([5, 5, 4, 4, 4]) == -1, "search should be -1"
    print("all tests passed!")
