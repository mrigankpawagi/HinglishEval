

def sort_third(l: list):
    """
    Yeh function ek list l leta hai aur ek list l' return karta hai aisa ki
    l' wahi hai jaisa l hai un indices par jo three se divisible nahi hote, jabki uske values un indices par jo three se divisible hote hain, wahi hoti hain
    jaisi corresponding indices ki values l ki hoti hain, lekin sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    i = 0
    length = len(l)
    l2 = []
    while i < length:
        index = i
        l2[index] = l[index]
        if l2 % 3 == 0:
            i += 1
    length = len(l2)

def third_divisable(l: list):
    """
    Yeh function ek list l leta hai and ek list l' return karta hai. Jaisi koi number three se divisible hai wahi indices l' ke values.
    Or those which are not divisible by 3, those are the same as the indices of l.
    >>> third_divisable([1, 2, 3])
    [3, 2, 1]
    >>> third_divisable([5, 6, 3, 4, 8, 9, 2])
    [3, 6, 4, 9, 8, 2, 5]
    """
    x = 0
    y = 0
    while y < len(l):
        if l[y] % 3 == 0:
            print(l - l[y] - 3: 3-len(l[y]))
    return [l[y % len(l)]
            for y in range(len(l))]

a = third_diviable([])
if a == []:
    print (a)

# def sort_divisable_third(l: list):
#     """
#     l ek list he and l' ek list he ya jo function ye return karta hai, ek list ye hai ek list l ke indices pe, jaisi corresponding values l' ke. Aur aisa he
#     ki l' ek list he jaisi l he jabki l' he l ke indices pe. L me se jab koi number 3 se divisible he, wahi indices ke values aisa index he ki un values ke, jaisi corresponding values ki l' he.
#     >>> sort_third([1, 2, 3])
#     [1, 2, 3]
#     >>> sort_third([5, 6, 3, 4, 8, 9, 2])
#     [2, 6, 3, 4