

def below_threshold(l: list, t: int):
    """
    Agar list l mein saare numbers threshold t se kam hai to True return karo.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return all(b <= t for b in l)


def below_threshold_v2(l: list, t: int):
    """
    Agar list l mein saare numbers threshold t se kam hai to True return karo.
    >>> below_threshold_v2([1, 2, 4, 10], 100)
    True
    >>> below_threshold_v2([1, 20, 4, 10], 5)
    False
    """
    if not l:
        return True
    if l[0] > t:
        return False
    return below_threshold_v2(l[1:], t)


def below_threshold_v3(l: list = None, t: int, result: bool = None):
    """
    Agar list l mein saare numbers threshold t se kam hai to True return karo.
    >>> below_threshold_v3([1, 2, 4, 10], 100)
    True
    >>> below_threshold_v3([1, 20, 4, 10], 5)
    False
    """
    if not l:
        return True
    if l[0] > t:
        return False

    return below_threshold_v3(l[1:], t)



if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
