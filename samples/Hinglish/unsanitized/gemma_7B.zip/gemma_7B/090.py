
def next_smallest(lst):
    """
    Aapko ek list di gayi hai integers ki.
    Ek function likho next_smallest() jo list ka 2nd sabse chhota element return kare.
    Agar aisa koi element nahi hai to None return kare.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    x = min(lst)
    lst = sorted(lst)
    return lst[lst.index(x) + 1] if lst.index(x) + 1 < len(lst) else None

# 2.
def even_odd_count(lst):
    """
    Aapko ek list di gayi hai integers ki.
    
    Har pair jo odd hai usko aur har pair jo even hai usko ek extra step pe increement karana hai.
    List ko sort kar de aur vo karte karte jo odd no. the uspe vo even step karte ho aur vo karte karte jo even the uspe
    vo odd chli jae.
    
    return = [7, 5, 4, 3, 2, 1]
    """
    lst = sorted(lst)
    # if len(lst):
    lst.reverse()
    step = 1
    # return lst
    x = lst[::2]
    y = lst[1::2]
    if len(y) == 0:
        return x
    if x[0] < y[0]:
        x = [
            i + (step if (i % 2 == 0) else 0) for i in x
        ]
        y = [i - (step if (i % 2 == 0) else 0) for i in y]
    else:
        x = [
            i - (step if (i % 2 == 0) else 0) for i in x
        ]
        y = [i + (step if (i % 2 == 0) else 0) for i in y]
    x += y
    return x

# 3.
def odd_even(lst):
    """
    Aapko ek list di gayi hai integers ki.

    If element %2 == 0 agar even hai then increase 2 ko and if %2 == 1 agar odd the then increase 1 ko.

    return = [7, 5, 4, 3, 2, 1]
    """
    t = [
        i - (1 if (i % 2 == 0) else 2) for i in sorted(lst)
    ]