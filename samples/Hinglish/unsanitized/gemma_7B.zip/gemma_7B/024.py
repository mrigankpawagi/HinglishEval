

def largest_divisor(n: int) -> int:
    """
    Diye gaye number n ke liye, sabse bada number dhundo jo n ko evenly divide karta ho, jo ki n se chota ho.
    >>> largest_divisor(15)
    5
    """

    for i in range(n, 0, -1):
        if n % i == 0:
            return i


def largest_divisor2(n: int) -> int:
    """
    1. Sabse bada number dhundo, jo n ko divyakar kar sake.
    2. Wahan aur agar n ke ilawa, jo number n ko divyakar kare, ussi ko se bada number n se bhi divyakar karega.
    3. Wahan se agar aapke pass ye hai ki number, ye n se bhi chhota hoga.
    4. Is liye phir se ye step 2 perform krenge.
    >>> largest_divisor2(20)
    5
    >>> largest_divisor2(25)
    3
    """

    largest_divisor = n
    while(largest_divisor % n != 0):
        if n % largest_divisor == 0:
            largest_divisor = n
        n = largest_divisor
    return largest_divisor




if __name__ == "__main__":
    import doctest
    doctest.testmod()
