
def is_equal_to_sum_even(n):
    """
    Evaluate karo ki diya gaya number n kya exactly 4 positive even numbers ka sum ho sakta hai
    Udaharan
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # YOUR CODE HERE
    return ???

# 2
def are_consecutive(n) -> bool:
    """
    evaluate karo ki diya gaya n numbers ke list me adjacent numbers kya 1, 2, 3, ....... aur so on ke values ke equal hai.
    Udaharan:
    are_consecutive([0, 1, 2, 3, 4]) == True
    are_consecutive([0, 1, 3, 4]) == False
    are_consecutive([0, 1, 2, 4]) == False
    """
    # YOUR CODE HERE
    return ???

### 3
def are_consecutive_in_row(n, x):
    """
    evalute karo ki diya gaya x ke list me, n consecutive numbers aane ke baad kya alag ho jaate hai.
    Udaharan:
    are_consecutive_in_row(3, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == True
    are_consecutive_in_row(3, [0, 1, 2, 9, 8, 7, 6, 5, 4, 3]) == False
    are_consecutive_in_row(3, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == True
    are_consecutive_in_row(5, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == False
    are_consecutive_in_row(1, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == True
    """
    # YOUR CODE HERE
    return ???

### 4
def is_consecutive_in_row(n) -> bool:
    """
    evalute karo ki diya gaya n numbers ke list me, first and last aane ke baad kya alag ho jaate hai.

    Udaharan:
    is_consecutive_in_row