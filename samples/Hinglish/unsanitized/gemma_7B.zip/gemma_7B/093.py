
def encode(message):
    """
    Ek function likho jo ek message leta hai, aur usko aise encode karta hai 
    ki wo saare letters ki case ko swap kar deta hai, saare vowels ko 
    unke aage wale 2nd letter se replace kar deta hai english alphabet mein. 
    Sirf letters maan lo. 
    
    Udaharan:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    result = [x[1] if x[0].isalpha() else x[0].upper() for x in
      enumerate(message)]
    print(result)
    return ''.join(result)


def decode(message):
    """
    Ek function likho jo encoded message lena chahiye aur usme 
    encode hui letter ko decode karke saare letters ki case swap kar de 
    aur wo ek aise manner mein decode karay ga ki ek random string bana jayega.
    
    Sirf letters maan lo. 
    """

    result = [x[1] if x[0].isalpha() else x[0] for x in
     enumerate(message)]
    print(result)
    return ''.join(result)


if __name__ == '__main__':

    # Test
    print('Encode test...')
    assert encode('test') == 'TGST'
    assert encode('This is a message') == 'tHKS KS C MGSSCGG'

    print('Decode test...')
    assert decode('TGST') == 'test'
    assert decode('tHKS KS C MGSSCGG') == 'This is a message'
    print('Test Passed')
