

def derivative(xs: list):
    """
    xs ek polynomial ke coefficients ko represent karte hain.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Is polynomial ka derivative same form mein return karo.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    derivatives = []
    n = len(xs)
    for i in range(n):
        derivatives.append(i*xs[i])
    return derivatives


# Second Task


def is_even(n: int):
    """
    Given an integer, tells whether that number is even. 
    >>> is_even(6)
    True
    >>> is_even(2)
    True
    >>> is_even(7)
    False
    """
    # Write your code below

# Third Task


def reverse(xs: list):
    """
    Reverse a list in place.
    >>> numbers = [1, 2, 3]; reverse(numbers)
    >>> numbers
    [3, 2, 1]
    >>> xs = [3, 3, 2, 1]; xs_reversed = reverse_two_lists(xs, [])
    >>> xs_reversed
    [1, 2, 3, 3]
    >>> xs
    [3, 3, 2, 1]
    """
    # Write your code below


def reverse_two_lists(first_list: list, second_list: list):
    """
    Reverse a list in place.
    >>> numbers = [1, 2, 3]; reverse(numbers)
    >>> numbers
    [3, 2, 1]
    >>> xs = [3, 3, 2, 1]; xs_reversed = reverse_two_lists(xs, [])
    >>> xs_reversed
    [1, 2, 3, 3]
    >>> xs
    [3, 3, 2, 1]
    """
    # Write your code below
