
def unique_digits(x):
    """
    Diye gaye positive integers ki list x me Woh saare elements ki sorted list return karo jisme koi bhi even digit nahi hai.

    Dhyan de: Return ki gayi list ko increasing order me sort kiya jana chahiye.
    
    Jaise ki:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    ans = []
    def rec(x,n,l):
        if x==0:
            return
        if(x>0 and x%10!=0 and x%10%2!=0  and l.count(x%10)==0):
            ans.append(x%10)
            l.append(x%10)

        rec(x//10,n+1,l)

    l=[]
    k = str(x)
    rec(int(k),0,l)
    return list(map(int,ans))
