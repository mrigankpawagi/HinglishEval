

def how_many_times(string: str, substring: str) -> int:
    """
    Mool string mein diye gaye substring ko kitni baar mila ja sakta hai, yeh find karo. Overlapping cases ko bhi count karo.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if len(string) == 0:
        return 0
    else:
        return sum(1 for _ in range(len(string) - len(substring) + 1) if string[_] == substring[0] and list(string[_:]) == list(substring))


def how_many_times_r(string: str, substring: str) -> int:
    """
    Mool string mein diye gaye substring ko kitni ho ki b a sakte hai, yeh find karo. Overlapping cases ko bhi count karo.
    >>> how_many_times_r('', 'a')
    0
    >>> how_many_times_r('aaaa', 'aa')
    3
    >>> how_many_times_r('aaaab', 'a')
    5
    """
    string = str(string)
    substring_len = len(substring)
    string_len = len(string)
    
    if substring in string:
        # first_index = a.index(substring)
        # print(a)
        return 1 + how_many_times(string[substring_len:-1], substring)
    else:
        return 0


string = 'a'
substring = 'ab'
print(how_many_times_r(string, substring))
