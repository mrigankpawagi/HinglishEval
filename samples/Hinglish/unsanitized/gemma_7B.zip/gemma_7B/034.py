

def unique(l: list):
    """
    Ek list mein sorted unique elements return karo
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    pass

# def flatten(l: list):
#     """
#     Ek list mein distinct elements, sorted order mein rakh ke ek simple list return karo.
#     >>> flatten([5, 3, 5, 2, 3, [3, 9], 0, [1, 5, 123]])
#     [0, 2, 3, 5, 9, 1, 123]
#     """
#     pass

def flatten(l: list) -> 'list':
    """
    Ek list mein distinct elements, sorted order mein rakh ke ek simple list return karo.
    >>> flatten([5, 3, 5, 2, 3, [3, 9], 0, [1, 5, 123]])
    [0, 2, 3, 5, 9, 1, 123]
    """

    def my_flatten(x):
        if len(x) == 1:
            return x[0]
        return flatten(x[1:]) + my_flatten(x[0])

    # base case: return if length is 1
    if len(l) == 1:
        return l

    # iterate through list
    l_flat = []
    for elem in l:
        if type(elem) == list:
            l_flat += my_flatten(elem)
        else:
            l_flat += [elem]
    # return flattened list
    return l_flat

# print(flatten([[1]],[[3],4,5]))

def add(*l):
    """
    Ek list of numbers return karo, jo kehte hain sum of number list
    >>> add(3, 1, 5)
    [3, 1, 5]
    >>> add(3, 1, 5, 2, 4)
    [3, 1, 5, 2, 4]
    """


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    # print('OK')
    # print(len(doctest.failed_tests))
    pass
