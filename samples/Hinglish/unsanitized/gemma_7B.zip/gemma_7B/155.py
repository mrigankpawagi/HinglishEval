
def even_odd_count(num):
    """
    Ek integer diya gaya hai. Ek tuple return karo jo even aur odd digits ki sankhya ko kramashah darshata hai.

     Udaharan:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """



    odd_count=0
    even_count=0
    num=abs(num)
    while num>0:
        digit=num%10
        if digit%2==0:
            even_count+=1
        else:
            odd_count+=1
        num//=10

    return (even_count,odd_count)





def count_digits(num, digit):
    """
    Ek integer 'num' diya gaya hai aur usme 'digit' hai ki sankhya nikalana hai.

     Udaharan:
        count_digits(-1234151254) ==> (6, 3, 2, 1, 1)

    """



    l=[0]
    num=abs(num)
    while num>0:
        l.append(num%10)
        num//=10

    l.pop(0)
    t=[]
    for i in l:
        if i==digit:
            t.append(l.count(i))

    return tuple(t)




if __name__ == '__main__':
    print("Example:")
    print(even_odd_count(12))

    # These "asserts" using built-in functions check your solution against expected output,
    # and make your solution working correctly.
    print(even_odd_count(12))
    print(count_digits(126984, 4))
    print(count_digits(-1234151254))
    print(even_odd_count(1234567890))
    print(even_odd_count(987654321))
    print(even_odd_count(-1234568900))
    print(count_digits(432235, 2))
    print(count_digits(432235, 5))
    print(odd_even_count(19999544))
    print(count_digits(19999544, 9))
    print(count_digits(3, 1))
    print(count_digits(-