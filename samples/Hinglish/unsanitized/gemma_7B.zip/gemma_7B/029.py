from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """
    Diye gaye prefix se shuru hone wale strings ke liye input list ko filter karo.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    output = []
    for each in strings:
        if each.startswith(prefix):
            output.append(each)
    return output


if __name__ == '__main__':
    input_strings = ['abc', 'bcd', 'cde', 'array', '10a']
    output = filter_by_prefix(input_strings, 'a')
    print(output)

    print(list(filter_by_prefix(input_strings, 'a')))
