

def truncate_number(number: float) -> float:
    """
    Diye gaye positive floating point number ko hum integer part (diye gaye number se chota sabse bada integer) aur decimals 
    (hamesha 1 se chota bacha hua part) mein decompose kar sakte hain.

    Number ka decimal part return karo.
    >>> truncate_number(3.5)
    0.5
    """
    # fill this in.
    return number - int(number)  

# problem 2



def square(number1: int, number2: int) -> int:
    """
    This function returns the sum of square of a and b.
    >>> square(1, 2)
    5
    """
    # fill this in.
    return number1*number1 + number2*number2 

# problem 3



def add(numbers: list) -> float:
    """
    You are given an array of numbers. Sum it and return the answer.
    >>> numbers = [1, 2, 3]
    >>> add(numbers)
    6
    """
    # fill this in.
    final_sum = 0
    for number in numbers:
        final_sum = add(numbers)
    return final_sum 

# problem 4



def count(text: str, character: str) -> int:
    """
    Count the number of times that a character occurs in a text.
    >>> count(text, 'the')
    9
    """
    # fill this in.
    for num_char in text:
        if num_char == character:
            count = count + 1
    return count

# problem 5


def convert_to_binary(number: int) -> str:
    """
    Convert number to binary using divide by 2 method. We divide the number by 2. If the result has remainder,
    then assign 1 to str_result otherwise assign 0. We then repeat the process for the result of the division until
    we get a result of 0. Now we put the result into the start of list, then convert the list to string and return it.
    >>> convert_to_binary(4)
    '100'
    """
    # fill this in.
    result = str()

    # fill this in.
    while number >= 0 :
        if number % 2 == 0:
            result = str(number % 2) + result

            number = number / 2

        else:
            result = str(number % 2) + result

            number = number / 2

    return result
