

def sum_to_n(n: int):
    """
    sum_to_n ek function hai jo 1 se lekar n tak ke numbers ka sum karta hai.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    if n == 0:
        return 0
    else:
        return n + sum_to_n(n - 1)


def sum_to_n_without_recursion(n: int):
    """
    sum_to_n_without_recursion ek function hai jo 1 se lekar n tak ke numbers ka sum karta hai aur recursion ke
    medium se naya kaise shuru krna hai yeh dekhta hai.
    >>> sum_to_n_without_recursion(30)
    465
    >>> sum_to_n_without_recursion(100)
    5050
    >>> sum_to_n_without_recursion(5)
    15
    >>> sum_to_n_without_recursion(10)
    55
    >>> sum_to_n_without_recursion(1)
    1
    """
    return (n + 1) * n // 2


def fact_2(n: int):
    """
    fact ek function hai jo n se start krke 1 tak phele se likhe kiye jaayenge.
    >>> fact(3)
    6
    >>> fact(4)
    24
    >>> fact(6)
    720
    """
    if n == 1:
        return 1
    else:
        return n * fact_2(n - 1)


def fact(n: int):
    """
    fact_recursive ek function hai jo n se start krke 1 tak phele se likhe kiye jaayenge.
    >>> fact(3)
    6
    >>> fact(4)
    24
    >>> fact(6)
    720
    """
    if n == 1:
        return 1
    else:
        if n == 0:
            return 1
        else:
            return n * fact(n - 1)


def sum_of_digits(n):
    """
    sum_of_digits ek function hai jo n ke number ke digit ki sum ka bnaya h.
    """
    s = 0
    while n > 0:
        s += n % 10
        n //