
def any_int(x, y, z):
    """
    Ek function banao jo 3 numbers leta hai.
    Agar koi ek number doosre do numbers ka sum ho, aur saare numbers integers ho, toh true return kare.
    Kisi bhi aur case mein false return kare.
    
    Udaharan
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
    """


    result_1 = (x+y)==z
    result_2 = (x+z)==y
    result_3 = (x+z)==y
    
    if isinstance(x, int) == True and isinstance(y, int) == True and isinstance(z, int) == True:
        return(result_1 or result_2 or result_3) 
    else:
        return False    

print(any_int(5, 2, 7))
print(any_int(3, -2, 1))    
print(any_int(3.6, -2.2, 2))   


#2

def is_unique(letters):
    """
    Write a function to check if a string only contains unique characters.
    
    You can assume the test cases will have letters and/or numbers.
    
    Udaharan
    "apple" ➞ False
    
    "car" ➞ True
    
    "4" ➞ True
    """
    
    if len(letters) == len(set(letters)):
        return True
    else:
        return False
    
print(is_unique("apple"))
print(is_unique("car"))
print(is_unique("4"))


#3 

def double_check(lst):
    """
    ek function banaa jo input list mein jo bhi element aaraha hai usko input array ko ek number saari beshak duplicate ho jaayega, aur ye duplicate jo bhi ho, wahi dup_no yaar function main return kare. 
    Udaharan:
    >>> double_check([2, 1, 2, 2, 2, 3, 4])
    2
    """
    
    result = []
    for i in lst:
        result.append(i*2 if i not in lst else i)
        
    return result[0]
        
print(double_check([2, 1, 2, 2, 2, 3, 4]))
