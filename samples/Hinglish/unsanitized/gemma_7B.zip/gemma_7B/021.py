from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """
    Diye gaye numbers ki list (kam se kam do elements ki) par ek linear transform apply karo,
    aisa ki sabse chota number 0 ban jaye aur sabse bada number 1 ban jaye
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    min_value = min(numbers)
    max_value = max(numbers)

    for index, n in enumerate(numbers):
        numbers[index] = (n - min_value) / (max_value - min_value)

    return numbers


def rescale_logarithmically(numbers: List[float]) -> List[float]:
    """
    Diye gaye numbers ki list aur unse related log values ko 1-1 map karo
    log values unhone jo log10 ko relate kero, 0 ke samay 0 ban jaye
    (or may be use 1).
    >>> rescale_logarithmically([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.3, 0.5, 0.7, 1.0]
    """

    min_value = min(numbers)
    max_value = max(numbers)

    scaled_numbers = []

    for index, n in enumerate(numbers):
        baseless_x = (n - min_value) / (max_value - min_value)

        scaled_numbers.append(baseless_x)

    return scaled_numbers

"""
Q2. Write your answer to this Question in the Codepad
Write a function find_primes_under_a(), which returns a sorted list of all prime
numbers under a, where a is some positive integer.

>>> find_primes_under_a(14) # [2, 3, 5, 7]
"""


def get_digits(n: float) -> List[float]:
    digits = []
    while n >= 1:
        digits.append(int(n % 10))
        n = int(n / 10)

    return digits


def is_prime(n: float) -> bool:
    """Returns True if n is prime"""
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i = i + 