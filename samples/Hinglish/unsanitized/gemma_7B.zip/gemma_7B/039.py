

def prime_fib(n: int):
    """
    prime_fib woh n-th number return karta hai jo ek Fibonacci number bhi hai aur prime number bhi.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n <= 0:
        return 0

    if n == 1:
        return 2

    if (n == 2 or n == 3):
        return 3

    prev, prev_prev = 1, 2

    count = 3
    while True:
        if is_prime(count) and is_prime(count % 2) \
                and is_prime(count % 3) and is_prime(count % 5) and \
                is_prime(count % 7):

            if count < n:
                count += 10
                continue

            return count

        count += prev

        prev, prev_prev = prev + prev_prev, prev

# def prime_fib_helper(n: int, prev:int, prev_prev:int)->int:
#     # TODO: Write your recursive function helper here
#     if n <= 0:
#         return 0
#
#     if n == 1:
#         return 2
#
#     if (n == 2 or n == 3):
#         return 3
#
#     if is_prime(n) and is_prime(n % 2) \
#             and is_prime(n % 3) and is_prime(n % 5) and \
#             is_prime(n % 7):
#          return n
#
#     # Recursive case: prev, prev_prev ka role hai current number k calculation main.
#     # count k role hai main return ho jaaye aur aur recursion baar baar chali jaaye
#     count = prev + prev_prev
#     return prime_fib_helper(n - 1, count, prev_prev)



def is_prime(n: int) -> bool:
    """
    is_prime yeh function chek karti hai ki vo parameter ki value
    prime number hai na hai.  True hoga jab vo parameter ki value prime number hai.
    Oherwise False.

    >>> is_prime(2)
    True
    >>> is_prime(4)
    False
    >>> is_prime(5)
    True
    """
    # TODO: Write your function here
    for i