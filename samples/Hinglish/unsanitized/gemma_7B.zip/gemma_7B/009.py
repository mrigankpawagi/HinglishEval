from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """
    Diye gaye integers ki list mei se, sequence me diye gaye har moment tak paye gaye rolling maximum element ki list generate karo.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    def _rolling_max(numbers: List[int]) -> List[int]:
        max_number = numbers[0]
        res = []
        for number in numbers:
            res.append(max_number)
            if number > max_number:
                max_number = number
        return res

    return _rolling_max(numbers)


def remove_duplicate(numbers: List[int]) -> List[int]:
    """
    Diye gaye integers ki list mei se duplicate ko ghayayen.
    >>> remove_duplicate([0, 1, 1, 2, 2, 4, 4, 3, 3])
    [0, 1, 2, 4, 3]
    """
    numbers = list(set(numbers))
    return numbers


def all_sub_array(numbers: List[int]) -> List[List[int]]:
    """
    Diye gaye integers ki list mei sab sub arrays ko generate karo.
    >>> all_sub_array([1, 2, 3, 5, 5])
    [
       [ 1],
       [ 2],
       [ 3],
       [ 5],
       [ 5],
       [ 1, 2],
       [ 1, 3],
       [ 1, 5],
       [ 1, 5],
       [ 2, 2],
       [ 2, 3],
       [ 2, 5],
       [ 2, 5],
       [ 3, 3],
       [ 3, 5],
       [ 3, 5],
       [ 5, 5],
       [ 1, 2, 3],
       [ 1, 2, 5],
       [ 1, 2, 5],
       [ 1, 3, 5],
       [ 1, 3, 5],
       [ 1, 5, 5],
       [ 1, 5, 5],
       [ 2, 3, 3],
       [ 2, 3, 5],
       [ 2, 3, 5],
