

def string_sequence(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    return " ".join(str(i) for i in range(n+1))


def string_sequence_2(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence_2(0)
    '0'
    >>> string_sequence_2(5)
    '0 1 2 3 4 5'
    """
    return " ".join(str(i) for i in range(n+1))


def string_sequence_3(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence_3(0)
    '0'
    >>> string_sequence_3(5)
    '0 1 2 3 4 5'
    """
    return " ".join(str(i) for i in range(n+1))


def string_sequence_4(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence_4(0)
    '0'
    >>> string_sequence_4(5)
    '0 1 2 3 4 5'
    """
    return " ".join(str(i) for i in range(n+1))


def string_sequence_5(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence_5(0)
    '0'
    >>> string_sequence_5(5)
    '0 1 2 3 4 5'
    """
    return " ".join(str(i) for i in range(n+1))


def string_sequence_6(n: int) -> str:
    """
    Ek string return karo jisme 0 se lekar n tak ke numbers space-delimited honge.
    >>> string_sequence_6(0)
    '0'
    >>> string_sequence_6(5)