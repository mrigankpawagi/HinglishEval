

def incr_list(l: list):
    """
    Elements ko 1 se badhakar wala list return karo.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    return [x+1 for x in l]


def incr_by(l, n: int):
    """
    Elements ko pass kiye ja rahe n se badhakar wala list return karo.
    >>> incr_by([1, 2, 3], 1)
    [2, 3, 4]
    >>> incr_by([5, 3, 5, 2, 3, 3, 9, 0, 123], 1)
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    >>> incr_by([1, 2, 3], 2)
    [3, 4, 5]
    """
    return [x+n for x in l]


def swap(elem, idx1, idx2):
    """
    elem ko index 1 se index 2 tak swap karo.
    elem : list
    idx1, idx2 : int

    >>> swap([1, 2, 3, 4, 5], 1, 3)
    [1, 4, 3, 2, 5]
    >>> swap([1, 2, 3, 4, 5], 0, 4)
    [5, 2, 3, 4, 1]
    """
    elem[idx1], elem[idx2] = elem[idx2], elem[idx1]


def pop_from(l, idx, new_val):
    """
    l ki index idx se value remove karo aur usne ki place pe new_val rakh dia karo.
    -1 return kare jo ki baki wale elements ko bech renge.
    -1 return kare jo ki baki wale elements ko bech renge.

    >>> pop_from([1, 2, 3, 4, 5], 3, 123)
    [4, 5, 123, -1, -1]
    >>> pop_from([1, 2, 3, 4, 5], 0, 4)
    [4, 5, -1, -1,