

def change_base(x: int, base: int):
    """
    Input number x ka numerical base, base me badal do.
    Conversion ke baad string representation return karo.
    Base numbers 10 se kam hote hain.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    if x <= base:
        return str(x)

    return change_base(x // base, base) + str(x % base)


def factorial(n):
    """
    This function calculates the factorial of the given number using
    Python recursion.
    >>> factorial(4)
    24
    >>> factorial(3)
    6
    >>> factorial(100)
    93326215443944152681699238856266700490715968264381621468592963895217599993229915608941463976156518286253697920827223758251185210916864000000000000000000000000000000
    """
    """
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)
    """
    if n == 1:
        return n
    return n * factorial(n - 1)


def binary(n):
    """
    This function finds the binary of a given number.
    >>> binary(4)
    '100'
    >>> binary(2)
    '10'
    >>> binary(3)
    '11'
    """
    if n == 0:
        return '0'
    elif n % 2 == 0:
        return binary(n / 2) + '0'
    else:
        return binary(n / 2) + '1'


def fib(n):
    """
    Return the nth number in the Fibonacci sequence.

    >>> fib(4)
    3
    >>> fib(7)
    13
    >>> print(fib(0))
    0
    >>> print(fib(1))
    1
    >>> print(fib(2