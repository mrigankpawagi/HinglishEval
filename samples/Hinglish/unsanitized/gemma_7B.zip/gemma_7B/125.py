
def split_words(txt):
    """
    Ek string di gayi hai jisme words hain, aapko ek list return karni hai jisme words whitespace par split ho. Agar text me koi whitespace nahi hai toh aapko commas ',' par split karna hai. Agar koi comma bhi nahi hai toh aapko alphabet me odd order wale lower-case letters ki count return karni hai, jaise ki ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Udaharan
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3
    """
    words = (txt.split(" "))
    num_of_words = len(words)
    final_list = list()
    for i in range(0, num_of_words):
        final_list = final_list+words[i]+","
    final_listr_to_str = "".join(final_list)
    last_list = final_listr_to_str[0::2].split(",")
    return last_list
print(split_words("Hello,world!"))

def remove_odd(txt):
    for i in range(ord('a'), ord('z')):
        if i % 2 == 0:
            txt -= (i)
    return txt
print(remove_odd('Hello world!'))
