
def do_algebra(operator, operand):
    """
    Do lists diye gaye hain, operator aur operand. Pehla list basic algebra operations ka hai, aur 
    dusra list integers ka hai. Diye gaye do lists ka use karke algebraic 
    expression banaye aur is expression ka evaluation return kare.

    Basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Udaharan:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Dhyan de:
        Operator list ki length operand list ki length se ek kam hoti hai.
        Operand ek non-negative integers ki list hoti hai.
        Operator list me kam se kam ek operator hota hai, aur operand list me kam se kam do operands hote hain.
    """
    # Operator list ki length operand list ki length se ek kam hai.
    if len(operator) != (len(operand) - 1):
        return -1
    # Operand ka indexing karna hai, operator ka indexing karne ki jarurat nahi hai.
    operand1 = operand.pop(0)
    # Operand ek non-negative integers ki list hoti hai.
    sum = operand1
    for operator1 in operator:
        operand2 = operand.pop(0)
        if operator1 == '+':
            sum += operand2
        elif operator1 == '-':
            sum -= operand2
        elif operator1 == '*':
            sum *= operand2
        elif operator1 == '//':
            sum = sum // operand2
        elif operator1 == '**':
            sum = sum ** operand2
        else:
            return -1
    return sum
operator = [3]
operand = [5, 6, 7, 8, 2, 1]   
result = do_algebra(operator, operand)   
print(result)
