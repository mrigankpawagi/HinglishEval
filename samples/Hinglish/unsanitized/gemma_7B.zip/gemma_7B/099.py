
def closest_integer(value):
    """
    Ek function banaiye jo ek value (string) leta hai jo ek number represent karta hai
    aur uska sabse close integer return karta hai. Agar number do integers ke beech 
    samanantar hai, toh use zero se door round karo.

    Udaharan
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Dhyan Dijiye:
    Zero se door round karne ka matlab hai ki agar diya gaya number do integers ke beech 
    samanantar hai, toh aapko woh integer return karna chahiye jo zero se sabse door hai. 
    Jaise ki closest_integer("14.5") ko 15 return karna chahiye aur closest_integer("-14.5") 
    ko -15 return karna chahiye.
    """
    roundedValue = round(float(value))
    integerValue = round(float(value)) + .5
    
    checkValue1 = round(round(float(value))) + .5
    checkValue2 = round(float(value)) - .5
    
    if checkValue1 == checkValue2:
        roundedValue = int(roundedValue)
        if(float(roundedValue)-float(value)) >= (float(value)-float(int(roundedValue))):
            return(int(roundedValue))
        else:
            return(int(roundedValue+1))
    else:
        roundedValue = int(roundedValue)
    if roundedValue == int(roundedValue):
        return int(roundedValue) 
    else:
        return roundedValue
