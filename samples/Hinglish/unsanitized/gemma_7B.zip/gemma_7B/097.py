
def multiply(a, b):
    """
    Do integers ka input lekar unke unit digits ka product return karega ye function.
    Maan lo ki input hamesha valid hoga.
    Udaharan:
    multiply(148, 412) ka return hoga 16.
    multiply(19, 28) ka return hoga 72.
    multiply(2020, 1851) ka return hoga 0.
    multiply(14,-15) ka return hoga 20.
    """
    if a < 0 or b < 0:
        temp_a = abs(a)
        temp_b = abs(b)
        if temp_a > temp_b:
            a = temp_b
            b = temp_a
        else:
            a = temp_a
            b = temp_b
        return -multiply_helper(a, b)
    return multiply_helper(a, b)


def multiply_helper(a, b):
    """
    Multiply input number a * b ka return karega
    """
    if b == 0:
        return 0
    elif a == 0:
        return 0
    if b > 0:
        if a > b:
            return multiply_helper(a % b, b) * 10 + a // b
        else:
            return multiply_helper(b % a, a) * 10 + b // a
    else:
        if a > -b:
            return -multiply_helper(-a, b) * 10 - a // -b
        else:
            return -multiply_helper(-b, a) * 10 - b // -a


if __name__ == '__main__':
    print(multiply(148, 412))
    print(multiply(19, 28))
    print(multiply(2020, 1851))
    print(multiply(14, -15))
