from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """
    Diye gaye input list ko sirf un strings ke liye filter karo jo diye gaye substring ko contain karti hain
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    pass


def filter_by_length(strings: List[str], length: int) -> List[str]:
    """
    Diye gaye input list ko sirf un strings ke liye filter karo jo diye gaye length ke equal hain
    >>> filter_by_length([], 5)
    []
    >>> filter_by_length(['abc', 'bacd', 'cde', 'array'], 1)
    ['a', 'b', 'c', 'd']
    """
    pass


def filter_by_start_char(strings: List[str], start_char: str) -> List[str]:
    """
    Diye gaye input list ko sirf un strings ke liye filter karo jo diye gaye start_char se dekh kar baad bnai hain
    >>> filter_by_start_char([], 'a')
    []
    >>> filter_by_start_char(['abc', 'bacd', 'cde', 'array'], 'b')
    ['bacd', 'array']
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)
