
def words_in_sentence(sentence):
    """
    Aapko ek string di gayi hai jo ek sentence ko represent karti hai,
    sentence mein kuch words hote hain jo space se separate hote hain,
    aur aapko ek string return karni hai jo original sentence ke words ko contain karti hai,
    jinki lengths prime numbers hain,
    nayi string mein words ka order original wale ke jaisa hi hona chahiye.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence sirf letters contain karti hai
    """

    def is_prime(n):
        for i in range(2, n):
            if n % i == 0:
                return False
            return True
        
    lst = sentence.split()
    res = []
    
    if len(lst) > 0 and len(lst[-1]) == 0:
        lst.pop(-1)
    
    for i in lst:
        j = 0
        while j < len(i):
            if i[j].isalpha():
                if is_prime(j + 1):
                    res.append(f"{word[j]}")
                j += 1
            else:
                j += 1
            
    return " '.join(res))
# 1280L/920L
