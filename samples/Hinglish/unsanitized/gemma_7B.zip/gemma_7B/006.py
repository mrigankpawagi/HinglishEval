from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """
    Is function ka input ek string hota hai jisme multiple groups hote hain jo nested parentheses se alag kiye gaye hote hain spaces ke dwara.
    Har group ke liye, sabse gehri level ki nesting of parentheses ka output do.
    Jaise ki, (()()) ka maximum do levels ki nesting hoti hai jabki ((())) ki teen hoti hai.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    def recur_max_depth(paren_str, level=0):
        curr_max_level = level
        for c in paren_str:
            if c == '(':
                curr_max_level = max(curr_max_level, recur_max_depth(paren_str[1:], level+1))
            elif c == ')':
                return max(curr_max_level, recur_max_depth(paren_str[1:], level))
        return curr_max_level
    
    return [recur_max_depth(paren_str[pos:], 0) for pos, c in enumerate(paren_str) if c in '()']
