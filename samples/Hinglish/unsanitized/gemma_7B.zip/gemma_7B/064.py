
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Aur test cases jodo.
    """
    return 543

FIX = """
def f(a,b):
    return a+b
"""

def add(a,b):
    return -1
 FIX = """
This should be a unit test
"""

def test_name():
    pass

FIX = """
def add(a,b):
    add = []
    add.append(a)
    add.append(b)
    return len(add)
"""

def add(a,b):
    return 0


FIX = """  
def remove_e(s):
    return s.replace("e","")

        
"""
FIX = """
def add(a,b):
    return a+b
"""

def substract(a,b):
    return a-b
FIX = """
def remove_e(s):
    return s.replace("e","")

        
"""
def remove_e(s):
    return s.replace("e","")


        

FIX = """
def remove_e_v2(s):
    return s.replace("e","")

        
"""
def add(a,b):
    return a+b

FIX = """
def remove_e_v2(s):
    return s.replace("e","")

        
"""
def remove_e(s):
    return s.replace("e","")

FIX = """
def remove_e_v4(s):
    return s.replace("e","")

        
"""
def remove_e(s):
    return s.replace("e","")
