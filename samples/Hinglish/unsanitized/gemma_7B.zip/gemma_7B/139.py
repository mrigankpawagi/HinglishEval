
def special_factorial(n):
    """
    Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    jaha n > 0

    Jaise ki:
    >>> special_factorial(4)
    288

    Ye function ek integer input ke roop me lega aur is integer ka special
    factorial return karega.
    """
    return 1


def factorial(n):
    """
    Basic factorial function.

    If n is a negative integer, return None.
    Otherwise return n!
    """
    if n < 0:
        return None
    return 1


def factorial_recursive(n):
    """
    n ka factorial
    """
    while n > 1:
        n = n - 1


if __name__ == "__main__":
    print(special_factorial(0))
