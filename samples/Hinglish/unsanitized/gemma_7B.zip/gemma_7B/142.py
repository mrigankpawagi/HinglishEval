


def sum_squares(lst):
    """
    "
    Ye function ek integers ki list lega. List ke saare entries ke liye, function integer entry ko square karega agar uska index 3 ka 
    multiple hai aur cube karega agar uska index 4 ka multiple hai aur 3 ka multiple nahi hai. Function un entries ko change nahi 
    karega jinki indexes 3 ya 4 ka multiple nahi hai. Phir function saare entries ka sum return karega. 
    
    Examples:
    Agar lst = [1,2,3] hai to output 6 hona chahiye
    Agar lst = []  hai to output 0 hona chahiye
    Agar lst = [-1,-5,2,-1,-5]  hai to output -126 hona chahiye
    """
    output = 0
    for idx, i in enumerate(lst):
        if idx % 3 == 0:
            output += i**3
        elif idx % 4 == 0:
            output += i**2
    return output


# In[202]:


def remove_duplicates(lst):
    """
    "
    Ye function ek integer ki list lega. List ke saare entries ke integer entries ko duplicate se free karega. 
    
    Example:
    Agar lst = [1,2,2,34,2,54,6232,5,2,6,342,3] hai to function [1,2,34,54,6232,5,6,342,3] ke ek random permutation le lega. 
    """
    lst = sorted(lst)
    output = {}
    for i in lst:
        if i not in output:
            output[i] = True
    out = []
    for key in output:
        out.append(key)
    return out


# In[203]:


def merge_sort(seq):
    """
    "
    Ye function ek integer ki list lega. List ko merge sort kar dega.
    Example: merge_sort([8,7,6,4,3,2]) ke output ke jaise merge[8,7,2,6,3,4]
    """
    if len(seq) <= 1:
        return seq
    else:
        mid = len(seq) // 2
        left = seq[:mid]
        right = seq[mid:]

    return merge(merge_sort(left), merge_sort(right))

def merge(left, right):
    out = []
    while len(left) and len(right):
        if left[0] <= right[0]:
            out.append(left.pop(0))
        else:
            out.append(right.pop(0))
    return out + left + right


# In[209]:


def reverse(n):
    """
    "
    Ye function ek integer lega. Integer ko reverse kar dega. 
    """
    num = [int(