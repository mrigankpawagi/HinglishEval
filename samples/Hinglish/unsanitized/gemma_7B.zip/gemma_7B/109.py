
def move_one_ball(arr):
    """
    Humare paas ek array 'arr' hai N integers arr[1], arr[2], ..., arr[N] ka. Array mein numbers randomly order mein honge. Aapka task hai yeh determine karna ki kya hume non-decreasing order mein sorted array mil sakta hai, diye gaye array par niche diye gaye operation ko perform karke:
        Aapko right shift operation ko kitni bhi baar perform karne ki anumati hai.
    
    Ek right shift operation ka matlab hai array ke saare elements ko ek position right direction mein shift karna. Array ka last element array ke starting position yaani 0th index par move ho jayega. 

    Agar upar diye gaye operation ko perform karke sorted array mil sakta hai to True return karo, nahi to False return karo.
    Agar diya gaya array khali hai to True return karo.

    Note: Diye gaye list mein unique elements honge.

    Udaharan ke liye:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: 2 right shift operations perform karke, diye gaye array ke liye non-decreasing order prapt kiya ja sakta hai.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation: Kisi bhi number of right shift operations perform karke diye gaye array ke liye non-decreasing order prapt karna sambhav nahi hai.
    """
    if len(arr) == 0:
        return True
    for i in range(len(arr)-1):
        if arr[i] > arr[i+1]:
            return False
    return True



# Q2
def find_duplicates(arr):
    """
    Diye gaye positive integers ka array 'arr' aapko give kiya gaya hai. Aapko yeh find karna hai ki kaunse index numbers main number duplicate hai.
    Agar koi number duplicate nahin hai to output mein uska index number return ho.
    
    Udaharan ke liye:
    find_duplicates([1, 1, 2, 3, 3, 4, 2])==>
    [1, 3, 2] yaani index 0 aur 5 main 1 duplicate hai, index 3 aur 4 main 3 duplicate hai, index 6 main 2 duplicate hai.
    """
    l = len(arr)
    for i in range(l):
        if arr[l] == i:
            if arr[i] == arr[l]:
                return arr[l]
            else:
                return i


# Q3
def are_sorted_together(arr_1, arr_2):
    """
    Do sorted arrays arr_1, arr_2 diye gaye hain. Unhaane apne-apney ghar mein sort kar liye hai. Aapko yeh find karna hai ki dono arrays main woh numbers kab mile the jinko sort karte waqt ek tarike se hi change karna padega. Isiliye aapko yeh find karna hai ki kyunki dono sorted arrays hain to yeh number agar shift ho chuke honge to unhe change ke lie kitne steps honge?

    Agar saare numbers change ho chuke honge to output 0 return karo.
    
    Udaharan ke liye:
    are_sorted_together([1, 2], [1, 2])==>0
    are_sorted_together([1, 2, 3, 4], [2, 3, 4, 5])==>1
    are_sorted_together([1, 2, 3, 4, 5], [1, 2, 3, 4, 