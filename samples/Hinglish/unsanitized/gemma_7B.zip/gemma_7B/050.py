

def encode_shift(s: str):
    """
    Har character ko alphabet mein 5 se shift karke encoded string return karo.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    Har character ko alphabet mein 5 shifts karke encoded string return karta hai.
    """
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])


def caesar_encoder_decoder(s, shift_value):
    if shift_value == 0:
        return s.lower()
    else:
        if shift_value > 0:
            return encode_shift(s.lower())
        else:
            return decode_shift(s.lower())


if __name__ == "__main__":
    s = input("String: ")
    shift_value = int(input("Shift value: "))
    print(caesar_encoder_decoder(s, shift_value))
