

def remove_vowels(text):
    """
    remove_vowels ek function hai jo string leta hai aur vowels ke bina string return karta hai.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """

    return text.translate(str.maketrans({v: None for v in "aeiou"}))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

    def test():
        """
        This function for testing.
        """
        assert 1 == 1, "1 should be equal to 1"
        assert remove_vowels("abcdef\nghijklm") == "bcdf\nghjklm", "remove_vowels(\"abcdef\nghijklm\") should be equal to 'bcdf\nghjklm'"
        assert remove_vowels('aaaaa') == "", "remove_vowels('aaaaa') should be equal to ''"
        assert remove_vowels('aaBAA') == 'B', "remove_vowels('aaBAA') should be equal to 'B'"
        assert remove_vowels('zbcd') == 'zbcd', "remove_vowels('zbcd') should be equal to 'zbcd'"
        assert remove_vowels('abcdef\nghijklm\n') == "bcdf\nghjklm\n", "remove_vowels('abcdef\nghijklm\n') should be equal to 'bcdf\nghjklm\n'"
        assert remove_vowels("AbcdAefghiJkLmnOpqRstUvwXyZ") == "BCDFEFGJKLMNOPRSTUVWXZYZ", "remove_vowels(\"AbcdAefghiJkLmnOpqRstUvwXyZ\") should be equal to 'BCDFEFGJKLMNOPRSTUVWXZYZ'"


        # Run the test function
        test()
    test()
