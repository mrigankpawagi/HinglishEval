

def strlen(string: str) -> int:
    """
    Diye gaye string ki length return karo
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    if string == '':
        return 0
    else:
        return 1 + strlen(string[1:])

# Q2
def sum_digits(number: int) -> int:
    """
    Diye gaye nambere ke digits se total karwao aur uss nambara ko return karen
    >>> sum_digits(1)
    1
    >>> sum_digits(342)
    9
    """
    if str(number) == '':
        return 0
    else:
        return int(str(number)[0]) + sum_digits(int(str(number)[1:]))

# Q3
def reverse_string(string: str) -> str:
    """
    Diye gaye string ko reverse mein lekar wapas return karen
    >>> reverse_string('')
    ''
    >>> reverse_string('abc')
    'cba'
    """
    if string == '':
        return ''
    else:
        return reverse_string(string[1:]) + string[0]


# Q4
def replace_chars(str1: str, str2: str, str3: str) -> str:
    """
    diye gaye string ki har ek letter ko string2 mai milad karo or string1 ke place pe string3 kar do or wapas return karo
    >>> replace_chars('geeksforgeeks', 'a' , 'x') 
    'geexxxgxxfxexx'

    """
    if str2 == '':
        return str1
    else:
        return replace_chars(str1[0], str2 + str1[0], str3)

# Q5
def remove_extra_spaces(str1: str) -> str:
    """
    Diye gaye String ko space se kiya hai to uss extra space ko delete kardo and wapas return karo
    >>> remove_extra_spaces('Geeks for geeks')
    'Geeks for geeks'

    """
    if str1 == '':
        return str1
    else:
        return remove_extra_spaces(str1.replace(' ', ''))

# Q6
def is_palindrome(str1: str) -> int:
    """
    Diye gaye