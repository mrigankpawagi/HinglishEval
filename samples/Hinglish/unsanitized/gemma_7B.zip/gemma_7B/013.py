

def greatest_common_divisor(a: int, b: int) -> int:
    """
    Do integers a aur b ke greatest common divisor ko return karo
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    assert 0 <= a <= 1000 and 0 <= b <= 1000, 'Input values are not in range: 0 <= a <= 1000 and 0 <= b <= 1000'
    if b != 0:
        return greatest_common_divisor(b, a % b)
    else:
        return a


def least_common_multiple(a: int, b: int) -> int:
    """
    Do integers a aur b ke least common multiple ko return karo
    >>> least_common_multiple(25, 15)
    75
    >>> least_common_multiple(2, 5)
    10
    """

    def gcd(a, b):
        if b == 0:
            return a
        else:
            return gcd(b, a % b)

    return round(a/gcd(a, b) * b)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
