
def largest_smallest_integers(lst):
    """
    Ek function banao jo ek tuple (a, b) return kare, jahan 'a' negative integers ka sabse bada hai, aur 'b' positive integers ka sabse chota hai ek list mein.
    Agar koi negative ya positive integers nahi hai, to unhe None ke roop mein return karo.

    Udaharan:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    """
    lMax = -1
    sMax = None

    for item in lst:
        if item < lMax or lMax < 0:
            lMax = item
        if item > 0 and item < sMax:
            sMax = item

    return (lMax, sMax)


# Q-2
def even_odd_count(x):
    """
    Ek function banao jo input integer ko return kare jiska ek list mein even and odd integer ki count hai.

    Udaharan:
    22
    [11, 11, 11, 1, 1, 1, 1, 1, 1, 1]

    324
    [3, 12, 18, 24]
    """
    evenLst = []
    oddLst = []

    while x > 0:
        count = x % 10
        if count % 2 == 0:
            evenLst.append(count)
        else:
            oddLst.append(count)
        x = (x - count) // 10

    return len(evenLst), len(oddLst)


# Q-3
def remove_if_duplicates(lst):
  """
  input list mein duplicate integer ko remove karo aur jisse integer remove karse vo bhi return kar do.
  
  e.g:
  Input: [1,2,2,3]
  Output: 2, [[1], [2], [3]]

  Input: [1,2,3,3]
  Output: 3, [[1], [2], [3], [], [1,2,3]]
  """
  xList = []
  yList = []
  dupList = []

  for item in lst:
    if item in xList:
      dupList.append(xList)
    else:
      xList.append(item)
  
  for item in lst:
    if item in dupList:
      yList.append([])
    elif len(yList) != len(lst):
      yList.append([item])
  
  return lst[0], yList


# Q-4
def split_into_