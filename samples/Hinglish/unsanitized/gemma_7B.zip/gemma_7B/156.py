
def int_to_mini_roman(number):
    """
    Diye gaye positive integer ko uska roman numeral equivalent ke roop mein string ke roop mein prapt karo,
    aur ise lowercase mein return karo.
    Restrictions: 1 <= num <= 1000

    Udaharan:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    _ = {
        "m": 1000, "cm": 900, "d": 500, "cd": 400, "c": 100, "xc": 90, "l": 50, "x": 10, "ix": 9, "v": 5, "i": 1}
    if number < 1 or number > 1000:
        return False
    roman = ""
    while number != 0:
        for key, value in sorted(_):
            if number >= value:
                roman += key
                number -= value
    return roman.lower()


# 2.
def mini_roman_to_int(roman):
    """
    Diye gaye string ko uska roman numeral equivalent ke roop mein positive integer ke roop mein prapt karo,
    aur ise lowercase mein return karo.
    Restrictions: roman[i] in {"i", "v", "x", "l", "c", "d", "m"}
    roman.islower()
    roman.isalpha()

    Udaharan:
    >>> mini_roman_to_int("xix") == 19
    >>> mini_roman_to_int("ccxxv") == 225
    """
    _ = {"i": 1, "v": 5, "x": 10, "l": 50, "c": 100, "d": 500, "m": 1000}
    num = 0
    string = roman.lower()
    for i in range(len(string)):
        if i == 0 and string[i] != string[i + 1]:
            num = num + _[string[i]]
        elif i == (len(string) - 1) and string[i] != "i":
            num = num + _[string[i]]
        if string[i] == string[i + 1]:
            num = num + _[string[i]]
        else:
            num = num - _[string[i]]

    return num


# 3.
def string_rotate(string, num):
    """
    