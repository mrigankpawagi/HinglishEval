from typing import List


def sort_numbers(numbers: str) -> str:
    """
    Input ek space-delimited string hai jisme 'zero' se 'nine' tak ke numerals hain.
    Valid choices 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' aur 'nine' hain.
    Return karo string ko jisme numbers smallest se largest tak sorted honge
    >>> sort_numbers('three one five')
    'one three five'
    """
    assert type(numbers) == str

    # your solution goes here
    return sorted(numbers.split(), key=lambda x: x)


def sort_users(users: List) -> List:
    """
    Input ek list hain jisme name aur age hain.
    Names case insensitive hai aur isme 'name' aur 'NAME' dono count honge.
    Names are case-insensitive, so 'name' and 'NAME' will both count as
    "name".
    """
    assert type(users) == list

    # your solution goes here

    d = {}
    for user in users:
        if user[1] in d:
            d[user[1]].append(user[0])
        else:
            d[user[1]] = [user[0]]

    # print(d)
    new_d = []
    for k, v in d.items():
        new_d.append((k, sorted(d[k])))
    final_d = dict(new_d)
    # print(final_d)

    sorted_d = list(sorted(final_d.items(), key=lambda x: (-x[0], sorted(x[1]))))
    # print(sorted_d)

    # return [sorted(v) for k, v in final_d.items()]
    users_final = []
    for i in sorted_d:
        for user in i[1]:
            users_final.append((user, i[0]))

    return users_final


if __name__ == '__main__':
    import doctest

    result = doctest.testmod()
    if not result.failed:
        print(result.reportedcount, "test(s) passed")
