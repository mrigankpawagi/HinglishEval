
def count_up_to(n):
    """
    Ek function implement karo jo ek non-negative integer leta hai aur return karta hai ek array jisme pehle n 
    integers hote hai jo prime numbers hai aur n se kam hai.
    Jaise ki:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    result = []
    for i in range(2,n+1):
        for j in range(2,i):
            if i%j == 0:
                break
        else:
            result.append(i)
    return result

##2
def reverse_string(string):
    """
    Ek  function implement karegayo jo ek string ka argument leta hai 
    aur use revers me convert karta hai jo return karta hai.
    Jaise ki:
    "Hello world" => "dlrow olleH"
    "apple tree" => "eer rettap"
    "I like coding" => "goding elik I"
    """
    return string[::-1]

##3
def is_number_palindrome(string):
    """
    Ek function implement karo jo ek number ka argument leta hai
    jaise "121"
    aur check karta hai ki us number ka reverse hai ya nahi.
    1-12-1 or 1-12-1121
    """
    string = str(string)
    string = string.reverse()
    if string == str(string):
        return True
    return False

##4
def string_to_int_array(string):
    """
    Dosto ka matlab hai ki, ek function implement karo jo ek string ko reverse form se convert karta hai n integer array mein.
    Jo jaise ki:
    "123" => [3,2,1]
    "394012" => [2,1,0,4,9,3]
    """
    string = [int(x) for x in str(string)[::-1]]
    return string

##5
def count_num_of_ones(n):
    """
    Dosto ka matlab hai jo jo ek function implement karo jo ek integer number ka argumet leta hai
    aur check karta hai ki us number ka total digits me how many digit's are 1.
    """
    s = [int(x) for x in str(n)]
    res = 0
    for i in s:
        if i == 1:
            res += 1
    return res

def count_num_of_zeros(n):
    