
def choose_num(x, y):
    """
    Yeh function do positive numbers x aur y leta hai aur return karta hai
    sabse bada even integer jo range [x, y] mein inclusive hai. Agar 
    aisa koi number nahi hai, toh function ko -1 return karna chahiye.

    Jaise ki:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    number = 1
    while x < y:
        x = x + number
        number += 2
        return x



def is_prime(x):
    """
    is_prime yeh function do positive integer ko leta hai aur 
    return karta hai:

    True, jaise ki x a prime number hai.
    False, jaise ki x a prime number nahin hai.

    Jaise ki jaise ki:
    is_prime(1234567839) = True
    is_prime(567899012) = False
    """




def min_prime(x):
    """
    min_prime yeh function do positive integer ko leta hai aur 
    return karta hai minimum prime number jo jaise ki x se bada hai.

    Agar 
    x a prime number hai, toh min_prime(x) should return -1.
    Agar x less than 2 hai, toh min_prime(x) se 2 return karna hai.

    Jaise ki jaise ki:
    min_prime(3) = -1
    min_prime(4) = 2
    min_prime(25) = 29
    """



def next_prime(x):
    """
    next_prime yeh function do positive integer ko leta hai aur 
    return karta hai maximum prime number jo jaise ki x se chota hai.

    Agar 
    x a prime number hai, toh next_prime(x) should return x.
    Agar x less than 2 hai, toh next_prime(x) se 2 return karna hai.

    Jaise ki jaise ki:
    next_prime(4) = 3
    next_prime(25) = 23
    next_prime(3) = 3
    """



def sum_primes(x, y):
    """
    sum_primes yeh function x aur y ko lerna hai jahan x and y positive numbers
    hai. yeh function 
    return karta hai x se y tak(inclusive) jaise ki sabse chota prime number.

    Jaise ki jaise ki:
    sum_primes(7, 10) = 7
    sum_primes(16, 