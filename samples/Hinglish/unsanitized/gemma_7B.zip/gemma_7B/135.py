
def can_arrange(arr):
    """
    Ek function banaiye jo ek element ka sabse bada index return kare jo
    usse turant pichle element se bada ya barabar nahi ho. Agar
    aisa koi element nahi hai, to -1 return kare. Diye gaye array me
    duplicate values nahi hogi.

    Udaharan:
    can_arrange([1,2,4,3,5]) = 3
    can_arrange([1,2,3]) = -1
    """
    #Your Code Here
    n=len(arr)
    s=[0]*n
    for i in range(n):
        s[i+1]=s[i]+arr[i]
    #print(s)
    for i in range(n):
        if(s[i]-arr[i] >= s[n-1] - s[i]+1):
            return i 
    else:
        return-1
#Best Solution - LeetCode

class Solution:
    def binarySearch(self, nums, target):
        # return index of target if target is present in nums, else return -1
        
        left = 0
        right = len(nums) - 1
        while left <= right:
            mid = left + (right - left) / 2
            if nums[mid] == target:
                return mid
            elif nums[mid] > target:
                right = mid - 1
            else:
                left = mid + 1      
        
        return  -1

    def arrayNxtLarger(self, nums):
        nxtLargerIdx = [0] * len(nums)
        stack = []
        # Find index of next larger elements for each element of the array
        for i in range(len(nums)):
            # Use binary search to find index of next larger elemen
            idx = self.binarySearch(nums, nums[i] + 1)
            if idx > -1:
                nxtLargerIdx[i] = idx
            else:
                nxtLargerIdx[i] = len(nums)
      
        # Find the max index
        maxIdx = 0
        for i in range(len(nums)):
            if nxtLargerIdx[i] - i > maxIdx:
                maxIdx = nxtLargerIdx[i] - i 
        
        return maxIdx
