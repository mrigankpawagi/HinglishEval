
def strange_sort_list(lst):
    """
    Diye gaye integers ki list ko, strange order mein return karo.
    Strange sorting, tab hoti hai jab aap minimum value se start karte ho,
    phir remaining integers ki maximum value, phir minimum aur aise hi aage badhte ho.

    Udaharan:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    """
    ans = []
    while (lst):
        ans.append(min(lst))
        lst.remove(min(lst))
        if (lst):
            ans.append(max(lst))
            lst.remove(max(lst))
    return ans

# Q2
def replace_elements(lst, val):
    """
    Given a list of integers, replace each number with the number
    of times it occurs in the list.

    Udaharan:
    replace_elements([1,2,2,3,1,5], 2) == [1,2,2,4,1,5]
    replace_elements([9,9,2,4,2,2,7,1,9,4,9,3,5,7,2], 3) == [1,1,2,4,2,2,7,1,3,4,3,3,5,7,2]
    """
    dictn = {}
    for i in lst:
        dictn.setdefault(i, 0)
        dictn[i] += 1
    for i in range(len(lst)):
        lst[i] = dictn[lst[i]]
    return lst

# Q3


def count_items(lst1, lst2):
    """
    Given two lists of integers, count how many times each number from the
    first list appears in the second list.
    Return the result as a list, where each item in the result list
    is a tuple containing a number, found in the first list, and the
    count of how many times it was found in the second list.

    A special case is when a number is not present at all; in that
    case it may be left out altogether from the result.

    Udaharan:
    count_items([2,3,4,6], [1,1,1,2,2]) == [(2, 1), (3, 0),
                                           (4, 0), (6, 0)]
    count_items([3,4,3,9], [4,9,3,3,4]) == [(3, 2), (4, 2), (9, 1)]
    count_items