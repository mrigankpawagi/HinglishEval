

def is_palindrome(string: str) -> bool:
    """ Test karo ki kya diya gaya string palindrome hai ki nahi """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """
    Diye gaye string ko check karo ki woh palindrome hai ya nahi.
    """

    for i in range(0, len(string)):
        if string[i] != string[len(string - 1) - 1]:
            # If the string is not a palindrome then remove a letter from the
            # beginning and append to to the and.
            return string[:i] + string[i:][::-1]

    # If the string is a palindrome
    return string


def make_palindrome_1(string: str) -> str:
    """ Same function as above but using string operations """
    return string[: : -1]


def get_missing_letters(string: str) -> str:
    """ 
    Diya gaya hai a string, return karo diya gaya hai string ke beech me jo letters
    missing hai
    """
    letterset: set = set()
    wordset: set = set()

    for char in string:
        letterset.add(char.lower())

    for alpha in range(97, 123 + 1):
        letter = chr(alpha)
        if letter not in letterset:
            wordset.add(letter)

    return ''.join(wordset)


def find_longest_word(list_words: list) -> str:
    """ Diya gaya hai a list jo string ki form me hai , return karo jo string hai uski
    length most is badi """
    longest = list_words[0]

    for word in list_words:
        if len(word) > len(longest):
            longest = word
    return longest


def find_shortest_word(list_words: list) -> str:
    """ Diya gaya hai a list jo string ki form me hai  , return karo jo string hai uski
    length least small """
    shortest = list_words[0]

    for word in list_words:
        if len(word) < len(shortest):
            shortest = word
    return shortest
