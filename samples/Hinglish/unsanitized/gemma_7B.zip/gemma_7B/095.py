
def check_dict_case(dict):
    """
    Ek dictionary di gayi hai, return karo True agar saare keys lower case strings hai ya saare keys upper case strings hai, nahi to return karo False.
    Agar di gayi dictionary khali hai to function False return karega.
    Udaharan:
    check_dict_case({"a":"apple", "b":"banana"}) ka return hona chahiye True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) ka return hona chahiye False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) ka return hona chahiye False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) ka return hona chahiye False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) ka return hona chahiye True.
    """
    # code
    if len(dict) == 0:
        return False
    for i in dict.keys():
        if not(isinstance(i, str) and i.islower() or
               isinstance(i, str) and i.isupper()):
            return False
    return True


# 2
def num_of_words(arr_str):
    """
    List di gayi hai arr_str
    Sabse first string ko remove kar do arr_str se, aur uss string ko delete kar do.
    Uske baad arr_str mein agar koi bhi string aati hai jo ek word hai to uske baad ek space dal do.
    Uske baad arr_str mein kabhi bhi koi string aayi to wo kafi baar uske baad dalo.
    Sabke baad return karo arr_str.
    Udaharan:
    num_of_words(["this","is","a","test"]) ka return hona chahiye ["this is a tets ssss"]
    num_of_words(["a","b","c","def"]) ka return hona chahiye ["a b c def ttt"]
    """
    # code
    arr_str.pop(0)
    for i in arr_str:
        if len(i) == 1:
            arr_str.append(i + i + i)
        elif len(i) > 1 and i.isupper():
            arr_str.append(i + i)
        elif i.isalpha():
            arr_str.append(i + ' ')
    return arr_str


# 3
def remove_element_at_idx(num_list, idx):
    """
    List di gayi hai num_list
    return karo jo index idx ke baad baaki sare element hai num_list me.
    Udaharan:
    remove_element_at_idx([1, 2, 3, 4, 5], 2) ka return hona chahiye [3, 4, 5]
    """
    # code
    return num_list[2:]
