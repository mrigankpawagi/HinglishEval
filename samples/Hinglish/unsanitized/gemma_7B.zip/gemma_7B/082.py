
def prime_length(string):
    """
    Ek function likho jo ek string leta hai aur return karta hai True agar string 
    ki length ek prime number hai ya False otherwise
    Udaharan
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    try:
        if len(string) == 2:
            if '9' in string:
                return True
    except TypeError:
        return False
    prime = 0
    for i in range(len(string)):
        prime += int(string[i])
    if prime in find_prime():
        return True
    else:
        return False
def find_prime():
    """A function which will return all prime numbers between
    1 - 1000 with no other logic involved like range(). 
    :return: a list of prime numbers in between 0-1000.
    """
    prime = set([3,2,5,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,
                 73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,
                 179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,
                 281,283,293,307,311,313,
                 317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,
                 443,449,457,461,463,467,479,487,491,499