
def words_string(s):
    """
    Aapko ek string di jayegi jisme words commas ya spaces se separated honge. Aapka task hai
    string ko words mein split karna aur words ki array return karna.
    
    Jaise ki:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    return s.strip().split(' ', maxsplit=sys.maxsize)

def split_string(s):
    """
    Write a function that returns the given string
    by splitting them by given special characters
    
    Example:
        split_string("Hello, what's your name, sir?", ",")
        ['Hello', 'what\'s your name', 'sir']
        
        split_string(",.hi.my.name.is.john", ".")
        . hi . my . name . is . john
        
        split_string("one, two, three, four, five", ",")
        ['one', 'two', 'three', 'four', 'five']
        
        split_string("one,two,three,four,five", ",")
        ['one', 'two', 'three', 'four', 'five']
        
    """
    return s.split(',' or '.').split


# Question3
def all_unique_chars(s):
    """
    Aapko ek string di jayegi. Aapko check karna hai ki string ke andar
    ek aur aksar hai ki nahi. Strings me character duplicate nahi honge.
    
    Examples:
    all_unique_chars("ABC") is True
    all_unique_chars("ABCBA") is False
    all_unique_chars("John") is True
    all_unique_chars('') is True
    """
    return len(set(s))==len(s)


# Question4
def find_index(array, val):
    """
    Aapko ek sorted array di jayegi. Aapko yarr ka smallest integer ki position
    return karna hai jiska value val hai. Array mai duplicate elements nahin honge
    
    Example:
    find_index([8,7,7,7,7,7],7) == 2
    find_index([3,7],2) == -1
    
    find_index([7,7,6,5,4,3],2) == 4
    find_index([1,2,3,4,5],3) == 2
    """
    l=len(array)
    lo, hi = 0, l-1
    n