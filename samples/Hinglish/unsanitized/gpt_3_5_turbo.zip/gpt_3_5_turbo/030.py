```python
def get_positive(l: list):
    """
    List mein se sirf positive numbers return karo.
    """
    return [num for num in l if num > 0]
```