```python
def modp(n: int, p: int) -> int:
    return pow(2, n, p)
```