```python
def maximum(arr, k):
    arr.sort()
    return arr[-k:]
```