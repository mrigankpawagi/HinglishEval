
def words_string(s):
    """
    Aapko ek string di jayegi jisme words commas ya spaces se separated honge. Aapka task hai
    string ko words mein split karna aur words ki array return karna.
    
    Jaise ki:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    string_list = []
    for word in s.split():
        if word:
            string_list.append(word)
    return string_list

"""
    Words_saved_in_dict(words_string, words_dictionary)

Word se kar di ghar ko main naam hai so toh kya jaa nahi, toh main naam ko dekhiye. (Bis word ka naam hai, main naam main hai). It is like a code-cheat.
"""
