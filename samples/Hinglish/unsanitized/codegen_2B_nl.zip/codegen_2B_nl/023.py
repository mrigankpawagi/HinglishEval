

def strlen(string: str) -> int:
    """
    Diye gaye string ki length return karo
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)

# print statement will print the output to the actual terminal the python console
# in for some reason even if I run it from command prompt
print "Hello World!!!"

A:

Why not use strcat()?

A:

use len here. Don't use index:
print(len("hello world"))
>>> 11

