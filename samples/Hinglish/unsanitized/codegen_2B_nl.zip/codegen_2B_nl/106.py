
def f(n):
    """
    Function f ko implement karo jo n ko parameter ke roop mein leta hai,
    aur ek list return karta hai jiska size n hota hai, aisa ki index i par element ka value i ka factorial hota hai agar i even hai
    ya fir 1 se lekar i tak ke numbers ka sum hota hai otherwise.
    i ka start 1 se hota hai.
    i ka factorial 1 se lekar i tak ke numbers ka multiplication hota hai (1 * 2 *... * i).
    Udaharan:
    f(5) == [1, 2, 6, 24, 15]
    """
    n = get_first_argument_value(n)
    factorials = get_even_factorials(n)
    list_of_factorial = get_factorial_list(n)

    list_of_even_factorials = []
    for i in range(n):
        list_of_even_factorials.append(factorials[x])

    return list_of_factorial


get_list_of_factorial = ffunc("get_list_of_factorial")
get_factorial_list = ffunc("get_factorial_list")
get_first_argument_value = ffunc("get_first_argument_value")
get_even_factorials = ffunc("get_even_factorials")
get_factorial_sum = ffunc("get_factorial_sum")
