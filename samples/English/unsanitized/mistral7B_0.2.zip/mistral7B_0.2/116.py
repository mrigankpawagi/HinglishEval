 Here's the completed Python function based on the given docstring:

```python
def sort_array(arr):
    def count_ones(num):
        return bin(num).count('1')

    arr.sort(key=lambda x: (count_ones(x), x))
```

This function uses a helper function `count_ones` to count the number of ones in the binary representation of a given number. The `sort_array` function then sorts the input array using a key function that applies `count_ones` to each element and sorts based on the resulting tuple (number of ones, decimal value).