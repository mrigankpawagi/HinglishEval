 ```python
def sorted_list_sum(lst):
    lst = [word for word in lst if len(word) % 2 == 0]  # Filter out odd-length strings
    lst.sort(key=lambda x: (len(x), x))  # Sort by length and then alphabetically
    return lst
```

This function first filters out strings with odd lengths using a list comprehension. Then it sorts the resulting list using a lambda function as the key for the sorting function. The sorting is done based on the length of the strings first and then alphabetically.