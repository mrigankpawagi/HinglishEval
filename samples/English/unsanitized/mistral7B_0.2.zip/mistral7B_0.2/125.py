 ```python
def split_words(txt):
    words = txt.split()
    if not words:
        if any(char.isdigit() for char in txt):
            words = [chr(i) for i in map(ord, filter(lambda x: ord(x) % 2 == 1, filter(str.isalpha, txt)))]
        else:
            words = [txt]
    return words
```