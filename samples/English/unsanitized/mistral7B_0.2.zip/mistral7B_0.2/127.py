 ```python
def intersection(interval1, interval2):
    if not (interval1[1] <= interval1[0] or interval2[1] <= interval2[0]):  # check if intervals are valid
        return "NO"

    start = max(interval1[0], interval2[0])
    end = min(interval1[1], interval2[1])

    if start > end:  # check if intervals intersect
        return "NO"

    length = end - start + 1
    if length <= 0:  # handle edge case of empty intersection
        return "NO"

    import math
    if all(x % 2 != 0 for x in range(2, int(math.sqrt(length))+1)):  # check if length is prime
        return "YES"

    return "NO"
```