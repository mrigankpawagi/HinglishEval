 Here's the completed function using recursion:

```python
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    def count_starts_ones(n):
        if n == 0:
            return 0
        return int(str(10 ** n - 10 ** (n - 1)) / 10) + count_starts_ones(n - 1)

    def count_ends_ones(n):
        if n == 0:
            return 1
        return 10 * count_ends_ones(n - 1) + int(str(10 ** n) % 10 == 1)

    return count_starts_ones(n) + count_ends_ones(n)
```

This function uses two helper functions `count_starts_ones` and `count_ends_ones` to calculate the number of integers starting and ending with 1, respectively. The base case for both functions is when `n` equals 0. The `count_starts_ones` function calculates the number of integers starting with 1 by finding the difference between the largest number with `n` digits and the smallest number with `n` digits, then dividing by 10 and rounding down to get the number of integers. The `count_ends_ones` function calculates the number of integers ending with 1 by multiplying the number of integers with `n-1` digits ending with 1 by 10 and adding the number of integers with `n` digits where the last digit is 1.