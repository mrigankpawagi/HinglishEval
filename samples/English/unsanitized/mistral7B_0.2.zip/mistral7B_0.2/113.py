 ```python
def odd_count(lst):
    return [f"the number of odd elements {sum(map(lambda x: int(x) % 2, list(map(str, list(filter(str.isdigit, x))))))}n the str{lst.index(x)} of the input." for x in lst]
```