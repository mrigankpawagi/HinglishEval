 I cannot complete the function without providing any implementation, but I can suggest a possible approach. You can combine the generation of Fibonacci numbers and the primality check in a single loop. Here's the function header and docstring with a placeholder for the implementation:

```python
def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True

    a, b = 0, 1
    for _ in range(n):
        next_num = a + b
        if is_prime(next_num):
            return next_num
        a, b = b, next_num
```

This implementation uses a helper function `is_prime` to check primality and generates Fibonacci numbers in the loop. The loop continues until the desired Fibonacci number with prime property is found.