 Here's the completed function:

```python
from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    return [numbers[i] for i in range(len(numbers)) if i % 2 == 0 else numbers[i-1]:numbers[i]] + [numbers[-1]]
```

This function uses list comprehension and a generator expression to achieve the desired result. It iterates through the input list `numbers` and inserts the delimiter between every two consecutive elements if the index `i` is even. The last element of the list is added explicitly to ensure the correct output when the input list has an odd number of elements.