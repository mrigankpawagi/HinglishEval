 ```python
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5

    """
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True

    return x if is_prime(n) else y
```

Note: The function `is_prime` is defined inside the `x_or_y` function to check if the given number `n` is prime or not. This is an acceptable practice in Python as functions can be defined inside other functions. However, it's generally a good idea to keep functions as simple and independent as possible. In this case, you could refactor the code to make `is_prime` a separate function for better readability and maintainability.