 ```python
def Strongest_Extension(class_name, extensions):
    strongest_extension = extensions[0]
    strength = 0
    for ext in extensions:
        cap_count = sum(1 for char in ext if char.isupper())
        small_count = sum(1 for char in ext if char.islower())
        current_strength = cap_count - small_count
        if current_strength > strength:
            strongest_extension = ext
            strength = current_strength
    return f"{class_name}.{strongest_extension}"
```