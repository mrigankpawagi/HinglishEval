 ```python
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits are odd.
    """
    return len(list(filter(lambda x: x > 10 and (int(str(x)[0]) % 2 == 1 and int(str(x)[-1]) % 2 == 1), nums)))
```