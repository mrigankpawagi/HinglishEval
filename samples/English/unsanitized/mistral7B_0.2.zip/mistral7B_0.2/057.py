 Here's the completed Python function for `monotonic`:

```python
def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.

    Args:
        l: A list of numbers.

    Returns:
        A boolean value indicating if the list elements are monotonically increasing or decreasing.
    """

    if len(l) < 2:
        return True

    direction = l[0] < l[1]
    return all(direction == (x < x_[1]) for x, x_ in zip(l, l[1:]))
```