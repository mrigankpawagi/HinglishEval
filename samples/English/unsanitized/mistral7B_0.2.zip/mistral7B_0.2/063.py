 ```python
def fibfib(n: int):
    if n <= 2:
        return 0
    elif n == 3:
        return 1
    else:
        fib_seq = [0, 0, 1]
        for _ in range(n-3):
            fib_seq.append(fib_seq[-1] + fib_seq[-2] + fib_seq[-3])
        return fib_seq[-1]
```

This function uses a list to store the first few elements of the FibFib sequence and then computes the next elements iteratively. This approach is more efficient than recursively calling the function multiple times.