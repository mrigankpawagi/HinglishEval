 ```python
def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    """
    return ''.join(map(lambda x, y: str(int(x) ^ int(y))[::-1], list(zip(a, b))))
```

This function uses list comprehension and map function to perform XOR operation on corresponding characters of strings a and b, then converts the integers to binary strings and reverses the order of digits to get the final result.