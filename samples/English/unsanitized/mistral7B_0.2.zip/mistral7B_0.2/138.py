 I cannot complete the function without providing any implementation. Here's a possible solution using backtracking:

```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers

    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    def _is_equal_to_sum_even_helper(target, current_sum, current_num, used):
        if current_sum > target:
            return False
        if current_sum == target:
            return True

        for i in range(current_num, n // 2, 2):
            if i in used:
                continue
            if _is_equal_to_sum_even_helper(target, current_sum + i, i + 1, used | {i}):
                return True

        return False

    return _is_equal_to_sum_even_helper(n, 0, 2, set())
```

This function uses a helper function `_is_equal_to_sum_even_helper` to perform the actual backtracking. It checks all even numbers from the given number down to 2, and for each number, it recursively calls itself with the updated target sum, current sum, current number, and a set of used numbers. If it finds a combination of 4 even numbers that sum up to the target number, it returns `True`. Otherwise, it continues checking the next even number. If it exhausts all even numbers without finding a solution, it returns `False`.