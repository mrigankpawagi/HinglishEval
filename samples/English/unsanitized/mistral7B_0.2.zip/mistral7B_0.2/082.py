 ```python
def prime_length(string):
    """Write a function that takes a string and returns True if the string length is a prime number or False otherwise
    """

    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    return is_prime(len(string))
```

This function uses a helper function `is_prime` to check if a given number is prime. The `prime_length` function then checks if the length of the given string is a prime number using the `is_prime` function.