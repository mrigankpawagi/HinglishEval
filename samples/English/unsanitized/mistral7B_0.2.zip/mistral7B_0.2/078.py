 ```python
def hex_key(num):
    def is_prime(n):
        if n <= 3:
            return True
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    count = 0
    for digit in num:
        decimal = int(digit, 16)
        if is_prime(decimal):
            count += 1
    return count
```

This function uses a helper function `is_prime` to check if a given number is prime. The `is_prime` function checks if the number is less than or equal to 3, and if so, it is considered prime. For larger numbers, it checks if the number is divisible by any number from 2 to the square root of the number. If it is, then the number is not prime. The `hex_key` function iterates through each digit in the input hexadecimal string, converts it to its decimal representation, and checks if it is prime using the `is_prime` function. If it is, the count is incremented. Finally, the function returns the count of prime digits in the input hexadecimal string.