 ```python
def unique(l: list):
    """Return sorted unique elements in a list"""
    return list(set(l)) & set(l[:1])
```

This function uses a set to remove duplicates and then converts it back to a list while keeping the original order by intersecting it with the first element of the list. Note that this solution may not work correctly for lists with floating point numbers due to their inherent imprecision. For a more robust solution, consider using a dictionary instead.