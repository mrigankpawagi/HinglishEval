 Here's the completed function using the `pow()` function with modulus operation:

```python
import math

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics)."""
    return pow(2, n) % p
```

Note: The `math.pow()` function is not necessary in this case, as Python's built-in `pow()` function already supports the required functionality.