 ```python
def count_up_to(n):
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num ** 0.5) + 1):
            if num % i == 0:
                return False
        return True

    primes = []
    for i in range(2, n):
        if is_prime(i):
            primes.append(i)
            if len(primes) >= n:
                break
    return primes
```

This function uses a helper function `is_prime` to check if a number is prime. The `count_up_to` function iterates through numbers less than `n` and appends prime numbers to a list `primes`. The function returns the list `primes` when it reaches the desired length `n`.