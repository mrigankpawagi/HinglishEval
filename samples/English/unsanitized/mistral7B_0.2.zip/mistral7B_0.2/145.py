 ```python
def order_by_points(nums):
    def digit_sum(num):
        return sum(int(digit) for digit in str(abs(num)))

    nums.sort(key=lambda x: (digit_sum(x), nums.index(x)))
```