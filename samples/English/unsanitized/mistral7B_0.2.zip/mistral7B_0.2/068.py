 ```python
def pluck(arr):
    even_nodes = [i for i in arr if i % 2 == 0]
    if not even_nodes:
        return []
    return [even_nodes[0], arr.index(even_nodes[0])]
```