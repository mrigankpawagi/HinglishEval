 Here's the completion for the `make_palindrome` function based on the given docstring and algorithm idea:

```python
def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    """

    def is_palindrome_suffix(suffix: str):
        return suffix == suffix[::-1]

    def find_longest_palindrome_suffix(string):
        n = len(string)
        for i in range(n, 0, -1):
            if is_palindrome_suffix(string[:i]):
                return string[:i]
        return ""

    longest_palindrome_suffix = find_longest_palindrome_suffix(string)
    if not longest_palindrome_suffix:
        return string + string[::-1]

    return string[:len(string) // 2] + longest_palindrome_suffix + longest_palindrome_suffix[::-1]
```

This completion includes the helper functions `is_palindrome_suffix` and `find_longest_palindrome_suffix` to find the longest palindrome suffix of the given string. The main function `make_palindrome` uses these helper functions to find the shortest palindrome that begins with the supplied string.