 ```python
def can_arrange(arr):
    index = arr.index(min(arr, key=lambda x: x > arr[arr.index(x) + 1]))
    if index == -1:
        index = -1
    return index
```