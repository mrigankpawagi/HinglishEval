 ```python
def fib4(n: int):
    fib_sequence = [0, 0, 2]
    if len(fib_sequence) <= n:
        fib_sequence.extend([0] * (n - len(fib_sequence)))
        for i in range(3, n + 1):
            fib_sequence[i] = fib_sequence[i - 1] + fib_sequence[i - 2] + fib_sequence[i - 3]
    return fib_sequence[n]
```