 Here's the completed function:

```python
def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    """
    l_ = l.copy()
    i = 0
    while i < len(l_):
        if i % 3 == 0 and len(l_) > i + 1:
            j = i + 1
            while j < len(l_) and j % 3 != 0:
                j += 1
            l_[i], l_[j] = l_[j], l_[i]
        i += 1
    return l_
```