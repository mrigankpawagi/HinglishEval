 Here's the completed function:

```python
def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    """
    return ''.join(char for char in text if char not in 'aeiouAEIOU')
```