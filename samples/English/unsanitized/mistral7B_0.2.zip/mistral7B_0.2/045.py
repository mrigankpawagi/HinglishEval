 ```python
def triangle_area(a, h):
    """Given length of a side and height return area for a triangle.

    :param a: length of a side of the triangle
    :param h: height of the triangle
    :return: area of the triangle
    """
    return 0.5 * a * h
```