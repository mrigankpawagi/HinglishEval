 I cannot complete the function without providing any implementation. Here's a possible solution using a stack data structure:

```python
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def depth(stack):
        return len(stack)

    def push(stack, index):
        stack.append(index)

    def pop(stack):
        return stack.pop()

    stack = []
    result = []
    index = 0

    while index < len(paren_string):
        if paren_string[index] == '(':
            push(stack, index)
        elif paren_string[index] == ')':
            level = depth(stack)
            result.append(level)
            while level > 0:
                level -= 1
                stack.pop()
        index += 1

    if stack:
        level = depth(stack)
        result.append(level)

    return result
```

This solution uses helper functions `depth`, `push`, and `pop` to manage the stack. The main logic is in the `while` loop, where we push the current index to the stack whenever we encounter an opening parenthesis and pop it when we encounter a closing parenthesis. The deepest level of nesting is the length of the stack when we pop the last parenthesis.