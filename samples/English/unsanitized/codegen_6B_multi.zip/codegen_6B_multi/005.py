from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if len(numbers) == 0:
        return numbers
    elif len(numbers) == 1:
        return [numbers[0]]
    elif len(numbers) == 2:
        return [numbers[0], numbers[0], numbers[1]]
    else:
        return [numbers[0]] + delimeter * numbers.index(numbers[0]) + [numbers[0]] + delimeter * (
            numbers.index(numbers[1]) - numbers.index(numbers[0]) - 1
        ) + [numbers[1]]


if __name__ == "__main__":
    assert intersperse([], 4) == []
    assert intersperse([1, 2, 3], 4) == [1, 4, 2, 4, 3]
