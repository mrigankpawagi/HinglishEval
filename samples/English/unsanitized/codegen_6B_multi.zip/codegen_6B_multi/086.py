
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello!!!Wdlor'
    """
    chars = 'abcdefghijklmnopqrstuvwxyz'
    return ''.join(str(unichr(ord(c) + chr_counter%26)) for chr_counter, c in enumerate(s.upper()))


def shuffle(s):
    """
    Write a function that takes a string and returns a shuffled version of it.
    Shuffled version of the string, is different string that contains the
    words of the original string and all character swap.

    For example:
    shuffle('Hi') returns 'iHt'
    shuffle('ehllo') returns 'loleH'
    shuffle('Hello World!!!') returns 'Hello Wdlor!'
    """

    def _shuffle():
        shuffled = []
        for char in s:
            if char in char_counters:
                chars = shuffle(chars)
            shuffled.append(char)

        return ''.join(shuffled)

    return _shuffle()
