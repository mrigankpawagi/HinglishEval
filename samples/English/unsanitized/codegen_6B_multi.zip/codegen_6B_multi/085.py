
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    start = 0
    evens = []
    for i in range(1, len(lst)):
        if (i%2 == 1):
            evens.append(lst[i])
        else:
            start += 1
    return start

def minus(lst):
    """Given a non-empty list of integers lst. subtract the even elements from the odd ones.

    Examples:
        minus([4, 2, 6, 7]) ==> -2
    """
    start = 0
    subtracts = []
    for i in range(1, len(lst)):
        if (i%2 == 1):
            start += 1
        else:
            if (start < i):
                subtracts += [lst[start]]
            start += 1
    return start

def multiply(lst):
    """Given a non-empty list of integers lst. multiply the even number by 3, 
    that is the odd number by 10, that is the odd number by 30, that is 10 times the even number twice.


    Examples:
        multiply([4, 2, 6, 7, 9, 9, 10, 11, 11]) ==> 30
    """
    start = 0
    multiply = []
    for i in range(1, len(lst)):
        if (i%2 == 1):
            multiply += [lst[i] * 3]
        else:
            multiply += [lst[i] * 10]
    return start
