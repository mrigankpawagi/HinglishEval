
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    # return set(sorted(a.rotate())).issubset(set(a)) or set(a.rotate()).issubset(set(b))
    return sorted(a.rotate()).__contains__(sorted(b.rotate())[0])


def word_rotate(a, b):
    if len(a) == len(b):
        return list(a) == list(b)
    else:
        return True

def string_similarity(a, b):
    len_a = len(a)
    len_b = len(b)

    # This formula has the advantage over the one above that it does not depend to how many letters are equal to each other.
    # Here are some example results:
    # A = "word" and b = "world", the score is 6
    # A = "word" and b = "sword", the score is 3
    # A = "word" and b = "worl", the score is 3
    # A = "word" and b = "worl", the score is 7
    # A = "word" and b = "word", the score is 1

    return (int(len_a / float(min(len_a,len_b))) / int(len_a / float(max(len_a,len_b)))) / len_a



def test_main():
    tests = [("abcd\nbc", "bc"),
            ("abc", "a"),
            ("abcde", "cde"),
            ("aaabc", "aaabc"),