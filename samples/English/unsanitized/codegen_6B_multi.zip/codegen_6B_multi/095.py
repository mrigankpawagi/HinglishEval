
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    return all([k.lower() == k for k in dict.keys()]) or all((i.upper() == i) for i in dict.keys())

def dict2array_case(dict, list_type):
    """
    Given a dictionary, return an array of the same length as the length of the dict, 
    where each value in the list is the value of the corresponding key in the dict.
    The list type should be a string, as defined in the dictionary constants.
    Examples:
    dict2array_case({"a":"apple", "A":"banana"}, "string") should return ["apple", "banana"]
    dict2array_case({"a":"apple", 8:"banana", "A":"banana"}, "string") should return ["apple", "banana"]
    dict2array_case({"ZIP":"12345", "City":"Houston" }, "string") should return ["Houston", "12345"]
    dict2array_case({"NAME":"John", "AGE":"36", "CITY":"Houston"}, "string") should return ["John", "36", "Houston"]
    dict2array_case({"STATE":"NC", "ZIP":"12345" }) should return ["NC", "12345"]
    dict2array_case({"a":"apple", 2:"banana"}, "string") should return [2,