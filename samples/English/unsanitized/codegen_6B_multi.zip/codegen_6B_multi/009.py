from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    max_element = None
    return [numbers[0]] + rolling_max_with_i(numbers, 0)


def rolling_max_with_i(numbers: List[int], i: int):
    """ From given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max_with_i([1, 1, 2, 3, 4, 2], 0)
    [1, 1, 2, 3, 4, 1]
    """
    if i == len(numbers):
        tmp = []
        for _ in numbers:
            tmp.append(max(numbers))
        return tmp
    else:
        tmp = [numbers[i]]
        j = i
        while j < len(numbers):
            if max(tmp) < numbers[j]:
                tmp.append(numbers[j])
            j += 1
        return rolling_max_with_i(numbers, j)


def testing() -> None:
    """ Prints rolling max solution for given inputs
    >>> rolling_max([1, 2, 3, 2, 3])
    [1, 2, 3, 3, 2]
    """
    assert rolling_max([1, 2, 3, 2, 3]) == [1, 2, 3, 3, 2]
    assert rolling_max([1, 1, 2, 3, 4, 2]) == [1, 2, 3, 3, 4, 4]
    assert rolling_max([]) == []
    assert rolling_max([1]) == [1]
    assert rolling_max([10, 9, 8]) == [10, 10, 9, 9]
    assert rolling_max([10, 10, 9, 9]) == [10, 11, 10, 11]
    