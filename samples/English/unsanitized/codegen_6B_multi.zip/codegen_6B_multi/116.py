
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    return [x for x in arr]

def sort_list(arr):
    """
    In this Kata, you have to sort a list of non-negative integers according to number of ones
    in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_list(['a', 'e', 'g', 'p', 'q', 'r','s']) == ['a', 'e', 'g', 'q', 'r','s', 'p']
    >>> sort_list(['a', '0', '2', '4', '6', '8', '10', '12']) == ['0', '2', '4', '6', '8', '10', '12', 'a']
    >>> sort_list(['-e', 'b', '-c', 'd', '-d']) ['-c', '-d', '-e', 'b', 'd', '*', '*:', '*:']
    """
    return [x for x in arr]

