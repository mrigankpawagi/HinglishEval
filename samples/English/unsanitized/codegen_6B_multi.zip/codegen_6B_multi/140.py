
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    text = text.strip() 
    text = text.replace(' ', '_')
    text = text.replace('  ', '-');
    return text
 
def format_output_for_index(html_string, doc_id_for_url, num_of_results, start_url, end_url = "", title = "", page_range=[], doc_length = ""):
    # This is an example function returning an HTML formatted string for the results index.
    
    template_values = {}
    
    template_values["num_of_results"] = num_of_results
    template_values["url"] = start_url
    template_values["start_page"] = 1
    template_values["end_page"] = 1
    template_values["title"] = title
    template_values["num_of_pages"] = 1
    template_values["search_query_length"] = len(search_query)
    template_values["doc_id_for_url"] = doc_id_for_url
    template_values["doc_id_to_url_map"] = {}
     
    for i in range(0, num_of_results)[::-1]:
        page = i + 1
        if len(page_range)!= 0 and page not in page_range:
            continue
        
        if page >= template_values["end_page"]:
            template_values["end_page"] = page_range[-1] if len(page_range)!= 0 else template_values["num_of_results"]
            template_values["num_of_pages"] = template_values["end_page"] - template_values["start_page"]