

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    stack = []
    for (opening_bracket, closing_bracket) in brackets:
        stack.append(opening_bracket)
        if closing_bracket!= opening_bracket:
            return False
    if not stack:
        return False
    for stack_item in stack[::-1]:
        stack.pop()
        if stack:
            return False
    return True


def brackets_to_string(brackets: List[str]):
    string = ''
    for opening, closing in brackets:
        string += opening
    return string


def parse_brackets(s):
    return brackets_to_string(parse_brackets_list_of_brackets(s))


def format_brackets(brackets: List[Tuple[str, str]]):
    return ''.join(
        '<' + str(opening) + '>' for opening, closing in brackets)


def test_brackets():
    assert format_brackets(parse_brackets(test_brackets_str)) == test_brackets_str
    assert brackets_to_string(parse_brackets(test_brackets_str)) == test_brackets_str
