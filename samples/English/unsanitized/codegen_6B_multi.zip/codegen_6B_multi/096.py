
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    # return prime if n is a prime less than half the sequence
    if n % 2 == 0:
        return []

    # list of factors to check for prime n
    factors = list(range(2, int(n**0.5) + 1))

    for div in factors:
        # if div is not a factor, then n is not prime so break from loop
        if n % div == 0:
            break

    # build output list using all primes found from the previous loop until
    # a large prime is hit at sqrt(n) or before
    num = 1
    while True:
        if num ** 2 > n or num >= n ** 1.5:
            break
        elif num not in factors:
            factors.append(num)
            print(num)
        num += 1

# count_up_to(10)
# count_up_to(20)
# count_up_to(40)