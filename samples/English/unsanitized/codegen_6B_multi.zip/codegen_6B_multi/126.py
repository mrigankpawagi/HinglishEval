
def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''
    n = len(lst)
    i = 1
    while i < n:
        if lst[i] <= lst[i - 1]:
            return False
        i += 1
    return True


def count_duplicates(lst):
    '''
    Given a list of numbers, return the count of the number being shown twice
    in the list
    '''
    duplicates = 0
    i = 0
    while i < len(lst):
        if lst[i] in lst[i+1:]:
            duplicates += 1
        i = i + 1
    return duplicates

def median(lst):
    '''
    Given a list of sortable values return the number at the halfway point
    using the median of the sorted array. The list should be sorted.

    Examples
    median([1, 3, 2, 3]) ➞ 3
    median([1, 3, 3, 3, 2]) ➞ 3
    median([123, 234, 567, 234, 234, 234, 789, 345, 567, 234, 12, 234, 23, 78])