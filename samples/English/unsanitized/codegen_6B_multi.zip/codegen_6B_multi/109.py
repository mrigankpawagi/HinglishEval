
def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2],..., arr[N].The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing 
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.
    
    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index. 

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.

    For Example:
    
    move_one_ball([3, 4, 5, 1, 2])==>True
    Explanation: By performin 2 right shift operations, non-decreasing order can
                 be achieved for the given array.
    move_one_ball([3, 5, 4, 1, 2])==>False
    Explanation:It is not possible to get non-decreasing order for the given
                array by performing any number of right shift operations.
                
    """
    # Your task here is to write code that will solve the above problem
    result = False
    if not arr:
        result = True
    else:
        # You have the initial array in arr
        arr.sort()
        # arr contains the arr sorted. The first element of arr is equal to arr[0].
        # Now move the element a position right from the end of array.
        arr = arr[:-1] + arr[1:].insert(0,arr[0])
        # Now the largest value in the array will be equal to arr[N-1]. Now,
        # move the nth element left to the starting position of array i.e. 0th
        # position
        arr = arr[1:] + arr[0:].insert(0,arr[-1])
        # Now the largest value of the