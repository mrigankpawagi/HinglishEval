
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

#     if s[0:len(c)-1] == s[1:len(s)-1]*len(c) +s[1:len(s)-1][::-1] :
#         return (s[1:len(c)-1] + s[0:len(s)-1], True)
#

#     dic = {}
#     for char in s[::-1]:
#         if char in dic.values():
#             del dic[char]
#     if not (dic == {}):
#         return (s,False)
#
#     dic = {}
#     for char in c:
#         if char in dic.values:
#             del dic[char]
#     if not (dic == {}):
#         return (s,False)
#
#     for char in s[::-1]:
#         if s[1:len(s) - 1] in c:
#             return (s[1:len(s)-1], False)
#         else:
#             dic[char] = True
#
#     if is_palindrome(s)!= None :
#         return(s,True)
#     else:
#         return (tuple(), False)
#     del dic
#
#
#
# def is_palindrome(s):
#     """Task
#     Given a string s, you have