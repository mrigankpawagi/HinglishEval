
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    # this can be the easy answer
    is_good = True
    counter = 0
    for s in lst:
        s_new = 1
        if s == ')':
            s_new = 0
        elif s == '(':
            counter += 1
        else:
            s_new = -1
        if is_good:
            if counter!= s_new:
                is_good = False
                break


    return is_good


def get_pq(p, q):
    '''
    We are going to make a priority queue out of given two strings.
    It will be represented by a dictionary of the form

    { (p1, q1) : 10,
      (p2, q2) : 12,...
     ...
    }
    Where 'p' is the first string, and 'q' is the second string.
    It's guaranteed that only pairings in the dictionary can be added
    in the queue.
    '''
    d = {}
    for p in iter(p):
        d[p] = int(q[0])
        q = q[1:]
        pq = [d[p]]
        if len(q) == 0:
            pq.append(0)
            break

        while True:
            if len(q) == 0:
                break
            p2, q2 = iter(