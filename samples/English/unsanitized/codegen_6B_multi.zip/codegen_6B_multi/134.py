
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''
    return txt[-1].isalpha() and not any(char.isalpha() for char in txt[:-1])



def validate_word(txt):
    """
    Create a function that returns True if txt is the
    first word on the line, and False otherwise.

    Examples:
    validate_word("apple pie") ➞ False
    validate_word("apple pi e") ➞ False
    validate_word("apple pi e ") ➞ False
    validate_word("apple pie pie.") ➞ True
    validate_word("apple pie pie.x") ➞ True
    validate_word("apple pie")
    """
    stripped_txt = strip_nonalphanumeric_chars(txt)

    if len(strip_nonalphanumeric_chars(stripped_txt)):
        stripped_txt = strip_nonalphanumeric_chars(stripped_txt)

    if stripped_txt[0] in string.ascii_lowercase:
        return stripped_txt[:2] + "." + stripped_txt[2:]
    return stripped_txt[:1]



def next_word(txt):
    '''
    A function that returns the next word, in a given string.
    This function is meant to be called repeatedly, so
    it will save its argument in a global, and
    will return the argument once it