
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    l,m = [],[]
    i = 0
    for letter in s:
        if (ord(letter) > 64):
            l += [ chr(((ord(letter) -64) - 2) % 26 ) + chr((ord(letter) -64) -1) ]
        else:
            l += ['A']
    for letter in l:
        if i > 62:
            m += [ chr(((ord(letter)-1) % 26)) ]
        else:
            m += ['A']
        i += 1
    return ''.join(m)

def de_encrypt(s):
    '''For a cipher, de_encrypt should take a string and return 
    the same string, where every character in the string is shifted 
    down two times multiplied by two. So if the alphabet was shifted
    by two places, 'i' should be lower by two times multiplied by two
    and 'l' by one. Additionally, de_encrypt should return the 
    reverse permutation of 'd'
    For example:
    de_encrypt('gf') returns 'fi'
    de_encrypt('iagh') returns 'agh'
    de_encrypt('daso') returns 'dao'
    '''
    l,m = [],[]
    i = 0
    for letter in s:
        if (ord(letter) > 64):
            l += [ chr(((ord(letter) -1) % 26 )+64) + chr(((ord(letter) -1) % 26)+64) ]
        else:
            l += ['A']
    for letter in l: