

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    max_val = 10
    for i in range(2, max_val):
        if n%i == 0:
            return i
    return n

def divisor_count(n: int) -> int:
    """ For a given number n, count the number of times n is evenly divided by some number
    >>> divisor_count(15)
    3
    """
    sum = 0
    for i in range(1, max_val):
        if n%i == 0:
            sum += 1
    return sum

def largest_primes(n: int) -> list:
    """ Get the largest primes smaller than n, in descending order
    >>> largest_primes(15)
    [2, 3, 5]
    """
    prime_set = set([2])
    for i in range(2, largest_divisor(n)):
        if len(prime_set) >= largest_divisor(n):
            break
        for prime in prime_set:
            if prime * prime > n:
                break
            if n % prime == 0:
                prime_set.add(prime * largest_divisor(n))
                break
    return list(reversed(sorted(prime_set)))


def largest_pandigital_number(n: int) -> int:
    """ Get the largest palindrome without 1-digit factor
    >>> largest_pandigital_number(10)
    9009
    """
    def is_pandigital(val: int) -> bool:
        """ Check if a number n is pandigital if all its digits sum to n
        >>> is_pandigital(9)
        True
        >>> is_pandigital(0)
        False
        """
        digits = [int(x) for x in str(val)]
        return all(1 <= x + digits[i] <= 10 for x, i in zip(dig