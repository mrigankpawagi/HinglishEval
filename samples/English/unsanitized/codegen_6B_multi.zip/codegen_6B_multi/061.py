

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    stack = []
    stack.append(0)
    for c in brackets:
        if c == ")":
            stack.pop()
        elif c == "(":
            stack.append(0)
    return stack.pop() == 0

def is_valid_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.
    The brackets are guaranteed to be balanced.

    >>> is_valid_bracketing("()")
    True
    >>> is_valid_bracketing("(()(")
    False
    >>> is_valid_bracketing("((])")
    False
    """
    stack = []
    for c in brackets:
        if c == ")":
            stacked = stack.pop()
            if stacked == 0:
                return False
            stack.append(stacked)
        elif c == "(":
            stack.append(0)
    return len(stack) == 0
