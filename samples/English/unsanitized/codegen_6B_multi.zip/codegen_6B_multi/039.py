

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    for t in range(1, n+1):
        if gmpy.isprime(t):
            return t
    return 0


def find_fib(n):
    """
    find_fib finds n-th fibonacci number and returns prime number.
    >>> gmpy.prime(2)
    2
    >>> find_fib(4)
    5
    >>> find_fib(9)
    89
    """
    a = prime_fib(n)
    b = a % (((np.sqrt(2*a))-2*a)//2)
    return a


def fib_pow(n, p):
    """
    fib_pow returns n-th fibonacci number raised to the p power and is still prime.
    >>> gmpy.prime(2)
    2
    >>> fib_pow(2, 2)
    1
    >>> fib_pow(3, 2)
    3
    >>> fib_pow(10, 3)
    43674163850
    """
    a = prime_fib(n)
    return gmpy.pow(a, p)