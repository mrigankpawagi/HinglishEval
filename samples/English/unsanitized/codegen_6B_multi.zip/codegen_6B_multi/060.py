

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    prod = 1
    for i in range(n, 1, -1):
        prod = prod * i
    return prod


def f_1(n: int) -> int:
    """Sum of numbers from 1 to n.
    >>> f_1(5)
    23
    >>> f_1(100)
    4515
    >>> f_1(1)
    1
    """
    sum = 0
    for i in range(1, n + 1):
        sum += i
    return sum


def g_3(n: int) -> int:
    """sum of digits in the number starting from 1 to n.
    >>> g_3(5)
    8
    >>> g_3(8)
    24
    >>> g_3(15)
    50
    >>> g_3(11)
    55
    >>> g_3(1)
    1
    """
    sum = 0
    for i in range(1, n + 1):
        sum += sum(int(f_1(i)))
    return sum


def h_4(n: int) -> int:
    """Function sums every power of a number from 1 to n.
    >>> h_4(5)
    120
    >>> h_4(30)
    6,087,777,774,000,923,765,432,098,765,432,097,431
    >>> h_4(99)
    909,976,637,000,976,637,000,976,637,832
    >>> h_4(1)
    1
    """
    sum = 1
    for i in range(2, n + 1):
        sum