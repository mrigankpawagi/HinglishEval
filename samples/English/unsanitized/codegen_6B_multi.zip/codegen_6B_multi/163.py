
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    from bisect import bisect_left

    # use bisect_left to maintain an ordered list of all indices greater than
    # a
    indices = [i for i in range(b) if i > a]
    return [i for i in indices if i % 2 == 0]


def generate_fibonacci(n):
    """
    Given an integer n, return the nth elements of the fibonaci sequence.

    For example:
    generate_fibonacci(5) => [0, 1, 1, 2, 3]
    generate_fibonacci(30) -> [0, 1, 1, 2, 3]
    """
    from __future__ import division

    # store the previous two fibonacci numbers
    last = 0
    last_prev = 1

    # the fibonacci sequence
    sequence = [last_prev]

    # loop through the sequence in reverse order
    for _ in range(n - 1):
        # determine the new fibonaci number from the previous one
        curr = last + last_prev

        # store the newly determined index
        sequence.append(curr)

        # store the previous one for the next iteration
        last = last_prev
        last_prev = curr

    return sequence


def generate_primes(n):
    """
    Given an integer n, return the nth elements of the prime list.

    For example:
    generate_primes(3) => [2, 5, 7]
    generate_primes(7) => [2, 5, 7]
    generate_primes(8) -> []
    """
    from numpy.core.multiarray import primes
    from functools import reduce

    