

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    return [x * p[1:] for p in reversed(list(zip(polynomial_values(xs), reversed(polynomial_values(list(reversed(xs)))))))]

'''
x^2 * ( x + 3 )^2

x^2 * ( x + 3 ) * ( x + 5 )^2

x^3 * ( x + 3 ) * ( x + 5 )^3

x^4 * ( x + 3 ) * ( x + 5 )^4

x^5 * ( x + 3 )^5

x^6 * ( x + 3 )^6
'''

def integrate(xs: list):
    return sum(c * d for c, d in zip(xs[1:], derivative(xs)))


def get_all_polys_and_integrals():
    polys = []
    xs = [3, 1, 2, 4, 5]
    for i in range(len(xs)):
        if (i == 0):
            polys.append([xs, [xs[i]]])
        else:
            polys.append([xs[i:i + 2], [xs[i + 1]]])
    return polys

