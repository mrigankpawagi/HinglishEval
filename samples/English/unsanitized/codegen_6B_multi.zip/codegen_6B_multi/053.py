

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y


def subtract(x: int, y: int):
    """Subtract one number from another
    >>> subtract(10, 5)
    5
    >>> subtract(5, 7)
    2
    """
    return x - y


def multiply(x: int, y: int):
    """Multiply two numbers
    >>> multiply(10, 5)
    50
    >>> multiply(5, 7)
    49
    """
    return x * y


def multiply_and_check(x: int, y: int):
    """Multiply two numbers and check if result is 50
    >>> multiply_and_check(10, 5)
    50
    >>> multiply_and_check(10, 17)
    350
    >>> multiply_and_check(5, 7)
    49
    """
    return x * y

multiply_test_input = [
    (2, 3, AddError),
    (3, 7, AddError),
    (5, 7, AddError)
]

for _ in multiply_test_input:
    add_test_out, subtract_test_out, multiply_test_out = multiply_and_check(*_)
