
def fruit_distribution(s,n):
    """
    In this task, you will be given a string that represents a number of apples and oranges 
    that are distributed in a basket of fruit this basket contains 
    apples, oranges, and mango fruits. Given the string that represents the total number of 
    the oranges and apples and an integer that represent the total number of the fruits 
    in the basket return the number of the mango fruits in the basket.
    for examble:
    fruit_distribution("5 apples and 6 oranges", 19) ->19 - 5 - 6 = 8
    fruit_distribution("0 apples and 1 oranges",3) -> 3 - 0 - 1 = 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 100 - 2 - 3 = 95
    fruit_distribution("100 apples and 1 oranges",120) -> 120 - 100 - 1 = 19
    """
    
    #Initialize our string object which will process and represent the
    #total numbers of apples and oranges
    string = ""
    apple_sum = 0
    orange_sum = 0
    mango_sum = 0

    #iterate over the amount of apples and oranges given in the string, 
    #convert into integers and sum them up.
    for x in range(5,10):
        string += " " + str(x)  + " apples"
        apple_sum += int(x)
    for x in range(0,5):
        string += " " + str(x)  + " oranges"
        orange_sum += int(x)
    
    #iterate over the number of mango fruits provided in the string, sum them up
    for x in range(100, 120): 
  
        #convert them to floats for string 
        string +=" " +  str(x)
        mango_sum += float(x)

    #print and return result
    print(string)
    return  (apple_sum + orange_sum ) - mango_sum


def main():

    # Prints the banana count on the fruits list
    print(fruits)
    for entry in fruits:
        print(fruit_distribution(str(total_fruit), total_fruit))


