from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    matches = []
    for string in strings:
        if string.find(substring) > -1:
            matches.append(string)
    return matches


def filter_str_reversed(strings: List[str], expr: str) -> List[str]:
    """ Filter an input list of strings using regular expression
    >>> ['a'], ['a']
    >>> ['abc', 'bac']
    >>> ['as', 'abc', 'abd', 'abcabc', 'aaca', 'fabb']
    """
    matches = []
    for string in strings:
        reversed_string = string[::-1]
        if re.finditer(expr, reversed_string):
            matches.append(string)
    return matches
