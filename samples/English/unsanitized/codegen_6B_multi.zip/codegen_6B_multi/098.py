
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    return 'BCD_'.find(s[i:i+2]
                          for i, char in enumerate(s)
                          if char.isupper())
   

def make_upper(s):
    """
    Given a string s, make the output string a number of uppercase vowels.
    
    For example:
    make_upper('aBCdEf') returns 'A1B3C5E'
    make_upper('abcdefg') returns 'abcdefg'
    make_upper('dBBE') returns 'D0B3'
    """
    return ''.join(s[i:i+2] for i, char in enumerate(s) if char.isupper())
    

if __name__ == '__main__':
    for word in (list(l) for l in load_words(sys.argv[1])):
        print(sum(count(word)))
        print('upper:', make_upper(count_upper(word)))
        print('lower:', make_upper(word))
        print('count:', count(word))
