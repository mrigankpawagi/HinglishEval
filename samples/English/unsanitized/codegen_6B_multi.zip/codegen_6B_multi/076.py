
def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    return n**int(x) == x


def is_perfect(n):
    """Your task is to write a function that returns true if n is perfect (i.e. 100 mod
    n == 0, for a number n > 0) and false otherwise.
    For example:
    is_perfect(6) => false
    is_perfect(20) => true
    """
    return n % 1 == 0


def is_prime(n, base=2):
    """Returns true if n is prime, false otherwise."""
    if n < base:
        return True
    return all(n % i for i in range(2, n))


def fermatTest_n(n, m, q=None):
    """Returns a tuple consisting of (n, m, q) for n-digit numbers that are
    divisible by m and by q. q is absent if n is in such a number."""
    for i in range(10, n):
        if is_perfect(i):
            return fermatTest(n, m, i)
        if i >= q:
            return None
    return fermatTest(n, m, q)


def fermatTest(n, m, number):
    """ Returns a tuple consisting of (n, m) if n-digit number
    is divisible by m and by number. If there is no such number
    then (n, m) is None and number is not prime."""
    if n == 1:
        assert(number % m == 0)
        return (n, m)
    