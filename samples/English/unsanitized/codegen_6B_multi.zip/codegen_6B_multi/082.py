
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    #print(string)
    lower_string = string.lower()
    #print(lower_string)
    n = len(lower_string)
    i = 1
    while i * 2 <= n:
        if lower_string[i] == 'o':  # in case there's a letter in front
            if lower_string[i+1] == 'e' or lower_string[i+1] == \
               lower(string[i+1]):
                #print(i)
                return False
    return True

def test_prime_length():
    r = prime_length('greeting')
    print(r)

def number_with_three_odd_digits(string):
    return ''.join(int(x) for x in string if x % 10 == 9 or
                   int(x) % 10 == 3)

if __name__ == '__main__':
    test_prime_length()
    print(prime_length('greeting'))
    print(number_with_three_odd_digits('abcea'))
