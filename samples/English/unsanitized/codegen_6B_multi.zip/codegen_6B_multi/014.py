from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    output = []
    length = 0
    for position in range(len(string)):
        substring = string[:position + 1]
        if substring is not string:
            length = len(string) - position
            output.append(substring)
    return output


def longest_prefix(string: str, prefix_length: int) -> str:
    """ Return longest prefix of the input string with the specified length
    >>> longest_prefix('abc', 3)
    'abc'
    >>> longest_prefix('ab', 2)
    'ab'
    >>> longest_prefix('a', 1)
    ''
    """
    if str(string).startswith(str(prefix_length * " ")) or \
            str(string).startswith(str(prefix_length * "|")):
        return str(string)[:prefix_length]
    return ""


def longest_prefix_length(string: str) -> int:
    """ Return length of the longest prefix (length of the longest common substring) of the
    input string
    >>> longest_prefix_length('a')
    1
    >>> longest_prefix_length('aaaaaa')
    2
    """
    substring = ""
    length = 0
    for i in range(1, len(string)):
        substring = string[:i]
        if substring == string:
            length = i
            break
    return length
