from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    min_ = min(numbers)
    max_ = max(numbers)

    # Apply the scaling
    scaled_numbers = [k * (max_ - min_) + min_ for k in numbers]

    # Make sure they're positive and that we have at least two
    if len(scaled_numbers) < 2:
        scaled_numbers.append(1)
    if min_ < 0:
        numbers -= min_
    scaled_numbers = [k / max_ for k in scaled_numbers]

    return scaled_numbers


def rescale(x: float) -> float:
    """ Return the scaled version of x, with the largest number set to 1.0
    >>> rescale(0.25)
    0.25
    """
    return max(x, 1 - x)


def normalize(numbers: List[float]) -> List[float]:
    """ Scale a range of numbers to the range 0 to 1.0.
    >>> normalize([0, 0.3, 0.4, 0.6, 0.9])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    return rescale_to_unit(numbers)


def merge_dims(array: np.ndarray, new_dims: tuple) -> np.ndarray:
    """ Given an array dimensioned [A, B, C,...] and the new dimensions to add (a) [A, B],
    merge the remaining dims. This returns [A, B]xNxC, where N the number of non-zero new dims and C
    the number