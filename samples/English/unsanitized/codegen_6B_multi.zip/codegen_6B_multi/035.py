

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    max_val = max(l)
    if isinstance(max_val, int) and abs(max_val) == max(abs(val) for val in l):
        return max_val
    raise ValueError("Not a number!")