

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)

# ------------------------------------------------------------------------------
# String concatenation

def print_string(string: str, tab: int = 0) -> None:
    """ print given string """
    if string:
        print(string[:1], end='')
        for tabbed in range(tab):
            print('\t', end='')
        print(string[1:])


def string_concatenation() -> None:
    """
    >>> e = "hi my name is foo"
    >>> print_string(e)
    hi
    >>> e += " and my name is bar"
    >>> e = e.strip()
    >>> e
    'hi my name is foo and my name is bar'
    >>> print_string(e)
    hi
    >>> string_concatenation()
    """
    try:
        name = int(input("What's a real name? "))
    except SyntaxError:
        pass
    else:
        print("'", name, "' is a real name because it's int()able.")



