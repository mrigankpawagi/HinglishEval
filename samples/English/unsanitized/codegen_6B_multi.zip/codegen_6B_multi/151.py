
def double_the_difference(lst):
    '''
    Given a list of numbers, return the sum of squares of the numbers
    in the list that are odd. Ignore numbers that are negative or not integers.
    
    double_the_difference([1, 3, 2, 0]) == 1 + 9 + 0 + 0 = 10
    double_the_difference([-1, -2, 0]) == 0
    double_the_difference([9, -2]) == 81
    double_the_difference([0]) == 0  
   
    If the input list is empty, return 0.
    '''
    sum_squares = 0
    for x in lst:
        if not type(x) is int:
            continue # ignore floats and None
        if x % 2 == 0:
            pass
        else:
            sum_squares += x * x
    return sum_squares
    
class Solution:
    def is_happy(self, n):
        sides = [int(num/10) ** 2, (int(num) % 10 + 1) ** 2]
        return max(sides) <= n
    
class Solution2(object):
    def isHappy(self, n):
        """
        :type n: int
        :rtype: bool
        """
        counter = {}
        sum_counts = 0
        i = n
        while i > 0:
            if i not in counter:
               counter[i] = 1
            else:
               counter[i] += 1
            i = counter[i]
            sum_counts += i
        return sum_counts > n
        
class Solution3(object):
    def isHappy(self, n):
        """
        :type n: int
        :rtype: bool
        """
        
        def dfs(n):
            if n == 1:
                return (0)
            if n == 0:
                return (0)
            if sum([i * i for i in [int(digit) for digit in str(n)]]) % n!= 0:
                return (0)
            else:
                return (-1) if n < 0 else