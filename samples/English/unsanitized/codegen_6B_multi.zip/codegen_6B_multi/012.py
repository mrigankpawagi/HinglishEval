from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None
    l = len(strings[0])
    output: List[str] = []
    for s in strings:
        if len(s) > l:
            l = len(s)
            output = [s]
        elif len(s) == l:
            output.append(s)
    return ''.join(output)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
