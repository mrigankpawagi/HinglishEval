
def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    
    if len(s)>3 and 'bdb' in s:
        return True

def is_string(s):
    """You are given a string that may or may not be palindrome.
    Check if it is a palindrome or not.
    A palindrome is a string that has same characters in the same order.
    The characters are not necessarily distinct.
    For example:
    is_palindrome(abc) => True
    is_palindrome(abac) => True
    is_palindrome(aabac) => False
    """
    str_len = len(s)
    if str_len < 3:
        return False
    rev = s[::-1]
    if s == rev:
        return True

def main():
    tests = [((1, ""), True),
             ((1, "A"), True),
             ((1, "aA"), False),
             ((1, "aBcD"), False),
             ((2, "a"), True),
             ((2, "aa"), True),
             ((2, "aD"), False),
             ((2, "abcd"), True),
             ((3, "a"), True),
             ((3, "aa"), True),
             ((3, "aD"), True),
             ((3, "aaaa"), True),
             ((3, "aabcd"), True),
             ((3, "aaBC"), False),
             ((4, "a"), False),
             ((3, "abcd"), False),
             ((4, "xyy"), False),
             