

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    l = iter(l)
    lodd = [next(l) for i in range(len(l)//2)]
    loven = [next(l) for i in range((len(l)//2) - 1, -1, -1)]
    lval = [x for x in zip(lodd, loopen)]
    merged = itertools.chain(lodd, loopen)
    return [x if x in lval else next(merged) for x in l]


def flatten(l: iterable):
    for element in l:
        if isinstance(element, collections.Iterable) and not isinstance(element, str):
            for sub_element in flatten(element):
                yield sub_element
        else:
            yield element


def flatten_sorted(l: iterable) -> iterable:
    """Take a non-trivial iterable l and return a
    non-trivial iterable consisting of elements e for which
    (e, next(l)) = sorted((e, next(l)))."""
    return [next(l) for element in l]


def grouper(iterable, n, fillvalue=None):
    args = [iter(iterable)] * n
    return zip_longest(*args, fillvalue=fillvalue)


# taken from Python 3.5's groupby module
def grouper_sorted(iterable, n, key=None, reverse=False, fillvalue=None):
    args = [iter(iterable)] * n
    return zip_longest_with_fill(*args, fillvalue=fillvalue, key=key,
                                 reverse=reverse)