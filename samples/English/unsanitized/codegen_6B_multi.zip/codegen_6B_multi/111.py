
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    d = {}
    for c in test:
        d[c] = d.get(c, 0) + 1
    return d

def frequent_words(test):
    """Given a string representing a space separated list of lowercase letters, return the most
    frequent words and their occurrence. It is guaranteed that there is no duplicate in
    the list except for in two words. And the space between words is also excluded.

    Examples:
    frequent_words('a b c d') == {'a': 4, 'b': 2, 'c': 2, 'd': 1}
    frequent_words('a b c d e') == {'a': 4, 'b': 3, 'c': 2, 'd': 1}
    frequent_words('a b c d e d') == {'a': 4, 'b': 3, 'c': 2, 'd': 2}

    """
    d = {}
    for w in test.split(space_regex):
        d[w] = d.get(w, 0) + 1
    finalize(d)
    return d

def finalize(d):
    """Calculate the final histogram and the most frequent words.

    The histogram is used to calculate which word(s) are most frequent in the test.

    Examples:
    finalize({'a': 3, 'b': 4, 'c': 2}) == {'a': 5, 'b': 3, 'c': 2}
    """
    sorted_