

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    counter = collections.Counter(string.lower())
    return len(counter)

def count_frequency_of_characters(string: str) -> typing.Dict[str, int]:
    """ Given a string, count how many times any particular character appears in it """
    counter = collections.Counter(string.lower())
    return counter

def find_first_uniques(string: str) -> str:
    """ Given a string, find the first occurrance of every character except those in string and return it.
    This is used as a primitive of finding the character that occurs first in the reversed string.
    >>> find_first_uniques('abcABC')
    'B'
    """
    list_of_uniques: typing.List[str] = []
    for index, value in enumerate(string):
        if index not in string:
            list_of_uniques.append(value)
    return list_of_uniques[0]
