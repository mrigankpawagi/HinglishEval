
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    return sum([ord(c) for c in s if ord(c) >= ord('A') and ord(c) <= ord('Z')])

def test_functions():
    """Functional test"""
    assert digitSum('') == 0
    assert digitSum(u'AB') == 131
    assert digitSum(u'abcCd') == 67
    assert digitSum(u'eH') == 69
    assert digitSum(u'woArbld') == 131
    assert digitSum(u'aAaaaXa') == 153

if __name__ == '__main__':
    print(digitSum(u'woArbld'))
