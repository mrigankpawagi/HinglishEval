

def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    return [a for a in l if a > 0]

def get_negative(l: list):
    """Return only negative numbers in the list.
    >>> get_negative([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [-5, -3, -2, -3, 9, 0, 123, 1]
    >>> get_negative([-1, 2, -4, 5, 6])
    [-1, -4, -5, -6]
    """
    return [a for a in l if a < 0]

def sort_list(l: list):
    """Return sorted list."""
    l.sort()
    return l

def main(n: int = 15) -> None:
    import timeit
    setup = 'from __main__ import get_positive, sort_list'
    print(f'Time to sort through a list of elements: {seconds_to_human_time(
            timeit.timeit(lambda: sort_list(get_positive(get_random(n) + [10000, -1, -100])),
                          setup=setup))}')
    print(f'Time to sort through a list of elements: {seconds_to_human_time(
            timeit.timeit(lambda: sort_list(get_negative(get_random(n) + [10000, -1, -100])),
                          setup=setup))}')


if __name__ == '__main__':
    main()
