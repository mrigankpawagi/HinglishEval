
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    num_set = {num for num in nums}
    sorted_list = sorted(num_set)

    def _find_sum_of_digits(point):
        # find next point
        def _next_point_in_list(point):
            # find next point or the last element
            # of the list
            for i in xrange(point, len(sorted_list)):
                if sorted_list[-i] > point:
                    return i
            return None

        _dum = '%d' % point
        first_dum, _ = _dum.split('d')
        for i in xrange(len(sorted_list)):
            if sorted_list[-i] == point and (int(first_dum) in [i and int(_dum) for _dum in sorted_list[-i:]]):
                return sorted_list[-i]

        for next_num in sorted_list[-i:]:
            curr_sumOfD = sum(int(_d) for _d in _dum)
            if curr_sumOfD > point:
                return next_num
        return None

    def _sort_after_sum(point):
        """
        sorts list after point according to _find_sum_of_digits(point)
        """
        next_point = _find_sum_of_digits(point)
        if next_point:
            _sort_after_sum(next_point)

    _sort_after_sum(min(sorted_list))
    return sorted_list


def main():
    # num = [1, 1