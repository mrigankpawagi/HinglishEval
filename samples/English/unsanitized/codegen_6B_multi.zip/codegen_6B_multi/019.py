from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    return [num for num in sorted([int(num) for num in numbers.strip().split()])]


def permute_string(data: List[str]) -> List[str]:
    """ Input is a list of string that form a permutation of the numbers in one of two ways:
    the last number needs to come first at each step (1st case), or after each step that number
    needs to come last (2nd case).
    Return a list of the stringified permutations.
    """
    if not data:
        return []
    if len(data) == 1:
        return [data[0]]
    elif len(data) == 2:
        # case 1: last one must be first in sequence
        first_case_data = (data[0].replace(data[-1], '')) + data[1]
        # case 2: last one must be last in sequence
        last_case_data = data[-1] + (data[1].replace(data[0], ''))
        return [first_case_data, last_case_data]
    else:
        cases = []
        for i, num in enumerate(data[:-1]):
            one_digit_data = data[i].replace(data[i+1], '')
            last_digit_data = data[i+1].replace(data[i], '')
            cases.append(one_digit_data+last_digit_data)
        cases += [data[-1]]
        return permute_string(cases)


def make_tetrahedron(data: List[str]) -> str:
    """ Find largest string in str that is a permutation of the given string
    
    