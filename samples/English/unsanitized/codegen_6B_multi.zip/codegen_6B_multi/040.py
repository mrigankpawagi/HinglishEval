

def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    from collections import Counter
    counter = Counter(x for x, y in map(lambda x: (x, y), l))
    return sum(x for x, y in map(lambda x: (x, -x), counter.items())) == 0

# In[ ]:

def find_triples(l: list):
    """
    find_triples takes a list of integers as an input.

    It returns a tuple (a, b, c) such that a + b + c is smaller than
    zero, and (a, b, c) is a triple with the property that a + b + c
    is zero.

    >>> find_triples([3, -4, 2, 9])
    (0, 1, 1)
    >>> find_triples([1, 2, -2, 1])
    (0, 0, 1)
    >>> find_triples([3, 7, 5, 2, 4, 0])
    (0, 0, 1)
    >>> find_triples([-7, -1, 4, 7, 2, 0, 9, 6, -4])
    (0, 3, 4)
    >>> find_triples([6, 2, 5, -3])
    (0, 1, 1)
    """
    a, b, c = [x for x in filter(triples_sum_to_zero, l)][0]
    return (a,