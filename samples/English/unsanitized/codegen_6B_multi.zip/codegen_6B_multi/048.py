

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if not isinstance(text, str):
        raise TypeError('Can only compare string instances')
    if len(text) <= 1; return True
    else:
        return text[::-1] == text[1::-1]

def palindrome_check(text: str) -> int:
    """
    Calculates number of common characters between given string and its
    reverse. Returns -1 if it is not a palindrome, otherwise number of common
    characters.

    >>> palindrome_check('The quick brown fox')
    6
    >>> palindrome_check('The quick brown FOX')
    6
    >>> palindrome_check('The quick grey FOX')
    -1
    """
    if is_palindrome(text):
        length1 = len(text)
        length2 = re.search(r'\b(\w+)', text).end()
        return len(text[:length2])
    else:
        return -1

# Test for Palindrome


if __name__ == "__main__":
    import doctest
    doctest.testmod()