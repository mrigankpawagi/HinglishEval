
def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    # Convert planet names into numbers using the planets dictionary
    t1 = planet1
    if t1 not in planets:
        return ()
    planet1 = planets[t1]
    t2 = planet2
    if t2 not in planets:
        return ()
    planet2 = planets[t2]
    # Distance from the sun to each planet
    s1 = 1
    s2 = 1
    # Planets' co-orbits
    c1 = ()
    c2 = ()
    # Orbits and eccentricity of the orbits
    e1 = 0
    e2 = 0
    # Orbit's number
    d1 = 0
    d2 = 0
    # Number of the moons orbiting each orbit
    m1 = ()
    m2 = ()
    # Orbit's coefficient of total energy
    t1 = 0
    t2 = 0
    # Number of coefficients in the coefficient matrix A (a)
    num1 = 2
    num2 = 2
    # Orbit's coefficient matrix A
    a = ()
    # Orbit's coefficient matrix B
