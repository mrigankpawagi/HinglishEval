

def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    if len(s0) == len(s1):
        for i in range(len(s0)):
            if s0[i]!= s1[i]:
                return False
        return True
    return False

# print(same_chars('eabcd', 'dddddddabc'))
# print(same_chars('eabcdzzzz', 'dddzzzzzzzddddabc'))


def unique(seq):
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]

# print(unique(range(19)))
# print(unique([1, 1, 2, 2, 1, 3, 2, 3, 2, 1, 2, 1, 1, 3, 2, 3, 2, 2, 3, 1, 3, 1]))

def merge_dup_arrays(arr1: [int], arr2: [int]) -> [int]:
    """Create new array with sorted elements of both arrays

    >>> merge_dup_arrays([1,2,2,3], [1,2])
    [1,2,2,3]
    """
    return sorted(set(arr1) | set(arr2))


print(merge_dup_arrays([1,2,2,3], [1,2]))

def longest_un