

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    return number - int(number)


def float_repr(number: float, decimals: int = 4) -> str:
    """ Given a float number, return a representation of it, with the
    given number of decimals.

    >>> float_repr(3.5, 3)
    '3.500'
    """
    return '{0:,.{1}f}'.format(number, decimals)


def sum_list(sum: int, list: list) -> int:
    """ Sum the whole list.

    >>> sum_list(42, [1, 2, 3])
    64
    """
    return sum(list)


def double(x: float) -> float:
    """ Return the double of any given float.

    >>> double(2.5)
    5.0
    """
    return float(2 * x)


def sum_mult(factor: float, lists: list) -> float:
    """ Sum one per many lists

    >>> sum_mult(3, [[2, 1, 1], [2, 3, 4]])
    30.0
    """
    return sum(sum(map(double, lists)) for lists in zip(*lists))


def main():
    # -------------------------------
    # First example: using `__add__`
    # --------------------------------
    x = 3.5
    # Use double
    print('x = ', float_repr(double(x)))

    # Sum the list
    print('x = ', sum_list(42, [1, 2, 1]))

    # Sum 3
    print('x = ', sum_list(3, [1, 2, 3]))

    # Sum a list of lists
    print('x = ', sum_mult(3, [[1, 2, 3], [5,