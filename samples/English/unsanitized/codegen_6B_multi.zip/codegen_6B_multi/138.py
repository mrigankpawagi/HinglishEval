
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    if n % 2 == 0:
        return sum(range(1, int(n/2) + 1)) == n
    else:
        return False

def is_sum_equal_to_half():
    """Evaluates if the two functions are equivalent for a given number
    Example
    is_sum_equal_to_half(1000) == True
    is_sum_equal_to_half(1234) == False
    """
    return sum(range(1, (len(range(1,1000 + 1)) // 2) + 1)) == len(range(1, 1000 + 1)) // 2

def is_prime(n):
    """Evaluates if the given number n is prime or not
    Example
    is_prime(4) == False
    is_prime(5) == True
    is_prime(2) == False
    """
    for i in lrange(2, (1 + n / 2)):
        if n % i == 0:
            return False
    return True

def is_prime_by_trial_division(n):
    """Evaluates if the given number n is prime or not by
    trial division test
    Example
    is_prime_by_trial_division(4) == False
    is_prime_by_trial_division(10) == True
    """
    for i in lrange(2, n + 1):
        j = n // i
        if j < i:
            return False
    return True

def next_prime(n):
    """Takes a number n and finds the prime number n+1
    which is the next prime to n. The function rounds up
    by 1, so the function would return 4 for n=3.
    Example
    next_prime(100) == 100 + 1
    