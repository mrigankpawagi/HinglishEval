

def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    result = ""
    for count in range(n):
        result += str(count) + " "
    return result[:-1]


def string_sequence_reverse(n: int) -> str:
    """ Give a string with numbers starting from n to 0 inclusive
    >>> string_sequence_reverse(6)
    '5 4 3 2 1 0'
    """
    result = ""
    for count in range(n, 0, -1):
        result += str(count) + " "
    return result[:-1]


if __name__ == "__main__":
    import doctest

    doctest.testmod()
