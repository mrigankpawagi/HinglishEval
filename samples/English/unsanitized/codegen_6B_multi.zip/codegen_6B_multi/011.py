from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    return ''.join([chr(ord(char) ^ ord(other_char)) for char, other_char in zip(a, b)])


def longest_common_substring(str1: List[int], str2: List[int]) -> str:
    """
    Input is two lists of integers each representing a string
    and their lengths(i.e. number of characters).
    Find the longest common string that occurs in the inputs.
    return only that string
    >>> longest_common_substring([2, 4, 5, 7], [4, 5])
    2
    >>> longest_common_substring([1, 2, 3, 4, 5], [6, 7])
    ''
    >>> longest_common_substring([2, 4, 5, 7], [4, 5, 7])
    2
    """
    string_pairs = [(a, b) for a, b in zip(str1, str2)]
    sorted_pairs = sorted(string_pairs, key=lambda pair: pair[0])
    first_pairs = sorted_pairs[: len(sorted_pairs) / 2]
    second_pairs = sorted_pairs[len(sorted_pairs) / 2:]
    for item_i, item_j in first_pairs:
        if string_xor(str(item_i), str(item_j)) in second_pairs:
            return str(item_i) + str(item_j)


def find_xor_key(seed: List[int]) -> List[str]:
    """
    Input is a list of all integers in the range 0 - 9,
    easting to the seed length, a list of lists.
    1. Generate a string of only 1s or 0s of given length,
    2. Hash the string to get