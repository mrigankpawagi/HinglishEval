
def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    try:
        h = hashlib.md5()
        h.update(text)
        return h.hexdigest()
    except:
        return None

def parse_args():
    """
    Parse command line arguments.

    Returns: dict with keys'source' and 'dest' (each, a string) and a'md5sum'
             key (a string that, when given as an MD5Hash, will match the
             corresponding output hash from the `md5sum` tool).

    If an "md5sum" command cannot be found, `None` is returned for the
    'dest' key in the returned dictionary.
    """
    try:
        p = subprocess.Popen(["/usr/bin/md5sum", "-"], stdin=subprocess.PIPE,
                             close_fds=True)
    except OSError:
        raise NoMd5sumFound
    (stdout, stderr) = p.communicate(args.filename)

    # The process exited with an error if we have an input file and it fails
    # to produce an MD5 sum
    if not stderr and not stdout:
        raise OpenFailed
    
    h = hashlib.md5()
    h.update(stdout)
    md5sum = stdout.split()[0].strip()
    if not stdout:
        raise HashFailed
    try:
        r = hashlib.new('md5', open(args.filename).read())
    except IOError, e:
        if e.errno!= errno.ENOENT:
            raise
        log.warning("File not found." + str(e))
    else:
        log.info("md5 = " + r.hexdigest() + " " + args.filename)
        r.