

def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return sum(i < t for i in l) < len(l)


def above_threshold(l: list, t: int):
    """Return True if all numbers in the list l are above threshold t.
    >>> above_threshold([1, 20, t, 10], t)
    True
    >>> above_threshold([1, 2, t, 10], 100)
    False
    """
    return sum(i > t for i in l) < len(l)


def is_sorted(l: list):
    """Return True if all items in the list are sorted."""
    return all((i < j for i, j in zip(l[:-1], l[1:])))