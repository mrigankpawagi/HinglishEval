from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    return [str for str in strings if str.startswith(prefix)]


def is_valid_numeric_digit_digit(ch: str) -> bool:
    """ Whether a given character is a numeric digit"""
    return (ord(ch) > ord('A') and ord(ch) < ord('J') or ord(ch) > ord("0") and ord(ch) < ord("9"))


def is_valid_alphabetic_digit(ch: str) -> bool:
    """ Whether a given character is an alphabetic char or a numeric digit"""
    return (ord(ch) > ord("A") and ord(ch) < ord("J") or ord(ch) > ord("0") and ord(ch) < ord("9") or
            ch in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@")


def filter_words(strings: List['StrWrapper'], valid_characters: List[str]) -> List['StrWrapper']:
    """ Filter an input list of StrWrapper objects only for ones that contain alphabetic or numeric
    characters only for those that start with alphabetic characters
    >>> fromStrWrapper('A', 'B')
    A
    >>> fromStrWrapper('A', 'B')
    A
    >>> fromStrWrapper('A', 'B')
    A
    >>> fromStrWrapper('A', 'B')
    A
    >>> fromStrWrapper('A', 'B')
    B
    >>> fromStrWrapper('A', 'B')
    B
    >>> fromStrWrapper('A', 'B', 'X')
    'X'
    >>> fromStrWrapper('A', 'B', '