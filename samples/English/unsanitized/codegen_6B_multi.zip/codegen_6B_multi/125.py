
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1,... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    return [item.strip() for item in txt.split()]

def parse_time(txt):
    '''
    Given a string of hour-minute time values, return a tuple of (hour,minute)
    Examples
    parse_time("1:5:33") ➞ (1, 5)
    parse_time("3:32")    ➞ (3, 32)
    parse_time("21:56")   ➞ (21, 56)
    '''
    hours, minutes = txt.split(':')
    return int(hours), int(minutes)

def find_date_month(txt):
    '''
    Given a string of a date or month, return the proper month name (full name of the month)
    Examples
    find_date_month("May")    
    find_date_month("May")   
    find_date_month("May")   
    find_date_month("Feb")
    '''
    month = txt.upper()
    if month == 'JAN' or month == 'JANUARY':
        return 'Jan'
    elif month == 'FEB' or month == 'FEBRUARY':
        return 'Feb'
    elif month == 'MAR' or month == 'MARCH':
        return 'Mar'
    elif month == 'APR' or month == 'APRIL':
        return 'Apr'
    elif month == 'MAY':
        return 'May'
    elif month == 'JUN