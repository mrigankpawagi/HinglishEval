
def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """
    if n <= 1:
        return [n]
    tri_list = []
    tri_list.append(1)
    for i in range(1, n):
        tri_list.append(1 + (i / 2))
        if i % 2 == 0:
            tri_list.append(tri_list[i - 1] + tri_list[i - 2])
    if n == 2:
        tri_list.append(tri_list[n - 1])
    return tri_list


def fib(MAX_ITEMS):
    """You are given a positive integer number or non-positive integer number n.
    Number n is in range [1..1000000], that means to calculate number of ways
    for integers starting with 1 and ending with n.
    If n is non-positive then just calculate total number of ways.
    Example:
    fib(3) = 2

    fib(10) = 40,49,55
    """
    if not MAX_ITEMS >= 1:
        return 0
    fib_list = [1]
    for i in range(2, MAX_ITEMS):
        fib_list.append(f