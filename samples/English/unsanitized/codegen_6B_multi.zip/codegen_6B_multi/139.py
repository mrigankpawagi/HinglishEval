
def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! *... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    special = 1
    for number in range(0, n):
        special = special * number + 1
    return special


def prime_factoriallize(n):
    """
    Given an integer, it will return the first prime number that exceeds this
    value.
    """
    number = special_factorial(n)
    while number > 0:
        number = number + 1
        number = next_prime_number(number)
        number = find_all_primes(number)
    return 1


def prime_factoriallize_list(n):
    """
    Given an list of integers, it will return the first prime number that exceeds
    this list.
    """
    n = int(n)
    result = []
    while n > 0:
        result = result + [n]
        n = next_prime_number(n)
        n = find_all_primes(n)
    return result


test_case1 = 3
a = prime_factoriallize_list(test_case1)
print a
print prime_factoriallize_list(test_case1)

test_case2 = 2
a = prime_factoriallize(test_case2)
print prime_factoriallize(test_case2)
print a

# You can try the above function with a range from 1 to 3:
# print a[:5]
