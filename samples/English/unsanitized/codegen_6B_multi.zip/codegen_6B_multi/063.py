

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n == 0:
        return 0
    elif n == 1:
        return 0
    else:
        return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


def fib_gcd(a: int, b: int):
    """GCD Algorithm using Euclides Algorithm
    >>> fib_gcd(16, 32)
    8
    >>> fib_gcd(1,0)
    1
    >>> fib_gcd(4, 5)
    0
    >>> fib_gcd(4, 6)
    1
    >>> fib_gcd(9, 24)
    4
    """
    while b!= 0:  # gcd(0, n) = n
        a, b = b, a % b  # gcd(a, n) = gcd(a, n) = n, n - a
    return a


if __name__ == '__main__':
    fib = float(input("Enter an number:"))
    print("Fibonacci number n={} is {}".format(fib, fibfib(fib)))
