
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    strange_return = []

    # check whether length of the list is greater than 1
    if len(lst) > 1:
        # sort the list in descending order.
        lst.sort(reverse=True)

        # reverse each element individually
        lst_rev = reversed(lst)

        # loop through and combine each list element
        lst_rev.pop()
        for i, j in zip(range(0, len(lst_rev)), lst):
            strange_return.append(i + j)

    return strange_return

def print_tree(preorder):
    '''
    print_tree creates a pretty tree view.
    Args:
    preorder  : the array of values in a PreOrder Tree
    '''
    space =''
    tab = '\t'

    if len(preorder) > 0:
        #print tab*indent + 'node:'+ str(preorder[0])
        print tab*indent + 'node:'+ str(preorder[0])
        print tab*indent + space + 'left:'+ str(preorder[1])
        print tab*indent + space + 'right:'+ str(preorder[2])
        print tab*indent + space + 'parent:'+ str(preorder[3]).rstrip()
        print tab*indent + space + 'depth:'+ str(preorder[4])
        print tab*indent + space + 'height:'+ str(preorder[5])
        print tab*indent + space + 'keys:'+ str(preorder[6