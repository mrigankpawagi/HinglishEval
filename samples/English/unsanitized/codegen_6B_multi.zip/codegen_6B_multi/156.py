
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    number = abs(number)
    if number > 1000 or number < 1:
        raise ValueError('Input must be within range [1, 1000]')

    if number < 10:
        res = 'i'
    elif number < 20:
        res = 'x'
    else:
        res = ['xii', 'xxi', 'cxii', 'lxii', 'dxxii','mxxii'][
        number / 100 - 1]  # get index for m xx

    if number % 10 == 0:
        return res + res[:number % 10 + 1]
    else:
        return res + res[:number % 10 + 1] + 'x'


min_numbers = [1, 10, 100, 1000]

string_to_num = {
    'I': 1,
    'II': 2,
    'III': 3,
    'IV': 4,
    'V': 5,
    'VI': 6,
    'VII': 7,
    'VIII': 8,
    'IX': 9,
    'X': 10
}
# 10 is not considered
for i in range(11, 101):
    key = int_to_mini_roman(i)
    string_to_num[key] = i


numbers = 0


def mini_roman_to_int(n):
    n = n.replace('i', 'I')
    n = n.replace('x', 'X')
    return string_to_num[n]


# print(str_to_num)

for n in sys.stdin.readlines():
    try:
        print(n)
        numbers += mini