
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """

def sum_all(words):
    """
    Return the sum of characters in each word.
    :rtype : int
    """


def words_with_same_first_char(words):
    """
    Return a list of words that start with the same letter
    """


#These "asserts" using only for self-checking and not necessary for auto-testing
if __name__ == '__main__':
    assert findMax([1, 23, 1, 34, 23, 23, 1, 3, 2, 4, 23, 23, 23]) == 23

    assert sorted(findAllNumbers([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    assert sorted(findNumbers([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    
    #assert findEven([1, 2, 3, 4, 5, 6, 7]) == 6
    assert findAllRanges([1, 2, 3, 4, 5, 6, 7, 78, 9, 10, 11, 12]) == {(1, 2), (5, 7), (9, 10), (11, 12)}
    #assert findAllSubstrings([{}, {}, {}]) == {}
    
    # assert find_max([{}, {}]) == {}

    assert sum_all([[1,2,3,4,5],1,[1,2