
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''
    return int(x) + int(y) == int(z)

'''
Examples

any_int    
    True
    True
    False


any_int(5, 2, 7)
    True
    True
    False


any_int(3.6, -2.2, 2)
    True
    True
    False
    
'''

def any_int_plus_2(x, y, z):
     '''
     Create a function that takes 3 numbers.
     Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers +2.
     Returns false in any other cases.
     
     Examples
     any_int_plus_2(3, -2, 2) ➞ True
     
     any_int_plus_2(3, -2, 1) ➞ False
     
     '''
     return int(x) + int(y) == int(z) + 2

'''
Examples

any_int_plus_2    
    True
    True
    False


any_int_plus_2(3, -2, 2)
    True
    False
    False
    
'''

def any_int_equal_2(x, y, z):
     '''
     Create a function that takes 3 numbers.
     Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers +2.
     Returns false in any other cases.
     
     Examples
     any_int_