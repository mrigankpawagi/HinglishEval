

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    l2 = len(substring)
    index = 0
    while True:
        index = string.find(substring, index)
        if index == -1:
            break
        index += l2
    return index + 1

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", "--strings", help="String Input", default="")
    parser.add_argument("-e", "--expansion", help="Expansion of the String", default="")
    args = parser.parse_args()
    how_many = how_many_times(args.strings, args.expansion)
    print(f"How many times '{args.expansion}' can be found in '{args.strings}' string? {how_many}")
    raw_input("Press ENTER to Continue")
