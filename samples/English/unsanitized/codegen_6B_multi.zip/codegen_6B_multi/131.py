
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    p = [0]*10
    d = 0
    while n > 0:
        d = (d + n%10) % 10
        p[d%10] += 1
        n //= 10
    return sum(p[:9])

def main():
    # These "asserts" using only for self-checking and not necessary for
    # auto-testing
    assert sum(digits(1)) == 1, "First number!"
    assert sum(digits(1000)) == 987654321, "Second number"
    print("Third task")

if __name__ == "__main__":
    main()
