from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    return clipper(numbers)


# This code is not intended to run in production.

def load_input() -> List[float]:
    """ Prompt the user to load values as comma separated floats and return them as a list in alphabetical order.
    >>> load_input()
    [5.15, 6.7, 9.0, 1.0]
    """
    # noinspection PyTypeChecker
    return list(map(float, input().split(' ')))


def clipper(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> clipper([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> clipper([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    closest_two = sorted(((abs(a - b), a, b) for a, b in zip(numbers, numbers[1:])))[:2]
    return closest_two[0][2], closest_two[1][2]
