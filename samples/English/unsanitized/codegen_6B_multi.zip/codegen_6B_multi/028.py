from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(strings)


def split_words(s: str) -> List[str]:
    """ Split a sentence into individual words
    >>> split_words('a b c')
    ['a', 'b', 'c']
    >>> split_words('a.b.c')
    ['a.b.c']
    """
    return s.lower().split('. ')


def words_to_lower(words: List[str]) -> List[str]:
    """ Convert string representation of list of words to lowercase
    >>> words_to_lower(split_words('a b c'))
    ['a', 'b', 'c']
    """
    return [word.lower() for word in words]


def flatten_string(s: str) -> str:
    """ Flatten a string of space delimited strings into a single string
    >>> flatten_string(' a b    c')
    'a b c'
    """
    return''.join(s.split())


def load_text_file(filename: str) -> List[str]:
    """ Read a text file and return a list of strings representing the content
    """
    with open(filename, 'rt') as f:
        return [x.strip() for x in f.readlines()]


def word_generator(sentences: List[str]) -> List[str]:
    """ Replace words with their tokens in the given sentences
    >>> list(word_generator(load_text_file('../data/p13.txt')))
    ['a', ['b', 'c'], []
    """
    for sentence in sentences:
        for word in sentence.split():
            yield word
