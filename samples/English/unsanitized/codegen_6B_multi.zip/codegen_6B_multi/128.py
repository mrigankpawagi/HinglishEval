
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr:
        return None
    return sum([abs(num) * sign for num, sign in zip(arr, [-1, +1])])

def sum_distances(arr):
    """
    You are given two integer arrays arr and dist respectively,
    where arr is one part of a path and dist is its destination (next node).
    The distance is the number of nodes between the starting point of the line
    and its destination.

    Return the sum of distances between arr[i] and dist[j] for the given
    arr[i] < arr[i+1].
    In case the length of dist is not strictly less than arr,
    return sum of distances between arr[i] and dist[i], assuming that 
    the distance is greater than 0.

    Note: Return None if length of dist is zero, or arr and dist are not same
    size.

    Example:
    >>> sum_distances([1, 2, 3, 4]) == 4
    >>> sum_distances([3, 4]) == 0
    >>> sum_distances([4, 5, 6]) == 1
    >>> sum_distances([9, 8, 7]) == None
    >>> sum_distances([1, 2, 3]) == 3
    """
    if len(arr) == len(dist):
        return sum([i - j for i, j in zip(arr, dist)])
    else:
        if len(dist) > 0:
            return sum([abs(abs(i) - abs(j)) for i, j in zip(arr, dist)])
        else:
            return None

if __name__ == '__main__':
    import doctest
