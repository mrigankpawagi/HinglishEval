

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n < 2:
        return n
    return fib(n-1) + fib(n-2)


class FibN_10(object):
    """Fibonacci with cache (fetch-on-first-access)."""

    def __init__(self, cache=None):
        self._n = 1
        self._cached = cache or set()

    def __call__(self, n):
        n = int(n)
        if n < 2:
            return n
        if n in self._cached:
            return self._cached[n]
        self._cached[n] = fib(n)
        return self._cached[n]
