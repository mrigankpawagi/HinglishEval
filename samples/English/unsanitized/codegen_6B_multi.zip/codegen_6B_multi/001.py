from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    # NOTE: This is essentially a copy/paste of the below function, but with one crucial change: it's using a dict instead of
    # a loop.
    # Use it as long as it makes sense!

    paren_groups = {}
    for index in range(0, len(paren_string), 1):
        # Find which paren is open this time.
        open_paren = True if paren_string[index] == '(' else False
        index_of_current_group = 0
        while open_paren:
            index_of_current_group += 1
            next_index = paren_string.find('(', index_of_current_group)
            index_of_next_group = paren_string.find(')', next_index)
            open_paren = True if next_index!= -1 else False
            paren_groups[(index_of_current_group, index_of_next_group)] = paren_string[index_of_current_group:next_index]
            index = index_of_next_group + 1
            paren_string = paren_string[1+index:]
    out = []
    # Add empty brackets up front to make things easier to see.
    open_parens = []
    for k,v in paren_groups.items():
        out.append(v)
        if len(paren_groups) == 1:
            out.pop()
            out.append(k[1])
            k = [v,k[0],k[1]]
        if k in paren_groups:
            out.append(v)
            k = [v, k[0],