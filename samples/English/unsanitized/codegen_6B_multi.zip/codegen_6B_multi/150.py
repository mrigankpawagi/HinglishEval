
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    if n%2 is 0:
        x = 0
    return x
    
if __name__ == '__main__':

    # testing x_or_y
    print x_or_y(43, 12, 13)
    print 'x_or_y passed example 1'

    #testing y_or_x
    print y_or_x(43, 12, 13)
    print 'y_or_x passed example 1'

    # testing x_or_x
    print x_or_x(43, 12, 13)
    print 'x_or_x passed example 2'

    # testing x_or_y with different values
    assert x_or_y(15, 8, 5) == 5
    assert x_or_y(13, 19, 10) == 13
    assert x_or_y(-1, -1, 8) is None
    assert x_or_y(0, 0, 8) is None
    assert x_or_y(17, -9, 29) == 17
    assert x_or_y(-9, 19, -29) == -9
