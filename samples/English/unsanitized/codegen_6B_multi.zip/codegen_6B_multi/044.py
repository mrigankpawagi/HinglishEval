

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    m = power_of_two(base)
    digit_sum = x if base == _base else x % m
    rep = []
    while digit_sum > 0:
        digit = digit_sum % base
        digit_sum -= digit
        rep.append(digit)
    rep = ''.join(reversed(rep))
    if base == _base:
        return str_to_int(rep)
    return base*str_to_int(rep)


def change_base_decimal(x: int, base: int):
    """
    Change base decimal input number x to base.
    return string representation after the conversion.
    """
    m = power_of_two(base)
    digit_sum = int(_to_decimal(x))
    rep = []
    while digit_sum > 0:
        digit = digit_sum % base
        digit_sum /= base
        rep.append(digit)
    rep = _decimal_to_str(rep)
    if base == _base:
        return str_to_int(rep)
    return base*str_to_int(rep)


def is_palindrome(x: int):
    return x == change_base(x, 2)


def is_permutation(a: int, b: int):
    try:
        power_of_two(a, b, reverse=True)
        return False
    except ValueError:
        return True


def power_of_two(x: int, base=10):
    # return 1 << i where 2^i is x
    if x < base:
        return x
    l = 1
    while l * base < x:
        l = l + 1
    return l


def _to