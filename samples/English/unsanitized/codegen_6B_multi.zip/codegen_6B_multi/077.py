
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    return ((2**(a - 2)) * a**(3-2)) == a**4


def isdigit(s):
    '''
    Write a function that takes a string s and returns True if
    every character of the string is a digit.
    Examples:
    isdigit("412345") ==> True
    isdigit("abc") ==> False
    '''
    if s.isalpha():
        return False
    elif 'a' <= s[0] and s[0] <= 'z' or 'A' <= s[0] and s[0] <= 'Z':
        return False
    else:
        return all(Character.isDigit(s[idx]) for idx in range(0, len(s)))


def islist(l):
    '''
    Write a function that takes in a list l and returns True if every 
    element in l is one of '[' (or ']') (or '{' or '}')
    Examples:
    islist(["[",1,[2,3]]) ==> True
    islist([] or {}) ==> True
    islist([1,2,3]) ==> True
    '''
    return '[' == l[0] or ']' == l[0] or '{' == l[0] or '}' == l[0]


def ispalindrome(s):
    '''
    Write a function that given a string s, return True if and only if
    the string is a palindrome.
    Examples:
    s.isalnum() ==  True
    s.isdigit() ==  True
    s.islist