


def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """
    sums = 0
    for i in range(len(lst)):
        i_index = i*3
        i_mod = i_index % 3
        if i_mod == 2:
            i_index -= 3
            i_index += 1
        elif i_mod == 0:
            i_index -= 4
            if i_index :
                if (i_index-1) % 3 == 2:
                    i_index -= 3
        elif i_mod == 1:
            i_index -= 3
            i_index += 2
            if i_index :
                if (i_index-1) % 3 == 2:
                    i_index -= 2
                    if (i_index-1) % 4 == 3:
                        i_index -= 2
        elif i_mod == 3:
            i_index -= 4
            i_index += 3
        # The above code can be easily removed with a loop on the modulus
        # The following should print -126

        sums += lst[i]**2
    return sums

if __name__ == '__main__':
    lst = [1,2,3]
    sums = sum_squares(lst)
    assert isinstance(sums, int)
    assert sums == 6
    
    lst = []
    sums = sum_squares(lst)
    assert isinstance(sums, int)
    assert sums ==