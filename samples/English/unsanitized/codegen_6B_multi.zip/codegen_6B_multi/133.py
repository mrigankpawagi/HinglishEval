

def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """
    import math
    sum = 0
    for x in lst:
        sum += math.power(x,2)
    return sum

def getMaxNumber(lst):
    """Given a list of numbers, return max of them.

    """
    
    lst = [math.trunc(i) for i in lst]
    print(lst)
    return max(lst)

def getMax(function):
    """Using 'x=function(y)' take the x value and return the expression's
    output value.
    """
    import math
    from operator import itemgetter
    def realFunc(y):
        realValue = math.trunc(y)
        return realValue
    f = itemgetter(realFunc)
    return max(map(f,lst))

def getMin(function):
    """Using 'x=function(y)' take the x value and return the expression's
    output value.
    """
    import math
    from operator import itemgetter
    def realFunc(y):
        realValue = math.trunc(y)
        return realValue
    f = itemgetter(realFunc)
    return min(map(f,lst))

def main():
    pass

if __name__ == '__main__':
    main()
