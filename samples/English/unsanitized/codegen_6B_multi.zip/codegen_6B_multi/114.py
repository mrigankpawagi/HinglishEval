
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    return _greedy(nums)
def _greedy(nums):
    length = len(nums)
    if length <= 1:
        return nums[0]
    min_sum_n = nums[0]

    for i in range(1, length):
        cur_sum = nums[0] + nums[1]
        for j in range(1, i+1):
            cur_sum += nums[j]
            if cur_sum < 0:
                cur_sum = 0
            if cur_sum < min_sum_n:
                min_sum_n = cur_sum
    return min_sum_n

    
    

  
    
    
    
    
 
nums = [-1, -2, -3, -4]
print minSubArraySum(nums)





def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    
    length = len(nums)
    print "length = ", length
    sums = [num * (length-1) + nums[i] for i, num in enumerate(nums)]
    print "sums = ", sums
    start = 0
    end = len(sums)-1
    sum = max(0, sums[start] + sums[end])
    while start < end:
        print'start: ', start, 'end: ', end,'sum: ', sum
        tmp_sum = sum
        sum = min(sum, sums[start] +