from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    paren_stack = []
    nested_paren_stack = []
    unwrapped_string = ""
    for index, char in enumerate(paren_string):
        if char == "(":
            paren_stack.append(index)
        elif char == ")":
            nested_paren_index = paren_stack.pop()
            nested_paren_string = nested_paren_string[:nested_paren_index]
            nested_paren_stack.append(nested_paren_index)
        elif char == ")":
            nested_paren_string = "(" + nested_paren_string + char
            paren_stack.append(index)
        elif char == ")(":
            unwrapped_string += "()" * len(nested_paren_stack) + "()"
            nested_paren_string = char
            nested_paren_stack = []
            new_string = paren_stack[-1]
            paren_stack.pop()
            paren_stack.append(new_string)
            unwrapped_string += nested_paren_string
        elif char == ")":
            unwrapped_string += "()" * len(nested_paren_stack) + "()"
        elif nested_paren_string:
            nested_paren_string += char
        else:
            unwrapped_string += char
    if nested_paren_stack:
        unwrapped_string += "()" * len(nested_paren_stack)
    return unwrapped_string.count("()")


def test_nested_parens_function():
    # TODO