

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    return (n // 11) % 2 + (n // 13) % 2

def prime_factorize(n):
    """Return an integer x such that n = x**2 + 1 for all non-primes less than n
    >>> prime_factorize(10)
    2
    >>> prime_factorize(13)
    5
    """
    if n <= 1:
        return n
    p = 2
    while True:
        p += 1
        if p * p > n:
            return n
        elif n % p == 0:
            return p
