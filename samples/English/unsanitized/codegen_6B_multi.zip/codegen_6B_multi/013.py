

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    while b:
        a, b = b, a % b
    return a

class Solution(object):
    def isPower(self, x: int, N: int) -> bool:
        return 2 ** x == N

print(Solution().isPower(10, 25))
print(Solution().isPower(12, 15))
print(Solution().isPower(1000, 10))
print(Solution().isPower(1000, 9))
print(Solution().isPower(1000, 3))
print(Solution().isPower(1000, 4))
print(Solution().isPower(6, 15))