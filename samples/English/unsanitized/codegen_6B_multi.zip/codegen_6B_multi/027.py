

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    return string[0].upper() + string[1:].lower()


class CaseInsensitiveDict:
    """Makes a dictionary case insensitive by using a regular expression match as a key.
        >>> d1 = CaseInsensitiveDict({'Hello': 'world', 'World': 'hello'})
        >>> d1['HELLO'], d1['WORLD']
        ('world', 'hello')
    """
    def __init__(self, d: dict = None) -> None:
        """CaseInsensitiveDict optionally initialized with a dict.
        """
        self.d = {}
        if d is not None:
            self.update(d)

    def __contains__(self, s: str) -> bool:
        return s in self.d

    def __setitem__(self, s: str, pair: tuple) -> None:
        self.d[re.sub('(.)', r' \1', s)] = pair[0]

    def __getitem__(self, s: str) -> tuple:
        return self.d[re.sub('(.)', r' \1', s)]

    def __delitem__(self, key: str):
        del self.d[key]

    def pop(self, k:' str key') -> tuple:
        return self.d.pop(k)

    def __getattr__(self, attr: str) -> dict:
        raise AttributeError(attr)

    def get(self, k:' str object') -> dict | tuple:
        if k in self.d:
            return self.d[k]
        return self.d.get(k)

    def has_key(self, k:' str object') -> bool:
        return k in self.d

    def __iter__(self) -> Iterator[str]:
        return iter(self.d)

    def copy(self) -> 'CaseInsensitiveDict':
        d =