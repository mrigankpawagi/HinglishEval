

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if n < 2:
        return False
    elif n==2:
        return True
    elif n%2==0:
        return False
    else:
        for i in xrange(3, sqrt(n)+1, 2):
            if n%i==0:
                return False
        return True

def is_sum(a, b):
    if sum(a) == sum(b):
        return True
    else:
        return False

def list_to_dict(alist):
    """Helper function that converts a list to a dictionary
    >>> list1=[[12, 34, 1], [4, 22, 725]]
    >>> dict1=list_to_dict(list1)
    >>> len(dict1)
    2
    >>> dict1[12]
    34
    """
    dictionary = {}
    for i in range(len(alist)):
        dictionary[alist[i][0]] = alist[i][1]
    return dictionary

#### Some test cases

def test():
    assert is_prime(6)==False  # false
    assert is_prime(2)==True  # true
    assert is_prime(11)==True  # prime number
    assert is_prime(2)==False  # non prime 
    assert is_prime(101)==False  # non prime
    assert is_prime(44)==False  # non prime
    assert is_prime(1)==True  # prime number but only one digit
    assert is_prime(13441)==True  # prime with only two digit number
    assert is_sum([1, 2, 3], [4, 5, 6])==False  