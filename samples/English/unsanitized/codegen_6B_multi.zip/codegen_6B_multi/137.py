
def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be. or,

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """
    def func(t):
        if t.type_ == "str" and len(t.val) >= 3:
            if t.val[0] == '"' and t.val[-1] == '"':
                return t.type_, t.val[1:-1]

        return None
    return func



def cmp_two(a, b):
    """
    This method is a wrapper for compare_one, but computes the value for
    both variables at the same time.
    """
    return compare_one(compute_val(a), compute_val(b))


def do_calc(a, b):
    """
    This method performs the appropriate comparison for two variables.
    It works regardless of type or category.
    """
    if a is None or b is None:
        return None

    if a.type_ == 'int' and b.type_ == 'int':
        return a + b
    elif a.type_ == 'int' and b.type_ == 'float':
        #print(a.val)
        #print(b.val, float(a.val) + float(b.val))
        print(float(a.val) + float(b.val))
        #return (float(a.val) + float(b.val))
        return float(a.val) + float(b.val)
    elif a.type_ == 'float' and b.type_ == 'int':
        return a - float(b.val)