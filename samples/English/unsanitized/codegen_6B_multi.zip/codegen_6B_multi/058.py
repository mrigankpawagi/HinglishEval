

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    l1, l2 = sorted(l1), sorted(l2)
    _l1, _l2 = [], []
    for i_l1, i_l2 in zip(l1, l2):
        if i_l1 not in _l1:
            _l1.append(i_l1)
            if i_l2 not in _l2:
                _l2.append(i_l2)
    return sorted(_l1), sorted(_l2)


@parametrize('a, b', [
    ([0, -1, -2, -3, -4], [0, 1, -4, -3, -2]),
    ([5, 2, 3, 4, 1], [5, 6, 7, 8, 9]),
    ([4, 4, 4, 4, 4], [4, 3, 2, 1, 4]),
    ([1, 1, 1, 1], [3]),
    ([0], [-1, -3, -2]),
    ([], [-1, 1]),
    (['foo', 'Foo', 'FOO'], ['bar', 'Bar', 'BAR']),
    (['foo','Foo','a'], ['Foo', 'x', 'y', 'z', 'foobar', 'Fo'])
])
def test_common(a, b):
    res = common(a, b)
    common_l, common_r = res

    assert len(common_l) == len(common_r)
    assert sorted(common_l) == 'aBarbFooFOOxzFoo'.split()
    assert sorted(common_r) == 'aBarbFooFOOxz'.split()

    assert len(common_l