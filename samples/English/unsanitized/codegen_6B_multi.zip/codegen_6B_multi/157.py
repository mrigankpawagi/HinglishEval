
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    angle = (a * b) / (float((abs(a) + abs(b) + abs(c))) / 2)
    if math.sqrt(math.pow(float(angle), 2) + 1) == math.sqrt(float(a) * b):
        return True
    else:
        return False

class Node:
    def __init__(self, x=0, y=0, val=0):
        #print("new node has: %s %s %s" % (x, y, val))
        self.x = x
        self.y = y
        self.val = val

def bfs(x1, y1, x2, y2, map, max_dist, dist):
    """ Finds out the shortest path among all possible
        by brute force.
    """
    # store visited values in a map
    visited = {x1: 1, y1: 1}

    queue = [Node(x1, y1, 1)]

    while queue:
        node = queue.pop(0)

        if node.x == x2 and node.y == y2:
            # if you have reached the destination
            #print("The shortest path is: ")
            #print(dist[x1][x2] + " " + str(node.x) + " " + str(node.y))
            return dist[x1][x2] + node.val

        x = node.val
        y = node.y

        # if you collide with one of map
        if not map[x][y]:
            # you do not have to go there. 
            # Just delete the node from the queue
            #