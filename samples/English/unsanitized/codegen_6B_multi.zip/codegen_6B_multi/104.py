
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    
    results = [x]
    for i, n in enumerate(x):
        if(n % 2 == 0):
            continue

        tmp = set(results)
        tmp.add(n)
        results = list(tmp)

    return sorted(list(set(results)))

def sort(lst):
    """Return a sortd list of elements of any type

    Note:
    """
    sorted_list = sorted(set(lst))
    return sorted_list

def make_matrix_of_num_list(num_list, n):
    """
    Make a 2d list of n elements

    Input:
    num_list
    n
    
    Output:
    2d Array.
    """
    
    array = [[] for i in range(n)]
    for num in num_list:
        array[int(num/10) ].append(num%10)  
    return array

def count_digit(num):
	"""
	Count digit n in number x
	
	Input: : num
	
	Output: count
	"""
	ret = 0
	while(num / (10) >= 1):
        	ret += num % 10
		num = int(num / 10)
	if (num):
        	ret += num
	return ret

def is_palindrome(num):
	"""
	Given a positive number num, check if num is a palindrome

	Assume all negative numbers are 0 before
	calculating whether num is palindrome.

	Input: num
	
	Output: True if num is a palindrome, False otherwise
	"""
	# Check if integer and make it to positive
	num =