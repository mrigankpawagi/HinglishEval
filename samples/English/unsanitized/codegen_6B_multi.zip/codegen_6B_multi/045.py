

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return float(a * h) / 2


class BoundingBox(object):
    """
    A bounding box is a (top-left, bottom-right) tuple. Used for
    colliding objects.
    """
    def __init__(self, top_left, bottom_right):
        """
        Create a new BoundingBox from two points.

       .. warning::

            The top-left coord is not on the bottom-right.
            Make them equal by passing `(0, 0)` if you want 0-based
            coordinates.

        >>> bb = BoundingBox((0, 0), (8, 8))
        >>> bb
        BoundingBox((0, 0), (8, 8))

        >>> bb = BoundingBox(Point((0, 0)), (8, 8))
        >>> bb
        BoundingBox((0, 0), (8, 8))
        """
        self.center = (top_left[0] + bottom_right[0],
                       top_left[1] + bottom_right[1])
        self.width = bottom_right[0] - top_left[0]
        self.height = bottom_right[1] - top_left[1]

    def __repr__(self):
        """

        >>> a = BoundingBox((0, 0), (2, 2))
        >>> print(repr(a))
        BoundingBox((0, 0), (2, 2))
        """
        return f"BoundingBox({(self.top_left[0], self.top_left[1])}, ({self.bottom_right[0], self.bottom_right[1]}))"

    def __iter__(self):
        yield self.top_left
        yield self.bottom_right

    def __eq__(self, other):
        if self.top_left == other.top_left and self.bottom_right == other.bottom_right:
            return True
        else:
            