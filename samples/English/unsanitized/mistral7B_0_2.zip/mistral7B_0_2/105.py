 ```python
def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]

     If the array is empty, return an empty array:
     -> return [] if not arr else ...

     If the array has any strange number ignore it:
     -> arr = list(filter(lambda x: 1 <= x <= 9, arr))

    """
    return [] if not arr else list(map(lambda x: {"one": "One", "two": "Two", "three": "Three", "four": "Four", "five": "Five", "six": "Six", "seven": "Seven", "eight": "Eight", "nine": "Nine"} [str(x)], filter(lambda x: 1 <= x <= 9, arr)))[::-1]
```

This function first filters out any numbers that are not between 1 and 9 using the `filter` function with a lambda function. Then it maps each number to its corresponding name using the `map` function and a dictionary. Finally, it reverses the resulting list using slicing.

Note that this solution assumes that the input is a list and not an array. If the input is supposed to be an array, you would need to convert it to a list using the `list` function before applying the `filter` and `map` functions.