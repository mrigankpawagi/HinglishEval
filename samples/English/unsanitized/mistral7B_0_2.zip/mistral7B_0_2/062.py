 ```python
def derivative(xs: list):
    n = len(xs)
    return [0] * (n - 1) + [i * (x ** (i + 1)) for i in range(n)]
```