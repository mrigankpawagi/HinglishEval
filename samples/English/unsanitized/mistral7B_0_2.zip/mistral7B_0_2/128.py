 ```python
def prod_signs(arr):
    if not arr:
        return None

    magnitudes = [abs(i) for i in arr]
    signs = [1 if i > 0 else -1 for i in arr]

    return sum(magnitudes) * functools.reduce(lambda x, y: x * y, signs)
```

Here's a brief explanation of the code:

1. We check if the array is empty and return `None` if it is.
2. We create two lists: `magnitudes` which contains the absolute values of the integers in the array, and `signs` which contains `1` for positive integers, `-1` for negative integers, and `0` for zeros.
3. We use the `functools.reduce` function to calculate the product of all signs in the array.
4. Finally, we multiply the sum of magnitudes with the product of signs to get the result.