 ```python
import re

def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.

    Args:
        date (str): date in the format 'mm-dd-yyyy'

    Returns:
        bool: True if the date is valid, False otherwise
    """

    if not date or not re.match(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|[12][0-9]|3[01])-(\d{4})$', date):
        return False

    month, day, year = map(int, date.split('-'))

    if month < 1 or month > 12:
        return False

    if month in [1, 3, 5, 7, 8, 10, 12]:
        if day < 1 or day > 31:
            return False
    elif month == 2:
        if (year % 4 == 0 and year % 100 != 0 or year % 400 == 0) and day < 29:
            pass
        else:
            if day < 1 or day > 28:
                return False
    else:
        if day < 1 or day > 30:
            return False

    return True
```