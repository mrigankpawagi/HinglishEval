 ```python
def is_bored(S):
    boredom_count = 0
    words = S.split('. ' if S[-1] == '.' else S.split('!') if S[-1] == '!' else S.split('?'))
    for word in words:
        if word.strip().lower().startswith('i'):
            boredom_count += 1
    return boredom_count
```