 ```python
def count_distinct_characters(string: str) -> int:
    set_string = set(string)
    return len(set_string)
```