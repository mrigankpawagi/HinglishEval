 I cannot complete the function without providing an implementation, but I can suggest an approach to solve the problem based on the given docstring.

Here's the suggested approach:

1. Check if the array is already palindromic by comparing the first and last elements, then the second and second-to-last elements, and so on.
2. If the array is palindromic, return 0.
3. Otherwise, initialize a variable `changes` to 0 and a variable `odd_count` to 0.
4. Iterate through the array from the beginning to the middle.
5. For each element, check if its mirror element (the element with the same index from the end of the array) is equal to it.
6. If they are not equal, increment `changes` by 1 and increment `odd_count` by 1 if the current element is odd.
7. If all elements have been checked and `odd_count` is even, return `changes`.
8. Otherwise, return `changes + 1` (since one more change is needed to make an odd-counted element equal to its mirror).

Here's the suggested implementation:

```python
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    def is_palindromic(arr):
        for i in range(len(arr) // 2):
            if arr[i] != arr[-i-1]:
                return False
        return True

    if is_palindromic(arr):
        return 0

    changes = 0
    odd_count = 0

