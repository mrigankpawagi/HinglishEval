 Here's the completed function based on the given docstring:

```python
def strange_sort_list(lst):
    result = []
    while lst:
        min_elem = min(lst)
        result.append(min_elem)
        lst.remove(min_elem)
    return result
```