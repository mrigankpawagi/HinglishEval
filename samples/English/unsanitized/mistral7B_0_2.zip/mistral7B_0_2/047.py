 Here's the completed Python function for the given docstring:

```python
def median(l: list):
    """Return median of elements in the list l.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    l.sort()
    length = len(l)
    mid = length // 2

    if length % 2 == 0:
        return (l[mid - 1] + l[mid]) / 2
    else:
        return l[mid]
```

This function first sorts the list, then calculates the middle index based on the length of the list. If the length is even, it returns the average of the two middle numbers. Otherwise, it returns the middle number.