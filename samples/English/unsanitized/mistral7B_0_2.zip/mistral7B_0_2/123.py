 ```python
def get_odd_collatz(n):
    sequence = [n]
    while n not in [1]:
        if n % 2 == 0:
            n = int(n / 2)
        else:
            n = 3 * n + 1
        sequence.append(n)
    return list(filter(lambda x: x % 2 != 0, sequence))
```

This function completes the `get_odd_collatz` function by implementing the Collatz sequence generation and filtering the even numbers. The function maintains a list `sequence` to store the sequence elements and uses a while loop to generate the sequence until it reaches 1. The filter function `list(filter(lambda x: x % 2 != 0, sequence))` is used to extract the odd numbers from the sequence and return them as a list.