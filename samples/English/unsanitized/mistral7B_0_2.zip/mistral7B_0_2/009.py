 Here's the completed function using a deque (double-ended queue) from the collections module to maintain the sliding window:

```python
from typing import List, Tuple
from collections import deque


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    if not numbers:
        return []

    window = deque(numbers[:len(numbers) // 2 + 1])
    result = [numbers[0]]

    for num in numbers[1:]:
        window.append(num)
        result.append(max(num, window.popleft()))

    return result
```