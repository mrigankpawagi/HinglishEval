 Here's the completed function:

```python
from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    """
    return any(abs(x - y) < threshold for x, y in pairwise(numbers))

from itertools import combinations

def pairwise(iterable):
    """ A generator that returns tuples of adjacent items from iterable.
    """
    return izip_longest(iterable, itertools.islice(iterable, 1, None), fillvalue=None)
```

Note: I added the `pairwise` function as it's a common idiom in Python to generate pairs from a list, but it's not part of the standard library. You can use the built-in `itertools.combinations` instead if you prefer.