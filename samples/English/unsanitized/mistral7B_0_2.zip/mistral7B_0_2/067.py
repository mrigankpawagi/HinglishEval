 ```python
def fruit_distribution(s, n):
    # Split the string into parts using ' and ' as delimiter
    parts = s.split(' and ')
    # Extract the number of apples and oranges from the parts
    apples, oranges = map(int, parts[0].split(' '))
    # Calculate the number of mangoes
    mangoes = n - apples - oranges
    # Return the number of mangoes
    return mangoes
```