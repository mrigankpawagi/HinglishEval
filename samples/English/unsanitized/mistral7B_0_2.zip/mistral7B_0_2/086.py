 ```python
def anti_shuffle(s):
    words = s.split()
    return " ".join([''.join(sorted(w)) for w in words])
```