 ```python
def closest_integer(value):
    value = float(value)
    return int(math.floor(value if value > 0 else ceil(value)))
```

Make sure to import the `math` and `math.ceil` functions before using them. This function first converts the input value to a float, then uses the `math.floor()` function to find the closest integer towards zero, and `math.ceil()` if the value is negative. The one with the greater absolute value is returned.