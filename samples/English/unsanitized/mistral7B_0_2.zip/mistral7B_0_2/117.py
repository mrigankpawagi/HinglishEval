 Here's the completed function definition:

```python
import re

def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    """

    words = re.findall(r'\w+\s*', s)
    result = [word for word in words if len([c for c in word if not c.isalpha()]) == n]
    return result
```

This function uses a regular expression to find all words in the input string, and then filters the list to include only the words with the desired number of consonants.