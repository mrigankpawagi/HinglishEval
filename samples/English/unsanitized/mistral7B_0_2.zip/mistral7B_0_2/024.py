 ```python
def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n

    Returns:
        The largest divisor of the given number n.
    """
    return int(n ** 0.5)
```

This function returns the square root of the given number `n` as the largest divisor, since the largest divisor is the largest number that can be multiplied by itself to produce `n`. However, it's important to note that this solution may not work for negative numbers or perfect squares. For a more comprehensive solution, consider implementing the Euclidean algorithm.