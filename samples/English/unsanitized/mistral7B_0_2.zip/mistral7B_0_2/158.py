 ```python
def find_max(words):
    max_word = words[0]
    max_unique_chars = len(set(max_word[0]))
    for word in words:
        current_unique_chars = len(set(word))
        if current_unique_chars > max_unique_chars:
            max_word = word
            max_unique_chars = current_unique_chars
    return max_word
```