 Here's the completed function using recursion for base conversion:

```python
def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    """

    def to_base_n(n, base):
        if not n:
            return ''
        return to_base_n(n // base, base) + str(n % base)

    return to_base_n(abs(x), base)[::-1] if x >= 0 else to_base_n(-abs(x), base)[1:]
```