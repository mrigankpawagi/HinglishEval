 ```python
import math

def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less than 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(math.sqrt(n))+1):
            if n % i == 0:
                return False
        return True

    primes = []
    for i in range(2, a+1):
        if is_prime(i):
            primes.append(i)
            if len(primes) >= 3:
                if a == math.prod(primes):
                    return True
    return False
```

This function uses a helper function `is_prime` to check if a number is prime. It then generates a list of prime numbers less than or equal to `a` and checks if their product equals `a`. If so, it returns `True`. If not, it continues generating prime numbers until it finds three that multiply to `a` or exhausts the list. If it exhausts the list without finding three primes that multiply to `a`, it returns `False`.