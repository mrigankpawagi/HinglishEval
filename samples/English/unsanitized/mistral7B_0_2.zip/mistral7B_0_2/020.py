 Here's the completed function definition based on the given docstring:

```python
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    """
    min_diff, closest_numbers = float('inf'), None
    for num1 in numbers:
        for num2 in numbers:
            if num1 != num2 and abs(num1 - num2) < min_diff:
                min_diff, closest_numbers = abs(num1 - num2), (num1, num2)
    return closest_numbers[0], closest_numbers[1]
```

This function uses nested loops to find the two numbers with the smallest difference in the given list. The `min_diff` variable keeps track of the smallest difference found so far, and the `closest_numbers` variable stores the two numbers with the smallest difference when it is found. The function returns these two numbers at the end.