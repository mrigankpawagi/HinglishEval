 ```python
import math

def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    index1 = planets.index(planet1)
    index2 = planets.index(planet2)

    if index1 < 0 or index2 < 0 or index1 >= len(planets) or index2 >= len(planets):
        return tuple()

    orbit_dif = abs(math.fabs(planets_orbits()[index1]) - math.fabs(planets_orbits()[index2]))
    result = [planets[i] for i in range(len(planets)) if abs(math.fabs(planets_orbits()[i]) - math.fabs(planets_orbits()[index1])) <= orbit_dif]

    return tuple(sorted(result, key=planets.index))

def planets_orbits():
    return [5.79e11, 1.08e11, 1.496e11, 2.279e11, 7.783e11, 1.429e12, 2.871e12, 4.493e12]
```

This function assumes that the `planets_orbits` function is defined and returns a list of the planets' orbital distances from the sun in meters. The `bf` function checks if the given planet names are valid, and if so, it calculates the difference in orbital distances between the two planets and returns a tuple of the planets whose orbits are located between them, sorted by their proximity to the sun.