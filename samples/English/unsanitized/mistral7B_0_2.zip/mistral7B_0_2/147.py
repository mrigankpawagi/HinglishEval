 ```python
from functools import reduce

def get_max_triples(n):
    a = list(map(lambda i: i * i - i + 1, range(1, n+1)))
    return len(list(filter(lambda x, a: sum(x) % 3 == 0, itertools.combinations(a, 3))))
```

Or, using NumPy for vectorized operations:

```python
import numpy as np

def get_max_triples(n):
    a = np.array(np.arange(1, n+1) * np.square(np.arange(1, n+1)) - np.arange(1, n+1) + 1)
    return len(np.count_nonzero(np.roll(np.roll(a, 1, axis=0), 1, axis=0) % 3 == 0, axis=0)[np.triu_indices(len(a), k=2)])
```