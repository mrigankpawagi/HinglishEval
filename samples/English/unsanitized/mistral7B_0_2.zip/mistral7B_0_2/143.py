 ```python
import math

def words_in_sentence(sentence):
    words = sentence.split()
    result = " ".join(word for word in words if all(math.isprime(len(word))))
    return result
```