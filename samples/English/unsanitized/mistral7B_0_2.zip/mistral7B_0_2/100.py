 ```python
def make_a_pile(n):
    pile = [n]
    for i in range(1, len(pile) + 1):
        pile.append(pile[-1] + (i % 2))
    return pile
```