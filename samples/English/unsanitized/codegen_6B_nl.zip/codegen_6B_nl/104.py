
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    result = []
    for i in x:
        if i % 2 == 0:
            result.append(i)
    return sorted(result)
        
        
        
        
"""

"""
# 什麼就讓我痛嘔(变量: 
#  a: 今天的作品, i: 第 i 章什麼就讓我痛嘔, result: 我一聽到要說什麼怎麼自手記)
# 我對 a 配合 i 第章的答案，所以我會為每個新的 a 應創建一段新的 i 答案（每段都符合這個的結果），
#   職素可能需要多個答案
# 什麼是 a，就是跟不適合的在相鄰的答案上，所以�