
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    print "Product of", b, ", ", a
    prod = 1
    for i in range(10):
        prod *= int(str(a)[-i])
        prod = prod * int(str(b)[-i])
    print prod
    return prod

def main():
    print "Enter a number to evaluate : "
    value = int(input())
    product = multiply(value)
    print "Product is", product
    print "The unit digits are", product.replace(".", "")
    print "The unit digits are", product.split("")[1] if value.is_integer else ""
main()
input("Press Enter to quit")

In the case of a noninteger input for a, the line should be value = int(input()) should be value = float(input()) to keep the original input intact. Also, I would like to know how to return the product and unit digit in the input as is.
Thanks in advance.

A:

You could take the values from the input stream and validate them as strings by the regular expression that describes an integer number:
import re

def multiply(a, b):

    if not re.match(r'^\d+$', a):
        return None
    if not re.match(r'^\d+$', b):
        return None
...

You could skip the splitting. If all the numbers are integers, the last digit will be the unit digit (10-based). Also, you don't need to parse the second input for a