
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    n = len(lst)
    result = 0
    for i in lst:
        result += i % 2
        result = result % 2 if n > result else result
    return result


t = int(input().split()[0])
ans = 0
while t:
    nums = [x for x in range(1, t + 1)]
    ans += solution(nums)
    t -= 1
print("%d" % ans)

```

#### [1283. Minimum Path](https://leetcode.com/problems/minimum-path/)

```python
class Solution(object):
    def minPathSum(self, graph: 'Node') -> int:
        """
        :type graph: List[List[int]]
        :rtype: int
        """
        n, m = len(graph) - 1, len(graph[0])
        s = [None] * (n + 1)
        # We can't do a direct calculation because
        # min_value can be negative. For example:
        #     -1, 1, -2 -> -1
        #      0, 1,  3 ->  3
        for i in reversed(xrange(n + 1)):
            if i in graph:
 