

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    while b < a:
        b, a = b, a % b  # right shift
    a, b = b, a // b  # right shift one time
    return a // b 

def fib_sequence(num_of_nums: int) -> int:
'''Returns an array of the prime numbers up to num_of_nums, where a prime number is defined as odd
'''

array = range(2, num_of_nums + 1)

def prime_array(array: List[int]) -> List[int]:
    """Returns a new array of all prime numbers
        >>> prime_array([2, 3, 5, 7, 11])
        [3, 5, 7]
    """
    if len(array) % 2!= 0:
        array.append(1)

    new_array = []
    for i in range(len(array) // 2):
        if array[i] % 2 == 0:
            new_array.append(array[i])
        else:
            array.remove(array[i])
    return new_array

def all_prime_factors(a: int) -> int:
    """Returns list of prime factors of a
        >>> all_prime_factors(100)
        [2, 2, 5, 10]
    """
    l = [a]
    while l:
        t