from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    choices = [
        'zero', 'one', 'two', 'three',
        'four', 'five','six','seven',
        'eight', 'nine'
    ]
    new_numbers = [
        number if number.isdigit() else number.lower()
        for number in numbers.split()
        if number in choices
    ]
    return new_numbers.lower()


def numbers_and_symbols(s: str) -> List[str]:
    """ Input is a single space-separated string of a number/symbol pair and the letter with which it is written
    Examples:
    >>> numbers_and_symbols('one one, b a')
    ['one', 'b']
    >>> numbers_and_symbols('two 3, a b')
    ['three', 'two']
    >>> numbers_and_symbols('s t e c k s')
    ['s']
    >>> numbers_and_symbols('x x x')
    ['x']
    >>> numbers_and_symbols('one two a')
    ['two', 'one']
    """
    pairs_to_count = {
        'a': 1,
        'b': 1,
        'c': 1,