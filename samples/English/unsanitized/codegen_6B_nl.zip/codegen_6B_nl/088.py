
def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum( first index value, last index value) is odd,
    or sort it in descending order if the sum( first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    # Write your code here
    array_sorted = array
    if len(array)!= 0:
        if sum(array) % 2!= 0:  # Check if the sum is even
            array_sorted = sort_array(array)
            array_sorted.reverse()
        else:
            array_sorted = sort_array(array, reverse=True)
            array_sorted.reverse()
        print(array_sorted)
    else:
        print('Error, you should give at least one number in the argument!' )

print('Enter a non-negative integer: ')
integer = int(input())
array = []
# Add the number to array
array.append(integer)
sort_array(array)

There is an example to your code so the example will run if possible.

