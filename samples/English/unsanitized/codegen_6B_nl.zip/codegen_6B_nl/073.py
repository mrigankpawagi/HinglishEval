
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    l = arr.index(lowest_element)
    r = arr.index(highest_element)
    n =  (r - l)
    diff = min((n * (diff(i) + n)), (i * 2 * n - i) for i in range(l, r))
    return diff

print(smallest_change([1,2,3,5,4,7,9,6]))
The index of lowest number is always even, so it is easy to find by simple `2 * (diff(i) + n)`. However, the index of largest number is always odd so it is `i * 2 * n - i)`. This can be generalized as `(i + n) * (2n - i)`. This will reduce to the following when n = 1:

```
print([i + n  * (2n - i)  for i in range(1, len(arr) + 1)])
```


