from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    return any(numbers[i - 1] - numbers[i] + numbers[i + 1] <= threshold for i in range(1, len(numbers))
               if numbers[i]!= numbers[i + 1])


def get_close_elements(numbers: Optional[List[float]] = None, threshold: float = 0.5) -> None:
    """ Find list of close numbers in given list.
    >>> get_close_elements([1.0, 2.0, 3.0], 0.5)
    [1.0, 2.0]
    >>> get_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    [4.0, 5.0]
    >>> get_close_elements([1.0, 2.0, 3.0], 0.5, numbers=[10, 20])
    [20, 20]
    >>> get_close_elements([1.0, 2.0, 3.0], 0.5, numbers=[10, 20, 30])
    []
    """
    if numbers is None:
        numbers = [math.inf]
    if all([math.isfinite(numbers[x]) for x in range(1, 1 + len(numbers))]):
        if len(numbers) == 1:
