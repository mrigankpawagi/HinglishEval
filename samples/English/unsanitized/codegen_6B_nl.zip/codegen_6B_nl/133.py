

def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6
    

    """
    sums = sum(lst)
    return sum(map(lambda i: i * i, lst))


lst = []
while True:
    test_str = input("-> ")
    if test_str!= " " and test_str:
        if lst and -1 not in lst:
            for i in test_str:
                lst.append(-1)
        if lst and lst[-1] == -1 and not lst:
            return sum_squares(lst)
        else:
            break

    while test_str[0] == " ":
        test_str = test_str[1:]

    try:
        test_str = int(test_str)
    except:
        test_str = 0

    lst.append(test_str)


print("Result is: " + str(sum_squares(lst)))
