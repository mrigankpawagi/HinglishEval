
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''

def create_new_string_from_prefix(prefix_string, prefix_count):
    '''
    Returns a new string by concatenating a number of different strings:
    If a prefix_string is given, the string 'prefix-' will be concatenated
    to the beginning of the strings that the prefix_count_parameter contains.
        Example: if the prefix_string is
        prefix-A, the strings 'A','B','C' will be concatenated to return 'B-'
        Example: if the prefix_string is
        None, the strings 'A','B','C' will be concatenated to return 'AABC'
    If the prefix_count is larger than the length of the strings, it is divided
    by the number of strings and rounded down.
    '''

    # Create the number of strings we should concatenate to form the resultant string.
    prefix_count_param = (prefix_count).rstrip("-")  
    string_to_be_formed = []
    for i in range(0, (1 + prefix_count_param).count(prefix_string), prefix_count_param):
   