
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    result = []
    if shift > len(x):
        shift = len(x) - shift
    # Reverse to get result in forward order
    x = reverse(x)
    for i in range(shift):
        result.append(0)
    if shift > 0:
        if i < len(x) - 1:
            x = x[1:] + [0] * (len(x) - i - 1) + x[0]
        result = result[::-1] + x
    return join(result)


def _find_prefix_digit(x, n):
    """Return last n digits of a hex or bin representation of a number,
    beginning from the right.
    >>> _find_prefix_digit(b'\x0012', 2)
    [0, 0]
    >>> _find_prefix_digit(b'\x0012', 3)
    [1, 0, 0]
    """
    base = 32 if int(base, 16) < 2 else 16

    x = x.lstrip('0x') + x
    if base > 9:
        n_digits = int('0' * (len(x) - len(x[-n:])))
        prefix_string = x[:n_digits + n]
    else:
        prefix_string = '0' * n
      