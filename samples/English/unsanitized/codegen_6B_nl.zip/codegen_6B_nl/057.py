

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    l2 = [len(u) for u in l]
    ix = 1
    for i, j in zip(l2[::2], l2[1::2]):
        if i < j:
            break
        ix += 1
    return ix > 1

class LinkedList:
    num = 1

    def __init__(self):
        self.head = None
        self.num += 1

    def append(self, x):
        if self.head == None:
            self.num += 1
            self.head = LinkedList()
        new_node = Node(x)
        # add new node at end
        self.head.next = new_node
        new_node.prev = self.head

    def display(self):
        print(self.head)

    def find(self, value):
        count = 1
        while count < 50:
            if value in self.head.data:
                count += 1
                break
            count += 1
     