
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    odd_ids = [lst[i] for i in range(1, len(lst) + 1) if lst[i] % 2!= 0]
    even = list(filter(lambda e: lst[e] % 2 == 0, odd_ids))
    for element in even:
        lst.insert(len(lst) / 2, element)
    return sorted(lst)


def filter_odd(lst):
    """Given a list, return a list of all the even numbers that are at odd indices.

    Examples:
        filter_odd([4, 2, 3, 6]) ==> [4, 6]
        filter_odd([4, 2, 3, 6]) ==> [2, 6]
        filter_odd([4, 2, 3, 6]) ==> [6]
    """
    odd_ids = [lst[i] for i in range(1, len(lst) + 1) if lst[i] % 2!= 0]
    return list(filter(lambda e: lst[e] % 2 == 0, odd_ids))


def count_even(lst):
    """Given a list, return the number of even numbers that are at odd indices.
    
    Examples:
        count_even([4, 2, 3, 6]) ==> 2
        count_even([4, 2, 3, 6]) ==> 1
    """
    odd_ids = [lst[i] for i in range(1, len(lst) + 1) if lst[i] % 2!= 0]
    return len(list(filter(lambda e: