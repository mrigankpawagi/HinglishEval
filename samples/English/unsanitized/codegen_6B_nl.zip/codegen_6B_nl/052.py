

def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return not any(abs(x - t) <= 1 for x in l)

def above_threshold(l: list, t: int):
    """
    Return True if all numbers in the list l are above threshold t.
    >>> above_threshold([1, 2, 4, 5, 10], 20)
    False
    >>> above_threshold([-1, 2, 4, 5, 10], 0)
    True
    """
    return not any(abs(x - t) >= 1 for x in l)

class Solution:
    def findMean(self, nums: List[int]) -> int:
        """
        :type nums: List[int]
        :rtype: int

        Find the mean if an array of n-integer.
            1
          -5
4         -9
-5         6

So the result for the above array is -3.0.
            1
          5   
4       -9   -5
-5      7    6

        :code: 1
        :return: The mean (of a numbers array)
        :qtype: int
        """
        n = len(nums)
        if not n