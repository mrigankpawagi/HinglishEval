from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(strings)


def str_join(strings: List[str]) -> List[str]:
    """ Return list of strings after joining"""
    return [s.join(',') for s in strings]


def get_type_from_string(type_name: str):
    """ Convert a type name to a valid type object
    >>> get_type_from_string('int')
    <class 'int'>
    """
    return type(type_name, (), {}) if type_name == 'builtin' else type_name


def create_class(nested_type_class: List[str]):
    """ Class object to represent a single, non-nested type
    e.g. int, string, list, etc.
    >>> create_class([])
    None
    >>> create_class([1])
    <class 'int'>
    >>> str_join(create_class(['a', 'b', 'c']))
    'abc'
    >>> get_type_from_string('Int')
    <class 'int'>
    >>> get_type_from_string('str')
    <class'str'>
    """
    class_name = '{}List'.format(nested_type_class[0])
    if not class_name.endswith('List'):
        class_name += 'List'
    if nested_type_class[-1] == ']':
        class_name += '}'

    return class_name if class_name else None


def create_class_from_nested_