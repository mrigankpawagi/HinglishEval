

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    return min(l) + max(filter(lambda x: x < min(l), l))

def round(n, **kwargs):
    """
    Return first argument rounded to the closest integer.
    Arguments are (n - integer value to round to, (optional) integer value to add after last digit).
    e.g. round(9.5, 2) -> returns 10, round(9.6, 2) -> returns 10.
    >>> round(1.2, 2)
    2
    >>> round(2.3, 0.1)
    2.4
    """
    return int(n)
# this one is to be fixed:
# round(1.2, 1) # fails

def sigmoid(x):
    """Function that produces sigmoidal output between 0 and 1 using the given x."""
    return float(1 + x) / (1 + 10 ** -9)
# this one is to be fixer:
# sigmoid(1.0)

def sin(x):  # use this if x isn't a number
    """
    Return the sine function of x.
    x takes any value except for the values divisible by pi (eg 0, pi/2, 3pi/2).
    It is accurate to at least 2 digits after the decimal point.
    >>> sin(0.35)
    0.8164965809288858
    """
    return 1 / (1 + math.sin(x /.5))

def sinc(x):
    """
    Return the sinc function of x.
    Sinc(x) is close to 1 for small x and falls off rapidly as |