

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    for bracket in brackets.split():
        if bracket.isupper():
            if bracket not in ["<", ">", "="]:
                return False
    return True

A:

Python, 32 bytes
lambda x:len(sorted(x.split()))==2

This function takes a string and returns False if it doesn't have the form '<>(...)'.
Example:
>>> f("<")
False
>>> f(">")
True
>>> f(">a<")
False
>>> f(">>a<")
True
>>> f(">a<b")
False
>>> f('>a<b>c<d>e<f>')
False

I should have saved myself some bytes by trying this. I should get credit for the algorithm used, but not for the implementation.

A:

Ruby, 42 39 bytes
->s->s=s.split()&~/(\w+-.*?)<.*\3/

Try it online!
This also works on strings of type ">a<b><c>" but I have no idea if that's due to implicit coercion or the regex.
Explanation
->s->s=s.split()&~/(\w+-.*?)<.*\3/

->s- Takes a string
s= s.split() - Split it into space separated strings
&~ - Bitwise and-not
(\w+-.*?)<.*\3/ - Groups the characters between the first > and the first < (so they are always the two brackets