
def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    isFactor = isInteger(n) and isInteger(x) and (n <= x)
    if isFactor:
        simplify = reduce(mul, x, n))
        isFactor = reduce(mul, x, mul)
        if simplify == x:
            break
        if not isFactor:
            return False
    return True

I tried to make it the general way, but I don't know how to make it general...

A:

The simplification you're describing can be done by repeatedly dividing numerator by denominator
until you're able to reduce the fraction to a single integer.
Here is an algorithm which does the above:
def simplify(x, n):
  if len(x) < len(n):
    x = reverse(x)
  if len(x) == len(n):
    return True

  while n[-1]!= 1:
    x = x[1:]
    x = [x[0] * n[-1] / x[-1] for x in x]
    x = [x*n[-1] for x in x]
    if reduce(lambda x,y:x==y*n