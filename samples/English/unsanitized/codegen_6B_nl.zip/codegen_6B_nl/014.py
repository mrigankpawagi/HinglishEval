from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return [string[i: i + 2] for i in range(len(string) - 1, -1, -2)]


def all_suffixes(string: str) -> List[str]:
    """ Return in increasing order all suffixes from longest to shortest of the input string
    >>> all_suffixes('abc')
    ['c', 'bc', 'b', 'bbc', 'bc', 'c']
    """
    return [string[i + 2:] for i in range(len(string) - 1)]


def all_common_prefixes(strings: List[List[str]]) -> List[str]:
    """ Return longest common prefix string for any element in input strings
    >>> all_common_prefixes([['a', 'abc', 'bbb'], ['x', 'xxx'], ['xxx']])
    'xxx'
    """
    return max(set.intersection(*s, ignore_case=True))


def all_common_suffixes(strings: List[List[str]]) -> List[str]:
    """ Return longest common suffix string for any element in input strings
    >>> all_common_suffixes([['a', 'abc', 'bbb'], ['x', 'xxx'], ['xxx']])
    'x'
    """
    return max(set.intersection(*s, ignore_case=True)) if len(s) > len(strings) else None


class WordCount:
    """ Count the number of words and punctuation marks"""

    def __init__(self,
                 filename: str,
                 word_tokenize_function: (List