

def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    s = 0
    try:
        for i in l:
            s = s + i
    except TypeError:
        return False
    else:
        return s == 0


if __name__ == '__main__':
    print('pair sum function from: '+ __file__, file=sys.stderr)
    print('\n', 'function: ', pair_sum_to_zero.__name__, file=sys.stderr)
    print('\n', 'name: ', np.unique(pair_sum_to_zero.__name__), file=sys.stderr)
    print('\n','version: ', pair_sum_to_zero.__version__, file=sys.stderr)
    print('\n', 'author: ', pair_sum_to_zero.__author__, file=sys.stderr)
    print('\n', 'date: ', pair_sum_to_zero.__date__, file=sys.stderr, sep='\n\n')

# END
