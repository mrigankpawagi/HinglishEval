
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    s = s.replace('i', 'a')
    # This does not work at the moment, I am trying to find a way to
    # get the vowels and then see how many vowels there are.
    vowel_count =???
    return vowel_count

if __name__ == '__main__':
    print(vowels_count('abcde'))
    print(vowels_count('ACEDY'))

A:

Try this
import re
count_vowels= re.compile(r',*[aeiou]',re.I)

def vowel_count(s):
    return sum(map(re.match,count_vowels.findall(s)))

print(vowel_count('abcde'))
print(vowel_count('ACEDY'))
print(vowel_count('AZEZOOO'))

