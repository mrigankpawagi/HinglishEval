
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    return digits_product(n, 1)

def digits_product(n, product=1):
    """Given an integer n and a product p, factor out an even number of
    digits if the product of digits is smaller than or equal to n. Return
    this many multiples of p. If it is impossible to factor out an even
    number of digits, return 0.
    """
    if n < product:
        print "impossible to factor out an even number of digits"
        return 0
    print n, product
    digits_product_recursive(n / product, product * product)
    return product

def digits_product_recursive(n, product):
    """Repeat as long as the number of digits is odd. Use it to factor
    out an even number of digits. Then, return this many multiples of p.
    """
    if n % product == 0:
        return digits_product_recursive(n / product, product * product)

def is_summation(n):
    """Return True if n is a perfect square or square root, False
    otherwise.
    """
    if n == 0:
        return True
    if n < 0:
        return False
    return is_digit_summation(n)

def is_digit_summation(n):
    """Return True if n is a perfect power of a single digit. False
    otherwise.
    """
    if n == 0:
        return False
    n &=