
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    if abs(a - b - c) == c:
        return True
    else:
        return False

# Define two methods here, or use a single method 
# that does more work than necessary:  

def left_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a left-angled triangle, False otherwise.
    A left-angled triangle is a triangle in which one angle is 270 degree or 
             degree, called complementary (opposite) angle and the others are 
             90-degree angles. 
    Example:
    left_triangle(3, 4, 5) == True
    left_triangle(1, 2, 3) == False
    '''
    if (abs(b * c) * (a - c) - abs(a * c) * (b - c)) > (b * c):
        return True
    else:
        return False

def isosceles_right_triangle(a, b, c):
    '''
    Given the lengths of the three sides of the triangle. Return True if they
    form an isosceles right triangle, False otherwise.
    An isosceles right triangle is a triangle in which two opposite angles