
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    return sum(c == 'A' for c in s[::2]) >= len(s) // 2

The above function, while nice and compact, just plain doesn’t work—we can’t use it because it counts as uppercase vowels anything that starts lower case, not just those that actually start with “A” like most English words do. That’s where Python starts to fall short in the analysis of word complexity. What we need is some sort of dictionary that contains all the valid uppercase vowels.

So the goal now is to define an upper case vowel dictionary we can use to make our function more reliable—some Pythonic way to do so. In Python, there is a very handy concept, which I will simply refer to as a dict, to refer to something like that.

The first thing we have to do is define such a dictionary:

>>> a = {'A':'a', 'E':'e', 'I':'i', 'O':'o', 'U':'u'} #we start empty, we add each character and its value later

Then we add everything in the string. We define a loop which, for every character in the string, compares that character to the “A” through “U” of the keys we defined. Then we increment the counter for the vowel, where the lower case version is zero.

The resulting dictionary will have keys that correspond only to the uppercase letters, and the values will be the corresponding lower case version of each “A” to “U”. So the result of our function will be the number of vowels we see in the first half of the string.

Here’s the code:

def count_upper(s): """

Given a string s, count the number of uppercase vowels in even indices.

For example: