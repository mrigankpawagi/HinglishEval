
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    if len(nums) == 0:
        return 0
    else:
        number = []
        number_str = str(nums[0])
        number_arr = number_str.split(' ')
        str_arr = []
        for num in number_arr:
            for i in range(len(number_arr)):
                # check if number is odd
                if num.isdigit() == 1 and num.isspace() == 1 and num.count('-') == 1 :
                    if not number or not num.isdigit() :
                        # Check if last digit is 'odd'
                        try:
                            if num.count('0') % 2:
                                # if last digit is odd
                       