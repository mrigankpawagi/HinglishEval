

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(set(string.lower()))


def print_cardinality_to_file_and_stdout(cardinality: int, test_filepath: str):
    """ Print the cardinality of a text file to a text file and stdout
    >>> print_cardinality_to_file_and_stdout(1, "test_file.txt")
    (1, 2, 3, 4)
      File: test_file.txt
        1
        2
        3
        4
    (1, 2, 3, 4)
    >>> print_cardinality_to_file_and_stdout(9, "test_file9.txt")
    (1, 2, 3, 4, 5, 6, 7, 8, 9)
      File: test_file9.txt
      1
      2
      3
      4
      5
      6
      7
      8
      9
    """
    print(cardinality)
    fhandle, fout = tempfile.mkstemp(suffix=".txt", prefix="card_file_{}".format(cardinality))
    f_filename = os.path.basename(fhandle)
    with open(f_filename, "w+") as f_handle:
        print(f_handle, file=fout)
        fhandle.flush()