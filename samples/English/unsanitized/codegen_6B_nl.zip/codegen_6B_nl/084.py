
def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    while N > 9:
        N = N % 10
    digits = int(N)
    return(''.join(str(d) for d in map(lambda x: x * '', range(1, int(N), 10))))

def main():
    # This is a list of test cases.
    testCases = [
        (999, '011000011', 111),
        (1000, '111', 100),
        (1000, '1111', 101),
        (1000, '101', 10),
        (1000, '011', 1),
        (1010, '110', 11),
        (1016, '01101', 110),
        (1010, '110', 11),
        (1010, '010', 10),
        (1010, '1', 1),
    ]

    # Generate test cases.
    for testCase in testCases:
        n = int(testCase[0])
        expected = testCase[1] + ''
