from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    return [delimeter] + numbers + [delimeter]


class Solution(object):
    def length(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        """
        查找足数个结点。如果一个足数和节点的差异无法超过1，那么结点删掉。
        否则排查越继越近，找到一个足数，然后加上起该足数个结点，继续剩余部分。
        换来一下的话也是同理。如果有个结点即为0位数，那么就删掉它。最后需要合并结果。
        """
        # 结果输出结果一般不能直接赋�