

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n == 0 or n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        return fibfib(n - 3) + fibfib(n - 2) + fibfib(n - 1)

if __name__ == '__main__':
    import time
    start_time = time.time()
    total_time = 0
    for i in range(100000): # the for loop is important on Pyhton because with a while loop you are running multiple python processes at once in the terminal.
        n = int(input("Enter an integer: "))
        print("The n value is ", n)
        total_time += time.time() - start_time
    print(total_time,'seconds were required to process ',n,'numbers.  Try a value of less than 10000 to see if it runs quickly')

Does any one have any thoughts on this please.

A:

You need to return the value of your recursive function instead of printing it, otherwise you are just printing the result you've just calculated, not the result of your recursive call. I've taken the liberty to reformat your method for clarity and