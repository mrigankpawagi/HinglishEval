from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    return [s for s in strings if s.startswith(substring)]


def filter(strings: List[str], substring: str) -> List[str]:
    return filter_by_substring(strings, substring)


def find(strings: List[str], substring: str) -> int:
    """ Return index for substring in input list or -1 is not found
    >>> find(['abc', 'bacd', 'cde', 'array'], 'a')
    0
    >>> find(['abc', 'bacd', 'cde', 'array'], 'ax')
    1
    >>> find(['ax', 'axes'], 'ax')
    -1
    """
    try:
        index = strings.index(substring)
    except ValueError:
        return -1

    return index


def find_by_substring(strings: List[str], substring: str) -> int:
    """ Return index for substring in input list or -1 is not found
    """
    return find(strings, substring)


def find_by_upperbound(strings: List[str], start_index: int, end_index: int) -> int:
    """ Return index for substring in given input list or -1 is not found
    >>> find_by_upperbound(['abc', 'bacd', 'cde', 'array'], 0, 3)
    1
    >>> find_