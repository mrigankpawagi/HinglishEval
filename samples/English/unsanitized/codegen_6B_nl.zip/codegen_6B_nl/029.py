from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    l = [s in strings for s in strings if s.startswith(prefix)]
    if l:
        return l

    return []


def filter_by_prefixed_string(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix
    >>> filter_by_prefix(["foo", "bar", "baz", "array"], "a")
    ['foo', 'array']
    """
    return filter_by_prefix(strings, prefix.lower())


def remove_prefix(s: str, prefix: str) -> str:
    """ Remove the prefix 'prefix' from a string.

    >>> reduce(remove_prefix, [b'This is a test', b'prefixThis is a test'])
    b'string'
    """
    return s[len(prefix):]


def remove_prefix_at(string: str, index: int, prefix_length: int) -> str:
    """ Like remove_prefix, but starts at `index` and `prefix_length` (in the input
    string) are specified.

    >>> reduce(remove_prefix_at, ['This is a test', 'prefixThis is a test', 'array'], 0)
    ('This is a test', 'array')
    """
    start = 0
    end = len(string)
    if prefix_length:
        start = int(start + prefix_length) - index

  