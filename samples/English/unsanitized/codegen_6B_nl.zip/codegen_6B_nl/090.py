
def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    lst = sorted(lst, reverse=True)
    min_num = lst[0]
    min_num_index = 0
    for num in lst:
        if num!= max(min_num, 0):
            if num < min_num:
                min_num = num
                min_num_index = len(lst) - 1
            else:
                break
            
    if min_num!= max(min_num, 0):
        min_num_index += 1
    if min_num_index == len(lst) - 1:
        return min_num
    if min_num_index + 2 >= len(lst):
        return None
    return lst[min_num_index + 1]

def max_sum(lst):
    """
    You are given an unsorted list of integers.
    Write a function max_sum() that returns the sum of the integers.
    Return None if the list has length zero or negative values.
    
    max_sum([1, 2,