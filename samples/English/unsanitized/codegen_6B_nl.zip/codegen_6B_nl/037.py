

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    even = []
    for i in range(0, len(l), 2):
        even.append(l[i])
    return even

list_2 = ['a', 'f', 'b', 'z', 'f', 'w', 'e', 'd', 'z', 'a', 'e', 'f', 'u', 'd', 'e',
           'z', 'u', 'b', 'e', 'k', 'a', 'z', 'd', 'w', 'j', 'g', 'k', 'z', 'q', 'k','m',
           'n', 'q', 'w', 'l', 'h', 'b', 'i', 'g', 'r','m', 'n', 'p', 'z', 'b', 'r', 'l',
           'l', 'd', 'k', 'g','s', 'o','s', 'p', 'u', 't', 'y', 'x', 'a', 'c','m','s',
           'p', 'e', 'c', 'r', 'a', 'o', 'v', 'b', 'f', 'z', 'd', 'b', 'q','m', 'u', 'f',
           'o', 'f', 'd', 'p', 'd', 'q', 'u', 'e','m', 'q', 'j',