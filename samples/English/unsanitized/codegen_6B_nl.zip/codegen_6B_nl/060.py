

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    n = int(n)
    return (int(range(0,len(n+1)+1))-1)*n

def product_to_n(n: int):
    """This function sums each number multiplied by a number from 1 to that number. It is the same
    as sum_to_n with each number replaced by the multiplication of it and num.
    >>> product_to_n(30)
    465
    >>> product_to_n(100)
    5050
    >>> product_to_n(5)
    2
    >>> product_to_n(10)
    6
    >>> product_to_n(1)
    1
    >>> product_to_n(20)
    20
    """
    n = int(n)
    answer = int(range(0,len(n+1)+1))*n
    for i in range(0,len(n+1)+1):
        answer = (n*(int(range(i,len(n+1)+1))-1)*i)
    return answer

def get_count_of_n(n: int):
    """This function simply counts how many numbers exist between "num" and "max"
    as per this format: 1,3,4,5,6,7,8,9... This is equivalent of sum_to_n(max-num).
    >>> get_count_of