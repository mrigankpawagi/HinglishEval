from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    # https://en.wikipedia.org/wiki/Yanking_problem
    # https://en.wikipedia.org/wiki/Pipeline_(Unix)
    # https://en.wikipedia.org/wiki/Pipelining_%28control_systems%29
    if not numbers: return []
    if numbers[1:] not in numbers[0:-1]: return numbers[1:]
    return numbers[:-1]


def rolling_min(numbers: List[int]) -> List[int]:
    """ From a list of integers generate a list of rolling maximum element found until given moment in sequence
    >>> rolling_min([1, 1000, 1000, 1000, 10])
    [1, 10, 10, 10, 1000]
    """
    return rolling_max(numbers)[1:]


def rolling_mean(numbers: List[int]) -> float:
    """
    From a list of integers, generate a list of rollinng mean of elements found until given moment in sequence.

    >>> rolling_mean([1, 5, 1, 0])
    1.5
    >>> rolling_mean(range(1, 5, 2))
    3.0
    >>> rolling_mean(range(1, 20))
    7.5
    """
    if not numbers: return 0
    if numbers[-1:]!= numbers[:-1]:
        return numbers[-1] / float(numbers.index(numbers[-1]))
    return sum(numbers) / float(len(numbers))


def rolling_median