

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    pal_suffix = ''.join(reversed(string[:reversed(string.rfind(string[::-1]) + 1)])[:-1])

    return string + ''.join(reversed(string[reversed(string.rfind(pal_suffix)):][::-1]).split())


def to_lowercase_list(lst: list) -> Set:
    """ Return a new dictionary mapping each character to the list of all the
    unique characters found in that index.
    """
    mapped = {c: frozenset(lst)}
    d = dict(mapped)
    return {k: lst for k, lst in d.iteritems()}


if __name__ == '__main__':
    lst = set([8, 1, 3, 5, 7])
    lst1 = set()
    s = len(lst)

    while s > 0:
        s -= 1
        lst1.update(to_lowercase_list(lst[:s]))

    print(lst1)

    print('    '.join([str(m) for