
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    if not isinstance(num, int):
        try:
            num = int(num)
        except:
            try:
                num = float(num)
            except:
                print("Only integer and float are allowed")
                sys.exit()
    if num > 0:
        sum = 0
        n = len(str(num))
        m = num # to get the total number of digits

        if n % 2 == 0:
            sum = sum + 2

        else:
            m -= 1

        while m > 0:
            if num % 10 == 0:
                sum = sum + 1
            m -= 1
        if sum % 2!= 0:
            sum = 0
            m = int(input("Enter the number of digits you want to be checked: "))
    return sum, m

def number_with_smallest_prime_substring(number_str):
    """Input will