

def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    return "".join([(ord(c) - 5 + ord("a")) % 26 + ord("a") for c in s])


def encode_base64(s: str):
    """
    encodes a string in base64.

    :param s: string to be converted
    :type s: str
    :returns: string representation of the input
    :type s: str
    """
    if not s:
        return ""

    result = []
    for i in s:
        result.append(map(ord, {0: "A",
                               1: "B",
                               2: "C",
                               3: "D",
                               4: "E",
                               5: "F",
                               6: "G",
             