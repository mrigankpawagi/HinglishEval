from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    min = numbers[0]
    max = numbers[-1]
    return [max - min / 2 + min.clamp(min, 0, 1) for value in numbers]


# pylint: disable=C0212,R0909
def expand_to_unit(numbers: List[float]) -> List[float]:
    """ Given a list of numbers, a range of unit values and a scale, apply a linear transform to the list,
    such that a range of values are selected from the original list and scaled such that they are
    between 0-1 units
    example:
    """
    return numbers[:] * scale_number(range(len(numbers)), unit_number(scale))


def normalize(numbers: List[int]) -> List[int]:
    """Given a list of integers, scale every number such that the smallest number becomes 1
    """
    n = 0
    for number in numbers:
        n += number * (numbers.count(number) - 1) / len(numbers)
        n = int(str(number))
    return [int(str(x)) for x in range(n, n + 1)]


def unit_number(scale: int) -> float:
    """Given a scale, returns the list of unit values corresponding to that scale"""

    if scale == 1:
        return [1])
    elif scale == 2:
       