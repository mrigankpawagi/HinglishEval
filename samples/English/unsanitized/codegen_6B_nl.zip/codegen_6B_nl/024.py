

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    x = min(n, 2)
    if n == x:
        return 1
    else:
        return x * largest_divisor(n // x)

>>> largest_divisor(15)
5
>>> largest_divisor(4242)
10033

What if I were to do it in a different way, using a recursive solution. I feel like I'd know a different solution, and would have been able to answer this just fine without using the base cases.
def largest_divisor_1(n: int) -> int:
    if n < 2:
        return 2
    else:
        return largest_divisor_1(n // 2)

def largest_divisor_2(n: int) -> int:
    i = 1
    j = 0
    while j < 2:
        if n == 0:
            break
        if n % 2 == 0:
            i = i * n // 2
            j += 2
        else:
            i = (n * i // 2) + 1
            j += 1
    return i

A:

Here's a way to rewrite the function using dynamic programming:
import itertools

def largest_divisor(n):
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    """
    L = {1, 2}   # keep track of the largest prime factor
   