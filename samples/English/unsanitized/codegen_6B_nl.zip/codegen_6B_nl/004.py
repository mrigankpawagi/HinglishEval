from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    mean_deviations = ((numbers[-1] - numbers[0])) / 2.0

    def maded_sum(nums) -> float:
        """ Compute MAD sum of non-zero length inputs (i.e. sums)
        >>> maded_sum(range(1, 11))
        1.0
        """
        return sum(abs(nums))

    return (maded_sum(numbers) / (float(numbers))).squeeze()


def root_mean_squared_deviation(numbers: List[float]) -> float:
    """ for a given list of input values,
    calculate the RMS for all numbers (average x 2) (not including the
    centerpoint).
    >>> root_mean_squared_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    nums = [(mean(numbers))**2] * len(numbers)
    return float(sum(nums)) / float(len(nums))


def mean(numbers: List[float]) -> float:
    """
    For a given list of input numbers (a.k.a. a set),
    calculate the mean
    >>> mean([1.0, 2.0, 3.0, 4.0])
    2.