
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    # Create dict from letters to the corresponding index of the english alphabet
    alphabet = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5, "G": 6, "H": 7, "I": 8, "J": 9}
    return "".join(sorted(list(map(alphabet, message))))
    
def decode(message):
    """
    Write a function that takes a message, and decodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Note: Assume only letters. 
    
    Examples:
    >>> encode('TGST')
    'test'
    >>> decode('tHKS KS C MGSSCGG')
    'test'

    Note: the function ignores capitalization of uppercase 
          vowels. 
    
    >>> encode('ThIs Is A MESSAGE')
    'THIs IS A mESSAGE'
    >>> decode('THIs IS A mESSAGE')
    'ThIs Is A MESSAGE'
    """
    # Create dict from letters to the corresponding index of the english alphabet
    return "".