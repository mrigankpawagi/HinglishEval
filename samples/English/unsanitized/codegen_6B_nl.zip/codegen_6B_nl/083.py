
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    s = {1: 0}
    for i in range(1, 4):
        s[i] = (s[i - 1] + s[i - i] + s[i + 1] + s[i + i] + s[i + 2]) \
                    / (3 * (4 - i))
    print(s)
    return s[n]

a = 0
b = 0
c = 0
a_start = 0
b_start = 0
c_start = 0
n = 1

while n < 100000:

    s = starts_one_ends(n)
    if s > 10:
        a += n
    if s >= 8:
        b += n
    if s >= 5:
        c += n
    n += 1

Print(b - a - c + n)
