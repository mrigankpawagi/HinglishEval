

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    text = text.lower()
    for i in range(len(text) - 1):
        for j in range(0, len(text) - i - 1):
            if text[i]!= text[j]:
                return False
    return True


def is_palindrome_using_memoize(text, start, end):
    if start >= end:
        return True

    if text[end]!= text[start]:
        return False

    if not is_palindrome(text[start:end]):
        return False

    return is_palindrome_using_memoize(
        text, start + 1, end - 1
    )


def longest_palindrome(text: str):
    """
    >>> longest_palindrome('')
    1
    >>> longest_palindrome('aba')
    3
    >>> longest_palindrome('ababca')
    4
    >>> longest_palindrome('ababcaa')
    5
    >>> longest_palindrome('cab')
    4
    """

    memoized_result = memoize_is_palindrome(text, 0, len(text) - 1)

    cache = {}

    if (memoized_result is not None):
 