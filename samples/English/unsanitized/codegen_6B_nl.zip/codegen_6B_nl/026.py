from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    seen = set()  # set keeps track of seen elements
    output = []  # keeps track of what's not yet seen
    for integer in numbers:
        if integer not in seen:
            output.append(integer)
        seen.add(integer)
    return output

def get_sum(numbers: List[int]) -> float:
    """
    Return the sum of an arbitrary set of numbers
    For example, if the numbers are 8, 5, and 13, then this return 13
    """
    return sum((numbers[n] for n in range(0, len(numbers))))


def get_product(numbers: List[int]) -> float:
    """
    Return the product of the numbers of an arbitrary list of numbers
    For example, if the numbers are 8, 5, and 13, then this return 80
    """
    return product(*numbers)  # multiply all numbers in the list


def count_pairs(numbers: List[int]) -> int:
    """ Find the count of pairs of elements
    For example, if the numbers are 2, 3 and 1, then this return 3
    """
    pairs = []
    for element1, element2 in enumerate(numbers):
        if element1!= element2:
            pairs.append(element1)  # count element1-element2
    return pairs.count(element)  # count element pairs


def check_permutation(numbers: List[