

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    def prime_fib_helper(n: int):
        if n == 1:
            return 1
        elif n == 2:
            return 2
        else:
            return (prime_fib(n - 2) * prime_fib(n - 1)) + int(prime_fib(n - 1))

    return prime_fib_helper(n)

if __name__ == "__main__":
    for i in range(1, 10):
        print(prime_fib(i))
```

[源码](fib_prime.py)

##### 练习

1. 分析 Fibonacci 本身的运行时参数来了解一下对于空间和排序问题是如何表现的。

