

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    length = len(string)
    count = 0
    last_last_match = -1
    last_last_ind = length - 1
    while last_last_match < length:
        last_last_match = string.index(substring, last_last_match + 1)
        count += 1
    return count

This runs the time as 16 µs, and a python solution using a list: 
def how_many_times(string: str, substring: str) -> int:
    match = []
    for i, s in enumerate(string[0].split(substring), 1):
        match += [s]
        if i == len(string[0].split(substring)):
            break
    return len(match)

