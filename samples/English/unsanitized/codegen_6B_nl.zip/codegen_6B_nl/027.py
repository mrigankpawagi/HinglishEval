

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    string = string.lower()
    return string.replace(" ", "").upper().replace(" ", "")


def to_uppercase(string: str) -> str:
    """ For a given string, lowercase characters to uppercase and remove leading and trailing whitespace.
    >>> to_uppercase('Hello ')
    'HELLO'
    """
    return string.replace(" ", "").replace("' ", "'").replace(" ", "")


def to_lowercase(string: str) -> str:
    """ For a given string, capitalize letters and remove the first occurrence of leading and trailing whitespace.
    >>> to_lowercase('HEllo woRlD!')
    'hello world!'
    """
    return string.title().lower()  # Python 3.6+


def remove_prefix(str: str, prefix: str) -> str:
    """ For a given string, remove everything from the first occurrence of `prefix` up to end-of-string
    >>> remove_prefix('Hello!', 'Hi,')
    'Hello'
    """
    if prefix:
        length = len(prefix.lower())
        if prefix.startswith(str[:length]):
            return str[length:]
    return str


def remove_suffix(str: str, suffix: str) -> str:
    """ For a given string, remove everything from the first occurrence of `suffix` up to end-of-string
    >>> remove_suffix('Hello!', '!')
    'Helo'
    >>> remove_suffix('Hello!', '!'[1:])
    'Hello'
