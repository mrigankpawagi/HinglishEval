

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    for i in range(0, len(text), 1):
        if text[i].isalpha():
            text = text[:i] + text[i:]
    return text

def remove_punctuation(text):
    """
    remove_punctuation is a function that takes string and returns string without punctuation characters
    >>> remove_punctuation('!@' +'' + '%')
    '!%'
    >>> remove_punctuation('\n\n\t-\n\t')
    '\n\n\t'
    >>> remove_punctuation('-')
    ''
    >>> remove_punctuation(' ')
   ''
    """
    text = remove_vowels(text)
    text = text.split()
    text = [x.lower() if i.islower() else x for i, x in enumerate(text) if x.isupper()]
    return ''.join(text)

# main logic starts here
for text in content_str.splitlines():
    content = remove_punctuation(text)
    content = content + remove_punctuation(content)
#print(content)