
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    if len(lst1)!= len(lst2):
        print("Error: LIST1 and LIST2 has different siz")
        exit(-1)
    count = len(lst1)
    for i in range(count - 1):
        count += lst2.count(lst1[i]) - 1
    match = [lst1[i] for i in range(count)]
    return [w for w in match if not w in lst2]

# TEST CASE
lst1 = [1, 2, 2, 2, 3]
lst2 = [1, 2, 3]
print(total_match(lst1, lst2)) # -> ['2', '3']

