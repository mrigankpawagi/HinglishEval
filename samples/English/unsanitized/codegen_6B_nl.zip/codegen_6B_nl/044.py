

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if base < 10:
        return str(x)
    else:
        return "0" + str(x)
            

def str_to_int(s: str) -> int:
    """Convert a string to an integer.
    Number is allowed in decimal, exponential notation, hexidecimal, octal and binary.
    >>> '2'
    2
    >>> '+3.5'
    3.5
    >>> '8e3' # octal
    8370
    >>> '2.5'
    5
    >>> '0044444444' # binary
    44640
    >>> '0x11' # hexadecimal
    11
    """
    # handle exponential notation
    if 'e' in s:
        n = int(s) 
        # convert from exponent to long if it is a float - see note in main
        exponent = (s == '1e1')
        n = 10 ** int(s[1:]) if exponent else int(s)
    else:
        try:
            n = int(s)
            # handle negative numbers and decimal numbers
            if s.startswith('