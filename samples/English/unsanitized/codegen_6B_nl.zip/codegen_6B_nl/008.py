from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    s = 0
    x = 1
    for num in numbers:
        s += num * x
        x *= num

    return s, x


def add_sum(sum: int, numbers: List[int]) -> int:
    return sum + sum_product(numbers)


def subtract_sum(sum: int, numbers: List[int]) -> int:
    return sum - sum_product(numbers)


def main():
    numbers = [2, 3, 4, 5]
    print(f"{add_sum(1, numbers)} = {sum(numbers)} - {subtract_sum(1, numbers)} =")
    for num, x in zip(numbers, [2+3, 3+4, 4+5, 5+2]):
        print(num, x)
        if num!= x:
            print("wrong")
    print(f"{add_sum(1, numbers)}\n")


if __name__ == '__main__':
    main()
