
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    boring_sentences = collections.Counter({
        "I" + word for word in S.split("\\.")
                      for word in word in S.lower().split("\\.")
                      for _ in "?!"
    })
    return len(boring_sentences)

##### 使用简单数字模板

Python 的简单数字模板可能意味着复杂的解释器、解析器什么的，但是你肯定很容易想到解释器需要很多重复的代码。例如，推理式乱数法可以用下面这样的实现：

```
def isdivisible(number, multiple):
    """Given two ints, the task is to determine if they are divisible by `multiple`.
    For example:
        >>> isdivisible(2, 3)
        True
        >>> is