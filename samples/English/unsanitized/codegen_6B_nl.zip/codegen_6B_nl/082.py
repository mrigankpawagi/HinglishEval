
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    i = 0
    cnt = 0

    for c in string:
        cnt += 1
        i += 1

    if cnt > 1:
        return False
    while True:
        if i == len(string):
            return True

        if string[i - 1]!= string[i]) and (string[i][1]!= string[0] or string[i][0]!= string[1]):
            return False

        i += 1
        cnt += 1

        if cnt > 1:
            return False


    print("Tests Passed")

str_lent = get_input("Enter a String: \n")

print(prime_length(t_str_lent))

A:

To get your program to print "Tests Passed" after running through all the scenarios, you'll need to have some conditional checking (which I'm not sure you had a good understanding of at the start of your code).
The conditional checks could be something like: 
if not print("Tests Passed")

or
if print("Tests Passed")!= True:
    print("Tests Passed")

I also would advise using len(string) instead of length if for the case if you're trying to call your prime_length method from another class.

