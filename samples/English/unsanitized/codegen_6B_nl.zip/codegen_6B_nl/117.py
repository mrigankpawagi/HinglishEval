
def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """
    result=[]   # return list
    words=set(s.split()) # set of all words
    consonants=set([ch for ch in s if not ch.isalpha()]) # set of all consonants
    for character in consonants:
        if len(result)==n-1:   # if the current (last) word contains n-1 characters
            return result # then terminate the recursive call
        if character in words and result: #... and the word that contains n-1 characters
                                         # was found in the recursive call then terminate...
            return [result[:]+[character]] #... and add the new character...
        result.append(character)
        result.append(character) #...to the end of the current word...
    return result #... and return the words found, in order

print(select_words("Mary had a little lamb