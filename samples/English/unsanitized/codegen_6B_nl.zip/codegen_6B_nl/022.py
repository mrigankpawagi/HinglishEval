from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    assert isinstance(values, List)
    return [int(x) for x in values]


def filter_floats(values: List[Any]) -> List[float]:
    """ Filter given list of any python values only for floats
    >>> filter_floats([1, 3.14, 5.6])
    [1.0, 3.1400000000000001, 5.6000000000000001]
    """
    assert isinstance(values, List)
    return [float(x) for x in values]


def filter_complex(values: List[Any]) -> List[complex]:
    """ Filter given list of any python values only for complex
    >>> filter_complex(['a', '(3.14)', 3.14])
    [3.14+0.j]
    >>> filter_complex('1[2.3](4+1e11)')
    '(4+1e11)'
    """
    assert isinstance(values, List)
    return [complex(x) for x in values]


def filter_int_or_float(values: List[Any]) -> List[int, float]:
    """ Filter given list of any python values only for integers or floats
    >>> filter_int_or_float(['a', 3.14, 5, 'abc', {}, []])
    [(1, 4.0), (2, 5.0), (3, 6.0), (4, 7.0), (5, 8.0)]
    >>> filter_int_or_float([1, 'a', 'b', 3])
  