

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if n < 2:
        return 1
    if n == 1 or n == 2:
        return n
    if num_prime_factor(n) > 1:
        return num_prime_factor(n)
    return largest_prime_factor(n // 4) * largest_prime_factor(n // 2)

You can think of this as an O(n log n) algorithm.  That is, first check if n is prime, then calculate the largest prime factor.  Of course, calculating prime factors takes an O(n) pass over the whole number.
If instead you try to factorize the numbers for which the largest prime factor is known to be n, it will run in O(n) time.
Here is a Python implementation that does the first thing:
def largest_prime_factor_2(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor_2(13195)
    29
    >>> largest_prime_factor_2(2048)
    2
    """
    # Assume the largest prime factor of n is n by default.
    if n < 2:
        return n
    if n == 1 or n == 2:
        return n
    if n % 4 == 0:
        return largest_prime_factor_2(n / 4)
    return largest_prime_factor_2(n / 2)

As @Martijn mentioned in his comment, this algorithm does not scale. To get the correct O(n log n) algorithm, we need to know more about n than n %