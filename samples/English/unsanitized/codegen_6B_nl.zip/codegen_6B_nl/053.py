

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    print("Add")
    return x + y

def display(x: int, y: int):
    """Print 'x + y'
    >>> display(10, 7)
    17
    """
    print(x + y)

def average(x: int, y: int):
    """Calculate the average of two numbers. (returns float)
    >>> average(7, 8)
    9
    >>> average(8, 6)
    9
    """
    if x == 1:
        return x
    else:
        return x + 1
    if y == 1:
        return y
    else:
        return y + 1

def divide(x: int, y: int):
    """Calculate the answer for dividing two numbers
    >>> divide(5, 2)
    2.5
    >>> divide(2, 5)
    0.4
    """
    if x == 0:
        return 0
    else:
        return y / x

def multiply(x: int, y: int):
    """Calculate the answer for multiplying two numbers
    >>> multiply(2, 3)
    6
    >>> multiply(7, 8)
    56
    """
    return x * y

def lessThan(x: int, n: int):
    if isNaN(x) == true:
        return True
    else:
        return False
    if