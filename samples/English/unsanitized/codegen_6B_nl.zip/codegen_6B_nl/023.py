

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)


def contains(string: str, character: str) -> bool:
    """ Return whether given character is stored in given string
    >>> contains('abcdef', 'ef')
    False
    >>> contains('abcdef', 'ax')
    True
    """
    if not isinstance(character, str):
        raise ValueError("character must be string type, not {0}".format(type(character)))
    length_string = len(string)
    length_character = len(character)
    result = character == string[:length_character]

    # make sure the string is sorted in ascending order
    # first find the location of the string in the array
    location = string.find(character, 1)
    if location is not -1:
        first_element = string[:location]
        result = first_element == character
        if not result:
            return result
        location = string.find(character, location+length_character)
        if location is not -1:
            second_element = string[location+1:]
            second_element = second_element[:length_character]
            result = second_element == character
            if result:
                # string contains character in middle and on the end
                return result

    return result
