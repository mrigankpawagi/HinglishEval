

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    l = len(xs)
    newl = l - 1
    d = [0] * l
    d[0] += 1
    for i in range(2, l):
        d[i] += xs[i]
        d[i] /= i
        d[i] *= x
        d[i] *= x ** (newl - i)
    return d

Now, it works as expected when you input a polynomial like
    >>> p = [3, 1, 2, 4, 5]
    >>> derivative(p)

it outputs
    [1, 4, 12, 20]
But for the general input, where I have a general polynomial, a coefficient string, it produces error.
    >>> c0 = "3"
    >>> c1 = "2"
    >>> p = [c0, c1, 2]
    >>> derivative(p)

TypeError >>> derivative(p)

I would like to use a list as input since the user is not required to input every value.
    >>> c0 = "3"
    >>> c1 = "2"
    >>> p = [c0, c1]
    >>> derivative(p)

But it seems to be not accepting the list.
I already tried list-comprehension as below, but it works if I just pass in integers.
    >>> def derivative(x):
  