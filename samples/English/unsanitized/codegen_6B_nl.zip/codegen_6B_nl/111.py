
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    try:
        str_len = len(test)
        letter_dict = {}
    except TypeError:
        print('Test must be a string')
        return letter_dict
    last_letter = ''
    count = 1
    # TODO: make sure all letters are lowercase before doing this
    #for char in test:
    for char in test.lower():
        count += (letter_dict.has_key(char) or 0)
        last_letter = char
        if count > last_letter_max:
            last_letter_max = count
            letter_dict[char] = count
    if len(last_letter) == 1 and last_letter =='':
        letter_dict[' '] = count
    if last_letter!='':
        length_dict = {letter: count+count_not_one for letter in last_letter for count_not_one in letter_dict.values()}
        letter_dict = {}
    