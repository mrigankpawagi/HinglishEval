
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    if len(a) < len(b):
        print("Please enter less then or equal to the length of the word."),
        print(str(a)),
        print(str(b))
        return False
    else:
        for i in range(len(a)):
            for j in range(0 if i < len(a) else i):
                for ix in range(0 if j < len(b) else j):
                    if a[i] == b[ix]:
                        result = ("".join([a[ix + l] for l in range(i)])) == b[ix]
                    else:
                        break
                    if result:
                        if a[i]==b[ix]:
        