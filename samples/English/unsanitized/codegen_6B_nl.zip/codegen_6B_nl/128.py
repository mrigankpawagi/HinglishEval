
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr:
        return None
    ans = list(map(abs, arr))

    return reduce(lambda x, y: x * y, map(lambda x: int(x), ans))

print(prod_signs([1, 2, 2, -4]) == -9)
print(prod_signs([]) == None)

Output:
1
0

The key to understanding this solution is to not do the product of signs at the very end-- instead, reduce() is used to generate the sum of the products of signs from left to right, where each pairwise combination of the numbers and signs is multiplied.
As you can see, reduce() returns the sum of those products.  Since the values returned by reduce() need to be multiplied (with the appropriate sign), the code is designed so that all the numbers are multiplied by zero before reduce() is applied, so all the values are added together.

A:

Try this, it may help you :
def prod_signs(arr):
    r = 0
    for i in range(len(arr)):
        c = list(map(abs, arr))
        r += c[i] * c[-1]

    return r

# Usage, try it online!
prod_signs([])  # -> 0
prod_signs([1])  # -> 1
prod_signs([1, -3])  # -> -3
prod_signs([1, -3, 2]) 