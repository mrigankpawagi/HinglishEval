

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    return trunc_float(number) + 1e-15

class NumpyModuleWrapper(object):
    """ A wrapper class which does not implement Python's weak references. The
    only purpose of this class is to enable the use of weak references in
    objects whose lifetimes span across multiple Python interpreter sessions.

    For example in the case of :func:`~numba.evaluate` call graphs built by
    :py:func:`~numba.compile.jit` are composed of numpy arrays which are
    managed in the C module by ``numpy.array``'s weak reference counter. Because
    this counter is reset after every interpreter session, the jit compilation
    can run into a situation where some of the call graph nodes become invalid
    while they are still reachable from active code. This problem occurs when a
    code path is running on a worker where the numpy array that we are calling
    into has been deleted since jit compilation ran on the worker. In this
    case the numpy array that was the destination of the call will become an
    invalid weak reference, which we need to fix up in order for our call graph
    to be properly constructed.
    """
    def __getattr__(self, name):
        # return Python native type.
        try:
            obj  = getattr(self.container, name)
            # The container lives for the duration of the numba evaluation, so
            # it cannot go away on its own.