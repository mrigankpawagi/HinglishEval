
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    s = ""
    if  len(s) <= 1:
        s = s[::-1] 
    if s.isalpha() <> False: 
        return s.upper ()+s.lower ()

    for i in range (len(s)):

        if (s[i] >= 'a' and s[k] < 'A') or (s[i] < 'a' and s[k] >= 'A'): # first case
            s[i] = s[i].lower ()
        ##
        if (s[i] >= 'a' and s[k] >= 'A' ) or (s[i] < 'a' and s[k] < 'A'): # second case
            s[i] = s[i].upper ()
        ##

    return s

def main():
    ##
    s = '#ab' 
    ##
    print solve(s)

    ##
    s = "ac#c"
    ##
    print solve(s)

    ##
    s = 'a#c'
    ##
    print s
    print solve(s)
##
main()

