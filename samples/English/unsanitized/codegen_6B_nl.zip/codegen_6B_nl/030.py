

def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    return [n for n in l if n > 0]


def get_positive_negative_sum(l: list):
    """Return list with positive and negative numbers from l
    >>> get_positive_negative_sum([1, 1, 2, -1, 0])
    [1, -1, 2]
    >>> get_positive_negative_sum([-1, 3, -5, 2, -3, 3, -9, 123])
    [3, 3, -5, -9, -9, 123, 123]
    """
    l = sorted(l) if l!= [] else [0]

    # add positive numbers first
    p = [n for n in l if n >= 0]
    p.sort()
    p.extend(l)
    p += [0] * len(l)

    # put negative numbers
    n = [-1] * len(l)
    # n = l
    n.discard(p)

    return (p, n)


def get_negative_sum(lis: List, n=0):
    """Return non-zero negative numbers from the input list. n specifies minimal number to include,
    so if n = -1, it excludes that number.

    >>> get_negative_sum([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [-3, -3, 0, -10, -10]
    >>> get_negative_sum(
   ...   