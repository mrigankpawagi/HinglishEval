
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    if a == b:
        return [a]
    for i in range(int(b / 2) + 1, int(a + 1) + 1, 2):
        yield a * i

Examples:
>>> all(i for i in generate_integers(2, 10))  # Using generator
[2, 4, 6, 8, 10]
>>> [i for i in generate_integers(100, 1000)]  # Using list comprehension
[100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
>>> generate_integers(2, 6)  # Using list slicing
[2, 4, 6]

(As @Wenlei noticed, you could write a generator function instead of a list comprehension: see How do I use a generator instead of a list comprehension?.)
The generator we're using is quite inefficient, however, since each time a new number is generated, the whole list needs to be traversed. A list comprehension can be more efficient, because it's basically just:
[x for x in [2, 4, 6, 8, 10]]

Which is basically like:

Take the list [2, 4, 6, 8, 10]
Traverse it, building up the inner list
Return the result

However, you can use a generator to build up the inner list in one step:
x = (i for i in range(2, 10 + 1, 2))

See @Erica Horvitz's comment below about using a generator with a range.
As always, there is no clear winner, and if performance counts, you should profile your function to really know where you'd want to optimize.
Edit: I'm using