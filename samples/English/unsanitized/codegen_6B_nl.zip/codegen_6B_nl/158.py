
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """

test_find_max = [
    "name", "name", 
    "nameenam", "game", 
    "aaa", "bb", "bbb", "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
]

test_find_max_unique_word_number_equal = [
    "name", "nameenam", "game"
]

test_find_max_unique_word_number_one_smaller = [
    "aaaaaaa", "bb", "bbb", "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
]

def test_find_max_is_called():
    assert find_max.__name__ == "find_max"

def test_find_max_call_args():
    assert test_find_max.__name__ == "find_max"
    assert test_find_max.__name__ == "test_find_max"
    assert test_find_max.__dict__  == {}
    assert test_find_max.__dict__.items() == {}

def test_find_max_call_result():
    assert test_find_max.__name__ == "find_max"
    assert test_find_max.__name__ ==