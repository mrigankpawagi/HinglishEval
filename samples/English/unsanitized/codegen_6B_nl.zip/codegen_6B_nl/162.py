
def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    md5_hash = hashlib.md5()
    md5_hash.update(text)
    return md5_hash.hexdigest()

@py.test.mark.skipif("os.environ.get('PYSLATE_BACKTRACE', '') == ''")
def no_back_trace():
    """
    If pySlate does not support backtraces then do not call this
    function. See https://github.com/lazd/pySlate/issues/839
    """
    pass
    
@py.test.mark.skipif(sys.version_info[:2] < (3, 3))
@py.test.mark.skipif(np is None, reason=('Numpy is not available (i.e. import numpy) '
                                        'to use the following tests.'))
@py.test.mark.skipif("environ.get('PYSLATE_BACKTRACE', '') == ''")
class test_numpyfuncs:
    def test_dot(self, pytest):
        pytest.importorskip('numpy')
        res = dot((1, 2), (3, 4))
        assert res[0] == 6 and res[1] == 8
        
        res = dot((1, 2), 5)
        assert res[0] == -4 and res[1] == -5