
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''
    def any_int_2(x, y, z):
        '''
        Return true if x is an integer
        
        Examples
        any_int_2(3, 2, 1) ➞ False
        any_int_2(5, -2, -3) ➞ False

        '''
        if x == x.z() or y == y.z() or z == z.z() or z == 0:
            true
        else:
            false
            
        '''
    any_int_2 = any_int_2_new()
    
    x = int(input('X '))
    y = int(input('Y '))
    z = int(input('Z'))
    
    if ((any_int_2(x, y, z) == true) 
    or any_int_2(y, x, z)
    or any_int_2(z,