

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    if not l:
        return None
    return max(l)

def min_element(l):
    """Return minimum element in the list.
    >>> min_element([1, 2, 3])
    1
    >>> min_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    -10
    """
    if not l:
        return None
    return min(l)

def is_nan_element(x):
    """Check if the element is a NaN.
    >>> is_nan_element(nan)
    True
    >>> is_nan_element("abc")
    False
    """
    if x.startswith("nan"):
        return True
    return False

def is_infinite_element(x):
    """Check if the element is an Infintiy.
    >>> is_infinite_element(inf)
    True
    >>> is_infinite_element("abcdefghij")
    False
    """
    if x.find("inf")!= -1:
        return True
    return False

def is_inf_element(x):
    """Check if the element is an Infintiy.
    >>> is_inf_element(inf)
    True
    >>> is_inf_element("abcdefghij")
    False
    """
    return is_infinite_element(x)
