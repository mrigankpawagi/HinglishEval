from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    prime_sizes = [[2] for _ in range(1, n//2 + 1)]
    for i in range(2, n):
        # the list of factor sizes contains sizes of all smaller primes already
        # find smallest prime that is larger than `i`
        prime = next(
            prime for prime in prime_sizes[primelist: primelist + [i]]
            if prime > i)
        # subtract the prime from the `n` multiple and increment the corresponding value in `prime_sizes`
        n -= prime * prime_sizes[primelist][-1] + 1
        prime_sizes[primelist].append(prime)
    return prime_sizes


def prime_sieve(n: int) -> List[int]:
    """ Calculate primes using Sieve of Eratosthenes.
    Input n: number of numbers that we are looking for prime numbers.
    Return list of all prime numbers less then or equal to `n`.
    >>> prime_sieve(10)
    [2, 5, 7]
    """
    from itertools import takewhile
    from functools import reduce
    s = set()  # store all prime factors
    candidates = takewhile