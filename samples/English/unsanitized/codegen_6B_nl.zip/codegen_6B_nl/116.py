
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """
    # The complexity of this algorithm is O(nlgn), where 'n' is elements and 'g' is
    # input_elements. We're taking input as string and converting
    # to an integer and so 'n' and 'g' are both bounded by 10, so the
    # complexity is O(10**10).

    len_array = len(arr)
    sorted_array = sorted(arr)
    for i in range(len_array - 1):
        count = arr[i] + arr[i + 1]
        for j in range(len_array - i - 1):
            count += sorted_array[j] * (2 ** i)
        
        if count == 0:
            swap(arr, i, i + 1)
            sort_array(arr[:i + 1])
            sort_array(arr[i + 1:])

            count = arr[i] + arr[i + 1]
            for j in range(len_array - i - 1