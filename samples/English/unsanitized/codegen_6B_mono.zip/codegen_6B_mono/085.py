
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    return sum(lst[0::2])

assert add([4, 2, 6, 7]) == 2
assert add([]) == 0
assert add([4, 3]) == None
assert add([4,5]) == None
assert add([4, 2, 5, 1]) == 8
assert add([4, 2, 5, 8, 5, 3, 6, 5, 4, 1, 5, 1000000001, 8, 9, 8, 4, 7]) == 42

