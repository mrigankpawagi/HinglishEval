
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    return n&3 == 3


def is_sum_of_squares(n):
    """
    Evaluate whether the given number n can be written as the sum of numbers which are squares
    Example
    is_sum_of_squares(36) == False
    is_sum_of_squares(81) == True
    is_sum_of_squares(45) == true
    is_sum_of_squares(12341234) == True
    """
    residual = n
    divisor = int(sqrt(n))
    while divisor > 0:
        residual -= int(sqrt(n)) ** 2
        if residual < 0:
            return False
        divisor -= 1
    if residual == 0:
        return True
    else:
        return False


def test_is_equal_to_sum_even():
    # These are the three exemplary cases of the function
    assert is_equal_to_sum_even(4)
    assert not is_equal_to_sum_even(3)
    assert is_equal_to_sum_even(-1)


def test_is_sum_of_squares():
    assert is_sum_of_squares(36)
    assert not is_sum_of_squares(3)
    assert not is_sum_of_squares(25)
    assert is_sum_of_squares(225)


if __name__ == "__main__":

    print(f"is_equal_to_sum_even({10})", is_equal_to_sum_even(10))
    print(f"is_equal_to_sum_even({11})", is_equal_to_sum_even(11))
    print(f"