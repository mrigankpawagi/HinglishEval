

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    assert n >= 0, "n must be a non-negative integer"
    if n == 0 or n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)


def sum_digits(n: int):
    """Sum all the digits of n.

    >>> sum_digits(10) # 1 + 0 = 1
    1
    >>> sum_digits(4224) # 4 + 2 + 2 + 4 = 12
    12
    >>> sum_digits(1234567890)
    45
    """
    if n < 10:
        return n
    else:
        return sum_digits(n//10) + n%10

from operator import mul

def factorial(n: int) -> int:
    """Factorial of n, aka n * (n - 1) * (n - 2) *...

    >>> factorial(0)
    1
    >>> factorial(10)
    3628800
    >>> factorial(5)
    120
    """
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

def count_partitions(n: int, m: int) -> int:
    """Count the partitions of n into at most m parts.

    >>> count_partitions(3, 2)
    2
    >>> count_partitions(4, 2)
    4
    >>> count_partitions(3, 1)
    1
    >>> count_partitions(4, 1)
    2
    >>> count_partitions(4, 0)
    1
    """
    if n == m:
        return 1
    elif n < m:
        return 0
    else:
        return count_partitions( n-m, m ) + count_partitions(n, m-1)

def count_paths(m, n):
    '''Count the number