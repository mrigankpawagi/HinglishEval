from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    result = [0 for __ in range(len(numbers))]
    result[0] = max(numbers[0], numbers[1])
    for index in range(2, len(numbers)):
        result[index] = max(numbers[index - 2], numbers[index])
    return result


@profile
def find_maximum_min_index(numbers: List[int]) -> Tuple[int, int]:
    """ Return index of a maximum in a given list of integers. """
    max_index = 0
    for index, number in enumerate(rolling_max(numbers)):
        if number > rolling_max([numbers[max_index]]):
            max_index = index

    return max_index, numbers[max_index]


@profile
def find_maximum_min_index_with(numbers: List[int]) -> Tuple[int, int]:
    """ Return index of a maximum in a given list of integers. """
    return find_maximum_min_index(numbers)


def test(fn):
    assert fn([1, 2, 3, 2, 3, 4, 2]) == (6, 4)
    assert fn([1, 2, 3, 4, 2]) == (3, 4)
    assert fn([10, 1, 2, -3, 3, 3, 4, 5, -4, 2, 1]) == (5, -4)
    assert fn([10, -5, -3, -3, -2, -1, 20, 3, -2, 10, 5]) == (4, -4)


if __name__ == '__main__':
    test(rolling_max)
    test(find_maximum_min_index)
    test(find_maximum_min_index_with)
