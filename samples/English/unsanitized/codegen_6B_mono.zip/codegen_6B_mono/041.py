

def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    
    race_done = 0

    current_row = list(range(1, n + 1))

    while len(current_row) > 1:
        race_done += 1

        if _is_straight_downstream(race_done, current_row, n):
            race_done += 1

def _is_straight_downstream(race_done: int, current_row: str, n: int):
    if race_done == 1:
        left_to_right = current_row[:len(current_row) - 1]
    else:
        left_to_right = current_row[1:]
    
    if len(left_to_right) > 1:
        if left_to_right[0] == left_to_right[-1]:
            return left_to_right
    
    if race_done == n:
        current_row = current_row[1:]
    
    return _is_straight_downstream(race_done, current_row, n)


if __name__ == '__main__':
    print(car_race_collision(20))
