from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    if numbers:
        num = reduce(lambda x, y: x * y, numbers)
        sum = reduce(lambda x, y: x + y, numbers)
    else:
        num = 1
        sum = 0
    return (sum, num)


def sum_list(items: List[int]) -> int:
    """ For a given list of integers, return a sum of those integers.
    Empty list should be treated as zeroes.
    >>> sum_list([])
    0
    >>> sum_list([1, 2, 3, 4, 12])
    15
    """
    return reduce(lambda x, y: x + y, items)


def remove_duplicates(items: List[int]) -> int:
    """ For a given list of integers, remove from that list all duplicates.
    >>> remove_duplicates([])
    0
    >>> remove_duplicates([1, 2, 3, 3])
    1
    """
    return len(set(items))


def even_length_counts(items: List[int]) -> int:
    """ For a given list of integers, return number of the integers with equal length.
    >>> even_length_counts([])
    0
    >>> even_length_counts([1, 2, 3, 4, 8, 8])
    3
    >>> even_length_counts([1, 2, 3])
    1
    """
    count = 0
    last_len = len(items[0])
    for item in items:
        last_len = len(item)
        if last_len!= len(item):
            break
        count += 1
    return count
