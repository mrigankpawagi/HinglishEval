

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring:
        return 0
    
    for i in range(len(string)):
        if len(string) - i <= len(substring):
            break
        if string[i:i + len(substring)] == substring:
            return 1 + how_many_times(string[i + len(substring):], substring)
    
    return 0


def remove_whitespace(string: str) -> str:
    """ Removes whitespaces at the beginning and the end of a string (as the strings are immutable).
    >>> remove_whitespace('     Python 3.6.9      ')
    'Python 3.6.9'
    >>> remove_whitespace('aaa    b    b   cc')
    'aaa b b cc'
    """
    while string and string[0] =='':
        string = string[1:]
    
    while string and string[-1] =='':
        string = string[:-1]
    
    return string


def remove_vowels(string: str) -> str:
    """ Replace vowels with a space and every vowel with a hyphen.
    >>> remove_vowels('Python 3.6.9')
    'Pthnhypn 3 6.9'
    >>> remove_vowels('aaa bbb ccc')
    'aa bb - c - '
    >>> remove_vowels('The quick brown fox jumps over the lazy dog')
    'Th - qck brwn fo - jprs ov trol - dg'
    """
    result = ''
    for i in range(len(string)):
        if string[i].lower() in 'aeiou':
            result +=''
        result += string