
def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    return [string for string in s.split(',')]
    
# Test:
##print(words_string("Hi, my name is John"))
##
##print(words_string("One, two, three, four, five, six"))
    
    
######################################################################
# Question 10
# Answers here:
######################################################################
def get_random_word(wordlist):
    """
    This function returns a random word from wordlist,
    excluding words that have been guessed already.

    The probability of each word being chosen is in proportion
    to its frequency in wordlist.
    
    This is implemented as described on pg. 300 of the Unix manual.
    """
    # your code here!
    

######################################################################
# Question 11
# Answers here:
######################################################################
def get_guessed_word(secret_word, letters_guessed):
    '''
    secret_word: string, the word the user is guessing
    letters_guessed: list, what letters have been guessed so far
    returns: string, comprised of letters and underscores that represents
      what letters in secret_word have been guessed so far.
    '''
    # FILL IN YOUR CODE HERE...
    

######################################################################
# Question 12
# Answers here:
######################################################################
def is_word_guessed(secret_word, letters_guessed):
    '''
    secret_word: string, the word the user is guessing
    letters_guessed: list, what letters have been guessed so far
    returns: boolean, True if all the letters of secret_word are in letters_guessed;
      False otherwise
    '''
    