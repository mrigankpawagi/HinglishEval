

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    "*** YOUR CODE HERE ***"
    assert n > 1
    factor = 2
    biggest_factor = factor  # not the largest
    while n!= 1:
        if n % factor == 0:
            n /= factor
        else:
            factor += 1
        if factor >= biggest_factor:
            biggest_factor = factor
    return biggest_factor


def limited_factor(n: int, limit: int):
    """
    >>> limited_factor(10, 5)
    [5, 3, 2, 5]
    >>> limited_factor(13195, 5)
    [5, 3, 23, 13, 19, 29]
    >>> limited_factor(25, 5)
    [5, 5]
    >>> limited_factor(81, 5)
    [5, 7, 11]
    >>> limited_factor(4321, 3)
    [4321]
    """
    "*** YOUR CODE HERE ***"
    pass



def get_primes(n):
    """
    >>> get_primes(3)
    [2, 3]
    >>> get_primes(-3)
    []
    >>> get_primes(20)
    [2, 3, 5, 7, 11, 13, 17, 19]
    """
    "*** YOUR CODE HERE ***"
    pass


def sum_of_square_roots(n):
    """Return the sum of the square roots of the given integer n.

    >>> sum_of_square_roots(1)
    0.0
    >>> sum_of_square_roots(2)
    1.4142135623730951
    >>> sum_of_square_roots(3)
    1.7320508075688772
    >>> sum_of_square_roots(27)
    1.9990180399161606
    """
    "*** YOUR CODE HERE ***"