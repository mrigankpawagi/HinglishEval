from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    substrings = enumerate(string, start=1)
    _, _, substrings = next(substrings)
    return [string[:end - 1] + substring for _, end, substring in substrings]


def longest_prefix(x: str, y: str) -> str:
    """ Return the longest common prefix between the input strings
    >>> longest_prefix('cabrillo', 'cabrilow')
    'cab'
    >>> longest_prefix('cabinets', 'cabinet')
    'cab'
    >>> longest_prefix('cabinets', 'cabinet2')
    'cab'
    >>> longest_prefix('cabinets', 'cabinet3')
    'cab'
    >>> longest_prefix('', '')
    ''
    >>> longest_prefix('ab', '')
    ''
    """
    if len(x) < len(y):
        x, y = y, x
    for start, end in reversed(list(zip(x, y))):
        if start!= end:
            return x[:start]
    return x


def longest_prefix_str(x: str, y: str) -> str:
    """ Return the longest common prefix between the input strings as a string
    >>> longest_prefix_str('cabrillo', 'cabrilow')
    'cab'
    >>> longest_prefix_str('cabinets', 'cabinet')
    'cab'
    >>> longest_prefix_str('cabinets', 'cabinet2')
    'cab'
    >>> longest_prefix_str('cabinets', 'cabinet3')
    'cab'
    >>> longest_prefix_str('', '')
    ''
    >>> longest_prefix_str('ab', '')
    ''
    """
    if len(x) < len(y):
        x, y =