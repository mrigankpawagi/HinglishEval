

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    # check for even integers less than 2
    if n % 2 == 0 and n > 2:
        return False
    i = 3
    while i <= math.sqrt(n):
        if n % i == 0:
            # found a factor, not a prime
            return False
        i += 2 # increase by 2 since i was skipped
    # no factors found
    return True

def main():
    print(is_prime(13441))

if __name__ == "__main__":
    main()