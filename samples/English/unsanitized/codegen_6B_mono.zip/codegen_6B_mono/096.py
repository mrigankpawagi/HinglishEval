
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    num_list = []
    index = 0
    while index < n:
        if is_prime(index):
            num_list.append(index)
        index = index + 1
    return num_list

def is_prime(num):
    """Checks if the input integer is prime.

    The function returns a boolean value(True of False)
    depending upon whether the input integer is a prime number or not.

    Examples:
    is_prime(2) => True
    is_prime(20) => False
    is_prime(5) => True
    """
    if num == 0:
        return False
        # If we want to give a false answer when the input is not a number
    if num == 1 or num == 2:
        return True
    for x in range(2, num):
        if num % x == 0:
            return False
        else:
            return True

def get_prime_numbers(n):
    """Return a new list of prime numbers that is 2 through n (inclusive)
    in a sorted manner.

     Examples:
    -> get_prime_numbers(2) => [2]
    -> get_prime_numbers(20) => [2, 3, 5, 7, 11, 13, 17, 19]

    The solution is to return a list of a to b with a <= b.
    This means the solution works if a and b are input values like
    [0, 3] rather than [0