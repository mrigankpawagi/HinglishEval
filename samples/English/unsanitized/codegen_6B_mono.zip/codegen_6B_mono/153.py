
def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters 
    in the extension's name, the strength is given by the fraction CAP - SM. 
    You should find the strongest extension and return a string in this 
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension 
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) =='my_class.AA'
    """
    def _get_strength(ext):
        cap, sm = sum((x < 'A'.upper() for x in ext)), sum((x>='a'.lower() for x in ext))
        strength = cap - sm
        return (strength*1.0)/max(length(ext)-1.0,1)

    max_strength = 1.0
    res = extensions[0]
    for ext in extensions[1:]:
        cur_strength = _get_strength(ext)
        if cur_strength > max_strength:
            max_strength = cur_strength
            res = '{}.{}'.format(class_name, ext)
        elif cur_strength == max_strength:
            res = '{}.{}'.format(class_name, ext)
    return res # Place your code here

# Do not modify below
if __name__ == "__main__":
    class