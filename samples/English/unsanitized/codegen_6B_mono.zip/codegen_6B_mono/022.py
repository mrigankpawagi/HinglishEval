from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    return [v for v in values if isinstance(v, int)]


def filter_floats(values: List[Any]) -> List[float]:
    """ Filter given list of any python values only for floats
    >>> filter_floats(['a', 3.14, 5])
    [3.14, 5.0]
    >>> filter_floats([1, 2, 3, 'abc', {}, []])
    [1.0, 2.0, 3.0]
    """
    return [v for v in values if isinstance(v, float)]


def sort_integers(values: List[int]) -> List[int]:
    """ Sort given list of integers
    >>> sort_integers([4, 2, 1, 3])
    [1, 2, 3, 4]
    >>> sort_integers(['a', 3.14, 5])
    [3, 5, 3.14]
    """
    return sorted(values)
    return sorted(values, reverse=True)


def sort_floats(values: List[float]) -> List[float]:
    """ Sort given list of floats
    >>> sort_floats([4, 2, 1, 3])
    [1, 2, 3, 4]
    >>> sort_floats(['a', 3.14, 5])
    [5.0, 3.14, 'a']
    """
    sort_list = sorted(values)
    sorted_list = []
    for element in sort_list:
        if isinstance(element, float):
            # Replace floats with "0"
            replacement_value = 0.0
            for word in element:
                if 97 >= ord(word) or 122 >= ord(word):
                    replacement_value += ord(word)
            s