

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    l2_sort = sorted(set(l2))
    combined = []
    for x in l1:
        if x in l2_sort and (len(combined) == 0 or x > combined[-1]):
            combined.append(x)
    return combined


def test_common():
    assert common([1, 4, 3, 34, 5, 653, 9, 23, 2], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert common([5, 3, 2, 8], [3, 2]) == [2, 3]


if __name__ == "__main__":
    print(common([1, 4, 3, 34, 5, 653, 9, 23, 2], [5, 7, 1, 5, 9, 653, 121]))
    test_common()