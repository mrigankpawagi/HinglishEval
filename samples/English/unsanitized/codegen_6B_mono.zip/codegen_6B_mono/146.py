
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    return sum(1 for n in nums if
        (n > 10) and (n // 10 % 10) == 1 and (n // 100 % 10)!= 1)


def gcd(a, b):
    """Return the greatest common divisor of a and b"""
    if not a and not b:
        return 1
    if not a or not b:
        return a or b
    a, b = max(a, b), min(a, b)
    return gcd(b, a % b)


def lcm(a, b):
    """Return the least common multiple of a and b"""
    return a // gcd(a, b) * b


def memoize(f):
    """Return a memoized version of f"""
    cache = {}

    def _f(*args):
        if args in cache:
            return cache[args]
        result = f(*args)
        cache[args] = result
        return result
    return _f


def fib(n):
    """Return the nth fibonacci number."""
    @memoize
    def _f(n):
        if n < 2:
            return n
        return _f(n - 2) + _f(n - 1)
    return _f(n)


def longestWord(words):
    """Given a dictionary of words, return the longest word and its length"""
    longest = None
    shortest = None
    for word in words:
        if longest is None or word > longest:
            longest = word
        if shortest is None or word < shortest:
            shortest = word
    return longest, shortest == longest


def wordReverser(words, _start=