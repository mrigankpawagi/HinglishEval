

def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    groups = [s[i:i + 3] for i in range(len(s)) if len(s[i:i+3]) == 3]
    return "".join([g[1] for g in groups])


# #############################################
# main
# #############################################

def main():
    """
    encodes input str using encode_cyclic(),
    decodes input str using decode_cyclic(),
    and reports whether encoding and decoding correctly use less space.
    """
    input_str = input("enter string: ")
    input_size = len(input_str)
    assert encoding_size(input_size) <= encoding_size(input_size, alternate=True)
    print(f"encoding_size: {encoding_size(input_size)}, decoding_size: {decoding_size(input_size)}")
    print(f"time to: encode {input_size} str: {timeit.timeit(lambda: encode_cyclic(input_str)) / 1000}")
    print(f"time to: decode {input_size} str: {timeit.timeit(lambda: decode_cyclic(encode_cyclic(input_str))) / 1000}")
    # return encode_cyclic(input_str), encode_cyclic(decode_cyclic(encode_cyclic(input_str)))


if __name__ == "__main__":
    main()