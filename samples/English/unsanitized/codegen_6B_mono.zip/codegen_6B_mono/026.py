from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    result: List[int] = []
    for i in numbers:
        if i not in result:
            result.append(i)
    return result


def remove_duplicates_followup(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all duplicates. In the case some duplicates exist,
    order of elements has to remain the same.
    >>> remove_duplicates_followup([1, 2,3, 2, 4])
    [1, 2, 3, 4]
    """
    result = []
    for i in numbers:
        if i not in result:
            result.append(i)
    return result


def replace_element_with_another_element(numbers: List[int], target: int, new_value: int) -> List[int]:
    """ In the list "numbers", replace the "target" element with the "new_value" element
    >>> replace_element_with_another_element([1, 4, 5], 1, 7)
    [1, 7, 4]
    >>> replace_element_with_another_element([7, 6, 5, 4, 5], 2, 4)
    [7, 6, 4, 3, 4]
    """
    if numbers[target] == target:
        for i in numbers:
            if numbers[target] == i:
                numbers[i] = new_value
    return numbers


def replace_elements_of_element(numbers: List[int], element: int, target_element: int, new_element: int) -> List[int]:
    return replace_element_with_another_element(numbers, element, new_element)


def checkio(*args) -> bool:
    numbers = list(args)
    numbers