
def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list 
    of length k with the maximum k numbers in arr.

    Example 1:

        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:

        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:

        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """
    heap = [None] * k
    arr = [(i, -value) for i, value in enumerate(arr)]
    idx = heapify(arr, 0, len(arr), heap)
    res = [-heap[0][1]]
    for i in range(k - 1):
        idx = heapify(arr, idx + 1, len(arr), heap)
        res.append(-heap[0][1])
    return res


def heapify(arr, start, end, heap):
    new_root = start
    parent = min_root = start / 2

    # while starting from root, 
    # move the smaller child up until new root has to be replaced
    while new_root!= -1:
        child = 2 * new_root + 1

        if child <= end - 1 and arr[child][1] < arr[child + 1][1]:
            child += 1
            if arr[child][1] < arr[parent][1]:
                parent = child
        if arr[new_root][1] < arr[parent][1]:
            heap[parent], heap[new_root] = arr[new_root], arr[parent]
            new_root = parent
        else:
            return new_root + 1


if __name__ == '__main