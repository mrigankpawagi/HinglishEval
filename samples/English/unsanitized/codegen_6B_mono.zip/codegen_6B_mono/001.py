from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    return [x.strip() for x in re.split(r'\s+', paren_string)]


import re

def build_balanced_paren_strings(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> build_balanced_paren_strings('( ) (( )) (( )( ))')
    ['', '(', ')', '', '(', ')', ')', '(', ')', '']
    """
    paren_groups = []
    current_group = []
    for char in paren_string.strip():
        if char == '(':  # add the open paren to the group
            current_group.append(char)
        elif char == ')':  # if we see a closing paren, we add the entire group to the list and clear it
            current_group = ''.join(current_group)
            print(current_group)
            paren_groups.append(''.join(current_group))
            current_group = []
        else:  # anything else we do nothing
            pass
    return paren_groups


def alternate_pairs(paren_string: str) -> List[str]:
    """ Input to this function is a string contains valid parens. Output should be 2 strings, the first
    containing all the balanced pairs between the '(' and ')' in the string, and the second containing the
    