
def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """
    a = [n, 0]
    b = [0, 1]
    c = [1, 1]
    result = []
    for i in range(2, n + 1):
        result.append(a[i - 1])
        temp = a[i - 2] + b[i - 1] + c[i - 1]
        a.append(temp)
        b.append(temp - a[i - 1])
        c.append(temp - c[i - 1])
    return result
    
def test_trib():
    assert trib(1) == [1]
    assert trib(2) == [1, 2]
    assert trib(3) == [1, 3, 2, 9]
    assert trib(3, 3) == [1, 3, 2, 8]
