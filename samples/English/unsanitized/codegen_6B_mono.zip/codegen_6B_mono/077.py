
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    return a**3==a
#def check_permutations(a, b, c):
#    '''
#    Write a function that takes 3 numbers a, b and c and checks if
#    they can be permutations of each other. Return True or False
#    depending on the result.
#    Examples:
#    check_permutations(1, 2, 3) ==> > False
#    check_permutations(1, 3, 2) ==>  True
#    check_permutations(2, 1, 3) ==> True
#    check_permutations(2, 3, 1) ==>  False
#    check_permutations(3, 1, 2) ==> True
#    check_permutations(3, 2, 1) ==>  False
#    '''
#    if a == b or a == c or b == c:
#        return False
#    else:
#        return True

def min_max(A, min_range, max_range):
    '''
    Write a function that takes a list of numbers and returns a list
    containing only numbers that are within a given range
    Example:
    min_max([2, 4, 5, 7], 1, 7) ==> [4, 5, 7]
    '''
    result = []
    for number in A:
        if min_range <= number <= max_range:
            result.append(number)
    return result

def min_max_sum(A, K):
    '''
    Write a function that takes a list of numbers and returns two 
    lists containing the indices of numbers that are within K, 
    and the remaining numbers
    Example:
