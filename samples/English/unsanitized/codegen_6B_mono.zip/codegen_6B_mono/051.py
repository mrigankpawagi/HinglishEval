

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    return ''.join(str(letter) for letter in text if letter not in 'aeiouAEIOU')

##########################################
## TESTING
##########################################

# Question 1:
def answer_for_examples():
    """
    This function is for when you are testing your own code that
    you don't know the answer (so you have to come up with it).
    It should print the value of the variable in the order of
    the examples given.
    >>> answer_for_examples()
    0
    >>> result = make_matrix(3, 5)
    >>> answer_for_examples()
    0
    >>> result = make_matrix(5, 3)
    >>> answer_for_examples()
    0
    >>> result = make_matrix(2, 2)
    >>> answer_for_examples()
    0
    """
    total_rows = 1
    while total_rows <= 2:
        total_cols = 1
        while total_cols <= 2:
            print(result[total_rows-1][total_cols-1])
            total_cols = total_cols + 1
        total_rows = total_rows + 1

if __name__ == '__main__':
    import doctest
    doctest.testmod()
