from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if len(paren_string) == 1:
        return []

    max_depth = depth = 0
    paren_stack = []

    for paren in paren_string:
        if paren == '(':
            depth += 1
            paren_stack.append(depth)
            if depth > max_depth:
                max_depth = depth
        elif paren == ')':
            depth -= 1
            if depth < -1:
                return []
            if depth == 0:
                paren_stack.pop()

    if depth!= 0:
        return []

    return paren_stack


test_nested_parens = """
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3] 
    """

test_parse_nested_parens_with_multiple_levels = """
    >>> parse_nested_parens('(()()) (()()) ((())) ((()()(())'
    [5, 5, 5, 3] 
    """

test_parse_nested_parens_long = """
    >>> parse_nested_parens('(()()) ((())) ((())()())'
    [5, 5, 5, 4]
    """
    

if __name__ == "__main__":
    import doctest

    doctest.testmod()
