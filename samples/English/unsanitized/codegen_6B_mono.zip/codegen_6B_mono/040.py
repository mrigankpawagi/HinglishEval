

def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    visited = set()
    for num1 in l:
        if num1 not in visited:
            for num2 in l:
                if num1 == num2 or num2 in visited:
                    continue
                elif -num1 == num2:
                    return True
                else:
                    visited.add(num2)
    return False


def longest_consecutive_run(l: list):
    """
    longest_consecutive_run takes a list of integers as an input. It
    returns the length of the longest consecutive run in the list.

    >>> longest_consecutive_run([1, 2, 3, 3, 4, 5])
    3
    >>> longest_consecutive_run([1, 2, 3, 4, 5])
    1
    >>> longest_consecutive_run([-10, -9, -8, -7, -6, -5])
    3
    >>> longest_consecutive_run([-10])
    1
    >>> longest_consecutive_run([1, 3, 2, 7, 4, -7])
    4
    """
    visited = set()
    length = 0
    for i in l:
        if i not in visited:
            curr = 0
            tmp = i - 1
            while tmp in visited:
                visited.add(tmp)
                curr += 1
                tmp -= 1