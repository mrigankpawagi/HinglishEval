
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # 1) Initialize the two pointers and the result array.
    minSubArraySum = -1
    left = 0
    right = len(nums) - 1
    sum = 0
    res = [sum]
    # 2) Traverse the array
    for i in range(right, left - 1, -1):
        sum += nums[i]
        cur_len = (right + 1) - i
        res.append(sum)
        minSubArraySum = min(minSubArraySum, res[cur_len])
    return minSubArraySum


assert minSubArraySum([2, 3, 4, 1, 2, 4, -10]) == 1
assert minSubArraySum([-1, -2, -3]) == -6
assert minSubArraySum([-1, -2, 3]) == 3
assert minSubArraySum([3, 2, 4]) == 1
assert minSubArraySum([3, 2, 4, 7]) == 3
assert minSubArraySum([3, 2]) == 2
assert minSubArraySum([1]) == 1
assert minSubArraySum([1, 2, 3]) == 6
assert minSubArraySum([-2, -1, -4, -0, -2, 1, 1]) == 1
