

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 +....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    assert isinstance(xs, list)
    assert len(xs) < MAX_COEF_COUNT, \
        'Polynomial has too many coefficients; Max count = {0}'.format(MAX_COEF_COUNT)
    result = []
    for i in range(0, len(xs)):
        if i == 0:
            result.append(1)
        result.append(xs[i])
        result.append(i)
    return result

def integrate(xs: list):
    """ xs = coefficients of the polynomial,
    xs[0] + xs[1] * x + xs[2] * x^2 +....
    xs should be in increasing order of the degree.
    Return the integral of the polynomial using simple integration,
    rounded to the nearest int, i.e., [1.0, 2.0].
    >>> integrate([3, 1, 2, 4, 5])
    [7.83333333333333, 10.0]
    >>> integrate([1, 2, 3, 4, 5, 6, 7, 8])
    [7.83333333333333, 10.0]
    """
    # Check for edge case of 0 degree polynomial with one coef
    if len(xs) == 1:
        return xs
    assert isinstance(xs, list), 'xs must be list'
    assert len(xs) <= MAX_COEF_COUNT, \
        'Polynomial has too many coefficients; Max count = {0}'.format(MAX_COEF_COUNT)
    return [round(sum(xs[:i]) + xs[i], 3) for i in range(0, len(xs) + 1)]