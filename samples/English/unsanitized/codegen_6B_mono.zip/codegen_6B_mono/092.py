
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
  

    
    '''
    return x == y + z or y == x + z or z == x + y
print(any_int(3, 2, 2))


def div_4(x):
    '''
    Some positive number is divisible by 4 if and only if the sum of its digits is a zero (the sum can be even).
    You are given an integer N. There are the floor N pairs of positive numbers.
    For each pair P[0], P[1] of this array, check if P[0] is divisible by 4.
    If either P[0] or P[1] is divisible by 4, print "YES", otherwise print "NO".

    >>>  div_4(4)
    YES
    no

    
    '''
    return "No" if sum([int(i) for i in str(divmod(x, 4)[1])]) > 0 else "yes"


def gcd(a, b):
    if b == 0:
        return a
    else:
        return gcd(b, a % b)


def two_arr(a, b):
    '''
    A number is called deficient if it is not the sum of two of its proper divisors.
    Deficient numbers can be classified according to the following rules:

        - If the number itself is deficient, it is called deficient.
        - If the number is not the sum of two its proper divisors, it is called improper.
        - If the number is not sum of two its proper divisors, it is called succesive.

    For example, according to