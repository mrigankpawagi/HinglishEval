
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb","cc"]) == ""aaaaaaa"
    """
    maximum = 0
    word = ''

    for x in words:
        if len(x) > maximum:
            maximum = len(x)
            word = x

    return word


def is_valid(s):
    """Write a function that accepts a string.
    If the string is valid, return True.
    If the string is invalid, return False.

    Examples: is_valid("abcd") == True
    is_valid("abcs") == False
    is_valid("dsdeea") == False
    is_valid("") == False
    is_valid("s") == False
    """
    regex = re.compile("[0-9]*$", re.IGNORECASE)

    if regex.search(s):
        return False

    return True


def count_digits_str(s):
    """Write a function that accepts a string.
    The string only contains decimal numbers.
    It's also guaranteed that the string does not contain any leading zeros.

    return the count of digits in the string
    Examples: count_digits_str("2345") == 4
    count_digits_str("123892223") == 4
    count_digits_str("000000013") == 3
    count_digits_str("0f2a") == 4
    count_digits_str("092") == 0

    """
    if not is_number(s):
        return -1

    if not is_valid(s):
        return -1

    return len(s) - s.count('0')


def is_number(s):
