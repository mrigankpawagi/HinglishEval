
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    conversion_table = ((1000,'m'), (900, 'CM'), (500, 'D'), (400, 'CD'), (100, 'C'),
                        (90, 'XC'), (50, 'L'), (40, 'XL'), (10, 'X'), (9, 'IX'),
                        (5, 'V'), (4, 'IV'), (1, 'I'))
    mini_roman = []
    for value, letter in conversion_table:
        quotient, reminder = divmod(number, value)
        mini_roman.append(letter * quotient)
        number -= (quotient * value)
        if reminder == 0:
            break
    return ''.join(mini_roman).lower()


def get_roman_numerals():
    """(7, 'LXL')
    Returns a dictionary in which keys are roman numerals and
    values are corresponding arabic number
    >>> get_roman_numerals() == {'l': 7, 'x': 60, 'v': 50, 'c': 100, 'd': 500,...}
    True
    """
    lookup_table = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    # return {letter: value for letter, value in get_arabic_numeral().items() if letter!= 'M'}
    return lookup_table


def is_int_roman(roman_numeral):
    """
    Given a string (in upper or lower case) representing a roman numerals,
    obtain the roman equivalent as an integer and return the value.
    Restrict