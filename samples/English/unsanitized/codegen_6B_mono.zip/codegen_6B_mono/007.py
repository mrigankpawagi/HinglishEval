from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    return [s for s in strings if substring in s]


def longest_common_substring(input1: str, input2: str) -> str:
    """ Find the longest common substring between two given strings.
    >>> longest_common_substring('abcdef', 'zabcdef')
    'abcdef'
    >>> longest_common_substring('abcd', 'abc')
    'abc'
    """
    n = len(input1)
    m = len(input2)
    l = [[0] * (m + 1) for i in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if input1[i - 1] == input2[j - 1]:
                l[i][j] = l[i - 1][j - 1] + 1
            else:
                l[i][j] = 0

    return _find_max(l)
    pass


def _find_max(l: List[List[int]]) -> str:
    # for finding all maxs
    maxs = []
    for i in l:
        maxs += i

    max_item_count = max(maxs)

    i = max_item_count
    substring = []
    while i < len(l):
        row = l[i]
        item_count = max(row)
        if item_count == max_item_count:
            j = row.index(item_count)
            substring.append((i - 1, j - 1))
        i += 1

    common_substring = ''

    for i, j in substring:
        common_substring