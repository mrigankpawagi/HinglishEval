

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n < 3:
        return 1 if n == 1 else 0
    else:
        return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)


def pascal_triangle(n: int):
    """Generate a list of lists of integers representing the nth row of Pascal's triangle. If n is 0 or 1, 
    then return the empty list. Otherwise return the triangle with exactly n+1 rows.
    
    The 0-indexed nth row of the Pascal Triangle is:
     [1 if n = 0, 1 if n = 1 else n * (n-1) / 2]
     
    >>> pascal_triangle(0)
    []
    >>> pascal_triangle(1)
    [[1]]
    >>> pascal_triangle(3)
    [[1], [1, 1], [1, 2, 1]]
    """
    # Write this with a recursive function
    return pascal_triangle_helper(n, 0, 1)
    
    
def pascal_triangle_helper(n: int, first: int, last: int):
    if n == 0 or n == 1:
        return [1 if n == 0 else [] for i in range(first, last + 1)]
    else:
        return pascal_triangle_helper(n - 1, first + 1, last) + [sum(x) for x in zip_longest(