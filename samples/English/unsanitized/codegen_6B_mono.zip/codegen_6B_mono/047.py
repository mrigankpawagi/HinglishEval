

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    l2 = len(l)
    if l2 <= 2:
        if not l:
            return None
        else:
            return sum(sorted(l)) / l2
    else:
        l1 = l2 // 2
        if l2 % 2 == 0:  # even
            l2_1 = (l[l1] + l[l1 + 1])
            l_ = l2_1
        else:  # odd
            l2_1 = l[l1]
            l2_2 = l[l1 + 1]
            l_ = l2_1 if l1_2 <= l2_2 else l2_2
    return l_

def mean(l: list):
    """Return the mean of the elements in l.
    >>> mean([1, 5, 6, 6, 9])
    6.0
    >>> mean([0, 0, 1, 2, 3])
    1.0
    >>> mean([])
    """
    l_sum = 0
    for i_elem in l:
        l_sum += i_elem
    return l_sum / len(l)


def main():
    for n in range(5):
        print(mean([2 * (random.randint(1, 3) * 1000) + 1000]))
    print(mean([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))

    def test_median():
        eq_(median([1, 2, 3, 4]), 2.5)
        eq_(median([1, 2, 3, 4, 5, 6, 7, 8, 9]), 4.5)
        eq_(median([3, 1, 2, 4, 5]), 3.5)
    test_median()

    listx = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
