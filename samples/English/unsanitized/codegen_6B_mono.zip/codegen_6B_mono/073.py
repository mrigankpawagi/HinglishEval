
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    diff = float('inf')
    memo = {}
    return smallest_change_recursive(diff, arr, memo)

def smallest_change_recursive(diff, arr, memo):
    if len(arr) <= 2:
        return diff

    n = len(arr)
    if n in memo:
        return memo[n]
    if is_palindromic(arr):
        memo[n] = 0
        return memo[n]

    if not is_increasing(arr):
        diff += 1

    smallest_change_recursive(diff, arr[:len(arr) - 1], memo)
    smallest_change_recursive(diff, arr[1:], memo)


def is_increasing(arr):
    return all(x < y for x, y in zip(arr, arr[1:])) or all(x > y for x, y in zip(arr, arr[1:]))

def is_palindromic(arr):
    return all(x == y for x, y in zip(arr, arr[::-1]))

if __name__ == '__main__':
    test_cases = [[1,2,3,5,4,7,9,6], [1, 2, 3, 2, 1], [], [3,3], [1,1,1], [0,1,2,5,6,10,15,23,31,24,17,7], [7,2,3,6,5,4,3,2,1,0,