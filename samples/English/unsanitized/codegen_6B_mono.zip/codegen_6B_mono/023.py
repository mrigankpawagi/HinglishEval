

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)

def concat(string1: str, string2: str) -> str:
    """ Return concatenated string
    >>> concat(10, 45)
    4510
    >>> concat('Hello', 'world!')
    'HelloWorld'
    """
    return string1 + string2

class String:
    def __init__(self, string):
        self.string = string

    def splice(self, i: int, j: int) -> str:
        """ Return string splice of string
        >>> s = String('xyz')
        >>> assert s.splice(0, 3).string == 'xyz'
        >>> assert s.splice(2, 1).string == 'z'
        >>> assert s.splice(0, 0).string == ''
        """
        s = self.string[i:j]
        if s == '':
            return ''
        return s

    def get(self, i: int) -> str:
        """ Return i-th character of string
        >>> s = String('xyz')
        >>> assert s.get(0).string == 'x'
        >>> assert s.get(1).string == 'y'
        >>> assert s.get(2).string == 'z'
        """
        return self.string[i]

    def reverse(self) -> str:
        """ Return reversed string
        >>> s = String('xyz')
        >>> assert s.reverse().string == 'zxy'
        """
        return self.string[::-1]

    def substr(self, start: int, end: int) -> str:
        """ Return substring starting with start and ending with end
        >>> s = String('xyz')
        >>> assert s.substr(0, 2).string == 'xy'
        >>> assert s.substr(-3, -2).string == 'z'
        >>> assert s.substr(0, 0) == ''
        """
        return self