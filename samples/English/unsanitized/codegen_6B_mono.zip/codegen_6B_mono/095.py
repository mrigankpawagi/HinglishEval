
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    newdict = {}.fromkeys({x for x in dict.keys() if type(x)!= str},dict)
    for i in newdict.keys():
        if i.isupper():
            return False
        else:
            continue
    return True

## 7. Fraction Addition ##

# Write a Function called fraction_add that accepts two tuples as parameters
# The first parameter should be a tuple of numbers in the numerator and denominator
# The second parameter should be another tuple of numbers in the numerator and denominator
# The function returns a tuple with the first three members in the first tuple added together, 
# and the fraction added together. The results (with the fraction added together) 
# are returned in the second tuple. 
# Example: fraction_add((1,2),(4,5)) should return (3,1)
def fraction_add(f1,f2):
    l3 = f1[1] + f2[1]
    l4 = f2[0] * f1[0] + f1[0] * f2[1]
    t1 = f1[0] * l3 / l4
    t2 = f1[1] * l3 % l4
    return ((t1,t2),l3)

## 8. Sum of Digits ##

# The