
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    pass

def vowel_upper(s):
    """
    Given a string s, return the character in s at its even index that is uppercase. If there is no even index, 
    return False.
    
    For example:
    vowel_upper('aBCDdEf') returns 'c'
    vowel_upper('abcdefg') returns False
    vowel_upper('dBBE') returns 'E'
    vowel_upper('H') returns 'H'
    vowel_upper('HV') returns 'V'
    vowel_upper('B') returns 'B'
    """
    pass

def f(x):
    """
    Given an int x, return True if x is even and False if not, without using if statements or loops.
    
    For example:
    f(1) should return True
    f(3) should return False
    f(4) should return True
    """
    pass

def even_list(l):
    """
    Given a list l, return a list that contains all the even integers in l.
    
    For example:
    even_list(range(1,8)) should return ['2', '4']
    even_list(range(2,8)) should return ['2', '4', '6', '8']
    even_list([]) should return []
    even_list([1,2,3,4,5]) should return []
    even_list([1,2,3,4,5,6,7]) should return ['2', '4', '6']
    even_list([1,2,3,4,5,1,2,3,5,12]) should return ['2']
    """
    pass

def odds_and_evens(l):
    """
    Given a list l, return two