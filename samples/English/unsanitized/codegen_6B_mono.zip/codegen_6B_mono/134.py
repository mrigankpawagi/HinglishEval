
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''
    # your code here
    if txt == '':
        return False

    if len(txt) <= 1:
        return False
    if txt[-1] in 'qwertyuopasdfghjklzxcvbnm':
        return True

    if txt[-1].isalpha():
        return False

    i = len(txt) - 1
    n = len(txt)

    while i >= 0:
        if txt[i].isalpha():
            return False
        i -= 1

    return True


# Question 2

from numpy import linspace
# Your are given a list which contains two items.

# Your task is to return the intersection point between the two lines
# represented by the lists.
# The intersection point is an ordered pair, and the format
# for the return value should be as in the example bellow:


def intersection_point(l1, l2):
    x1, y1 = l1
    x2, y2 = l2
    x3, y3 = max(x1, x2), max(y1, y2)
    x4, y4 = min(x1, x2), min(y1, y2)
    if x3!= x4 or y3!= y4:
        return None
    elif x3 == x1 == x2:
        return [x3, y2]
    elif y3 ==