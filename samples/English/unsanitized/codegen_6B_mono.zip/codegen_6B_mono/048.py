

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if len(text) < 2:
        return True
    return text[0] == text[-1] and is_palindrome(text[1:-1])

def is_perfect_palindrome(text: str):
    """
    Checks if given string is a perfect palindrome
    >>> is_perfect_palindrome('')
    True
    >>> is_perfect_palindrome('aba')
    True
    >>> is_perfect_palindrome('aaaaa')
    True
    >>> is_perfect_palindrome('za')
    False
    """
    if len(text) < 2:
        return True
    if len(text) == 2 and text[0] == text[-1]:
        return True
    return is_palindrome(text[:-1]) and text[0] == text[-1]

if __name__ == '__main__':
    from doctest import testmod
    testmod()