

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    area = (a**2) * (h/3)
    return area

def check_triangle(a, b, c):
    """Given the lengths of three sides of a triangle return if it is
    a valid triangle with the hypotenuse < b.
    """
    if a*a + b*b == c*c:
        if c < b:
            print "\nIt is an equilateral triangle with a = {0}".format(a)
        else:
            print "\nIt is a valid triangle with side lengths {0}, {1}, {2}".format(a, b, c)
    else:
        print "\nIt is no valid triangle with side lengths {0}, {1}, {2}".format(a, b, c)

def hypotenuse(a, b):
    """Given the lengths of both sides of a right triangle calculate the
    hypotenuse side length.
    >>> hypotenuse(3, 4)
    5.0
    """
    hypotenuse = (a**2 + b**2)**.5
    return hypotenuse

def test_dice():
    """
    >>> roll_dice()
    5
    6
    >>> result = roll_dice()*100
    >>> result
    201
    """
    print result
    return result

import doctest
if __name__ == "__main__":
    print test_dice()
