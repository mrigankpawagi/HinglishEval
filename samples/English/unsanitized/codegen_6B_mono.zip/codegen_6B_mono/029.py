from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    return [string for string in strings if string[:len(prefix)] == prefix]

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", "--source", default="data/output.txt", help="Path to file containing original text")
    parser.add_argument("-a", "--annotated", default="data/annotated.txt", help="Path to file containing annotated text")
    parser.add_argument("-o", "--output", default="data/output.txt", help="Path to file to output the filtered output")
    return parser.parse_args()

def main() -> None:
    # Retrieve options
    options = parse_args()

    # Read in the annotated and output
    with open(options.source, 'r') as f:
        original_lines = f.readlines()
    with open(options.annotated, 'r') as f:
        annotated_lines = f.readlines()

    # Check if we're actually getting some results
    if not len(original_lines) == len(annotated_lines):
        sys.exit("Something went wrong")

    # Filter the annotations
    filtered_lines = []
    for annotated_line, original_line in zip(annotated_lines, original_lines):
        if len(annotated_line.strip()) > 0:
            try:
                index = int(annotated_line.strip().split()[0])
            except ValueError:
                index = ""
            filtered_lines.append(original_line)

    # Rewrite annotated and output
    with open(options.output, 'w') as f:
        f.writelines(filtered