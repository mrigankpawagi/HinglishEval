from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None

    return max(strings, key=len)


__test__ = {
    "longest test": """
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
}


def longest_2nd(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return the second one in case of multiple strings of same length.
    Return the second if there are multiple second longest strings of same length
    >>> longest_2nd(['a', 'bb', 'cc'])
    'bb'
    >>> longest_2nd(['e', 'bb', 'cc', 'a', 'b', 'bb'])
    'bb'
    >>> longest_2nd(['bb', 'bb', 'cc'])
    'bb'
    >>> longest_2nd(['a', 'bb', 'cc'])
    'bb'
    >>> longest_2nd(['a', 'aa', 'cc', 'bb'])

    >>> longest_2nd(['a', 'bb', 'cddd', 'ccd', 'bb'])
    'bb'

    >>> longest_2nd([])
    """
    if not strings:
        return None
    longest_ = longest(strings)
    if longest_ in strings:
        return longest_

    same_length = sorted(strings, key=len)

    len_longest = len(longest_)
    len_2nd_longest = len(same_length[len_longest])

    if len_longest == len_2nd