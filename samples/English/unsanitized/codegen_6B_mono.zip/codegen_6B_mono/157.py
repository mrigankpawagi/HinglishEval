
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    s = (a+b+c)/2
    return(s*(s-a)*(s-b)*(s-c) <= 0)


def right_angle_triangles():
    '''
    The triplet of abc for which 1 -ac < abc < c < a < sqrt(abc), is a right 
    triangle which makes the statement that the sum of the lengths of any two sides
    must be strictly less than the length of the third side - the Pythagorean 
    theorem of Pythagorean triples; that is, it is a simple right triangle. The 
    sum of the lengths of two sides of any of these 3-lengths-simple right triangles
    will always be less than the sum of the lengths of the third and fourth sides,
    and since the third side is the hypotenuse of the right triangle, the length of 
    the third side must be less than the square of the length of a side (the 
    Pythagorean theorem dictates that the hypotenuse is the product of the two shorter 
    sides and the sum of the two longer sides is less than the sum of the lengths 
    of the hypotenuse and longer side).
    Return the sum of the lengths of all the right triangles with perimeter 
    greater than 1000 in ascending order of perimeter.

    Solution:
    Perimeter P can be described by 2 (P - 4) / 3, 2P, or 3P.
    P can be described by 2(P - a) + 2b if P is 2((P - a) + b), or else as P - a.
    P - a can be factored into 2P, 2(P - a), or 2P - a, depending on the quad