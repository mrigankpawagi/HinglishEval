
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    total = 1
    while n:
        d = n % 10
        if d % 2:
            total *= d
        n //= 10
    return total

#######################
#    MISCELLANEOUS    #
#######################


def find_prime_factors(n):
    """Divide n by all prime factors.
    Return a set of these prime factors and a set of remainders.
    For example:
    find_prime_factors(20) == ({2, 5}, {10})
    """
    # Set up variables
    res = set()
    factor = 2
    res_of_remainders = set()
    n_2 = n

    # Process while n is not divisible by 2:
    while factor * factor <= n_2:
        while n_2 & factor == 0:
            res.add(factor)
            n_2 = n_2 // factor

        factor += 1
    # If 'n' is not divisible by 2, we may have non-prime factors
    if n_2 > 1:
        res.add(n_2)
        n_2 - n_2 & (-n_2)
        res_of_remainders.add(n_2)

    return res, res_of_remainders


def compute_totient(n_set):
    tot = 1
    for n in n_set:
        tot *= (n - 1)
    return tot


def compute_permutations(n):
    if n == 0:
        return set()
    elif n == 1:
        return {1}

    perms = set()
    for x in range(1, n + 1):
        perms.add(x)
        perms.update(compute_permutations(n - 1))
        perms.remove(x