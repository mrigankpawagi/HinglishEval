
def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    return (x if is_prime(n) else y)
 
print 'x_or_y(7, 34, 12) == 34:', x_or_y(7, 34, 12)==34
print 'x_or_y(15, 8, 5) == 5:', x_or_y(15, 8, 5)==5


def sum_digits(n):
    """A simple program which should return the sum of the digits of n

    For example:
    
    sum_digits(10) - > 1
    sum_digits(56)  - > 6
    sum_digits(12345) - > 45

    """
    return (sum(int(digit) for digit in str(n)))
 
print'sum_digits(10) - > 1:', sum_digits(10)==1
print'sum_digits(56)  - > 6:', sum_digits(56)==6
print'sum_digits(12345) - > 45:', sum_digits(12345)==45


def is_palindromic(n):
    """A simple program which should return true if n is a palindrome
    and return false otherwise

    For example:
    
    is_palindromic(12345) - > True
    is_palindromic(99999) - > True
    is_palindromic(1234) - > False

    """
    return (n == int(str(n)[::-1]))
 
print 'is_palindromic(12345) - > True:', is_palindromic(12345)==True
print 'is_palindromic(99999) - > True:', is_palindromic(99999)==True
print 'is