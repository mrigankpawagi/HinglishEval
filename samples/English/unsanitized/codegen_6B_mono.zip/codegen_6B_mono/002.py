

def truncate_number(number: float) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (largest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return the decimal part of the number.
    >>> truncate_number(3.5)
    0.5
    """
    return math.floor(number)

def truncate_number_to_n(number, n: int) -> float:
    """ Given a positive floating point number, it can be decomposed into
    and integer part (highest integer smaller than given number) and decimals
    (leftover part always smaller than 1).

    Return truncated number such that the integer part is at least n digits.
    >>> truncate_number_to_n(3.5, 3)
    3.0
    """
    return truncate_number(number) + 0.5 - n

if __name__ == "__main__":
    import doctest
    doctest.testmod()