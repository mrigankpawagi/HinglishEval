

def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    return "".join([chr(((ord(ch) - ord("a")) % 26) + ord("a")) for ch in s])

def ceasar_encode_plain(s: str):
    """
    encodes plain text based on shift of every letter in the alphabet by 5 and returns the result.
    """
    return encode_shift(s)


def ceasar_decode_plain(s: str):
    """
    decodes encoded string based on shift of every letter in the alphabet by 5 and returns the result.
    """
    return decode_shift(s)


def test_ceasar_shifes():
    encoded_s = ceasar_encode_plain("hello")
    assert encoded_s == "mjqqt"

    decoded_s = ceasar_decode_plain(encoded_s)
    assert decoded_s == "hello"


if __name__ == '__main__':
    assert abs(
        ceasar_decode_plain(ceasar_encode_plain("hello"))
        - "hello") < 0.00001

    test_ceasar_shifes()
