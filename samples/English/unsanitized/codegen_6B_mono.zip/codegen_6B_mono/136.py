
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''
    if max(filter(lambda x: x < 0, lst)) is None:
        pos = max(filter(lambda x: x > 0, lst))
        neg = None
    else:
        neg = max(filter(lambda x: x < 0, lst))
        pos = min(filter(lambda x: x > 0, lst))
    return (pos, neg)


def sum_of_squares(n):
    '''
    Create a function that takes in a number n.  Compute the sum of
    all the elements of the series of squares starting with the first
    number, then the second number, and thus on, and ending with n^2.
    So, for example, sum_of_squares(10) would return the sum of
    8, 9,..., 49 (each individual number squared).  Also, sum_of_squares(n)
    would return zero if less than n (the base case) or if not possible.

    Examples:
    sum_of_squares(-3) == None
    sum_of_squares(0) == 0
    sum_of_squares(1) == 1
    sum_of_squares(100) == 1852
    '''
    assert 0 <= n


def primes(n):
    pass
