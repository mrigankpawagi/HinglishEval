

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    res = ""
    n = x
    while n > 0:
        resta = n % base
        if resta < 10:
            res += str(resta)
        else:
            res += chr(ord('A') + resta - 10)
        n = n // base
    return res[::-1]


def decode(code: str, key: str):
    """Replace each number with character according to key.
    >>> decode("11A2", "MARK")
    'MARK'
    """
    chars = []
    for c in code:
        if c in key:
            chars.append(key[key.index(c)])
        else:
            chars.append(c)
    return ''.join(chars)


def is_equal(a: int, b: int):
    """Return true if the given integers are equal, false otherwise.
    >>> is_equal(11, 11)
    True
    """
    return (a // 10 == b // 10) or (a % 10 == b % 10)


def is_greater(a: int, b: int):
    """Return true if a is greater than b, return false otherwise.
    >>> is_greater(2, 3)
    False
    """
    return a // 10 < b // 10 or (a % 10 > b % 10)


def generate_key(x: int, y: int, base: int):
    """Generate a random key.
    x,y - positions to be filled by key
    base - base of key
    return key as string if key have not already been used,
    'Key is used' otherwise.
    >>> key = generate_key(2, 3, 7)
    """
    