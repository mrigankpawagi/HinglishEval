
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    return sum(map(lambda x: ord(x)] if x.isupper() else 0, s))

def palindromeTester(test):
    """ Takes test string and returns True if test is a palindrome. test is a non-decreasing character
    list."""
    for i in range(len(test)//2):
        if test[i]!= test[len(test)-1-i]:
            return False
    return True

def minWordLength(testString):
    """Return the length of the shortest word in testString that is a palindrome.  testString is a string. """
    return min(map(lambda x: len(x), filter(lambda y: palindromeTester(y), testString.split())))

def myStrings(testString):
    """Takes a string containing letters and returns a string that contains only the letters and spaces.
    testString is a string. """
    return ''.join(filter(lambda e: e.isalpha() or e =='', testString))

def isBalanced(s):
    """ Returns True if s is balanced, False otherwise. s is a non-empty string. """
    return sum(map(lambda x: 1 if x == '(' else -1 if x ==')' else 0, s)) == 0

