
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    levels = [n]
    while len(levels) < 2 * n + 2:
        if len(levels) % 2 == 1:
            number_of_stones = len(levels)
        else:
            number_of_stones = len(levels) // 2
        levels += [number_of_stones]

    return levels


def build_a_stack(n):
    """
    You have to build a stack for an array with distinct elements.
    The length of the array will be between (inclusive) 1 and 100
    The elements of the array will be distinct
    The array is random.
    For index i, it will contain array[i] or (array[i] + 2 * i).
    We want to create a stack as a heap.

    There, is a root.
    Then, we insert all the second, third, etc. elemets
    The elements which are not inserted are put at the end of the stack.
    Note that they are still in the order they were inserted.
    It is not necessary to heapify all the elements.
    You can implement any heapify algorithm to complete

    Examples:
    >>> import random
    >>> length = random.randint(1, 100)
    >>> array = list(range(length))
    >>> array = random.sample(array, length)
    >>> stack = build_a_stack(array)
    >>> for i in range(len(array[1:])):
   ...     elem = array[i]
   ...     if elem > stack[0]:
   ...      stack = (stack[0], elem)
