
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    n = len(string)
    if n % 2 == 0 and n > 1:
        return False
    return True


def has_vowels(string):
    """Write a function that returns True if the given string contains a
    vowel and False otherwise
    Examples
    has_vowels('Hello') == True
    has_vowels('Cantaloupe') == False
    """
    return re.search('[aeiou]', string, re.IGNORECASE)


def get_longest_subseq(string):
    """Write a function that returns the sub-string with the longest repeating
    sequence of non-overlapping characters in the given string
    Examples
    get_longest_subseq('aabcdabcaa') == 'abcd'
    get_longest_subseq('asdfjhdskfjdskf') == 'asdfj'
    get_longest_subseq('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb') == 'bbbb'
    get_longest_subseq('aaabbbcdabcdddeee') == 'ee'
    get_longest_subseq('jkjsjfjjfkkjfjkjjfkjjfkd') == 'jk'
    get_longest_subseq('aaaaaaaaaaaa') == 'a'
    """
    max_len = 0
    max_substring = ''
    for i in range(0, len(string)):
        tmp_substring = ''
        for j in range(i+1, len(string)+1):
            tmp_substring = string[i:j]
            if tmp_substring not in string[i+1:]:
                if len(tmp_substring) > max_len:
                    max