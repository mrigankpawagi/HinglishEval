from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    unit = max(numbers) - min(numbers)
    if unit == 0:
        unit = 1
    result = [(n - min(numbers)) / unit for n in numbers]
    return result


if __name__ == '__main__':
    import doctest

    doctest.testmod()

    with open('input_01.txt', 'r') as data:
        print('data = %s' % data.read())

    print('Part 1:')
    data = [int(x) for x in data.read().split(',') if x]
    data[1] = 12
    data[2] = 2
    print(data)
    for noun in range(100):
        for verb in range(100):
            if output == 19690720:
                print('noun = %s, verb = %s, output = %s -> %s' % (noun, verb,
                                                                    noun * 100 + verb,
                                                                    100 * noun + verb))
                break
