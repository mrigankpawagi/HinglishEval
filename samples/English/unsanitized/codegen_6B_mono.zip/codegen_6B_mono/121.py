
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """
    sum = sum1 = 0
    for i in range(0, len(lst), 2):
        sum1 += lst[i]
    return sum1



import unittest


class TestSolution(unittest.TestCase):
    def test_function(self):
        self.assertEqual(
            solution([5, 8, 7, 1]),
            12)
        self.assertEqual(
            solution([3, 3, 3, 3, 3]),
            9)
        self.assertEqual(
            solution([30, 13, 24, 321]),
            0)
        self.assertEqual(
            solution([1, 0, 15, 3]),
            14)
        self.assertEqual(
            solution([-1, 1, 3, 3, 5]),
            0)
        self.assertEqual(
            solution([0, 0, 0, 0, 0]),
            0)
        self.assertEqual(
            solution([-1, -1, -1, -1, -1]),
            0)


if __name__ == "__main__":
    unittest.main()
