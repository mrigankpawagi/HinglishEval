

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    l = l[::-1]
    l1 = []
    x = True
    for i in range(len(l)):
        if x:
            l1.append(l[i])
            x = False
        else:
            l1.append(l[i])
            x = True
    return l1[::-1]

def sort_first_letter(l: list):
    """Given a list of strings l, returns l with the strings sorted by first letter,
    so the strings with the equivalent first letter are next to each other in the resulting list.
    >>> l = ['Aaa', 'bbb', 'Aaba', 'BBa', 'aaa', 'AAA', 'bb']
    >>> sort_first_letter(l)
    ['aaa', 'baa', 'bbb', 'bba', 'bb', 'aaa', 'Aaba', 'AA']
    """
    sorted_l = []
    for word in l:
        if word[0] not in sorted_l:
            sorted_l.append(word[0])
    sorted_l = sorted(sorted_l)
    l1 = []
    index = 0
    for letter in sorted_l:
        for word in l:
            if word[0] == letter:
                l1.append(word)
                index += 1
    x = 0
    for word in l:
        if word[0] == sorted_l[index]:
            l1.insert(index+x, word)
            x += 1
    return l1  
                    
#print(sort_first_letter(['Aaa', 'bbb', 'Aaba', 'BB