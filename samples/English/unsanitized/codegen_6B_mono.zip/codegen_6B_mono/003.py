from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    balance = 0
    for op in operations:
        balance += op
        if balance < 0:
            return True
    return False


def is_balanced(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account is not balanced and
    return True. Otherwise it should return False.

    >>> balance = [1, 3, 4, 3, 2] # balance = 4 - 1 + 3 - 5 = 2
    >>> is_balanced(balance)
    False
    >>> balance = [4, 3, 2] # balance = 3 - 4 = -3
    >>> is_balanced(balance)
    False
    >>> balance = [4, 3, 2, 1, 4, 2] # balance = 3 - 4 = -3
    >>> is_balanced(balance)
    True
    """
    balance = 0
    for op in operations:
        balance += op
        if balance is not abs(balance):
            return False
    return True


def reverse_nodes(root: List[int]) -> List[int]:
    """ Given a binary tree, reverse the entries of the nodes in its left and right subtrees and return them.

    >>> root = [4, 8, 2, [3, 5, 10], [7, 12, 18], [], [9], [6, -15, 24], []]
    >>> [8, 4, 10, 13, -5, 15, 24, 17, 6]
    reverse_nodes(root)
    """
    if root:
        root.reverse()
        reverse_nodes(root[