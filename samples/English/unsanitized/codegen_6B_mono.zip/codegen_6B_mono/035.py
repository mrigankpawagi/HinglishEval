

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    return max(l)


def max_element_with_index(l: list):
    """Return maximum element in the list along with its index.
    >>> max_element_with_index([1, 2, 3])
    (3, 2)
    >>> max_element_with_index([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    (123, 6)
    """
    m = max(l)
    return m, l.index(m)


def max_element_occurrences(l: list):
    """Return number of occurances of max element in the list
    >>> max_element_occurrences([1, 2, 1, 2, 3, 3, 3, 4, 4, 4])
    3
    """
    return l.count(max_element(l))


def is_evenly_divisible(n: int, d: int):
    return n % d == 0


def n_perfectly_divisible(n: int, d: int):
    """Return number of perfectly divisible n by d.
    >>> n_perfectly_divisible(9, 3)
    2
    >>> n_perfectly_divisible(10, 3)
    0
    """
    return sum(is_evenly_divisible(n, d) for d in range(1, d+1))

def divisors_sums_to_a(n: int, a: int):
    """Return boolean - is sum of divisors of n even equals to a?
    >>> divisors_sums_to_a(10, 3)
    False
    >>> divisors_sums_to_a(10, 7)
    True
    """
    divisors =  divisors(n)
    return sum(divis