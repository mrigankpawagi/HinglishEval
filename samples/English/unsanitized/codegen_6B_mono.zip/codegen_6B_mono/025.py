from typing import List


def factorize(n: int) -> List[int]:
    """ Return list of prime factors of given integer in the order from smallest to largest.
    Each of the factors should be listed number of times corresponding to how many times it appeares in factorization.
    Input number should be equal to the product of all factors
    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    result_list = []
    possible_divisor = 3
    possible_divisor_count = 0
    while n > 2:
        if n % possible_divisor == 0:
            possible_divisor_count += 1
            result_list.append(possible_divisor)
            n /= possible_divisor
        else:
            possible_divisor += 2
    if possible_divisor_count > 0:
        result_list.append(possible_divisor)
    return result_list


def factorial(n: int) -> int:
    """ n! = n * (n-1)! for n > 1 """
    result = 1
    for i in range(2, n+1):
        result *= i
    return result


def fibonacci(start: int, end: int) -> List[int]:
    """ First n fibonacci numbers for the sequence
    for end > start, return list with a single number - same to end.
    for end = start, get zero.
    for end < start, return list of fibonacci numbers:
        1, 1, 2, 3, 5, 8, 13, 21...
    """
    if start > end:
        return [0]
    if start == end:
        return [1]
    if start < end:
        return [1, 1] + fibonacci(start + 1, end)


def fibonacci_last_digits(n: int) -> int:
    """Last Digits of Fibonacci Sequence
    The Fibonacci sequence is a sequence that starts with the