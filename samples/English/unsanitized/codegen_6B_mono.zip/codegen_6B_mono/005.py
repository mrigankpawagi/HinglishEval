from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    numbers = numbers[:]
    if not numbers:
        return []
    return number_separator(numbers, delimeter)


def number_separator(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        raise ValueError('empty input')
    numbers = numbers[:]
    if not all([isinstance(x, int) for x in numbers]):
        raise ValueError("not all elements are integers")
    if delimeter < 1:
        raise ValueError("delimeter must be >= 1")
    if delimeter > len(numbers):
        raise ValueError("delimeter too big")
    if len(numbers) > 1:
        if not all([x <= y for x, y in zip(numbers, numbers[1:])]):
            raise ValueError("some numbers not increasing by 1")

    result = [numbers[0]]
    pos = 0
    for i in range(1, len(numbers)):
        if numbers[i] - 1 == numbers[i - 1]:
            pos += 1
        else:
            pos = 0
        if pos == delimeter:
            result.append(numbers[i])

    result.extend(
        intersperse(
            numbers[-delimeter:], delimeter
        )
    )
    return result


def inplace_number_separator(*args, **kargs):
    ''' Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    'inplace=true' in arg must be passed
    '''
    _delimeter = int(kargs.get('delimeter', 1))

    def _interleave(numbers, inplace):
        numbers = numbers[:]
        for i in