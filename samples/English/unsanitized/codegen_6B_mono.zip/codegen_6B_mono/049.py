

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    return (n % p + p) % p


def gcd(a, b):
    """Return the greatest common divisor of two numbers.
    >>> gcd(3, 18)
    3
    >>> gcd(54, 24)
    12
    >>> gcd(42, 180)
    42
    >>> gcd(36, 8)
    8
    """
    return abs(a - b) if abs(a - b) > 0 else abs(a)


def lcm(a, b):
    """
    Return Least common multiple
    >>> lcm(12, 56)
    504
    >>> lcm(8, 4)
    4
    """
    return abs(a * b) // gcd(a, b)


def divisors(n):
    """
    >>> divisors(-1)
    Traceback (most recent call last):
    ValueError: Cannot compute divisors for negative number: -1
    >>> divisors(0)
    Traceback (most recent call last):
    ValueError: Cannot compute divisors for zero: 0
    >>> divisors(1)
    Traceback (most recent call last):
    ValueError: Cannot compute divisors for one: 1
    >>> divisors(7)
    Traceback (most recent call last):
    ValueError: Cannot compute divisors for seven: 7
    >>> divisors(12)
    [1, 2, 3, 4, 6, 12]
    """
    if n == 0: raise ValueError("Cannot compute divisors for zero: 0")
    if n == 1: return [1]
    n_list = [i for i in range(1, n // 2 + 1) if