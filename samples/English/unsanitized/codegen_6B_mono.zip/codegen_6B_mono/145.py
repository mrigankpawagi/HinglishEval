
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    return sorted(nums, key=lambda x: x if sum([int(i) for i in str(x)]) > 0 else -x)

assert count_matching_numbers([]) == 0
assert count_matching_numbers([1, 2, 1]) == 1
assert count_matching_numbers([1, 2, 2]) == 2
assert count_matching_numbers([1, 2, 3]) == 0
assert count_matching_numbers([-1, -1, -1, 0]) == 4
assert count_matching_numbers([-1, 1, 0, -1]) == 0

assert order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
assert order_by_points([]) == []
assert order_by_points([2, 2, 8]) == [2, 2, 8]
assert order_by_points([-3, 0, 3, -1]) == [-3, 0, 3, -1]
assert order_by_points([5, -8, 9, -11, -13, 12, -4]) == [-11, -13, -4, 5, 9, -8, 12]
assert order_by_points([1, -2, 1, 2, 1, 0]) == [-2, 1, 1, 1, 0, 1]
assert order_by_points([-3]) == [-3, 0, 3]
