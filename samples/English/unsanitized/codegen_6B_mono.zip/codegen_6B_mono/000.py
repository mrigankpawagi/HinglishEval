from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    for number in numbers:
        for next_number in numbers:
            if next_number!= number and number + threshold > next_number > number - threshold:
                return True
    return False


def has_many_almost_equal(numbers: List[float], threshold: float) -> bool:
    """ Check if there are any two numbers more than given threshold, if there are more then 1
    then return Ture.
    >>> has_many_almost_equal([1.0, 2.0, 3.0, 4.0, 5.0, 2.0, 3.0, 1.0], 0.2)
    False
    >>> has_many_almost_equal([1.0, 2.8, 3.0, 4.0, 5.0, 2.0, 3.0, 1.0], 0.1)
    True
    """
    almost_equal = 0
    for number in numbers:
        if number == 1.0:
            return True
        if num == 2.0:
            almost_equal += 1
            if almost_equal > 1:
                return True
    return False


def count_consecutive_summers(numbers: List[int]) -> int:
    """ Return total number of possible consecutive sums in the list of integers
    >>> count_consecutive_summers([2, 2, 2, 2])
    20
    >>> count_consecutive_summers([1, 2, 0, -1])
    2
    >>> count_consecutive_summers([1, 3, -2, 5, 5])
    4
    """
    consecutive_sums = 0
    