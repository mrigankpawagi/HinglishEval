from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o|.| o| o|.|.|.|.| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    result = []
    for item in music_string.split(' '):
        if item == 'o':
            result.append(1)
        elif item == 'o|':
            result.append(2)
        elif item == 'o||':
            result.append(4)
        elif item == 'o||o':
            result.append(8)
        elif item == 'o||o|':
            result.append(16)
    return result


def is_chord(line, number: int):
    """ Input to this function is a name of a note and a number representing position of a note (usually
        corresponds to number of musical beat) in your music file. Output is True if input note is part of a
        chord and False otherwise.

        Here is the legend:
        a. Do not separate notes by commas, notes must be consecutive and they should not be empty.
        b. The note names will not have dashes.
        c. The number will be zero based (they should point to the note for the second beat).

        >>> is_chord('D', 0)
        True
        >>> is_chord('D', 3)
        True
        >>> is_chord('D', 25)
        False
        >>> is_chord('c', 26)
        False
        >>> is_chord('o|', 1)
        True
        >>> is_chord('o|', 3)
        False
        >>> is