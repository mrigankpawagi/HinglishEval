from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    return "".join([str(int(x)^int(y)) for x,y in zip(a,b)])


def to_decimal(number: str) -> int:
    # return int(number, 2)
    return int(number)


def from_decimal(decimal, width: int) -> str:
    if not decimal.isdigit():
        print("Invalid character in input")
        return
    return width * '0' + decimal


def number_base_converter(number: int,
                          fromDigit: int,
                          toDigit: int) -> str:
    """
    Converts an input number from any base to another base (usually digits of string).
    >>> number_base_converter(0, 10, 2)
    '0'
    >>> number_base_converter(0, 10, 8)
    '0'
    >>> number_base_converter(2, 10, 8)
    '10'
    >>> number_base_converter(12, 10, 8)
    '1100'
    >>> number_base_converter(12, 10, 11)
    '1100'
    >>> number_base_converter(32, 10, 8)
    '2'
    >>> number_base_converter(12, 2, 10)
    '12'
    >>> number_base_converter(12, 2, 11)
    '12'
    >>> number_base_converter(123, 10, 2)
    '233'
    >>> number_base_converter(123, 10, 8)
    '110123'
    """
    n = bin(num)[2:]  # remove the leading '0b'
    print(n)
    n = n.zfill(width)  #