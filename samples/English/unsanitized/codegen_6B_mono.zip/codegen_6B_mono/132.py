
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    # for r in string:
    #     if string.index(r)%2==1:
    #         return False
    # return True
    return string.count("[") % 2!= string.count("]")
    #return set(string).difference(set('[]'))!= set('[]')
    # return list[char for char in string if char not in '[]']==[]



#
#
# def next_highest(grades):
#     '''
#     Create a function that takes a list of integers and returns the next highest int in 
#     the list.
#     '''
#     return max(grades)
#
#
# def next_highest(grades):
#     '''
#     Create a function that takes a list of integers and returns the next highest int in 
#     the list.
#     '''
#     current_max = 0
#     for index in range(len(grades)):
#         if grades[index] > current_max:
#             current_max = grades[index]
#     # return index for max
#     return current_max
#
#
#
# def next_highest(grades, n):
#     '''
#     Create a function that takes a list of integers and returns the next highest int in 
#     the list.
#     '''
#     return int(max(grades))


def count_unpaired(input):
    '''
    Create a function that takes in a string and