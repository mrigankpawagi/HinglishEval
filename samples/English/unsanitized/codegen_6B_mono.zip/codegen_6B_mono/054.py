

def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    return set(s0) == set(s1)


def word_lengths(s: str):
    """
    >>> word_lengths('hello') == {4}
    True
    >>> word_lengths('hello world') == {6}
    True
    >>> word_lengths('ehhwo') == {3}
    True
    >>> word_lengths('hello world') == {6}
    True
    >>> word_lengths('ehhwo world') == {3, 6}
    True
    >>> word_lengths('hello world') == {6}
    True
    """
    result = []
    len_letters = string.ascii_letters_lowercase
    for i in range(7, len(s) +1):
        word = string.ascii_lowercase[:]
        for letter in len_letters:
            if s[i - 1]!= letter:
                word[len_letters.index(letter)] = s[i - 1]
                len_letters[len_letters.index(letter)] = s[i - 1]
        for k in word_lengths(s[i - 1:-1]):
            result.append(i + k)

    return set(result)
            

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    import python_ta.contracts
    python_ta.