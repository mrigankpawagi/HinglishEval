
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if len(arr) == 0:
        return None
    return sum([abs(i)*j for i,j in arr])


# ------------------------------------------------------------------
# HOMEWORK 6
# ------------------------------------------------------------------

def is_power2(n):
    """
    You are given any natural number n. Return True if n is a power of 2,
    False otherwise.
    To solve it by solving a simpler problem you could use `pow(2, 31)`
    or `1 << 31`.
    """
    return True


###############################################################################
#                                                                             #
#                   DO NOT MODIFY ANYTHING BELOW                                #
#                                                                             #
###############################################################################

def count_bits(b):
    "Return the value of the position of an array element b's position"
    if b == 0:
        return 0
    return pow(2, b-1).bit_length()

def sum_bits(arr):
    "Return the number of bits required to represent a non-negative number"
    if not arr:
        return 0
    return sum([count_bits(b) for b in arr])
