


def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """
    return sum([i**2 for i in lst if (i % 3 == 0) if (i % 4!= 0)])


def sort_array(lst):
    """
    This function takes a list of integers and returns a new list with the entries sorted in ascending order. The function should 
    return the same list if passed to it with the same list.
    
    Examples:
    For lst = [5,4,3,1,2] the output should be [1,2,3,4,5]
    For lst = [5,3,4,3,2,1] the output should be [1,2,3,3,4,5]
    For lst = [1] the output should be [1]
    For lst = [5,2,3,4,1] the output should be [1,2,3,4,5]

    """

    if len(lst) <= 1:
        return lst
    else:
        mid = int(len(lst)/2)
        left = sort_array(lst[:mid])
        right = sort_array(lst[mid:])

        return merge(left, right)


def merge(left, right):
    """
    The function takes a sorted list and returns a new list with the combined values of the lists. Both lists should be sorted in 
    ascending order. The function returns the list in a sorted order if the lists were sorted and