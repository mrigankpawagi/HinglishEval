

def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    return list(set(l))


def uniq_stable(l: list):
    """Return unique elements of a list, preserving order
    >>> uniq_stable([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    return [x for x in l if x not in l[:i] for i in range(len(l)+1)]


def invert_dict(d: dict):
    """Invert dictionary, taking values/keys into account
    >>> invert_dict({'a': 1, 'b': 2, 'c': 3})
    {1: ['a', 'c'], 2: ['b']}
    """
    return {v: [k for k in d if d[k] == v] for v in d}


def list2dict(l: list):
    """Convert list into dictionary
    >>> list2dict(['a', 'b', 'c'])
    {'a': None, 'b': None, 'c': None}
    """
    return {k: None for k in l}

def dict2list(d: dict):
    """Convert dictionary into a list
    >>> dict2list({'a': None, 'b': None, 'c': None})
    ['a', 'b', 'c']
    """
    return sorted(d)

def update_dictionary(d: dict, u: dict):
    """Update dictionary with items from another dictionary, where the value of each item is a list
    >>> orig = {'a': 'A', 'b': 'B', 'c': 'C'}
    >>> update_dictionary(orig, {'a': ['D', 'E'], 'f': 'F'})
    {'a': ['D', 'E'], 'b': 'B', 'c': 'C', 'f': 'F'