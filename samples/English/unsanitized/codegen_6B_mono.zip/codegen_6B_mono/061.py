

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    if not len(brackets) % 2 == 0:
        return False
    else:
        return len([x for x in brackets if x == "(" and brackets.count(x) % 2 == 1]) == 0

if __name__ == '__main__':
    doctest.testmod(verbose = True)

