

def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    x, y = 0, 1
    i = 0
    while i!= n:
        x, y = y, x + y
        i += 1

    return x

def merge_sort(l: list) -> list:
    """Sort list l in one pass with the merge sort algorithm, return sorted list."""
    if len(l) <= 1 : return l

    half = len(l)//2
    left, right = merge_sort(l[:half]), merge_sort(l[half:])

    return merge(left, right)


def merge(left: list, right: list) -> list:
    """Merge two sorted lists into a new one in sorted order"""
    i, j = 0, 0
    res = []
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            res.append(left[i])
            i += 1
        else:
            res.append(right[j])
            j += 1

    res += left[i:]
    res += right[j:]

    return res


def merge_sort2(l: list) -> list:
    """Merge sort in one pass, with O(logn) running time"""
    if not l: return l

    length = len(l)

    if length <= 1: return l

    middle = len(l)//2
    return merge(