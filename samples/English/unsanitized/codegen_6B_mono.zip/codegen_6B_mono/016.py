

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    count = len(set(string.lower()))
    return count

## Challenge ##
def count_upper_and_lower_characters(string: str) -> int:
    """ Given a string, find out how many upper and lower case letters it consists of
    >>> count_upper_and_lower_characters('Jerry')
    (4, 3)
    """
    lower_count = sum(1 for c in string.lower() if c.isalpha())
    upper_count = sum(1 for c in string.upper() if c.isalpha())
    total = lower_count + upper_count
    return total, lower_count

#-------------------------------------------------------------------------#

import doctest
import unittest

class TestCountDigits(unittest.TestCase):
    """ Test suite for the function above."""
    def test_one(self):
        self.assertEqual(0, count_digits("The"))
    def test_two(self):
        self.assertEqual(2, count_digits("A Famous Day"))
    def test_three(self):
        self.assertEqual(1, count_digits("The quick brown fox"))

def count_digits(value: str) -> int:
    """ Given a string, find out how many digits does it consist of
    >>> count_digits("The")
    0
    >>> count_digits("A Famous Day")
    2
    >>> count_digits("The Quick Brown Fox")
    6
    """
    count = sum(1 for c in value if c.isdigit())
    return count

def main():
    pass

if __name__ == "__main__":
    main()
    doctest.testmod()

