

def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    pass

def set_intersection(a, b):
    """
    Returns a list that contains the unique elements from both lists
    >>> set_intersection([1, 2, 3], [2, 1, 3])
    [2]
    >>> set_intersection([-1, 4, 3, 2], [1, -1, 0, 3])
    [-1]
    >>> set_intersection([1, 1, 2, 4], [1, 2, 4, 5])
    []
    """
    pass

def test_set_intersection():
    assert [3] == set_intersection([1, 2, 3], [2, 1, 3])
    assert [-1] == set_intersection([-1, 4, 3, 2], [1, -1, 0, 3])
    assert [] == set_intersection([1, 1, 2, 4], [1, 2, 4, 5])
    pass


def get_max_integer(a: list):
    """Return the maximum integer on the list."""
    pass

def test_get_max_integer():
    assert 10 == get_max_integer([-1, 4, 3, 2])
    assert 3 == get_max_integer([1, 2, 3])
    assert 1 == get_max_integer([1, 2, 3, 4, 0])
    pass


def reverse_string(a: list):
    """
    Return a list that contains the reverse of the strings (use recursion!)
    >>> reverse_string(['ab', 'abc', 'abcd', 'bca'])
    ['dcba' 'dcba' 'cbda' 'cda']
    """
    pass


def multiply_strings(a: list):
    