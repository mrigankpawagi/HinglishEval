

def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    for e in l:
        if e > t:
            return False
    return True

def threshold_passing(l: list, t: int):
    """Return the list [x, y, z] where:
    x is a list that only contains elements below threshold t,
    y is a list that only contains elements equal to or above threshold t,
    and z is a list that does not contain any elements smaller than t.
    >>> threshold_passing([5, 1, 4, 7, 10, 2, 3, 4, 10, 8, 9], 10)
    ([5, 1, 4, 7, 10], [], [8, 9, 10, 2, 3, 4, 10])
    >>> threshold_passing([], 5)
    ([], [], [])
    >>> threshold_passing([1], 5)
    ([], [], [1])
    """
    if t == 0:
        return [[], [], l[:]]

    l_min = l[0] # the minimum element in l
    if l_min < t:
        return threshold_passing([s for s in l[1:] if s >= t], t)
    else:
        return threshold_passing([s for s in l[1:] if s < t]+[l_min], t)

def passing_range(l: list, t: int):
    """Return the max-min of values in l >= t using the passing_threshold function.
    >>> passing_range([30, 10, 75, 15, 8], 40)
    150
    """
    min_max_pairs = threshold_passing(l, t)
    max_min_pairs = []
    for pair in min_max_pairs[0]:
        if pair == min_max_pairs[1]:
            break
        max_min_pairs.