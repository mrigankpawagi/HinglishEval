
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    def checkEvenDigit(digit):
        return digit % 2 == 0

    def isOdd(x):
        return x % 2!= 0

    return sorted(filter(isOdd, sorted(x)))


"""
Solution: Given an array S of n non-negative integers, where each integer 
in the array S is written as a value + (value // 10), where value >= 10. 
Now given an integer array (tosses, where each element of tosses is written 
as A + (A // 10) in a different row), return the number of distinct 
rows in tosses.

    """
import unittest
class UniqueRows(unittest.TestCase):
    def test_single_integer(self):
        self.assertEqual([1], unique_rows([1]))
    
    def test_two_integers(self):
        self.assertEqual([2], unique_rows([4,5]))

    def test_no_same_rows(self):
        self.assertEqual([1,2,3], unique_rows([1,2,3,4,5]))

    def test_one_of_each_row(self):
        self.assertEqual([1,2,3,4,5], unique_rows([1,1,1,1,2,2,3,3]))

    def test_one_of_each_row_multiple_times(self):
        self.assertEqual([1,2,3], unique_rows([1,1,1,2,2,3,3,3,3,4,5,5]))
    
    def test_multiple_rows(self):
        self.assertEqual([1,2,