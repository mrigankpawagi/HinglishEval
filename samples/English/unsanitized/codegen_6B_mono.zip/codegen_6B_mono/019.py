from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five','six','seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    dict_numeral = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,'six': 6,
                   'seven': 7, 'eight': 8, 'nine': 9}
    solution = ''
    for x in numbers.split():
        solution += str(dict_numeral[x.lower()])
    return solution


class Node:
    def __init__(self, data, next_node):
        self.data = data
        self.next = next_node


class Stack:
    """LIFO stack using a singly-linked list
    >>> s = Stack()
    >>> s.items == []
    True
    >>> s.is_empty()
    True
    >>> s.peek()
    Traceback (most recent call last):
    ...
    EmptyStackError
    >>> t = Stack(2)
    >>> t.items == [2]
    True
    >>> t = Stack(2, 4)
    >>> t.items
    [2, 4]
    >>> t.push(2)
    >>> t.push(4)
    >>> t.items
    [4, 2, 2]
    >>> t.peek()
    4
    """

    def __init__(self, *data) -> None:
        self.items = [x for x in data]
        self.index = -1

    def empty(self) -> bool:
        return self.items == []

    def push(self, item) -> None:
        self.index += 1
        self.items.insert(self.index, item)

    def pop(self) -> None:
