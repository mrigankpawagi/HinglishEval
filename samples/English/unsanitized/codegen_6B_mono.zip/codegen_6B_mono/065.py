
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    size = len(str(abs(shift)))
    numerator = abs(shift) % size
    if shift >= 0:
        return_str = "".join(str(x)[numerator:size]) + "".join(str(x)[0:numerator])
    if shift < 0:
        return "".join(list(reversed(str(x))[numerator:size]) + list(reversed(str(x))[0:numerator]))
    if shift == 0:
        return str(x)
    return return_str
