

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    # Use mon_helper, then swap last two elements and call it on reversed l
    return mon_helper(l)!= mon_helper(l[::-1])

from math import ceil
from typing import Callable

def monotonous_seq(l: list, k: int, f: Callable[[int, int], int]):
    """Return true if k-consecutive items in l satisfy f(y, y+k) = result for
    some result, false otherwise. (See mon_helper.)
    >>> monotonous_seq([1, 2, 3], 2, lambda a, b: a < b)
    True
    >>> monotonous_seq([1, 2, 3, 4, 5], 2, lambda a, b: a > b)
    True
    >>> print(monotonous_seq([1, 2, 3], 1, lambda a, b: a < b))
    False

    >>> monotonous_seq([1, 2, 3], 2, lambda a, b: a > b)
    False

    """
    return t1 == f(l[i], l[i+k]) for i in range(len(l) - k)

def mon_helper(l: list):
    size = len(l)
    if size <= 1:
        return True
    else:
        # Find the first increasing sequence.
        # If the sequence is monotonous and mon_helper(A[i:]) returns True,
        # it is a potential monotonous increasing sequence.
        # The next three cases look similar.
        # Find the first potential mon_helper(A[i, j]) where it is
        # mon_helper(A[i, j+1], A[i, j]) and mon_helper(A[i+1, j