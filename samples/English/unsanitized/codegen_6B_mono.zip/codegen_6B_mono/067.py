
def fruit_distribution(s,n):
    """
    In this task, you will be given a string that represents a number of apples and oranges 
    that are distributed in a basket of fruit this basket contains 
    apples, oranges, and mango fruits. Given the string that represents the total number of 
    the oranges and apples and an integer that represent the total number of the fruits 
    in the basket return the number of the mango fruits in the basket.
    for examble:
    fruit_distribution("5 apples and 6 oranges", 19) ->19 - 5 - 6 = 8
    fruit_distribution("0 apples and 1 oranges",3) -> 3 - 0 - 1 = 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 100 - 2 - 3 = 95
    fruit_distribution("100 apples and 1 oranges",120) -> 120 - 100 - 1 = 19
    """
    return s - n - sum(map(int, "01123456789".split(n)))


def hamming_distance(s, t):
    """
    In this task you will be given two strings that represent integers. 
    Take the hamming distance between the two numbers and return it.
    """
    x = int(s+t,2)
    y = int(t+s,2)
    return bin(x^y).count("1")


def is_anagram(s, t):
    """
    Two strings are an anagram of each other if they are the same length,
    and their sorted strings are equal.
    Given strings s and t, return true if t is an anagram of s, or false otherwise.
    """
    return sorted(s) == sorted(t)


def hamming_weight(s):
    """    
    For a binary string s, return the number of non-zero bits in the string.
    """
    return bin(s).count("1")


def sort_string(s):
    """
    In this task you will be given a string that might have mixed symbols 
    (both letters and digits). In order to count all of the letters in such a string
    first you need to convert to lowercase and then remove non-alphabet symbols and non