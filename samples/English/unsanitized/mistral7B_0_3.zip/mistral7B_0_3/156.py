 Here is the implementation of the `int_to_mini_roman` function:

```python
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    roman_numerals = {1: 'i', 4: 'iv', 5: 'v', 9: 'ix',
                      10: 'x', 40: 'xl', 50: 'l', 90: 'xc',
                      100: 'c', 400: 'cd', 500: 'd', 900: 'cm',
                      1000: 'm'}

    result = []
    for key in roman_numerals.keys():
        while number >= key:
            number -= key
            result.append(roman_numerals[key])
    return ''.join(result)
```

This function uses a dictionary to map numbers to their corresponding Roman numerals. It then iterates through the keys in the dictionary, subtracting the corresponding value from the input number as long as it is greater than or equal to the key. The resulting Roman numerals are then joined together and returned as a string.