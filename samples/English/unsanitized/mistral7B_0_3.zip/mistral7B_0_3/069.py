 Here is the completed function:

```python
def search(lst):
    freq = {}
    for num in lst:
        if num in freq:
            freq[num] += 1
        else:
            freq[num] = 1

    for num in freq:
        if freq[num] >= num and num > 0:
            return num
    return -1
```

This function first initializes an empty dictionary `freq` to store the frequency of each number in the input list. Then it iterates through the list, updating the frequency of each number in the dictionary. After that, it iterates through the dictionary again, returning the first number that has a frequency greater than or equal to itself and is greater than zero. If no such number is found, it returns -1.