 Here is the completed function for the given docstring:

```python
def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    if len(s) < 3:
        return False
    for i in range(len(s) - 2):
        if s[i:i+3] == s[i+1:i+4] == s[i+2:i+5]:
            return False
    return True
```

This function checks if the given string `s` is happy by first ensuring that its length is at least 3. Then, it iterates through the string in steps of 3 characters (consecutive letters) and checks if the current 3-character sequence is the same as the next 3-character sequence. If it finds any such pair, it returns `False`, indicating that the string is not happy. If it goes through the entire string without finding any such pair, it returns `True`, indicating that the string is happy.