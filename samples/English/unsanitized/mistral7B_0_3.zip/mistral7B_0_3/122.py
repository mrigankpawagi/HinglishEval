 Here is the completed Python function:

```python
def add_elements(arr, k):
    return sum(i for i in arr[:k] if len(str(i)) <= 2)
```

This function uses a generator expression to iterate over the first `k` elements of the array `arr`, and it checks if the length of each element is less than or equal to 2. If the condition is met, it adds the element to the sum. The `sum()` function then computes the total sum of the elements that meet the condition.