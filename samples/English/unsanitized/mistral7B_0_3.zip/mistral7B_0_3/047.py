 Here is the solution for the `median` function:

```python
def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    l = sorted(l)
    n = len(l)
    if n % 2 == 0:
        return (l[n//2 - 1] + l[n//2]) / 2
    else:
        return l[n//2]
```

This function first sorts the input list and then checks if the length of the list is even or odd. If the length is even, it returns the average of the two middle numbers. If the length is odd, it returns the middle number.