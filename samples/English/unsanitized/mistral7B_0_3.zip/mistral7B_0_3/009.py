 Here is the implementation of the `rolling_max` function:

```python
from typing import List

def rolling_max(numbers: List[int]) -> List[int]:
    result = []
    for i in range(len(numbers)):
        max_so_far = numbers[i]
        current_max = numbers[i]
        for j in range(i+1, len(numbers)):
            current_max = max(current_max, numbers[j])
            result.append(current_max)
        result.append(max_so_far)
    return result
```

This function iterates through the input list and keeps track of the maximum number seen so far and the current maximum number. For each number in the list, it checks if the current number is greater than the current maximum, and if so, updates the current maximum. It also appends the current maximum to the result list. Finally, it appends the maximum number seen so far to the result list before moving on to the next number.