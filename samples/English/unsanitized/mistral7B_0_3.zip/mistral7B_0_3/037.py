 Here is the completed function:

```python
def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    return [x if i % 2 != 0 else sorted(l[i])[i // 2] for i, x in enumerate(l)]
```

This function uses list comprehension to iterate through the input list `l` and checks if the index `i` is odd (`i % 2 != 0`). If it is, it keeps the original value at that index. If it's even, it takes the value at that index in the sorted list created from the even indices of `l` (`sorted(l[i])[i // 2]`). The `enumerate(l)` function is used to get both the index and value of each element in the list.