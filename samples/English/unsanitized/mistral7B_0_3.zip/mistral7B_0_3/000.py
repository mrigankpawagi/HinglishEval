 Here is the completed function:

```python
from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    return any(abs(numbers[i] - numbers[j]) <= threshold for i in range(len(numbers)) for j in range(i+1, len(numbers)))
```

This function uses the `any()` function to check if there exists any pair of indices `i` and `j` such that the absolute difference between the numbers at those indices is less than or equal to the given threshold. The nested `for` loop iterates over all possible pairs of indices.