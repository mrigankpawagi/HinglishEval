 Here is the completed Python function:

```python
def find_max(words):
    max_word = None
    max_count = 0

    for word in words:
        count = len(set(word))
        if count > max_count:
            max_word = word
            max_count = count

    return max_word
```

This function iterates through each word in the input list, calculates the number of unique characters in each word, and compares it with the current maximum count. If a word has more unique characters, it updates the maximum word and the maximum count. If multiple words have the same maximum number of unique characters, it returns the first one encountered in lexicographical order.