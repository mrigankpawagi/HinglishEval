 Here is the completed function:

```python
def iscube(a):
    '''
    Write a function that takes an integer a and returns True
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    return a > 0 and any(a == i**3 for i in range(1, int(a**(1/3)) + 1))
```

This function checks if the given number `a` is a cube by iterating through the cube roots of `a` and checking if any of them squared three times equals `a`. The `any()` function returns `True` if at least one element in the iterable (in this case, the sequence of cube roots) is `True`. The `range()` function generates the sequence of cube roots, and the `int()` function is used to round down the cube root to the nearest integer. The `a > 0` condition ensures that the input is a non-negative number, as stated in the problem description.