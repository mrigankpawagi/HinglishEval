 Here is the completed function:

```python
def get_closest_vowel(word):
    vowels = "aeiouAEIOU"
    consonants = set("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ")
    if not word or len(word) < 3:
        return ""

    for i in range(1, len(word)):
        if word[i] in vowels and word[i - 1] in consonants and word[i + 1] in consonants:
            return word[i]

    return ""
```

This function checks if the given word has at least 3 characters, then iterates through the word from the second character. If it finds a vowel between two consonants, it returns that vowel. If no such vowel is found, it returns an empty string.