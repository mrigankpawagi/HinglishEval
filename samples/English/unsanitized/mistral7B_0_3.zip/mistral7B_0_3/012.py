 Here is the completed function:

```python
from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])
    None
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None
    max_length = max(len(string) for string in strings)
    return max(strings, key=lambda string: len(string) == max_length)
```

This function first checks if the input list is empty and returns `None` if it is. Then it finds the maximum length of any string in the list. Finally, it returns the first string of the maximum length, or any string of the maximum length if there are multiple such strings.