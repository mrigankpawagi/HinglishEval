 Sure, here's a solution using a set to remove duplicates and then converting the set back to a list while preserving the order:

```python
from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    return list(set(numbers))
```

This function works by converting the input list to a set, which automatically removes duplicates. Then it converts the set back to a list to return the result. The order of elements is preserved because sets maintain the order of insertion in Python 3.7 and later versions.