 Here is the implementation of the `modp` function using the built-in Python function `pow()`:

```python
from math import floor

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    """
    return pow(2, n) % p
```

This function calculates 2^n and then takes the modulo of the result with p. The `floor` function is not necessary in this case, but it can be used to ensure that the result is an integer if needed.