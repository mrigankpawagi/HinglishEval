 Here is the completed function for the given docstring:

```python
def select_words(s, n):
    words = s.split()
    result = [word for word in words if len([letter for letter in word if not letter.isalpha() or letter.islower()]) == n]
    return result
```

This function splits the input string into words, then uses a list comprehension to filter the words based on the condition that they contain exactly `n` consonants. The condition checks if the length of the list of vowels and non-uppercase letters in the word is equal to `n`. The function returns the filtered list of words.