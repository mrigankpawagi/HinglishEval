 Here is the completed function:

```python
from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    min_num = min(numbers)
    max_num = max(numbers)
    return [(x - min_num) / (max_num - min_num) for x in numbers]
```

This function first finds the minimum and maximum numbers in the input list, then applies a linear transformation to each number in the list so that the smallest number becomes 0 and the largest number becomes 1. The transformation is done by subtracting the minimum number from each number, dividing the result by the range (maximum number - minimum number), and then multiplying by the range again to get the rescaled number.