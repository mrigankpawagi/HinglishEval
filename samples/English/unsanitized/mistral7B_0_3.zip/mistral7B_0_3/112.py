 Here is the completed function:

```python
def reverse_delete(s, c):
    """
    Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    s = list(s)
    for char in c:
        s = [elem for elem in s if elem != char]
    s_reversed = s[:]
    s_reversed.reverse()
    if s == s_reversed:
        return ("".join(s), True)
    else:
        return ("".join(s), False)
```

This function first converts the input string `s` into a list, then iterates through each character in `c` and removes those characters from the list `s`. After that, it creates a reversed copy of the modified list `s`. Finally, it checks if the original list `s` is equal to its reversed copy. If they are equal, it returns the joined list as the result string and `True` as the palindrome check. Otherwise, it returns the joined list as the result string and `False` as the palindrome check.