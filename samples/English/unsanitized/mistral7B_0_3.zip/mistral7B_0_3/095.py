 Here is the completed function:

```python
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower case or all keys are strings in upper case, else return False.
    The function should return False if the given dictionary is empty.
    """
    if not dict:
        return False

    case = next((k for k in dict.keys() if k.isupper()), None)
    if case:
        return all(k.isupper() for k in dict.keys())

    case = next((k for k in dict.keys() if k.islower()), None)
    if case:
        return all(k.islower() for k in dict.keys())

    return False
```

This function first checks if the dictionary is empty and returns False if it is. Then it tries to find a key that is in upper case and checks if all keys are in upper case. If it doesn't find a key in upper case, it tries to find a key in lower case and checks if all keys are in lower case. If it doesn't find any key, it returns False.