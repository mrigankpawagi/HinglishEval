 Here is the completed function:

```python
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
    a += a
    return b in a[len(b):] or b in a
```

This function first concatenates the input string `a` with itself to create a new string that includes all rotations of `b`. Then it checks if `b` is a substring in the new string or if `b` is already in the original string `a`.