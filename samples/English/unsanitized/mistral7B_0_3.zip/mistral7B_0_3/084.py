 Here is the completed function:

```python
def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.

    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".

    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    binary_sum = ''
    while N > 0:
        binary_sum = str(bin(N % 2))[2:] + binary_sum
        N //= 2
    return binary_sum
```

This function converts the given number to binary and then calculates the sum of the digits by concatenating the binary representation from the least significant bit (LSB) to the most significant bit (MSB). The `bin()` function is used to convert the number to binary, and the `//` and `%` operators are used for integer division and modulo operations, respectively. The `[2:]` is used to remove the '0b' prefix from the binary representation returned by the `bin()` function.