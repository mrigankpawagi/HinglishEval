 Here is the completed function:

```python
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 * ... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    result = [1] * n
    for i in range(1, n):
        if i % 2 == 0:
            result[i] = math.factorial(i)
        else:
            result[i] = sum(range(1, i+1))
    return result
```

This function uses the built-in `math.factorial()` function to calculate the factorial of a number and the built-in `sum()` function to calculate the sum of numbers from 1 to a given number. The `range()` function is used to generate a sequence of numbers from 1 to `n`. The list comprehension `[1] * n` initializes the list with `n` 1's.