 Here is the Python function that fulfills the given docstring:

```python
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    stack = []
    for char in string:
        if char == '[':
            stack.append(char)
        elif char == ']':
            if not stack or stack.pop() != '[':
                return False
    return len(stack) == 0
```

This function uses a stack to keep track of the opening brackets. If it encounters a closing bracket that doesn't have a corresponding opening bracket in the stack, it returns False. If there are any remaining opening brackets in the stack at the end, it also returns False. If the function finishes without returning False, it means that there is at least one nested sequence of brackets, so it returns True.