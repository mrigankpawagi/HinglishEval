 Here is the implementation of the `prime_fib` function in Python:

```python
def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    """
    fib_sequence = [0, 1]
    primes = [2]
    while len(primes) < n:
        next_fib = fib_sequence[-1] + fib_sequence[-2]
        if is_prime(next_fib):
            primes.append(next_fib)
        fib_sequence.append(next_fib)

    for fib in fib_sequence[n-1:]:
        if fib_sequence.count(fib) == 1 and fib_sequence.index(fib) + 1 == fib_sequence.index(fib - 1) + 2:
            return fib

def is_prime(n: int) -> bool:
    """
    is_prime checks if a number is prime.
    """
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True
```

The `prime_fib` function generates the Fibonacci sequence and checks each number for primality. The `is_prime` function checks if a number is prime by testing divisibility up to the square root of the number.