 Here is the completed function for `all_prefixes`:

```python
from typing import List

def all_prefixes(string: str) -> List[str]:
    prefixes = []
    for i in range(len(string) + 1):
        prefix = string[:i]
        prefixes.append(prefix)
    return prefixes
```

This function generates all prefixes of the input string by iterating through the string's length and appending each substring to a list of prefixes. The substring starts from the beginning of the string and its length increases from 1 to the length of the input string.