 Here is the completed function:

```python
def string_sequence(n: int) -> str:
    return " ".join(str(i) for i in range(n + 1))
```

This function uses a generator expression to create a sequence of numbers from 0 to n, then converts each number to a string and joins them with spaces. The result is a string containing the numbers from 0 to n, inclusive.