 Here is the implementation of the `change_base` function in Python:

```python
def change_base(x: int, base: int) -> str:
    digits = "0123456789ABCDEF"
    result = []
    while x:
        x, remainder = divmod(x, base)
        result.append(digits[remainder])
    return "".join(result[::-1])
```

This function converts an integer `x` from a given base to another base. It uses a dictionary `digits` to map the digits of the new base to their corresponding characters. The function then repeatedly divides the input number by the new base and appends the remainder to the `result` list. Finally, it returns the reversed `result` list as a string.