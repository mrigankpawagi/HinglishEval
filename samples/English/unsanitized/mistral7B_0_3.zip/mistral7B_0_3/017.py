 Here is the completed function:

```python
from typing import List

def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    notes = {'o': 4, 'o|': 2, '.|': 1}
    beats = []
    for note in music_string:
        if note in notes:
            beats.append(notes[note])
        elif note == '|':
            beats.append(notes[music_string[music_string.rfind('|') - 1]])
    return beats
```

This function uses a dictionary to store the duration of each note type and iterates through the input string. If the current character is a note, it appends the corresponding duration to the list of beats. If the current character is a pipe '|', it appends the duration of the last note before the pipe.