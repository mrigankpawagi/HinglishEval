 Here is the completed function:

```python
def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(string)
```

This function uses the built-in `len()` function in Python to get the length of the given string. The `len()` function returns the number of items in an object, and for strings, it returns the number of characters.