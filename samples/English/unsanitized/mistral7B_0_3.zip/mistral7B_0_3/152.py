 Here is the completed function:

```python
def compare(game, guess):
    return [abs(g - gm) for g, gm in zip(guess, game)]
```

This function uses a list comprehension to iterate over the pairs of elements in the `game` and `guess` lists, calculates the absolute difference between each pair, and returns a new list containing these differences. The `zip()` function is used to pair the elements from both lists.