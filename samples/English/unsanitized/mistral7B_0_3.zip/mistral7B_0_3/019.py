 Here's the completed function using a dictionary to map the number strings to their corresponding integers, and then sorting the list of integers:

```python
from typing import List
from collections import Counter

numbers_dict = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9}

def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    numbers_list = [numbers_dict[num] for num in numbers.split()]
    sorted_numbers = ' '.join([str(num) for num in sorted(numbers_list)])
    return sorted_numbers
```

This function first converts the input string into a list of integers using the dictionary, then sorts the list, and finally converts the sorted list back into a string.