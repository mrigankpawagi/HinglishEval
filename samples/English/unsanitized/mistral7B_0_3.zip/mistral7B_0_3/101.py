 Here is the completed function:

```python
def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.

    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    return s.split(r'\s+|,\s+')
```

This function uses the `split()` method of strings to separate the input string into words. The regular expression `r'\s+|,\s+'` is used to match one or more whitespace characters or a comma followed by one or more whitespace characters. This ensures that the function can handle both spaces and commas as separators.