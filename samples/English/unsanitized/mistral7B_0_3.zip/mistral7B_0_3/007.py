 Here's the completed function:

```python
from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    return [s for s in strings if substring in s]
```

This function uses a list comprehension to filter the input list of strings based on whether they contain the given substring. The `in` keyword is used to check if the substring is present in each string. The filtered list is then returned.