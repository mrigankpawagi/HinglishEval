 Here is the completed function:

```python
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    total1 = sum(len(s) for s in lst1)
    total2 = sum(len(s) for s in lst2)

    if total1 < total2:
        return lst1
    elif total1 > total2:
        return lst2
    else:
        return lst1
```

This function calculates the total length of all strings in both lists and compares them. If the total length of strings in the first list is less than the second list, it returns the first list. If the total length of strings in the second list is less than the first list, it returns the second list. If both lists have the same total length, it returns the first list.