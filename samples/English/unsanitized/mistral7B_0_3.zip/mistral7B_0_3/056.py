 Here is the Python function that completes the given docstring:

```python
def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    opening_brackets = "><"
    closing_brackets = "<"
    brackets_stack = []

    for bracket in brackets:
        if bracket in opening_brackets:
            brackets_stack.append(bracket)
        elif bracket in closing_brackets:
            if not brackets_stack or brackets_stack.pop() != bracket:
                return False

    return not brackets_stack
```

This function uses a stack to keep track of the opening brackets and checks if every closing bracket has a corresponding opening bracket in the stack. If there are any unmatched brackets left in the stack at the end, it returns False. Otherwise, it returns True.