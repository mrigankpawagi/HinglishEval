 Here is the completed function for Mean Absolute Deviation:

```python
from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    if not numbers:
        return 0

    mean = sum(numbers) / len(numbers)
    return sum(abs(x - mean) for x in numbers) / len(numbers)
```

This function first checks if the input list is empty and returns 0 in that case. Then it calculates the mean of the numbers and iterates through the list to find the absolute difference between each number and the mean, sums them up, and finally divides by the length of the list to get the Mean Absolute Deviation.