 Here is the completed function:

```python
def sum_squares(lst):
    """You are given a list of numbers.
    You need to return the sum of squared numbers in the given list,
    round each element in the list to the upper int(Ceiling) first.
    Examples:
    For lst = [1,2,3] the output should be 14
    For lst = [1,4,9] the output should be 98
    For lst = [1,3,5,7] the output should be 84
    For lst = [1.4,4.2,0] the output should be 29
    For lst = [-2.4,1,1] the output should be 6

    """
    return sum(i ** 2 for i in map(int, lst))
```

This function uses a generator expression to square each number in the list, and then a list comprehension to round each number to the nearest integer (ceiling). The `map()` function is used to apply the `int()` function to each number in the list. Finally, the `sum()` function is used to sum all the squared, rounded numbers.