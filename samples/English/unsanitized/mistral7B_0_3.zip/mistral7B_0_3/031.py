 Here is the implementation of the `is_prime` function in Python:

```python
def is_prime(n):
    if n <= 1:
        return False
    elif n <= 3:
        return True
    elif n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True
```

This function checks if a given number `n` is prime by first checking if it's less than or equal to 1 (in which case it's not prime), less than or equal to 3 (in which case it is prime), or divisible by 2 or 3 (in which case it's not prime). Then it checks for divisibility by numbers of the form 6k ± 1, starting from 5, until the square root of `n`. If `n` is divisible by any of these numbers, it's not prime; otherwise, it is prime.