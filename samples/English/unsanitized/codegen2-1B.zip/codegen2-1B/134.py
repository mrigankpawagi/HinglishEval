
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''
ovar<mask_52>input/vsvcportvt...button%)varIn,Inform<mask_52>),varpoly(vshasformODUCTvar)vt<mask_52>�ststpolyvar         form)oba�obahaso(�,hasvs(polyvcvar),hof<mask_1>storyODUCTst)input,vt(input"),%oba(inputpoly varvt<mask_18><mask_1>/(;         ODUCTstportvtvar(<vtvto� varstpolyvcob<mask_45>%(<portvsportwisewiseObject(varvarstIn(ventionIn         /sto<mask_52>(++ODUCT++         (input),port(polyvthoppolywise,vtob,ob<mask_18>
�texto<mask_45>->formhaspolyvcvtopoly<mask_1>haswiseK),storystIn%(,vt/port(wise(poly),handleoba(vt/(vtvtovc)/inputvc++->,o<portInvarvtvtform var-><(ob/form',wise<mask_18>,vc%hop"),',stportvaro,InODUCT(formpolyform,vt/)((oba/wiseK<mask_1>polywiseport%vt(polyODUCTform,->...vco#