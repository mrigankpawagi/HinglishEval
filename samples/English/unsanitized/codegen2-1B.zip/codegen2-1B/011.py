from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
,wiseInin),),vc...,formvt)input,port(),(form,
(...(stformhasst),++stob,InformKBODUCT,(stportform,wise<mask_1>(vs(has(ODUCTform(%form),form<mask_18>W),#