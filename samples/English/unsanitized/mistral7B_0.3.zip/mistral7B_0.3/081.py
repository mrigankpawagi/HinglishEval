 Here is the completed function:

```python
def numerical_letter_grade(grades):
    letter_grades = ['E', 'D+', 'D', 'D-', 'C+', 'C', 'C-', 'B-', 'B', 'B+', 'A-', 'A', 'A+']
    grades = [round(g, 2) for g in grades]

    result = [letter_grades[i] for i in range(len(letter_grades)) if grades[i] > grades[i - 1]]
    result.append(letter_grades[-1])

    return result
```

This function first rounds the given grades to two decimal places. Then it iterates through the letter grades list and appends the corresponding letter grade to the result list whenever the current grade is greater than the previous one. Finally, it appends the last letter grade (E) to the result list to handle the case when the last grade is less than the previous one.