 Here's the solution for the given function:

```python
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    length = len(string)
    if length < 2:
        return False
    for i in range(2, int(length**0.5) + 1):
        if length % i == 0:
            return False
    return True
```

This function checks if the length of the given string is a prime number by iterating through all numbers up to the square root of the length and checking if the length is divisible by any of them. If it is not divisible by any of them, then the length is a prime number.