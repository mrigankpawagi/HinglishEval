 Here is the completed function for checking if a given string is a palindrome:

```python
def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    return text == text[::-1]
```

This function checks if the given string is equal to its reverse by using the slicing operator `[::-1]`. If the string is equal to its reverse, it means the string is a palindrome, and the function returns `True`. Otherwise, it returns `False`.