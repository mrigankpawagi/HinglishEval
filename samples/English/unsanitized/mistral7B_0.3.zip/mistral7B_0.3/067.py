 Here is the completed function:

```python
import re

def fruit_distribution(s, n):
    """
    In this task, you will be given a string that represents a number of apples and oranges
    that are distributed in a basket of fruit this basket contains apples, oranges, and mango fruits.
    Given the string that represents the total number of the oranges and apples and an integer that
    represent the total number of the fruits in the basket return the number of the mango fruits in the basket.
    """
    fruits = re.findall(r'(\d+) ([a-z]+)s', s)
    apples, oranges = map(int, fruits[0])
    total_fruits = sum(map(int, fruits[0:2]))
    return n - total_fruits - oranges
```

This function uses regular expressions to find the number of apples and oranges in the given string, then calculates the total number of fruits and subtracts it from the total number of fruits provided to find the number of mangoes.