 Here is the completed function:

```python
def digitSum(s):
    """
    Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    return sum(ord(c.upper()) for c in s if c.isalpha())
```

This function uses a generator expression to iterate over the characters in the input string, and the `ord()` function to get the ASCII code of each character. The `upper()` method is used to ensure that only uppercase characters are considered, and the `isalpha()` method is used to filter out non-alphabetic characters. The `sum()` function is then used to sum up the ASCII codes of the filtered characters.