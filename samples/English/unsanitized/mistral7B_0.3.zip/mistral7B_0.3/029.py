 Here's the completed function:

```python
from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    return [string for string in strings if string.startswith(prefix)]
```

This function uses a list comprehension to filter the input list based on the given prefix. The `startswith()` method is used to check if each string in the list starts with the provided prefix. The filtered list is then returned.