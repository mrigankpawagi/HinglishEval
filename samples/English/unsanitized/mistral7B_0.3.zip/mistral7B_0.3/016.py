 Here is the completed function:

```python
def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(set(string.lower()))
```

This function uses the `set()` function to create a set from the input string, converting all characters to lowercase. Then, it returns the length of the set, which gives the number of distinct characters in the string.