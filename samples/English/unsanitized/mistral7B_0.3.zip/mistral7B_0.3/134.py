 Here is the completed function:

```python
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False
    '''
    if txt:
        last_char = txt[-1]
        if last_char.isalpha() and not txt[-1].isalnum() and not txt[-2:].isspace():
            return True
    return False
```

This function checks if the last character of the input string is an alphabetical character, not part of a word (not alphanumeric), and not preceded by a space. If all conditions are met, it returns True; otherwise, it returns False.