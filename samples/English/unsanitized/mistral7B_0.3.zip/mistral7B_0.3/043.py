 Here is the completed function:

```python
def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    """
    return any(i + j == 0 for i in l if i not in l[l.index(i)+1:] for j in l[l.index(i)+1:])
```

This function uses a generator expression to check if there are any pairs of numbers in the list that sum to zero. It uses the `any()` function to check if at least one such pair exists. The `not in` operator is used to ensure that the two numbers are distinct, and the slice `l[l.index(i)+1:]` is used to exclude the current number `i` from the remaining numbers in the list when checking for a pair.