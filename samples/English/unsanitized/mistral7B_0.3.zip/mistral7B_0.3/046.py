 Here is the solution for the given function using dynamic programming approach:

```python
def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    """

    fib4_sequence = [0] * (n+1)
    fib4_sequence[0], fib4_sequence[1], fib4_sequence[2], fib4_sequence[3] = 0, 0, 2, 0

    for i in range(4, n+1):
        fib4_sequence[i] = fib4_sequence[i-1] + fib4_sequence[i-2] + fib4_sequence[i-3] + fib4_sequence[i-4]

    return fib4_sequence[n]
```

This function initializes a list `fib4_sequence` with the first 4 Fib4 numbers and then computes the rest of the sequence using a loop. The time complexity of this solution is O(n) since we only iterate through the sequence once.