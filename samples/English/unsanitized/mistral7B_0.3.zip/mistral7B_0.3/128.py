 Here is the completed function for `prod_signs`:

```python
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    if not arr:
        return None

    product_sign = 1
    product_magnitude = 1

    for num in arr:
        product_sign *= (1 if num > 0 else -1 if num < 0 else 1)
        product_magnitude *= abs(num)

    return product_magnitude * product_sign
```

This function first checks if the input array is empty and returns `None` if it is. Then, it initializes two variables: `product_sign` to keep track of the product of signs, and `product_magnitude` to keep track of the sum of magnitudes.

For each number in the array, it updates the `product_sign` by multiplying it with 1 if the number is positive, -1 if the number is negative, and leaving it unchanged if the number is zero. It also updates the `product_magnitude` by multiplying it with the absolute value of the number.

Finally, it returns the product of `product_magnitude` and `product_sign`.