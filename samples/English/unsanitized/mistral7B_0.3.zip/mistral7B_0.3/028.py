 Here is the completed function:

```python
from typing import List

def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return ''.join(strings)
```

The `join()` method in Python concatenates all the elements in the list into a single string, with the specified separator between each element. In this case, since no separator is specified, it uses an empty string as the default separator.