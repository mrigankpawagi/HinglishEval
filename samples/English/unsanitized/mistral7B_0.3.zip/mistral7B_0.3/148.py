 Here is the completed function:

```python
planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]

def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closest to the Sun is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2.
    The function should return a tuple containing all planets whose orbits are located between the orbit of planet1 and the orbit of planet2, sorted by the proximity to the sun.
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names.
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    if planet1 not in planets or planet2 not in planets:
        return tuple()

    index1 = planets.index(planet1)
    index2 = planets.index(planet2)

    return tuple(sorted(planets[index1:index2+1]))
```

This function first checks if the given planet names are valid by checking if they are in the list of planets. If they are not, it returns an empty tuple. Then it finds the indices of the given planets in the list of planets. Finally, it returns a tuple containing the planets whose indices are between the indices of the given planets, sorted by their proximity to the sun.