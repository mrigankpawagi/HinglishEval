 Here is a solution for the given function using Kadane's algorithm:

```python
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    min_so_far = float('inf')
    min_ending_here = 0

    for num in nums:
        min_ending_here = min(num, min_ending_here + num)
        min_so_far = min(min_so_far, min_ending_here)

    return min_so_far
```

This function initializes two variables, `min_so_far` and `min_ending_here`, to store the minimum sum found so far and the current minimum sum ending at the current index, respectively. It then iterates through the array, updating `min_ending_here` and `min_so_far` as needed. The final result is the minimum sum found so far.