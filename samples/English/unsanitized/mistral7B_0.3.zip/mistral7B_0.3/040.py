 Here is the completed function:

```python
def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    l.sort()
    for i in range(len(l) - 2):
        if l[i] + l[i+1] + l[i+2] == 0 and l[i] != l[i+1] and l[i] != l[i+2] and l[i+1] != l[i+2]:
            return True
    return False
```

This function first sorts the input list to make it easier to check for distinct elements. Then it iterates through the list, checking if the sum of the current element and the next two elements is zero, and if the elements are distinct. If it finds such a triplet, it returns True. If it goes through the entire list without finding a triplet, it returns False.