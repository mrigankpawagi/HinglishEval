 Here is the completed function:

```python
def pluck(arr):
    even_nodes = [(node, i) for i, node in enumerate(arr) if node % 2 == 0]

    if not even_nodes:
        return []

    min_value, min_index = min(even_nodes, key=lambda x: (x[0], x[1]))
    return [min_value, min_index]
```

This function first filters the array to find all even nodes and their indices. Then it finds the minimum even value and its index, and returns them in a list. If there are no even values, it returns an empty list.