 Here is the solution for the function `how_many_times`:

```python
def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlapping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    count = 0
    for i in range(len(string) - len(substring) + 1):
        if string[i:i+len(substring)] == substring:
            count += 1
    return count
```

This function uses a loop to iterate through the string and checks if the substring is present at each position. If it is, the count is incremented. The loop starts from the index 0 and ends at the index `len(string) - len(substring) + 1` to ensure that the substring is not searched beyond its possible position in the string. The function returns the final count of occurrences.