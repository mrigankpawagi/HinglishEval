 ```python
def split_words(txt):
    words = txt.split()
    if not words:
        words = [letter for i, letter in enumerate(txt.lower()) if i % 2 == 1]
    return words
```