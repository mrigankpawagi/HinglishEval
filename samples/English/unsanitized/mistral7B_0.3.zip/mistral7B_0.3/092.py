 Here is the completed function:

```python
def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.

    Examples
    any_int(5, 2, 7) ➞ True

    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True

    any_int(3.6, -2.2, 2) ➞ False
    '''
    return any(x == (y + z) for x, y, z in zip([int(x) for x in (str(x), str(y), str(z))], [int(x) for x in (str(x), str(y), str(z))]))
```

This function first checks if the input numbers are integers by converting them to strings and then converting them back to integers. Then it checks if any of the numbers are equal to the sum of the other two numbers using a generator expression and the `any()` function.