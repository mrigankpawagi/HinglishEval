 ```python
def largest_divisor(n: int) -> int:
    return max(i for i in range(1, n) if n % i == 0)
```