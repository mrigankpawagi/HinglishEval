 Sure, here's a solution using the built-in `set` data structure in Python, which automatically removes duplicates:

```python
def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    return sorted(set(l))
```

This function first converts the input list into a set, which removes any duplicates. Then it sorts the set and converts it back into a list. This ensures that the output is a sorted list with unique elements.