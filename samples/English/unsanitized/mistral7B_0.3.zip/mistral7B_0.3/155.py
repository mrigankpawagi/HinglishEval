 Here is the completed function:

```python
def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    count_even, count_odd = 0, 0
    num_str = str(abs(num))
    for digit in num_str:
        if int(digit) % 2 == 0:
            count_even += 1
        else:
            count_odd += 1
    return count_even, count_odd
```

This function takes an integer as input, converts it to a string, and then iterates through each digit in the string. If the digit is even, it increments the count_even variable, otherwise it increments the count_odd variable. Finally, it returns a tuple containing the number of even and odd digits.