 Here is the completed function:

```python
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    return sum(i for i, index in enumerate(lst) if index != len(lst) and i != len(lst) // 2 and i % 2 == 1 and i % 2 == lst[i] % 2)
```

This function iterates through the list, checks if the index is odd, not the middle index, and the index and the number at that index are both even. If all conditions are met, it adds the number to the sum. The `sum` function is used to calculate the total sum of the even numbers at odd indices.