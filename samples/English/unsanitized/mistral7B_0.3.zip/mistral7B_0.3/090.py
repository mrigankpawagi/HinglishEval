 Here's the completed function:

```python
def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.

    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    if len(lst) < 2:
        return None

    sorted_lst = sorted(lst)
    return sorted_lst[1] if sorted_lst[1] != sorted_lst[-1] else next_smallest(filter(lambda x: x < sorted_lst[-1], lst))
```

This function first checks if the list has at least 2 elements. If not, it returns `None`. Then it sorts the list and returns the second element if the second element is not the same as the last element. If the second element is the same as the last element, it recursively calls the function with a filtered list containing only elements smaller than the last element.