 Here is the completed function:

```python
from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    if len(numbers) < 2:
        raise ValueError("The list must have at least two elements.")

    min_diff = float('inf')
    closest_num1, closest_num2 = None, None

    for num1 in numbers:
        for num2 in numbers:
            if num1 != num2 and abs(num1 - num2) < min_diff:
                min_diff = abs(num1 - num2)
                closest_num1, closest_num2 = num1, num2

    return closest_num1, closest_num2
```

This function iterates through all pairs of numbers in the list and finds the pair with the smallest difference. It then returns the two numbers in the order of smaller number first and larger number second. If there are multiple pairs with the same smallest difference, it chooses any one of them.