 Here is a possible implementation of the `largest_prime_factor` function:

```python
def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    factors = []
    for i in range(2, n + 1):
        if n % i == 0:
            factors.append(i)

    factors = list(filter(is_prime, factors))
    return max(factors)
```

This function first defines a helper function `is_prime` to check if a number is prime. Then it iterates through all numbers from 2 to `n` and checks if `n` is divisible by the current number. If it is, the number is added to a list of factors. After that, the list of factors is filtered to only include prime numbers using the `filter` function and the `is_prime` helper function. Finally, the largest prime factor is returned using the `max` function.