 Here is the completed function:

```python
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    from functools import reduce
    from operator import abs

    def sum_of_digits(n):
        return sum(abs(int(digit)) for digit in str(n))

    return len(list(filter(lambda x: sum_of_digits(x) > 0, arr)))
```

This function uses the `filter` function to filter out the numbers with a sum of digits greater than 0, and the `len` function to count the number of elements in the filtered list. The `sum_of_digits` function calculates the sum of the absolute values of the digits of a number. The `functools.reduce` and `operator.abs` functions are used to convert the number into a string and to get the absolute value of each digit, respectively.