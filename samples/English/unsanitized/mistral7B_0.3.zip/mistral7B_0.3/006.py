 Here is the implementation of the `parse_nested_parens` function using a stack data structure:

```python
from typing import List
from collections import deque

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    levels = []
    stack = deque()

    for group in paren_string.split():
        for char in group:
            if char == '(':
                stack.append(char)
            elif char == ')':
                stack.pop()
                if not stack:
                    levels.append(len(group))

    return levels
```

This function splits the input string into groups of parentheses, iterates through each group, and uses a stack to keep track of the opening parentheses. For each closing parenthesis, it checks if the stack is empty, and if so, it means that the current group has the deepest level of nesting, so it appends the length of the group to the `levels` list.