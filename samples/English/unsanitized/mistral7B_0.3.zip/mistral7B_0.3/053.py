 Sure, here is the completed function:

```python
def add(x: int, y: int) -> int:
    return x + y
```

This function takes two integer arguments `x` and `y`, and returns their sum. The `-> int` part is a type hint that specifies the return type of the function. The `>>>` lines are doctest examples, they are used for testing the function's behavior.