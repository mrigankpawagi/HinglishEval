 Here is the Python function that completes the given docstring:

```python
def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    opening_brackets = "("
    closing_brackets = ")"
    stack = []

    for bracket in brackets:
        if bracket in opening_brackets:
            stack.append(bracket)
        elif bracket in closing_brackets:
            if not stack or stack.pop() != bracket:
                return False

    return not stack
```

This function uses a stack to keep track of opening brackets and checks if every closing bracket has a corresponding opening bracket in the stack. If there are any unmatched brackets or the stack is not empty at the end, it returns False. Otherwise, it returns True.