 Here's the implementation of the Fibonacci function using recursion:

```python
def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n <= 1:
        return n
    else:
        return fib(n - 1) + fib(n - 2)
```

This function calculates the n-th Fibonacci number using recursion. It returns the number itself if n is 1 or 0, and the sum of the previous two Fibonacci numbers if n is greater than 1.