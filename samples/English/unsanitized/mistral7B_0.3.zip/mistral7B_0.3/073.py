 Here is a Python function that solves the problem as described:

```python
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    n = len(arr)
    count = 0
    left, right = 0, n - 1

    while left < right:
        if arr[left] != arr[right]:
            count += min(n - left - 1, right - left)
            arr[left] = arr[right]
            arr[right] = arr[left]
            left += 1
            right -= 1
        else:
            left += 1
            right -= 1

    # Check the middle element
    if arr[n // 2] != arr[~n // 2]:
        count += 1

    return count
```

This function first checks if the array is already palindromic. If it is, it returns 0. Otherwise, it initializes two pointers at the beginning and end of the array and starts comparing elements from both ends. If the elements are not equal, it changes the smaller number of elements required to make the array palindromic and updates the pointers. After that, it checks the middle element and adds 1 to the count if it's not equal to its mirror. Finally, it returns the total count of changes required.