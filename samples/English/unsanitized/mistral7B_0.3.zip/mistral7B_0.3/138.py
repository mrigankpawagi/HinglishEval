 Here is a possible solution for the function `is_equal_to_sum_even(n)`:

```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def is_even(num):
        return num % 2 == 0

    def is_sum_of_four_evens(num, evens):
        return num == sum(evens) and len(evens) == 4 and all(is_even(e) for e in evens)

    if n < 4:
        return False

    evens = set(range(2, n + 1))
    for e1 in evens:
        evens.remove(e1)
        for e2 in evens:
            evens.remove(e2)
            for e3 in evens:
                evens.remove(e3)
                for e4 in evens:
                    if is_sum_of_four_evens(n, [e1, e2, e3, e4]):
                        return True
    return False
```

This function first defines two helper functions: `is_even(num)` checks if a number is even, and `is_sum_of_four_evens(num, evens)` checks if a number can be written as the sum of exactly 4 positive even numbers from the given set of evens.

The main function then checks if the given number `n` is less than 4 (in which case it returns False), and then iterates over all possible combinations of 4 even numbers that sum up to `n`, using the helper function `is_sum_of_four_evens()`. If it finds such a combination, it returns True; otherwise, it returns False.