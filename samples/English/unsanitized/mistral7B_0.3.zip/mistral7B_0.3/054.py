 Here is the completed function:

```python
def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    """
    set_s0 = set(s0)
    set_s1 = set(s1)
    return set_s0 == set_s1 or set_s1 == set_intersection(set_s0, set_s1)
```

This function uses sets to check if both strings have the same characters or if one string is a subset of the other. The `set_intersection` function is from the `math` module. If you don't have it, you can replace it with `set(s0) & set(s1)`.