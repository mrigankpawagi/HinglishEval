 Sure, I can help with that! The area of a triangle can be calculated using the formula `0.5 * base * height`. Here's the completed function:

```python
def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    return 0.5 * a * h
```

This function takes two arguments, `a` (the base of the triangle) and `h` (the height), and returns the area of the triangle. The area is calculated by multiplying the base by the height and then dividing by 2.