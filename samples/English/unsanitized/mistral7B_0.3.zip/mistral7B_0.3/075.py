 Here is the implementation of the function `is_multiply_prime(a)`:

```python
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100.
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    primes = [2, 3, 5]
    for i in range(6, int(a**0.5) + 1):
        if a % i == 0:
            primes.extend(prime_factorization(i))
    return len(primes) == 3 and set(primes) == set(primes[:3])

def prime_factorization(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)
    if n > 1:
        factors.append(n)
    return factors
```

In this solution, I added a helper function `prime_factorization(n)` to find the prime factors of a given number. The main function `is_multiply_prime(a)` checks if the given number `a` can be expressed as the product of 3 prime numbers. It first finds the prime factors of `a` using the helper function and then checks if the length of the prime factors is 3 and if they are all unique.