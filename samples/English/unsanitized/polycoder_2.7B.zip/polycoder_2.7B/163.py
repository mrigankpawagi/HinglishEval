
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    from itertools import count
    count_result = count(a) * count(b))
    if result_int(count_result, 2) == a or result_int(count_result, 2) == b:
        if result_int(count_result, 2) == b:
            return result_int(count_result, 2)
        else:
            return result_int(count_result, 2) % 2
    if result_int(count_result, 4) == a or result_int(count_result, 4) == b:
        if result_int(count_result, 4) == b:
            return result_int(count_result, 4)
        else:
            return result_int(count_result, 4) % 2
    if result_int(count_result, 6) == a or result_int(count_result, 6) == b:
        if result_int(count_result, 6) == b:
            return result_int(count_result, 6)
        else:
            return result_int(count_result, 6) % 2
    if result_int(count_result, 8) == a or result_int(count_result, 8) == b:
  