
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    res = 'Yes'
    cnt = 0
    pre_cnt = 0
    for i in lst:
        if pre_cnt > 0 and i == '(':
            pre_cnt -= 1
            pre_cnt -= '('.count(i)
            i = lst.index(i)
        if cnt == 0: # First char is not '('
            res = 'No'
        pre_cnt += 1
        if cnt >= 2 and pre_cnt == cnt/2 and i.count(i) > 1: # If more than one '(' not present
            res = 'No'
            cnt -= 1
        if cnt > pre_cnt: # Only close parentheses in string before '('
            cnt -= 1

    return res
