
def cycpattern_check(a , b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True

    """
   i = 0
    while i < len(a) and i < len(b):
        s = a[i]
        e = b[i]
        if s == e:  # if both characters are equal
            continue
        s = a[i:i+1]
        e = b[i:i+1]
        if s == e:  # if first character of the characters is equal
            continue
        i += 1
    return False
