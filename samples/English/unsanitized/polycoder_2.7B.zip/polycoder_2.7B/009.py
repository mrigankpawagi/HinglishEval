from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """

    number_list = list(range(len(numbers)))
    for index, number in enumerate(number_list):
        if numbers[index] > number:
            number = -1
            break
    return number_list[::-1]

