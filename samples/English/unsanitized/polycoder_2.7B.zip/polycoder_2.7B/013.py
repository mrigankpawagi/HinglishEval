

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    n1 = a % 1000
    n2 = b % 1000
    if n1 == n2:
        return a // 1000
    result = a // 5*1000 + b
    while result > 1000:
        result, cant = divmod(result, 1000)
        result //= 1000
        n1, n2 = divmod(n1, 1000)
    return result
