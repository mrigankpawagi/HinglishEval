
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    
    def triangle_check(a, b, c):
        def inset(t, c, s):
            for j in range(1, s + 1):
                if abs( (a - t + j) * (b - c + j) ) < s:
                    return True
            return False
        if inset(b, a, c):
            return True
        if inset(b, b, c):
            return False
        if inset(c, a, b):
            return False
        if inset(c, c, b):
            return True
        if inset(c, a, c):
            return False
        return False
    if triangle_check(a, a, c) or \
        triangle_check(b, b, c) or \
        triangle_check(c, a, c):
        return True
    return False

