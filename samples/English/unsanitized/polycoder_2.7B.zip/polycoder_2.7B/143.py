
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    new_sentence = " ".join(sentence)
    new_sentence_len = len(sentence)

    letters = words = ""
    for i in range(0, len(new_sentence) + 1):
        letters += new_sentence[i]
        words = new_sentence_len - i
        for j in range(1, words + 1):
            if new_sentence_len - words - j <= 0:
                assert new_sentence_len - words - i <= len(new_sentence), "Sentence length of the sentence should equal the length of the original string."
                return new_sentence
            letters += new_sentence[words - j]

    # if it is not in this sentence, the sentence length of this sentence should be equal to the length of the original string
    assert (new_sentence_len - digits + 1 <= len(new_sentence)), "Sentence length of the sentence should equal the length of the original string."
  