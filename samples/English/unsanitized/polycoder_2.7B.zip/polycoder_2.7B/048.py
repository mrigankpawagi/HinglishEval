

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if not text:
        return False
    length = len(text)
    if length < 2:
        return bool(text == 'A'*length)
    letters = [c for c in range(ord('a'),ord('c')+1) if len(text[0:2][c]) == 2]
    if letters:
        return bool(re.search('[^A-Za-z]/', text[0:length-4]+text[0:length-1].lower()))
    return bool(text.lower() in text)

