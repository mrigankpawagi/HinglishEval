from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    sorted_numbers = sorted(numbers)
    ret = []
    cnt = 1
    while cnt < len(sorted_numbers):
        if sorted_numbers[cnt - 1] not in sorted_numbers[0:cnt]:
            del numbers[ret]
            ret.append(sorted_numbers[0:cnt])
            cnt += 1
        else:
            cnt += 1
            ret.append(cnt)
    return ret
