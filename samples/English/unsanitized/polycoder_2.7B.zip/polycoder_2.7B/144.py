
def simplify(x, n):
    """Your task is to implement a function that will simplify the expression
    x * n. The function returns True if x * n evaluates to a whole number and False
    otherwise. Both x and n, are string representation of a fraction, and have the following format,
    <numerator>/<denominator> where both numerator and denominator are positive whole numbers.

    You can assume that x, and n are valid fractions, and do not have zero as denominator.

    simplify("1/5", "5/1") = True
    simplify("1/6", "2/1") = False
    simplify("7/10", "10/2") = False
    """
    if n == '':
        if x == 1:
            return True
        if x == 0:
            return False
        _ = []
        for j in x:
            if j!= 1:
                _.append(j)
        return "".join(_)
    # This if statement will handle integer x and n if n == '':
    if n == '':
        if x in ['1', '2']: # we're only doing integer division
            return simplify(x)/simplify(n, '2')
        if x == '1':
            return simplify(n, '1')

    x, n = x.strip(), n.strip()
    if x == '0':
        return False
    if n.isdigit():
        return simplify(int(n), '1')
    for x0 in '0', x, '1', 1, '2', 2:
