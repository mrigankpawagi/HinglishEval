from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    def comparator(value):
        if value == 1.0:
            return 2.0
        elif value == 2.0:
            return 1.0
        else:
            return value

    def get_first_nearest_element_idx(numbers):
        idx = find_nearest_element(numbers, 0)
        return idx

    def get_nearest_element_at_idx(
        numbers: List[float], idx: int
    ) -> Tuple[int, float, int, int, float, int]:
        if idx == 0:
            return -1, -1, -1, -1, -1, -1
        return numbers[idx - 1], numbers[idx], idx - 1, idx - 1, idx - 1, idx

    res = get_nearest_element_at_idx(numbers, 0)
    res = comparator(res)
    return res[:1]

