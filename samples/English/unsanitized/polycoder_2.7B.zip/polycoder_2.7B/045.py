

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    # Area calculation using Tisberra's area calculation,
    # chapter 5, "Calculating area."
    if h <= 0.0:
        return 1.0
    elif h > 1.0:
        return 3.0
    if not 0 <= a < 2**30:
        raise ValueError('Argument may not be large', a, 2**30)
    # return sum( (x-b)^2 for x in (2)**n*log2(a) for n in (1,2,3,4,5)
    # where log2(a) is a log of a cosine and sinh(a) is a sinh(a) in
    # a mathematica formula, so 2**n=25
    # This formula is a slightly more precise formula for some circumstances
    # (for which it converges on values < 2) but has the unhelpful effect of
    # overflowing at 2**30*log2(a) for values in the interval [2**30,2**30+1]
    # and for values in other [2**30,2**30+1]?
    a = a - (floor(a + 0.5)
            )  # for roundoff errors, change sign to round up

    # area is actually 2*b + log a*cos(b) = a*b*log(a). The first
    # term is for special and inaccurate values of a. There's some
    # de-sync in that special terms do not fit with a.
    a2 = a * a  # cosh(a)
    a33 = a2 * a2  # cosh(2*a)
    area = a2*log