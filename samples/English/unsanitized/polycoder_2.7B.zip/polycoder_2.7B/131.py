
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    # digits(n), here n is an int
    if not isinstance(n, int):
        n += 1
    first = (n >> 21) & 0x7ff
    first = (((first) + (first << 3)) & 0x1fffff)
    second = ((n >> 10) & 0x3ff)
    r = first * 0x4000000
    for i in range(first, second):
        r = r + (((i) + (i << 10)) & 0x3ff)
    return r

