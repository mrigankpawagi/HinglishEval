
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    histogram = {}
    re = re.compile(r"(\w+)_[\d]+_(\d)(\w+)([.])?(\w+)")
    for (t, a, b, c) in test.split():
        d = a.split('_')
        aa = d[0]
        bb = d[1]
        cc = []
        for x in aa+bb+cc:
            cc += [sum([int(x) if re.match(regex) or isinstance(re.match(regex, x.strip()), int)]) for regex in r"([a-z]+_(\d)+(?:_[aeiou]+))"]+list(r"([a-z]+_(\d)+)\d+_?([a-z]+_(\d)+)"+dict.fromkeys(d[2:]))
        if aa == 'a':
            a = 0
            for x in bb+cc:
                a += int(x)
            a = sorted(a)[:aa]
        else:
     