
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    for i in range(len(x)-2,-2,-1):
        if x[i]+x[i+1] > x[i+1]:
            tmp = x[i+1]
            x[i+1] += x[i]+x[i]
            x[i] = tmp
    ret = []
    while len(x) > 1 and x[0] == x[1]:
        x = x[1:]
    while len(x) < len(x[1:]):
        if x[1] == 0:
            ret.append(x[0])
        else:
            ret.append(x[1] + x[0])
        x = x[2:]
    return ret
