
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    result = 0
    for subStr in s:
        c0 = ord(subStr[0])
        c1 = ord(subStr[1])
        c2 = ord(subStr[2])
        return sum( [c0-48, c1-48, c2-48] )
    return 0

