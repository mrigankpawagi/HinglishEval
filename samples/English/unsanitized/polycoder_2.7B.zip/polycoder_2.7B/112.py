
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    n = len(c)
    result1 = []
    for i in range(n):
        x = ""
        for k in range(n):
            x += c[k]
        x = x[::-1]
        x = x[:-1]
        if x in s:
            result1.append(x)
            if x!= '':
                break
    for i in range(n):
        x = ""
        for k in range(n):
            x += s[k]
        x = x[::-1]
        x = x[:-1]
        if x not in result1:
            return (result1,False)
        result1.append(x)
    return (result1,True)

