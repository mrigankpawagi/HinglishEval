 ```python

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = 'aeiouAEIOU'
    encoded_message = ''

    for char in message:
        if char in vowels:
            if char == 'a':
                encoded_message += 'c'
            elif char == 'e':
                encoded_message += 'g'
            elif char == 'i':
                encoded_message += 'k'
            elif char == 'o':
                encoded_message += 'q'
            elif char == 'u':
                encoded_message += 'w'
            elif char == 'A':
                encoded_message += 'C'
            elif char == 'E':
                encoded_message += 'G'
            elif char == 'I':
                encoded_message += 'K'
            elif char == 'O':
                encoded_message += 'Q'
            elif char == 'U':
                encoded_message += 'W'
        else:
            encoded_message += char.swapcase()

    return encoded_message

```