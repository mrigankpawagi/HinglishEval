 ```python

def max_fill(grid, capacity):
    import math
    wells = sum(row.count(1) for row in grid)
    return math.ceil(wells / capacity)

```