 ```python
def eat(number, need, remaining):
    total_eaten = number + remaining
    if total_eaten >= need:
        eaten = total_eaten - need
        remaining = need
    else:
        eaten = total_eaten
        remaining = 0
    return [eaten, remaining]
```