 ```python
def will_it_fly(q, w):
    if q == []:
        return True
    if q[0] > w:
        return False
    if q[0] == w:
        return will_it_fly(q[1:], w)
    return will_it_fly(q[1:], w - q[0])
```