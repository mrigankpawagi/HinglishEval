 ```python
def how_many_times(string: str, substring: str) -> int:
    count = 0
    while string.find(substring) != -1:
        count += 1
        string = string[substring.find(substring) + len(substring):]
    return count
```