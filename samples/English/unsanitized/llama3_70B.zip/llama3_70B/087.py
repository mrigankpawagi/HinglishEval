```
def get_row(lst, x):
    return sorted([(i, j) for i, row in enumerate(lst) for j, elem in enumerate(row) if elem == x], key=lambda x: (x[0], -x[1]))
```