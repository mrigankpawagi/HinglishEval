def words_string(s):
    s = s.replace(',', '')
    return s.split()