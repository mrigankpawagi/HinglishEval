

def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    # https://www.ipython.org/cgi-bin/ipython%2F-%3Fpython%3F%27jusy%27/postscript.py
    # (0, 3, 5) = [[ 0, 3, 5 ], [-1, -2, -3 ], [ 0, 0, 0 ], [ 0, 0, 0 ], [ 0, 0, 0 ]]
    # (0, 4, 3) = [( 0, 4, 3 ), [ 0, 0, 4, 4 ], [ 0, 0, 0, 4 ]]
    # (0, 3, 7) = [[ 1, 0, 0 ], [ 0, 1, 0 ], [ 0, 0, 1 ]]
    # (0, 7, 3) = [[ 0, 1, 0 ], [ 0, 0, 0 ], [ 0, 0, 0 ]]

    if not isinstance(l, list):
        return False

    for i in range(len(l)):
        try:
            (k, v, s) = l[i]
        except:
            return False
    return len(l) == 2 and v