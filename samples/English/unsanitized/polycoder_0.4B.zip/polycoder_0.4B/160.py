
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    if not isinstance(operand, list):
        raise TypeError('An operand argument may not be an list')

    if not isinstance(operator, list):
        raise TypeError('An operator argument may not be a list')

    # Basic algebra
    # Check the arguments.
    operator_list = operator[0] if operator == list
    operands_list = operand[0] if operand == list

    # Generate the algebra operator.
    if list(operator_list)!= list(operands_list):
        raise Exception('There is to different operators for each argument.')

    operators = operators_list[operator_list]
    operands = operands_list[operands_list[operator_list]]
    result = []
    if operands.size!= operator.size:
        raise Exception('The size of operand and operation can not be the same.')
    for op_index, op