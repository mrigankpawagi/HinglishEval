

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    # Note that the input is always digits with 7 bits of precision and a
    # small negative number which isn't a Number, so we should have
    # at least four digits.
    n = int(n)
    pow10 = pow10_for(n)
    if pow10 < 9:
        n -= pow10
        while pow10 < 9 and pow10!= 10:
            n -= pow10
            pow10 *= 2
        n += power10(pow10, 3)
    return int(n)

