

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    n = int(n)
    while 1:
        pow = 1
        while 1:
            e = n >> 1
            n = n - e
            pow = pow * pow
            if e == 0:
                break
        if pow > 1 and pow <= n:
            pow = pow * 1 + 1
            if pow > n:
                return pow
    return 1

