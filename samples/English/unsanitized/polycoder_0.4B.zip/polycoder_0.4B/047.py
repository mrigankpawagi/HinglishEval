

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    count = 0
    count2 = 0
    for el in l:
        count = count if count + sum(el) > l[count] else count2
        count2 = count
    count2 += sum(el)
    if count2 <= l[count]:
        return l[count]
    else:
        return max(l[count], 0)
