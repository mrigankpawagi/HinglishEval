
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    # TODO: This will just change our list
    if not lst:
        return 1
    elif len(lst) < 2:
        return 0
    else:
        return add(lst[0]) + add(lst[1])

