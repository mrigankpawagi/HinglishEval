
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    n = len(s)
    i = False
    for q in s[:n//2:n]:
        if q in s2:
            i = True
            break
        if q in s3:
            i = False
    if i:
        return 1
    return 0
