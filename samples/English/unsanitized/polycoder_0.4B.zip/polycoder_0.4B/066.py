
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """

    str = s.encode("ascii")
    if len(str) == 0: return 0

    c = str[0]
    if len(c) == 1 and ("0123456789ABCDEF" == c):
        return c.upper().count(c) - 4
    elif len(c.upper()) == 1: return str[0]
    else:
        return str.count(1, len(c) - 1)

