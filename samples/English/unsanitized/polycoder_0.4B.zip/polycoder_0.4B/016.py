

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    if string.isupper():
        return 0
    elif len(string) == 1:
        string = string.lower()
    elif (not string.startswith(" ") and string.endswith(" ")):
        return 0
    else:
        # not exact match (not empty str)
        return 1
