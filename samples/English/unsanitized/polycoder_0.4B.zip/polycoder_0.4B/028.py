from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    size = len(strings)
    result = ''
    for i, s in enumerate(strings):
        if i == 0:
            result += s
        else:
            result += s +''
        if i % size == 0:
            result += '\n'
    return result

