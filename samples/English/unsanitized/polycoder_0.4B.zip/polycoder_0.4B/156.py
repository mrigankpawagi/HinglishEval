
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    numbers = ["xox", "ixox", "ixoxo", "ixoxo", "ixoxu", "ixoxu",
               "xoxo", "xoxo", "xoxo", "xoxu", "xoxu", "ixo",
               "ixo", "i" * 19, "x", "x", "ix", "iix", "ixox", "ixoxy"]

    def _int_to_str(number):
        # convert the integer into lowercase
        return list(map(chr, number))

    # convert strings to lowercase
    return _int_to_str(int.from_bytes(number, byteorder='little',
                                      signed=True)
                      ).lower()
