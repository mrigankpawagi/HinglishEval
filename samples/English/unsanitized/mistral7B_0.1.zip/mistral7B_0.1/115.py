 ```python
def max_fill(grid, capacity):
    def dfs(i, j, visited, capacity):
        if i < 0 or i >= len(grid) or j < 0 or j >= len(grid[0]) or grid[i][j] == 0 or visited[i][j]:
            return 0
        visited[i][j] = True
        count = 0
        for k in range(-1, 2):
            for l in range(-1, 2):
                if k == 0 and l == 0:
                    continue
                d = (i + k) % len(grid)
                c = (j + l) % len(grid[0])
                if grid[d][c] == 1 and capacity > 0:
                    capacity -= 1
                    count += dfs(d, c, visited, capacity)
        visited[i][j] = False
        return count + 1
    n, m = len(grid), len(grid[0])
    visited = [[False] * m for _ in range(n)]
    return dfs(0, 0, visited, capacity)
```