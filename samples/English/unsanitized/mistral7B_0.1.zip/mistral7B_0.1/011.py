 ```python
from typing import List


def string_xor(a: str, b: str) -> str:
    return ''.join([chr(ord(c) ^ ord(d)) for c, d in zip(a, b)])
```