 ```python
def move_one_ball(arr):
    if not arr:
        return True
    
    for i in range(len(arr)):
        if arr[i] > arr[(i+1)%len(arr)]:
            break
        
    for j in range(i+1, len(arr)):
        if arr[j] < arr[i]:
            break
        
    if j == i+1:
        return True
    
    for k in range(i+1, len(arr)):
        if arr[k] > arr[i]:
            break
        
    for l in range(i, 0, -1):
        if arr[l] < arr[k]:
            break
        
    if l == i:
        return True
    
    return False
```