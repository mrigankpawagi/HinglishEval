 ```python
def multiply(a, b):
    a_digit = a % 10
    b_digit = b % 10
    return a_digit * b_digit
```