 ```python
def fruit_distribution(s, n):
    apples, oranges, mangoes = map(int, s.split())
    total = apples + oranges + mangoes
    return n - total
```