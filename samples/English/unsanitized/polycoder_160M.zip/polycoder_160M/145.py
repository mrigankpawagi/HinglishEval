
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    out = []
    for x in nums[::-1]:
        if x not in out and x > y[::-1]:
            out.append(x)
        n = int(x // 10)
        sum_n = 0
        for y in range(1, n + 1):
            tmp = sorted(out, reverse=True)
            for digit in out:
                tmp[digit] -= 1 if not x in tmp else x
            sum_n += len(tmp[digit])
            out += list(tmp)
        out.reverse()
        out = [order(x) for x in out]
    return out

