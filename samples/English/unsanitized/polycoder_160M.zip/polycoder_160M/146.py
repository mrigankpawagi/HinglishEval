
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    # Check all number
    if len(nums) % 2!= 0 and nums[0] in ('0', '0', 'd', 'd', 'M'):
        result = [nums[n] for n in range(1, len(nums)-1)]
    elif len(nums) == 1:
        sum = nums[0]
    else:
        if len(nums) == 2:
            sum = sum - 2
        if len(nums) == 3:
            sum = sum // 2
        if len(nums) * 2 > len(nums):
            result = [sum]
        else:
            num = nums[1]
            for j in range(len(nums)):
                if j > 1 or num % j!= 0:
                    result.append(num / nums[j])
                    num = num / j
    return result
    