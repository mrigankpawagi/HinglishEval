

def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    val = b"\x00" + encode_shift(s)
    s = b"".join([b(chr(2 ** i)) for i in range(len(s))])
    return s + val.encode("utf-8")

