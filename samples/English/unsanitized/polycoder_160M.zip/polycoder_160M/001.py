from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """

    def f_test(string: str, group: str) -> str:
        return group + string

    separated_paren_groups = [f_test, f_test]
    i = 0
    while i < len(separated_paren_groups):
        sep = separate_paren_groups[i]
        f_test(separated_paren_groups[i], sep)
        i += 1

    return separated_paren_groups

