
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    if not b.isneg() and not isinstance(b, (int, long)):
        return [a + b]

    if isinstance(a, (int, long)):
        return [a + b]

    # if a is an integer
    if isinstance(a, numbers.Integral):
        if b.isneg() and isinstance(a, types.Number):
            return [a + b]

    # for longs, use integer conversion
    elif isinstance(a, numbers.Long):
        if b.isneg() and isinstance(a, types.Number):
            if isinstance(a, types.Integer) and a.isneg():
                return [a + b]
        return [a + b]

    elif isinstance(a, str):
        if b.isneg() and isinstance(a, numbers.String):
            # If the string is an integer, check it for the length of a
            # Decimal (if negative) and return its length (if positive)
            return [(a + a.exp) & 15, (i + i.exp) & 15]
        return [a + b]

    return a
