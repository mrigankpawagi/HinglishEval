from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """

    for index in range(len(strings)):
        if prefixes[strings[index]]:
            continue
        if strings[index] not in prefix:
            strings.append(prefix)
        for char in strings[index]:
            if char not in prefixes[strings[index]]:
                strings[index] = '{}'
    return strings

