
def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    Examples:
    check_dict_case({"a":"apple", "b":"banana"}) should return True.
    check_dict_case({"a":"apple", "A":"banana", "B":"banana"}) should return False.
    check_dict_case({"a":"apple", 8:"banana", "a":"apple"}) should return False.
    check_dict_case({"Name":"John", "Age":"36", "City":"Houston"}) should return False.
    check_dict_case({"STATE":"NC", "ZIP":"12345" }) should return True.
    """
    try: 
        assert dict[0] == dict[0].lower(), tuple(dict[0].lower())
        assert dict[1] == dict[1].lower(), tuple(dict[1].lower())
        assert list(dict[0]) == [2, 3, 4, 5], tuple(dict[0])
        assert list(dict[1]) == [8], tuple(dict[1])
    except Exception as e: # pylint: disable=broad-except
        return False
