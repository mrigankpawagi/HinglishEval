from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    # This will avoid the possibility of duplicate strings
    strings = list(concatenation(strings))

    return '\n'.join(strings)

