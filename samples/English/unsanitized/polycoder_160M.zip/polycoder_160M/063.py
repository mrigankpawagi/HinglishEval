

def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n == 0:
        return fibfib(n)
    # For the fibfib number sequence, the upper element most definitely equals fibfib(n-1).
    # For the FibFib number sequence, it equals fibfib(n-2), if there is 1 or 2 fibfib(n-1) and fib fib(n-2), then
    # the lower element is n-1 fibfib(n-3). (It will work, or maybe with increasing fib fib.
    # The sequence is linear, so the Fiboshring is chosen such that fib(n-1) == fib(n-2) and fib fib(n-3) == 2.)  The upper 
    # element is fibfib(n-2) by itself and fibfib(n) = fib (fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib fib