

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    # remove vowel
    output = string.strip()
    try:
        return output.strip()
    except (AttributeError, ValueError, TypeError, AttributeError, NotImplementedError, ValueError):
        raise Exception("invalid input string '%s'" % output)


    # remove trailing space
    output = string.strip().strip('"').strip('"')
    # removing non-printable chars
    output = output.replace(" \\x00", "\x00")
    return string.ljust(strlen(output))

