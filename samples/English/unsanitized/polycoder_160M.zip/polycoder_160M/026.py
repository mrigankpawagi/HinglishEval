from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    new_keys = []
    for new_index in range(len(numbers) - 1, 0, -1):
        key = [numbers[i](new_index)]
        new_count = len(numbers)
        while key[-1][1] < new_index and key[1] > new_index and (len(numbers) - 1) < new_count:
            new_count = new_count * 2
        keys = sorted(list(key))
        new_keys.append(key)

        new_count = len(numbers)
        if len(new_count) < new_count:
            new_keys.extend([-1, key])

        # Now take the list element which would be lower
        # and take the second list element
        if len(new_keys) == new_count:
            break

    return list(new_keys)

