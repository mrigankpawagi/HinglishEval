

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    N = 10 ** n
    res_val = (0 * float(p) ** n)
    res_val |= (1 * (((n + 1) // 2) ** n) ** (n - 2))
    return (res_val * p) - 2 * res_val
