from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    result = []
    last_token = None

    def child_token(node):
        if next(node, lambda n, _, _next: last_token):
            last_token = n

        token = next(node, lambda token, _, _next: parentish(token, last_token))

        if last_token is not None:
            result.append(int(parentish(token, last_token)))

        else:
            result.append(last_token)

        if last_token is None:
            return result

        # Only if last_token is a string, then
        #   - If the parent expression is a list, then
        #     - Any level
        #   - Else the parent expression's last level
        elif next(node, lambda n, _, next: last_token).startswith('('):
            parentlevel = last_token[len('('):

            while node is not None and parentlevel not in node or (
                next(node