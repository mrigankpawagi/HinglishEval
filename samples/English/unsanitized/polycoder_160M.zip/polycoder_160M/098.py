
def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    with open(s) as infile:
        lines = infile.readlines()
    if len(lines) == 1:
        return len(lines[0])
    return 0

