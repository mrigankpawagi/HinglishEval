
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    # Don't boredom.
    if s == 'I':
        return False
    
    if s == '&':
        return not is_bored(S)
    elif len(S) == 1:
        return re.match('(?!I)(?i)'
                        '(?i)(?!(<br>\s+)Borns.)(?i)'
                        '(?i)(?<!I)(?i)'
                        '(?i)(?<br>\s+Borns.)(?i)')
    
    for w in [s for s in S] + ['.*', ']]
    
    return True
  
    
          
          

    
    
                          