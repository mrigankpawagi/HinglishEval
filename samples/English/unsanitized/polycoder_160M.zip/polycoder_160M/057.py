

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    i, j = imin()[:3], i
    return False if i + 0.5 >= j and i + 0.5 <= j and l[i] >= l[j]
    return True
