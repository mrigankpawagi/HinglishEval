
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    if not (hasattr(message, 'unicode') and isinstance(message, string_types)):
        message = {
            "unicode": "utf-8",
            "unicode_2": "UTF-16LE",
            "unicode_3": "UTF-16BE",
            "mixed": "Mixed",
            "mixed_2": "Mixed",
            "mixed_3": "Mixed",
            "mixed_4": "Mixed",
            "c": "c",
            "c_ext": "C_ext",
            "c_upper": "C_upper",
            "c_lower": "c_lower",
            "c_digit": "c_digit",
            "s": "S",
            "s_ext": "S_ext",
            "sword": "a",
            "sword_ext": "a_upper",
