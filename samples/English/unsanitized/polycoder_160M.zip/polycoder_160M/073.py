
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    if not arr:
        return 1
    arr = [arr]
    arr[1] * 7 - 1.25
    arr[2] * 7 - 2.05
    arr[4] * 7 - 4.9
    arr[5] * 7 - 7.4
    arr[6] * 7 - 2.5
    arr[7] * 5.5 - 5.2
    arr[8] * 3 - 7.2
    # Find next step in palindromic array
    for step in range(5):
        left, right, new_left_step, new_right_step, new_step = 0, 1, 0, step, 2, 1
        if arr[new_left_step] + arr[new_right_step] * 7 <= arr[left]:
            # The array has more elements (left = 12, right = 28, step = 6)
            for index, value in enumerate([arr[0], arr[new_left_step], arr[new_right_step], arr[left], arr[right], arr[new_step]], -1):
                # Don't allow this to be changed to either
      