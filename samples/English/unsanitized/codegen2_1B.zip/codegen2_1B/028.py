from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
)(� var(,poly++obK<mask_1>st(...ststproductvt),
�)textform(('),sc%var         In,,<mask_1>form<mask_45>handleinputvar++port�input,ODUCTsc<mask_1>vsformformob,portstvs%st#