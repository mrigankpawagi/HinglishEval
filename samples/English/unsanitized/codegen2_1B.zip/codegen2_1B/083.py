
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
(((form/polyportvarproduct/varpolyo((poly/++oba,vt�(<form varnodewisevtpolyhandle,has),ODUCT/stvtst<mask_1>ovt,has<mask_1>',�polyoportpoly)...hasvc(vt( var()o<mask_18>polyproductvarstory*varvsoform(),ob...#