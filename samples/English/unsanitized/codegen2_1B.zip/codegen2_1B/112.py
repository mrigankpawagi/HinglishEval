
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
<mask_1>vtwise++<mask_18>(%++ varvt(vtnodepoly/ovar%"),<mask_1>op Inst(port�vtvt,st),<mask_1>varvt,poly),vchandlevar/...poly)var/o,In,text),<mask_18>->',++stoIn(->(vt<mask_1>Objectvtport#