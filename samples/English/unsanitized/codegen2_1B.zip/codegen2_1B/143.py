
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
var(�o->scobwise,<mask_18>++vsinform),/ODUCTvanportpoly...polyform<mask_45>         st(in(has/obODUCT(formODUCTportIn++hop++/++)%'),handlevsproduct)(inODUCTvs,(formK),vt,vt//vt<,Invarstinput'),input<mask_18>vt',++)),<,o,ovarwise++,vs/portIn(vtobaObjectpolyin(var)(portwise<mask_18>)formst)++"),(o(polyvtpolyst'),scobform)/vc<vtstvsobaformvtob,),polyvt)obInstory(form)),handlevarODUCT++intext,port(         formvarinputvar)polyinputovt varst(),/
<mask_18>in),handle/vt/portovarvtformoOLvc(vt),wise(,var<mask_45>ODUCT(vttextob/in/vt,(),poly...,has'),vt)form(vtpolyvar(handlewisevt(</(
',-><mask_1>poly('),(),input),portformstpolyo<mask_45>portODUCT<form),st),'),#