

def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
,vcInportIn(form(++oba(/(,,Inpolyportvt         ODUCT)...ob)varvtport)port(oba/),'),))))port,(polyvt/ var,,var,wise/vt%forminput(),vcvar)�poly"),form,�,o,//formObject%polypolynode<mask_1>InKvarvt*<mask_1>ovco�poly,(handle(%((++poly#