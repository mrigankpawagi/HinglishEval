
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
vs,,++,),has(form<mask_1>in)',vtportvar<',,has),varform/vtpoly(vtODUCTpolyobvcODUCTvar%(portform/'),In%(productvtstpoly<("),%(vt(,,(vtobformvar(oobformformvt(<mask_52>)/owiseformvt,polyODUCTo(),...++,vt<mask_45>vtIn(++hasform�wise,polyIn,varpoly(,Inoforminc++stvarODUCT%polypolyobportformportvsvt<vt/%/(story(var,oIn(st(,,/(...polyvtformop(port�In(oincforminputInvt/has<mask_1>++vtform,var         <mask_18> varo varport),port'),stvar(/(<mask_18>%(op,(,<stformst"),Instory),vtformrequestpolyODUCT#