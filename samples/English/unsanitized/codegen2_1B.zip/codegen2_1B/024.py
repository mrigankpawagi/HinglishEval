

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
))productvc(),(<mask_18>,In/var...polynodeo<vt),product...,/In(,)<mask_1>,%),(vtvc++handle(),((,...("),,)node(st#