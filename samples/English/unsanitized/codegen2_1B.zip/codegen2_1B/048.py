

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
buttonstInObjectob%.../ovar"),<mask_1>ob,poly(varform,has,Inform,vs),%,vtstODUCT...st++(wiseincpolypolyhop(o#