
def minSubArraySum(nums):
    """
    Ek integer array nums diya gaya hai, usme se kisi bhi non-empty sub-array ka minimum sum dhundho.
    Udaharan
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # Write your code here.
    

# 2
def missingElement(nums):
    """
    Ek sorted integer array nums diya gaya hai. Usme se ek integer miss kar diya gaya hai. Uski
    value bhi aati hogi. Uss value dhundho.
    Udaharan
    missingElement([4, 5, 6, 7]) == 3
    missingElement([5, 6, 7, 8]) == 4
    """
    # Write your code here.
    

# 3
def canSum(targetSum, numbers):
    """
    Ek integer target sum and integer array numbers diya gaya hai. numbers array me numbers the
    jis target sum ke elements add karke target ke sum ki value mil jati ho.
    ek function make return karo jisme wo return karo ki aisa kesa array milta hai, aur ek bhi
    missing element nahi hai. Udaharan
    canSum(7, [2, 3]) == true
    canSum(7, [5, 3, 4, 7]) == true
    canSum(7, [2, 4]) == false
    canSum(8, [2, 3, 5]) == true
    """
    # Write your code here.


# 4
def canConstruct(targetWord, wordBank):
    """
    Ek string targetWord and string array wordBank diya gaya hai. aisa kaise array milta hai jo
    target ke word banay?
    Udaharan
    canConstruct("skateboard", ["o", "bo", "d", "s", "ka", "abo", "tb", "a", "sk", "t", "ea"])
    == true
    canConstruct("skateboard", ["sk", "bo", "d", "s", "ka", "abo", "tb", "a"])
    == false
    canConstruct("aaaa", ["a", "aa", "aaa"])
    == true
    canConstruct("dog", ["eat", "nat", "at"])
    == false
    """
    # Write your code here.


if __name__ == '__main__':
    print('1')
    nums = [84, 21, 1, 