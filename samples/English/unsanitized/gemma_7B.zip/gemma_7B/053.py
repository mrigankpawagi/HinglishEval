

def add(x: int, y: int):
    """
    Do numbers x aur y ko jodo
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return x + y


def sub(x: int, y: int):
    """
    Do numbers x aur y ko kam karo
    >>> sub(5, 2)
    3
    >>> sub(2, 2)
    0
    """
    return x - y
