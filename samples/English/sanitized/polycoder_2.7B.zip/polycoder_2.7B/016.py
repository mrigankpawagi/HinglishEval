

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    # http://stackoverflow.com/questions/482487/best-way-to-count-distinct-strings-in-python
    text = string.split()
    count = 0
    for c in text:
        if c in _SPECIALS:
            count += special_count(c)
        elif c and c.isalpha():
            count += letters_count(c)
        else:
            count += _COUNT
    return count

