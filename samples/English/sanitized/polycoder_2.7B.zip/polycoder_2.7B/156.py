
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    num = abs(number)
    if num <= 1000:
        return str(num) + 'i'

    r = (num // 1000)
    num %= 1000
    if num == 0:
        # do not output '10' because it would be interpreted as 'anything'
        return '10'
    if num % 10 == 0:
        return str(num) + 'i'
    return str((r + 1) % 10) + 'i'

