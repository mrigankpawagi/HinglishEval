
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    # write your code here
    m = len(arr)+1
    while 1:
        arr = [[0] * m] + arr
        m += 1
        if m > len(arr) and arr[m-1][0] == 0:
            m = len(arr)
        elif m < len(arr):
            break
    return arr[1][0]

