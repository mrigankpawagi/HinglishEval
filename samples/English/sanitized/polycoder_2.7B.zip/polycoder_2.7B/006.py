from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    depth = 0
    groups = []

    # depth = int(string[1:len(string) - 2])
    string = "(" + string[1:-1] + ")"

    while len(string) > 0 and not string.endswith(" ") and depth < PARAN_NEST_LIMIT:
        groups.append(depth)
        # string = string.replace(depth, " ").split(" ")
        if string[-1] == ")" and string[0]!= "":
            string = string[1:-1]  # cut parentheses from start to end
            groups.pop(-1)
        elif string[-1]!= ")":
            string = string[1:-1]  # cut parentheses from start to end
        else:
            depth += 1

    return sorted(groups)

