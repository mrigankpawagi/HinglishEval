from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    sum_x = 0.0
    sum_y = 0.0
    for i, x in enumerate(numbers):
        sum_x += x
        sum_y += sum([x - sum_x]) ** 2
    return float(sum_y) / len(numbers)

