

def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    _len = len(l)
    e = 0
    for elt in l:
        if elt > e:
            e = elt
            if e == _len:
                return e - 1
    return -1

