

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    base = int(math.floor(math.log10(base)))
    if x % 1!= 0:
        x = str(x) + '0'

    if x > '1' and x < '9':
        x=''
    if x!= base or x >= 10:
        return x

    n = int(x) + 1
    x = math.ldexp(x, n)
    if n == 0:
        return x

    res = -10
    while True:
        n = int(math.mod(n, 10))
        res *= 10
        n += n
        res += n
        if res < 0:
            break
    return "%d" % res
