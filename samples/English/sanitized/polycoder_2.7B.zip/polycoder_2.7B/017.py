from typing import List


def parse_music(music_string: str) -> List[int]:
    """ Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    not last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quater note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
 Omnipotent note
    if music_string == 'o':
        music_string = '(3)'
    # Quarter note
    elif music_string == 'o.':
        music_string = '(4.'
    # Half note
    elif music_string == '.':
        music_string = '(2)'
    # Quater note
    elif music_string == 'o.':
        music_string = '(1.3)'

    # A whole note
    if music_string.endswith('.'):
        music_string = ''
    # A half note
    elif music_string.endswith('.'):
        music_string =''.join(music_string[:-2])
    # A quater note
    elif music_string.endswith('.'):
        music_string = music_string[:-2] if music_string.endswith('.3') else''.join(music_string[:-2])
    return music_string.split('|')[0]
