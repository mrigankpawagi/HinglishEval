
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """
    if n < 1:
        return []
    # If n mod 2 is zero, then there are only odd numbers in the next level.
    if (n % 2 == 0):
        numbers = [n // 2 - 1, 2]
    # If n is even, then the odd numbers from the previous level are the next
    # odd number.  If n is odd, then the second last odd number is the last
    # even number.
    else:
        numbers = [[n % 2, n - 1], n - 1]
    return itertools.cycle(numbers)
