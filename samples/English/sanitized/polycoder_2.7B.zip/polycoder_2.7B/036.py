

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    total = 0
    total += int(math.floor(math.log((n % 10) + 1, 7)))
    total += int(math.floor(math.log(n % 10, 7)))
    total += int(math.log(10000, 15))
    return total

