
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if n == 0:
        return 0
    number_digits = [i for i, x in enumerate(reversed(range(0, int(pow(2, n-1)))) if x == 1)
                     or i + 1 <= n]
    return sum(number_digits) - 1

