
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    if not lst1 or not lst2: return lst1 or lst2
    if len(lst1)!= len(lst2): return lst1
    l = 0
    total = 0
    for i, lch in [(r.lower(), len(r)) for r in lst1]:
        for j, rch in [(r.lower(), len(r)) for r in lst2]:
            total += lch, total += rch
            if total >= len(l):
                return lst1[i:i]
    return lst1[0:0]

