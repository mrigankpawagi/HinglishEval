

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    if brackets == "":
        return False
    elif brackets[0]!= "<":
        return True
    else:
        return False if ((brackets[1] == "=" and brackets[2] == "<")
                        ,brackets[3] == ">>")
                        else True
