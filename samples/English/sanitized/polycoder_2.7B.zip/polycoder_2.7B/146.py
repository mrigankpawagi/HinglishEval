
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    if(nums.size == 0):
        return 0
    l = len(nums[0])
    m = len(nums[nums.size - 1])
    odd_num = (nums[0] + nums[nums.size - 1]) // 2
    if(odd_num < 100 or odd_num!= odd_num % 100):
        return 1
    odd_len = (l % 2) + odd_num + m
    return odd_len
