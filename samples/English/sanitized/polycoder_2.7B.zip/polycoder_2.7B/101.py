
def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    w = []
    for w_line in re.split(",|,", s):
        w_substrings = w_line.split()
        # the substrings should be the first entry of a tuple (name of the word, contents of the word)
        name, contents = w_substrings
        # and here we will just use the first word as our string because it
        # contains the name and contents of the word
        w.append(contents)
    else:
        # nothing in the string
        del w[:]
    return w

