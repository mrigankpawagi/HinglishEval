
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    def round_value(numeric):
        '''
        Returns nearest integer. If the value is 0, it is simply 0.
        If the value is equal to 0 and the current integer is lower than
        x, the current integer is returned. Otherwise, the current
        integer is returned.
        '''
        if value == 0:
            return 0
        if value == numeric:
            return value
        factor = math.ceil(math.sqrt(math.log(numeric)))
        lower = math.floor(numeric / factor)
        upper = math.ceil(numeric) / factor
        return lower

    closest = abs(value - math.floor(value)) // 2
    if value - closest > math.floor(closest):
        closest = round_value(closest)
    return closest

