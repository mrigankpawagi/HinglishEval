

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    substring = substring.strip()
    substring_len = len(substring)
    num_of_cases = int(math.ceil(string.count(substring)))
    i = num_of_cases - (substring_len - len(string))

    assert string % str[i] == 0, 'Please check if your string is a substring'
    if substring_len == 0:
        return num_of_cases

    i = num_of_cases - 1
    while substring[i:i+substring_len]!= substring:
        i -= 1

    return num_of_cases - i
