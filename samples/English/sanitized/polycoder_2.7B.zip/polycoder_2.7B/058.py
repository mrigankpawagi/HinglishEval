

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    if not l1 or not l2:
        return []
    first1 = l1 if not isinstance(l1, list) else [l1]
    last1 = l2 if not isinstance(l2, list) else [l2]
    common_list = defaultdict(list)
    for lst, cur in itertools.combinations(first1, last1):
        if not lst:
            continue
        if lst.__hash__() == cur.__hash__():
            common_list[0].append(lst)
        else:
            common_list[2].append(lst)
    merged_list = [list(a) for a in sorted(common_list[2], reverse=True)][1:]
    for lst in sorted(merged_list, reverse=True):
        if lst[0]!= lst[1]:
            return None
    reversed_lst = reversed(merged_list)
    for lst in reversed_lst:
        if lst[0]!= lst[1]:
            return None
    return merged_list

