

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    if string is None:
        return 0
    try:
        len = len(string)
    except TypeError:
        len = len(string)
        try:
            len += 1
        except Exception:
            raise TypeError('cannot compute strlen() of {}'.format(
                string or 'null'))
    return len

