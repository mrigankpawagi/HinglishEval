
def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    # we count the number of non-empty elements in the two lists without
    # taking any value of the counts in it, so each call is about 4 times faster
    # than counting the number of elements
    cnt = 0
    for i in range(len(lst2)):
        if lst1[i]!= lst2[i]:
            cnt += 1
    # return either "YES", "NO" or "no"
    if cnt % 2:
        return "YES"
    else:
        return "NO"

