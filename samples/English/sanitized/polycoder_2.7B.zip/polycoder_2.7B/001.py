from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    group_tokens = []
    in_parens = False

    for b in parens(paren_string):
        # If we encounter a paren in our token, move to the next token.
        if in_parens == True:
            in_parens = False
        # If we encounter a ')' in our token, add it to the group.
        if in_parens == False:
            if group_tokens:
                group_tokens.append(b)
            continue

        # If we encounter a '(' in our token, end the current group and move to the next token.
        if in_parens == True:
            in_parens = False
            if group_tokens:
                group_tokens[-1] += b
            continue

        # If we encounter neither '(' nor ')', the current group hasn't ended.
        if group_tokens:
            group_tokens.append(b)
       