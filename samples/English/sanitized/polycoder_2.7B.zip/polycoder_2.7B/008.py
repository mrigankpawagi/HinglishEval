from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    numbers = set(numbers)
    result = 0
    n = len(numbers)
    for i in range(n - 1, -1, -1):
        if result + numbers[i] + numbers[i + 1] == 0:
            result += numbers[i]
        else:
            product = 1
            for j in range(i + 1, n):
                product *= numbers[j] + numbers[j + 1]
            result = result + product
    return result, result

