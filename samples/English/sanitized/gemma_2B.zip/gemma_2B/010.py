

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    # longest palindrome that starts with given string
    palindrome_length = len(string)
    while palindrome_length % 2 == 0:
        if is_palindrome(string[palindrome_length//2:]):
            break
        palindrome_length -= 1
    # make the palindrome
    return string[:palindrome_length//2] + string[-palindrome_length//2:] + string