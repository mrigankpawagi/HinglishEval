
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.
    if the two lists have the same number of chars, return the first list.
    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''
    # your code here
    lst1 = lst1.sort()
    lst2 = lst2.sort()
    print(lst1, lst2)
    if len(set(lst1)) == len(set(lst2)):
        return lst2
    elif len(set(lst1)) < len(set(lst2)):
        a = sorted(lst2)
        return a
    else:
        a = lst1
        return a