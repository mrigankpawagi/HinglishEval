from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    # Write your code here.
    return [s[:n+1] for n in range(len(string))[::-1] for s in string.partition(string[n:])[1:]]