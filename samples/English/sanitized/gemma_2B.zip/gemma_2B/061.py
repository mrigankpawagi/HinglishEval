

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.
    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    # Write your code here.
    stack_lst = []
    for char in brackets:
        if char == '(':
            stack_lst.append(char)
        elif char == ')':
            if len(stack_lst) == 0:
                return False
            else:
                stack_lst.pop()
    return len(stack_lst) == 0
    # time: O(n), space: O(n)