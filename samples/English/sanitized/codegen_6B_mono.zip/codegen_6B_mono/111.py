
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """
    letters_map = {}
    l = set(c for c in test if c!='')
    for c in l:
        letters_map[c] = test.count(c)
    # return {key: max([test.count(key), test.count(key[::-1])])
    # if test.count(key) > test.count(key[::-1]) else test.count(key[::-1]) for key in l}
    return letters_map