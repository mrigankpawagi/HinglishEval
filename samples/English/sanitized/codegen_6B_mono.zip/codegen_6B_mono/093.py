
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = '.aeiouAEIOU'
    lower_char = 'abcdefghijklmnopqrstuvwxyz'
    upper_char = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    new_lower = []
    new_upper = []
    new = []
    for i, char in enumerate(message):
        if char in vowels:
            new.append(i-1)
            new_lower.append(lower_char[i-1])
            new_upper.append(upper_char[i-1])
        else:
            new.append(i)
            new_lower.append(lower_char[i])
            new_upper.append(upper_char[i])
    return ''.join([(lambda item: item[0] if item[1] == 'lower' else item[1])(char) if char in vowels else new[index] for index, char in enumerate(new_lower)]) + ''.join(new_upper)