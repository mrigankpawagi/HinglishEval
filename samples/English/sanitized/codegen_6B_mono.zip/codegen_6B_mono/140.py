
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    if len(text) == 0:
        return text
    if len(text) == 1:
        return text
    space = 0
    dash = 0
    new_str = []
    i = 0
    j = 0
    while i < len(text):
        if i + dash == len(text):
            new_str.append(text[i:i+1])
            break
        if text[i+dash] == " ":
            space = space + 1
            if space == 2:
                space = 0
                dash = dash + 1
                i = i + dash
                continue
        else:
            space = 0
        new_str.append(text[i])
        i = i + 1
    return "".join(new_str)