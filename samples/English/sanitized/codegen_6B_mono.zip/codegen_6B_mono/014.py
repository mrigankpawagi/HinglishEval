from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    substrings = enumerate(string, start=1)
    _, _, substrings = next(substrings)
    return [string[:end - 1] + substring for _, end, substring in substrings]