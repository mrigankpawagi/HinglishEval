from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    if not numbers:
        raise ValueError('Requires at least 1 input number')
    #
    # MAD can also be calculated using the following formula of n data points
    # MAD = sqrt((s^2 - 1) / (n-1))... e.g. MAD of [5, 3, 12, 1] = 2.0
    # MAD using the following formula => MAD = [mean(x) - x_mean] / sd(x)
    #
    x_mean = mean(numbers)
    var_squared = 0
    for num in numbers:
        var_squared += (num - x_mean) ** 2
    made = var_squared / (len(numbers) - 1)
    return sqrt(made)