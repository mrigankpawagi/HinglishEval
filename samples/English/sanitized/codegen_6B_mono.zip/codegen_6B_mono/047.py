

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    l2 = len(l)
    if l2 <= 2:
        if not l:
            return None
        else:
            return sum(sorted(l)) / l2
    else:
        l1 = l2 // 2
        if l2 % 2 == 0:  # even
            l2_1 = (l[l1] + l[l1 + 1])
            l_ = l2_1
        else:  # odd
            l2_1 = l[l1]
            l2_2 = l[l1 + 1]
            l_ = l2_1 if l1_2 <= l2_2 else l2_2
    return l_