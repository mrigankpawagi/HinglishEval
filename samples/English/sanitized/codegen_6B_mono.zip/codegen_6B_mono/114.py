
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # 1) Initialize the two pointers and the result array.
    minSubArraySum = -1
    left = 0
    right = len(nums) - 1
    sum = 0
    res = [sum]
    # 2) Traverse the array
    for i in range(right, left - 1, -1):
        sum += nums[i]
        cur_len = (right + 1) - i
        res.append(sum)
        minSubArraySum = min(minSubArraySum, res[cur_len])
    return minSubArraySum