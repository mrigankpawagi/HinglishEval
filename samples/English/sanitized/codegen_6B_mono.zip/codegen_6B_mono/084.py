
def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    def checkN(N):
        """Check if N is perfect powers"""
        if N == 1:
            return True
        if N % 2 == 0:
            return checkN(1) or checkN(N/2)
        return False
    def sumOfBinStr(N):
        """Return sumof the string digit"""
        # Initializing a counter
        count1 = 0
        # Applying the same as a string
        strN = str(N)
        for i in strN:
            count1 += int(i)
        return count1
    ans = ""  # initialize result
    if checkN(N) and 1 < N <= 10:  # check if the input is a perfect powers
        result = sumOfBinStr(N)
        ans = str(result)
    elif N <= 1:  # boundary condition
        ans = "0"
    else:  # N < 10
        x = 2
        N_ = int(N)
        while 3 * x <= N_:
            x = x**2 * 10
            ans += "1"  # adding 1 for the loop
            result = 0
            # adding the result in every position of loop 
            for i in range(len(ans)):
                result += int(ans[i])
            ans = str(result)  # converting the result to string
    return ans