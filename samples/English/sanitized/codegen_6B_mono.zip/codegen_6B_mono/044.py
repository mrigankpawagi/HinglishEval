

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    res = ""
    n = x
    while n > 0:
        resta = n % base
        if resta < 10:
            res += str(resta)
        else:
            res += chr(ord('A') + resta - 10)
        n = n // base
    return res[::-1]