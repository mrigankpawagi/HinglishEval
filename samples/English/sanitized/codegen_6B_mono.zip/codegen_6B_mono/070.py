
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.
    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    if not lst:
        return []
    def _strange_sort(lst):
        if len(lst) <= 1:
            return lst
        _max = max(lst)
        _min = min(lst)
        return _strange_sort([n for n in lst if n > _min]) + [_min] + \
               _strange_sort([n for n in lst if n < _max]) + [_max]
    return _strange_sort(lst)