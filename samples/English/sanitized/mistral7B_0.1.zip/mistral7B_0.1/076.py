
def is_simple_power(x, n):
    if n**int(n) == x:
        return True
    else:
        return False