
def int_to_mini_roman(number):
    roman_dict = {
        1: 'i',
        5: 'v',
        10: 'x',
        50: 'l',
        100: 'c',
        500: 'd',
        1000: 'm'
    }
    result = ''
    while number > 0:
        if number in roman_dict:
            result += roman_dict[number]
            number -= roman_dict[number]
        else:
            result += '?'
            number -= 1
    return result.lower()