
def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    """
    fib_sequence = [0, 1]
    primes = [2]
    while len(primes) < n:
        next_fib = fib_sequence[-1] + fib_sequence[-2]
        if is_prime(next_fib):
            primes.append(next_fib)
        fib_sequence.append(next_fib)
    for fib in fib_sequence[n-1:]:
        if fib_sequence.count(fib) == 1 and fib_sequence.index(fib) + 1 == fib_sequence.index(fib - 1) + 2:
            return fib