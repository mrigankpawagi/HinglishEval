
def closest_integer(value):
    value = float(value)
    closest_int = int(value)
    if abs(value - closest_int) > abs(value - (closest_int + 1)):
        closest_int += 1
    if abs(value - closest_int) > abs(value - (closest_int - 1)):
        closest_int -= 1
    return closest_int