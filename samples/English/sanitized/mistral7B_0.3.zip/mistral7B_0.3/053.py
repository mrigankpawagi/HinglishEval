
def add(x: int, y: int) -> int:
    return x + y