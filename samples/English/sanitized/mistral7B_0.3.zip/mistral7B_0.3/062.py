
def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
     Return derivative of this polynomial in the same form.
    """
    result = []
    for i in range(1, len(xs)):
        coefficient = xs[i]
        power = i
        new_coefficient = coefficient * power
        result.append(new_coefficient)
    result.insert(0, 0)  # Add 0 as the coefficient for x^0 (constant term)
    return result