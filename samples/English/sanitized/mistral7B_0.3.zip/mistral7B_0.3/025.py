
from typing import List

def is_prime(n: int) -> bool:
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def factorize(n: int) -> List[int]:
    factors = []
    primes = sieve_of_eratosthenes(n)
    i = 0
    while i < len(primes) and primes[i] * primes[i] <= n:
        if n % primes[i] == 0:
            count = 1
            while n % primes[i] == 0:
                n //= primes[i]
                count += 1
            factors.append(count * primes[i])
        i += 1
    if n > 1:
        factors.append(n)
    return factors