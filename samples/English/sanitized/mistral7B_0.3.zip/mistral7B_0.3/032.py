
def find_zero(xs: list):
    if len(xs) % 2 != 0:
        raise ValueError("xs must have an even number of coefficients")
    n = len(xs) // 2
    coeff = xs[n]
    root = -xs[n - 1] / (2 * coeff)
    return root if coeff != 0 else None