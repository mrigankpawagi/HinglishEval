
def select_words(s, n):
    words = s.split()
    result = [word for word in words if len([letter for letter in word if not letter.isalpha() or letter.islower()]) == n]
    return result