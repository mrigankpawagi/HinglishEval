
def make_palindrome(string: str) -> str:
    def is_palindrome_suffix(suffix: str) -> bool:
        return suffix == suffix[::-1]
    def find_longest_palindrome_suffix(string: str) -> str:
        max_length = len(string)
        max_palindrome = ''
        for i in range(1, max_length + 1):
            if is_palindrome_suffix(string[-i:]):
                if len(max_palindrome) < len(string[-i:]):
                    max_palindrome = string[-i:]
        return max_palindrome
    def find_prefix(string: str, palindrome_suffix: str) -> str:
        return string[:len(string) - len(palindrome_suffix)]
    palindrome_suffix = find_longest_palindrome_suffix(string)
    prefix = find_prefix(string, palindrome_suffix)
    return prefix + palindrome_suffix[::-1]