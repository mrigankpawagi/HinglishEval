
def sort_array(arr):
    def count_ones(num):
        return bin(num).count('1')
    def sort_by_ones_and_then_decimal(a, b):
        ones_a = count_ones(a)
        ones_b = count_ones(b)
        if ones_a < ones_b:
            return -1
        elif ones_a > ones_b:
            return 1
        else:
            return a - b
    sorted_arr = sorted(arr, key=count_ones, reverse=True)
    sorted_arr.sort(key=sort_by_ones_and_then_decimal)
    return sorted_arr