
def words_in_sentence(sentence):
    words = sentence.split()
    primes = [2]
    for i in range(3, 101):
        if all(i % j != 0 for j in range(2, int(i**0.5) + 1)):
            primes.append(i)
    result = ' '.join(word for word in words if len(word) in primes)
    return result