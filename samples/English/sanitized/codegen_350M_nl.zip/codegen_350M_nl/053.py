

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    print "Add ", x, y, " to ", x+y, "."
    addx(x+y, x, y)
    yield x, y