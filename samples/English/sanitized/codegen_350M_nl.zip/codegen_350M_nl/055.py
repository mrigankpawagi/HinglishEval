

def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    a, b = (f)
    result = -1
    n = n - a
    if n % 2 == 0:
        n += b
    n += b + b
    while n!= n + b:
        n -= b
    return n