
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    cmp_string = "Hello"
    m_primelength = sum(len(c) for c in string.split())
    return prime_length(cmp_string) == prime_length(string)