
def search(lst):
    freq = {}
    for num in lst:
        freq[num] = freq.get(num, 0) + 1
    for num in freq:
        if freq[num] >= num:
            return num
    return -1