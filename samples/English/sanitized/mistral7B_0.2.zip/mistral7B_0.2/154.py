
def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word"""
    def rotate(string, n):
        return string[-n:] + string[:-n]
    for i in range(len(b)):
        if b[i:] in a or rotate(b[i:], len(b[i:])) in a:
            return True
    return False