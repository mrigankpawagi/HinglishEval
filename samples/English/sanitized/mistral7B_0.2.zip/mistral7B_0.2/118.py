
def get_closest_vowel(word):
    vowels = "aeiouAEIOU"
    index = len(word)
    for i in range(len(word) - 1, -1, -1):
        if word[i] not in vowels:
            continue
        for j in range(i, len(word)):
            if word[j] not in vowels:
                index = j
                break
        else:
            return word[i]
    return ""