
def reverse_delete(s, c):
    s = s.translate(str.maketrans("", "", c))  # Remove characters in c from s
    return s, ispalindrome(s)  # Check if the result string is palindrome