
def compare_one(a, b):
    # Compare the types and convert strings to floats if necessary
    if isinstance(a, str) and isinstance(b, (int, float)):
        a = float(a.replace(',', '.'))
    elif isinstance(a, (int, float)) and isinstance(b, str):
        b = float(b.replace(',', '.'))
    # Compare the values and return the larger one
    if a > b:
        return a
    elif a < b:
        return b
    else:
        return None