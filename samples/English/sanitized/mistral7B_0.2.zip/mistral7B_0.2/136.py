
def largest_smallest_integers(lst):
    negatives = [i for i in lst if i < 0]
    positives = [i for i in lst if i > 0]
    if not negatives and not positives:
        return None, None
    if negatives:
        return min(negatives), None
    return None, max(positives)