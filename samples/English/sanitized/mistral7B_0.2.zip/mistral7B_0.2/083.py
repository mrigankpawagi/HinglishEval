
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    def count_starts_ones(n):
        if n == 0:
            return 0
        return int(str(10 ** n - 10 ** (n - 1)) / 10) + count_starts_ones(n - 1)
    def count_ends_ones(n):
        if n == 0:
            return 1
        return 10 * count_ends_ones(n - 1) + int(str(10 ** n) % 10 == 1)
    return count_starts_ones(n) + count_ends_ones(n)