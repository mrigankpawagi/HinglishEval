
import math

def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    index1 = planets.index(planet1)
    index2 = planets.index(planet2)
    if index1 < 0 or index2 < 0 or index1 >= len(planets) or index2 >= len(planets):
        return tuple()
    orbit_dif = abs(math.fabs(planets_orbits()[index1]) - math.fabs(planets_orbits()[index2]))
    result = [planets[i] for i in range(len(planets)) if abs(math.fabs(planets_orbits()[i]) - math.fabs(planets_orbits()[index1])) <= orbit_dif]
    return tuple(sorted(result, key=planets.index))