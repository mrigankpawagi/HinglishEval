
def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    Returns:
        The largest divisor of the given number n.
    """
    return int(n ** 0.5)