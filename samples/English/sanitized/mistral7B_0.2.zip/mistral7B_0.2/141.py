
import re

def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    """
    pattern = r'^[a-zA-Z][a-zA-Z0-9._-]*\.(txt|exe|dll)$'
    if re.match(pattern, file_name):
        return 'Yes'
    else:
        return 'No'