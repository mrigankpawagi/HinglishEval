
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.
    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    def is_valid_brackets(subsequence):
        stack = []
        for bracket in subsequence:
            if bracket == '[':
                stack.append(bracket)
            elif bracket == ']':
                if not stack or stack.pop() != '[':
                    return False
        return not stack
    return any(is_valid_brackets(seq) for seq in re.findall(r'\[(.*?)\]', string))