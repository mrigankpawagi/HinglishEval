
def prod_signs(arr):
    if not arr:
        return None
    magnitudes = [abs(i) for i in arr]
    signs = [1 if i > 0 else -1 for i in arr]
    return sum(magnitudes) * functools.reduce(lambda x, y: x * y, signs)