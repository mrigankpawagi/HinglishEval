
def encrypt(s):
    shift = 2
    encrypted_string = ""
    for char in s:
        if char.isalpha():
            ascii_value = ord(char)
            if char.islower():
                encrypted_string += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            else:
                encrypted_string += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        else:
            encrypted_string += char
    return encrypted_string