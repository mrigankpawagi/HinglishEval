
def get_closest_vowel(word):
    vowels = "aeiouAEIOU"
    result = ""
    for i in range(len(word)-2):
        if word[i] in vowels and word[i+1] in vowels:
            result = word[i]
            break
    return result