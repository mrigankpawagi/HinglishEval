


def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    """
    def is_palindrome_helper(string: str) -> bool:
        """ Helper function to check if a string is a palindrome """
        return string == string[::-1]
    def longest_palindrome_postfix(string: str) -> str:
        """ Helper function to find the longest palindrome postfix of a string """
        if len(string) == 0:
            return ''
        else:
            max_length = 1
            for i in range(1, len(string)):
                if is_palindrome_helper(string[i:]) and len(string[i:]) > max_length:
                    max_length = len(string[i:])
            return string[i:]
    def reverse_string_prefix(string: str) -> str:
        """ Helper function to reverse a string prefix """
        if len(string) == 0:
            return ''
        else:
            return string[::-1]
    def make_palindrome_helper(string: str) -> str:
        """ Helper function to make a string a palindrome """
        postfix = longest_palindrome_postfix(string)
        prefix = reverse_string_prefix(string[:len(string) - len(postfix)])
        return prefix + postfix
    return make_palindrome_helper(string)