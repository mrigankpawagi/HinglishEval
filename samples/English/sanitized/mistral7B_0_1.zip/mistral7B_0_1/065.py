
def circular_shift(x, shift):
    x = str(x)
    shift = int(shift)
    x = x[1:] + x[0]
    return x[1:] + x[0] if shift < len(x) else x[::-1]