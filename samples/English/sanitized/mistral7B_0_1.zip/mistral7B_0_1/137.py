
def compare_one(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if a > b:
            return a
        else:
            return b
    elif isinstance(a, str) and isinstance(b, str):
        if a > b:
            return a
        else:
            return b
    else:
        return None