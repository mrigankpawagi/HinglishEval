
def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    """
    def convert(num, base):
        result = ""
        while num != 0:
            num, remainder = divmod(num, base)
            result += str(remainder)
        return result[::-1]
    return convert(x, base)