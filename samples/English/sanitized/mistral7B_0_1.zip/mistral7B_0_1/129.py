
def minPath(grid, k):
    def dfs(x, y, visited, path):
        if visited[x][y] or x < 0 or x >= len(grid) or y < 0 or y >= len(grid[0]):
            return
        visited[x][y] = True
        path.append(grid[x][y])
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nx, ny = x + dx, y + dy
            dfs(nx, ny, visited, path)
        visited[x][y] = False
        path.pop()
    visited = [[False] * len(grid[0]) for _ in range(len(grid))]
    path = []
    dfs(0, 0, visited, path)
    return sorted(path)