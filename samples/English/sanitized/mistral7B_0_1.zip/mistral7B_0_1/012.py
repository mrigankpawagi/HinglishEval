
def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    max_len = len(strings[0])
    for s in strings:
        if len(s) > max_len:
            max_len = len(s)
    return strings[0] if max_len == len(strings) else None