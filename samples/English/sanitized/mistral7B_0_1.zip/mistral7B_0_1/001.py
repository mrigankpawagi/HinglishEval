
from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    stack = []
    result = []
    for char in paren_string:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack or stack.pop() != '(':
                raise ValueError("Unbalanced parentheses")
            result.append(''.join(stack))
            stack = []
        else:
            raise ValueError("Invalid character in parent string")
    if stack:
        raise ValueError("Unbalanced parentheses")
    result.append(''.join(stack))
    return result