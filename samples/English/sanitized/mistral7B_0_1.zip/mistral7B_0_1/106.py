
def f(n):
    result = []
    for i in range(n):
        if i % 2 == 0:
            result.append(1)
            for j in range(1, i+1):
                result.append(result[j-1] * j)
        else:
            result.append(0)
            for j in range(1, i+1):
                result.append(result[j-1] + j)
    return result