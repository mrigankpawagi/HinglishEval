
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    def _parse_nested_parens(paren_string: str, depth: int = 0) -> List[int]:
        if not paren_string:
            return []
        if paren_string[0] == '(':
            depth += 1
            result = _parse_nested_parens(paren_string[1:], depth)
            result.append(depth)
            return result
        elif paren_string[0] == ')':
            depth -= 1
            result = _parse_nested_parens(paren_string[1:], depth)
            return result
        else:
            return []
    return _parse_nested_parens(paren_string)