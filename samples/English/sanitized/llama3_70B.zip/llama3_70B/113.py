
def odd_count(lst):
    return [f"the number of odd elements {sum(int(digit) % 2 for digit in s)}n the str{sum(int(digit) % 2 for digit in s)}ng {i+1} of the {i+1}nput." for i, s in enumerate(lst)]