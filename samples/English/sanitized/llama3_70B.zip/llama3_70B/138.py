
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    for a in range(2, n, 2):
        for b in range(a, n, 2):
            for c in range(b, n, 2):
                for d in range(c, n, 2):
                    if a + b + c + d == n:
                        return True
    return False