
def minPath(grid, k):
    from itertools import product
    from heapq import heappop, heappush
    N = len(grid)
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    pq = [(grid[0][0], 0, 0, [grid[0][0]])]
    visited = {(0, 0)}
    while pq:
        val, x, y, path = heappop(pq)
        if len(path) == k:
            return path
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < N and 0 <= ny < N and (nx, ny) not in visited:
                visited.add((nx, ny))
                heappush(pq, (val + grid[nx][ny] / (10 ** (k - len(path))), nx, ny, path + [grid[nx][ny]]))