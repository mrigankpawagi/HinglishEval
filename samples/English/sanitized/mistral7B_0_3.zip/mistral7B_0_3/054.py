
def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    """
    set_s0 = set(s0)
    set_s1 = set(s1)
    return set_s0 == set_s1 or set_s1 == set_intersection(set_s0, set_s1)