
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def is_even(num):
        return num % 2 == 0
    def is_sum_of_four_evens(num, evens):
        return num == sum(evens) and len(evens) == 4 and all(is_even(e) for e in evens)
    if n < 4:
        return False
    evens = set(range(2, n + 1))
    for e1 in evens:
        evens.remove(e1)
        for e2 in evens:
            evens.remove(e2)
            for e3 in evens:
                evens.remove(e3)
                for e4 in evens:
                    if is_sum_of_four_evens(n, [e1, e2, e3, e4]):
                        return True
    return False