
def get_row(lst, x):
    results = []
    for i, row in enumerate(lst):
        for j, val in enumerate(row):
            if val == x:
                results.append((i, j))
    results.sort(key=lambda x: x[0])
    for i in range(len(results)):
        for j in range(i, len(results)):
            if results[i][1] == results[j][1]:
                results[i], results[j] = results[j], results[i]
                results[j][1] -= 1
    return results