
def change_base(x: int, base: int) -> str:
    digits = "0123456789ABCDEF"
    result = []
    while x:
        x, remainder = divmod(x, base)
        result.append(digits[remainder])
    return "".join(result[::-1])