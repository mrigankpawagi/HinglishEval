
def numerical_letter_grade(grades):
    letter_grades = ['E', 'D+', 'D', 'D-', 'C+', 'C', 'C-', 'B-', 'B', 'B+', 'A-', 'A', 'A+']
    grades = [round(g, 2) for g in grades]
    result = [letter_grades[i] for i in range(len(letter_grades)) if grades[i] > grades[i - 1]]
    result.append(letter_grades[-1])
    return result