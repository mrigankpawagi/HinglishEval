
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    # Base case: when n is 1, there is only one number (1) that starts or ends with 1
    if n == 1:
        return 1
    # Recursive case: for n > 1, we have two possibilities:
    # 1. The number starts with 1, and the remaining (n-1) digits can be any number (0-9)
    # 2. The number ends with 1, and the remaining (n-1) digits can be any number (0-9), except for the case where the number is 10^(n-1) (since it doesn't end with 1)
    return 10 * starts_one_ends(n - 1) + (9 * starts_one_ends(n - 1) if n > 1 else 0) - (1 if n == 1 else 0)