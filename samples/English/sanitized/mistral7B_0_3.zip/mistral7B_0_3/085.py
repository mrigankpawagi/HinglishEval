
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices.
    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    return sum(i for i, index in enumerate(lst) if index != len(lst) and i != len(lst) // 2 and i % 2 == 1 and i % 2 == lst[i] % 2)