
def max_fill(grid, capacity):
    import math
    total_water = sum(sum(row) for row in grid)
    num_fills = math.ceil(total_water / capacity)
    return num_fills * len(grid) if total_water else 0