
def file_name_check(file_name):
    dot_index = file_name.find('.')
    if dot_index == -1 or dot_index == 0:
        return 'No'
    before_dot = file_name[:dot_index]
    after_dot = file_name[dot_index + 1:]
    if not before_dot[0].isalpha() or not after_dot in ['txt', 'exe', 'dll']:
        return 'No'
    digit_count = sum(c.isdigit() for c in before_dot)
    if digit_count > 3:
        return 'No'
    return 'Yes'