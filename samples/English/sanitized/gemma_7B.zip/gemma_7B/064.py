
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """
    Aur test cases jodo.
    """
    return len(s) - s.replace("a", "").replace("i", "").replace("o", "").replace("u", "").replace("e", "")