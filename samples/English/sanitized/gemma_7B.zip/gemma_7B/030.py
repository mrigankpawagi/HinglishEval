

def get_positive(l: list):
    """
    List mein se sirf positive numbers return karo.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    # positive list mein bhar lo
    positive = []
    # loop karo
    for num in l:
        # agar positive number hai, to yehi add karlo in positive list mein
        if num > 0:
            positive.append(num)
    # positive list ko yehi return karo
    return positive