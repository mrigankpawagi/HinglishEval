
def largest_smallest_integers(lst):
    """
    Ek function banao jo ek tuple (a, b) return kare, jahan 'a' negative integers ka sabse bada hai, aur 'b' positive integers ka sabse chota hai ek list mein.
    Agar koi negative ya positive integers nahi hai, to unhe None ke roop mein return karo.
    Udaharan:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    """
    neg_int = None
    pos_int = None
    for i in lst:
        if neg_int is None and i < 0:
            neg_int = i
        elif neg_int is not None and i < neg_int:
            neg_int = i
        if pos_int is None and i > 0:
            pos_int = i
        elif pos_int is not None and i > pos_int:
            pos_int = i
    if neg_int is None and pos_int is None:
        return None, None
    else:
        return neg_int, pos_int