

def how_many_times(string: str, substring: str) -> int:
    """
    Mool string mein diye gaye substring ko kitni baar mila ja sakta hai, yeh find karo. Overlapping cases ko bhi count karo.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    string_length = len(string)
    substring_length = len(substring)
    count = 0
    length_to_compare = min(string_length, substring_length)
    for starting_index in range(len(string)):
        current_index = starting_index
        found = True
        while found and current_index - starting_index <= length_to_compare - 1:
            current_index += 1
            if string[current_index - 1] != substring[current_index - starting index]:
                found = False
        count += 1 if found else 0
    if string == substring and string:
        return count + 1
    return count