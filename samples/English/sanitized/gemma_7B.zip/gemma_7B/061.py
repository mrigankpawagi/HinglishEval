

def correct_bracketing(brackets: str):
    """
    brackets ek string hai "(" aur ")" ka.
    return True agar har opening bracket ka ek corresponding closing bracket ho.
    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    "*** YOUR CODE HERE ***"
    stack = []
    for opening in brackets:
        if opening == "(":
            stack.append(opening)
        elif stack.pop() != "(":
            return False
    return True
    # return brackets.count('(') + brackets.count(')') == len(brackets) 