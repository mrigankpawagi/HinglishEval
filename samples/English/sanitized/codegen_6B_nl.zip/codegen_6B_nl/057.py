

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    l2 = [len(u) for u in l]
    ix = 1
    for i, j in zip(l2[::2], l2[1::2]):
        if i < j:
            break
        ix += 1
    return ix > 1