
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    result = []
    if shift > len(x):
        shift = len(x) - shift
    # Reverse to get result in forward order
    x = reverse(x)
    for i in range(shift):
        result.append(0)
    if shift > 0:
        if i < len(x) - 1:
            x = x[1:] + [0] * (len(x) - i - 1) + x[0]
        result = result[::-1] + x
    return join(result)