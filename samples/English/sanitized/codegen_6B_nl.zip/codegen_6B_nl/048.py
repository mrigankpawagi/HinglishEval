

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    text = text.lower()
    for i in range(len(text) - 1):
        for j in range(0, len(text) - i - 1):
            if text[i]!= text[j]:
                return False
    return True