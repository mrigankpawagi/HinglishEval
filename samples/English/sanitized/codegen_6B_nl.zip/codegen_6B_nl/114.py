
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    if len(nums) <= 1:
         return 100000000
    s2 = 0
    m = (len(nums) - 1) // 2
    for i in range(len(nums) // 2):
         for j in range(m+1, len(nums)):
             if ((i >= m) and (nums[i] == nums[j])):
                 s += nums[j]
                 j -= m+1
                 if j < 0:
                     q = 0
                 else:
                     q = m
    if q == 0:
        return -6
    s2 = S2
    for k in range(q+1):
        S2 += nums[m] + nums[m+k] + nums[m] + nums[m+k+1]
    return s2+minSubArraySum(nums[m+1:-m-1:-1])