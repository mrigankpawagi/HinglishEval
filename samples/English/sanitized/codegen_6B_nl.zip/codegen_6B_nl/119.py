
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.
    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    lst_p  = []
    lst_c   = []
    if not isinstance(lst, (list, tuple)):
        return 'No'
    len_l   = len(lst)
    for index, el in enumerate(lst):
        if isinstance(el, str):
            lst_p.append(el)
        else:
            break
        # find the beginning of the next one
        start_index = index + 1
        index = start_index
        while index < len_l and isinstance(lst[index], str):
            index = index + 1
        while index >= 1 and isinstance(lst[index - 1], str):
            index = index - 1
        if index >= 1:
            lst_c