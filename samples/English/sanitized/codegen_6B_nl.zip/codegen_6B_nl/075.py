
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    try:
        a_prime_numbers = [3, 5] # [2, 3, 5]
    except (ValueError):
        print("You cannot divide by 0!") # "You cannot divide by 0!"
        sys.exit()
    a_multiples = list(map(int, [30] + 
                                      [a_prime_numbers, a_prime_numbers * a_prime_numbers,
                                       a_prime_numbers * a_prime_numbers * a_prime_numbers,
                                       a_prime_numbers * a_prime_numbers * a_prime_numbers * a_prime_numbers]))
    if a_multiples == [] or (len(a_multiples) > 1 and sum(a_multiples) < 100):
        return True
    return False)