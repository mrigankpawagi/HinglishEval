
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    # replace the first space in the string with the character we will "fix"
    fixed_str = text.replace(" ", "_")    
    fixed_str = re.sub(r"\s+", "_", fixed_str) # replace consecutive spaces with _ (underline)
    fixed_str = re.sub(r"([a-z])\s{2,}",
        r"\1_\1", fixed_str) # replace more than 2 consecutive spaces with _ (underline)
    return fixed_str