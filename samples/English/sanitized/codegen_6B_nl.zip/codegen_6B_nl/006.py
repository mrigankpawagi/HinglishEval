from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    try:
        input_str = paren_string.replace('_','').replace(',', '(').replace(')', ')')
    except ValueError as e:
        raise ValueError(f"Invalid input: `{paren_string}`."\
                         f"Try to use '_', ',' or ')' characters.") from e
    try:
        groups = [input_str.split('(', -1)]
    except ValueError:
        return []
    if groups[-1] == ')':
        return groups[:-1]
    while len(groups[:-1]) > 0:
        nested_parens = parse_nested_parens(groups[-1])
        return [max(nested_parens)] + groups + nested_parens
    return groups