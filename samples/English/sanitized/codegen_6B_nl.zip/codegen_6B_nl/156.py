
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000
    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    if number <= 1 or number > 1000:
        raise ValueError('Cannot convert number %s because it is out of bounds' % number)
    roman_nums = set((i, i) for i in range(5, 0, -1)) to create a set containing
                    the roman numeral for 1-5 only
    num_parts = int(math.log(number, 1000)) + 1 if number > 1 else 1
    for a in range(num_parts, 0, -1):
        last_number = 1000 + a - 1
        for r in xrange(4, 0, -1):
            if number % last_number == 0 or number / last_number == r:
                num_range = last_number + 1 to number // last_number
                if number % num_range == 0 or number / num_range == r:
                    num = last_number
                    break
        else:
            num = str(number)
            roman_nums.add((a, a))