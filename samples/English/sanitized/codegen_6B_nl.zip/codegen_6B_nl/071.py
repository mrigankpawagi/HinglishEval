
def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
    a = float(a)
    b = float(b)
    c = float(c)
    val = 0
    if(a + b > c):
        val = a*b/(c)
    else:
        val = 0
    for a1 in range(0, 2):
        for b1 in range(0,2):
            if val < 0:
                val = val + a1*b1*(b1+a2)
        for a2 in range(0, 2):
            if val > 0:
                val = val + a1*b1*(b1+a2)
        if abs(val) < 0.5:
            return "%.2f" % val
            return -1
    return "%.2f" % val