
def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.
    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    # Base case: if the number is less than 11 (or zero), then return -1.
    if ((y-1) <= x):
        return -1
    # Step to 11, we keep adding 11 incrementally until we get an even number.
    for n in range(2, 11):
        if ((11-(n-1)) <= x):
            return int((11-(n-1)))
    # Step to -1, we keep subtracting -1 until we get an odd number.
    for n in range(-1, 0):
        if (((-11)-n) <= y):
            return int(((-11)-n))
    return -1