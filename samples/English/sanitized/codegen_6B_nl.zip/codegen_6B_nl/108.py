
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    if not arr:  # if array is empty
        print("The empty array.")
        return 0
    nums = []
    # we will use a for loop instead of a `for` statement
    for number in arr:  # for every number in the array, do this...
        # we will use the modulo (%) operator to find the number of negative digits
        print(str(number))
        # for signed number...
        # if a-b= 0, then we will be looking for a single digit, a non-negative number
        # if a-b<>0, then we will be looking for a single digit, a negative number
        for digit in str(abs(number)):  # for every digit, do this...
            print('',end=' ')  # we will start a new line and space
            # if sum(nums) > 0, add the value to the list
            nums.append(nums[-1])
            print(str(digit))  # print a single digit
        # add a space after sum of negative digits
        nums[-1] = str(nums[-