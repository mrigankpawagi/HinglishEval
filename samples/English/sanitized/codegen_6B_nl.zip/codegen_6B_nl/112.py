
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    # write your code here  
    #s will always be a length of 2^n + 1 as we need one extra space at the end
    #c is c = "a:bcdefabcdcbaed"
    #c will always be as a length of 2^n 
    #reverse_delete takes a string of length 2^n+l and c string of length 2^n and deletes all the chars in s which are equal to some one char in c
    if len(s) < c.count("a"):
        return (s, False)
    else:
        # find the index of the first character 'a' in s
        l=len(s)-1
        a=s[l]
        # count how many 'a's we saw in the last step
        count = c.count("a")
        if c.count("a") < (count -1):
            i = c.find("a")
            # count the number of 'a's at the end of c and put them at the end of s to give us