
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    i = 0
    cnt = 0
    for c in string:
        cnt += 1
        i += 1
    if cnt > 1:
        return False
    while True:
        if i == len(string):
            return True
        if string[i - 1]!= string[i]) and (string[i][1]!= string[0] or string[i][0]!= string[1]):
            return False
        i += 1
        cnt += 1
        if cnt > 1:
            return False
    print("Tests Passed")