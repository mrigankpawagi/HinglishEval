

def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    unique_list = copy.deepcopy(l)
    i=0
    set1 = set()
    set2 = set()
    while(i<len(unique_list)):
        if(unique_list[i] not in set1 or unique_list[i] in set2):
            set1.add(unique_list[i])
            set2.add(unique_list[i])
        i += 1
    return set1