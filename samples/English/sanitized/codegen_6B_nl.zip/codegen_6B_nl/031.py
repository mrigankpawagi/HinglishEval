

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if not number and not number.__eq__(str(number)):
        raise TypeError('not number')
    if number.is_integer() and n >= 0:
        # integer >= 0
        if n > number.number:
            return False
        # integer < 0
        if n < 0:
            return False
        # the number we are testing is odd
        if not number.is_odd() and not number.is_even():
            return False
        # we can compare it directly
        if n!= number:
            return False
    elif not number.is_integer():
        return False
    else:
        # not an integer
        n = abs(n)
        if not n:
            return False
        for i in range(2, n):
            if n % i == 0:
                return False
    return True