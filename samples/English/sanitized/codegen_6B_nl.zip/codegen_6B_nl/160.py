
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.
    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    operators = operator.keys()
    operators_array = []
    operators_array.append(operators.index("+"))
    operators_array.append(operators.index("-"))
    operators_array.append(operators.index("*"))
    operators_array.append(operators.index("/")) 
    operators_array.append(operators.index("**"))
    operators_array.append(operators.index("**"))
    operand_array = list(operand)
    operand_array.remove(operand[0])
    operand_array.insert(operand[0],operand[0])
    op1_array = list(operand_array)
    op_array = []
    op_array.append(operators_array[0])
    op_array.append(operators_array[1