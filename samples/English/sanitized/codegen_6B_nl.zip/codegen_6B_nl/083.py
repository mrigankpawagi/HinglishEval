
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    s = {1: 0}
    for i in range(1, 4):
        s[i] = (s[i - 1] + s[i - i] + s[i + 1] + s[i + i] + s[i + 2]) \
                    / (3 * (4 - i))
    print(s)
    return s[n]