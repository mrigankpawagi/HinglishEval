

def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    seen = set()
    seen_set = set(range(n))
    seen.add(n)
    for integer in seen_set:
        number = str(integer)
        if number.find('7')!= -1:
            return int(number) # count digit 7
        elif number.find('11')!= -1 or number.find('13')!= -1:
            # if `n` is divisible by 3 or 5...
            if number.find('3')!= -1 or number.find('5')!= -1:
                # and the number is not `7`, `11`, or `13`, add one.
                return int(number) + 1
    return 0