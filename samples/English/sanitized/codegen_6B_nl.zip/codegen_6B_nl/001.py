from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    pos = 0
    # Keep a stack of open brace information
    stack = []
    stack_ptr = 0
    paren_stack = stack
    def process_char(char):
        if char == ')':
            pos += 1
        elif char == '(':
            open_stack.append(stack_ptr)
            stack[stack_ptr] = '('
            stack_ptr += 1
        elif char == ')':
            stack[stack_ptr] = ')'
            stack_ptr -= 1
        while len(stack) > 0:
            paren_stack[stack_ptr] += stack.pop()
    while len(paren_string) > pos + 1:
        char = paren_string[pos]
        if len(paren_string) - pos > 1:
            process_char(paren_string[pos:len(paren_string) - 1])
        elif char =='':
            pass       #