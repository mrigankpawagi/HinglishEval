
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1,... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    split_chars_count = count_lower_letters_with_odd_order
    chars = 0
    len_txt = len(txt)
    for i in range(0, len_txt):
        if txt[i] not in string.whitespace: chars += 1
    if split_chars_count > chars:
        return []
    words = []
    c = chars 
    new_c=c//2
    start = c-new_c
    for i in range(start, c+1):
        words.append(txt[i:i+1])
    return words