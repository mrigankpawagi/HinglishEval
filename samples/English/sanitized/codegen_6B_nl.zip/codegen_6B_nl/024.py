

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    x = min(n, 2)
    if n == x:
        return 1
    else:
        return x * largest_divisor(n // x)