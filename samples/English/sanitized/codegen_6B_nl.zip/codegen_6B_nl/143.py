
def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.
    Example 1:
        Input: sentence = "This is a test"
        Output: "is"
    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"
    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    sentence = sentence.replace(" ", "").lower()
    def words_in_sentence_1(sentence, s):
        for start, end in zip(sentence.find(s), sentence.find(" ", end) + 1):
            if len(set(word.strip(string.punctuation) for word in sentence.split()) is None):
                if start!= end:
                    yield s[start:end]
            else:
                if start!= end:
                    yield s[start:end] + word
                else:
                    yield word
    # use list comprehension to create a generator to be fed to the next function
    def words_in_sentence_2(sentence):