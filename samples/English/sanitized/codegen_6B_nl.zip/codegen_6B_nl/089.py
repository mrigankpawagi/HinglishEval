
def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """
    alphabet = [('a', 'd'), ('b', 'e'), ('c', 'f'), ('d', 'g'), ('e', 'h'), ('f', 'i'), ('g', 'j'), ('h', 'k'), ('i', 'l'), ('j','m'), ('k', 'n'), ('l', 'o'), ('n', 'p'), ('o', 'q'), ('p', 'r'), ('q','s'), ('r', 't'), ('s', 'u'), ('t', 'v'), ('u', 'w'), ('v', 'x'), ('w', 'y'), ('x', 'z')]
    rot = 2 * 2 # 2 to the power of 2.
    string = input('Enter a string to encrypt: ')
    encrypted = ""
    for i in range(0, len(string)):
        letter = string[i]
        encrypted += alphabet[rot * (i % 3)] # % Operator returns remainder divided by remainder and remainder divided by remainder (i+1) times.
        # I think that % operator needs to be changed in the line below.
        # In a multiplication, remainder divided by remainder (that is, i) is
        # (remainder-1) divided by remainder (i), which means that the remainder 
        # divided by (i+1) (that is, (i%3) divided by ((i-1) % 3)) is ((i%3) divided