
def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.
    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''
    negative_indices = []
    positive_indices = []
    largest = -100000000
    smallest = 1
    for i in lst:
        if i < 0:
            negative_indices.append(i)
        elif i > 0:
            positive_indices.append(i)
        if i == large:
            biggest = biggest
            smallest = smallest
            largest = large
    return largest, (largest_smallest if largest >= small else smallest_smallest_positive,
             smallest)