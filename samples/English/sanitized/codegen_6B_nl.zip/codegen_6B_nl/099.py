
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.
    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15
    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    if is_integer(value):
        return int(value)
    if value in integer_ranges:
        # If the number is an integer, return it
        return value
    v = value.lower()
    if v in ['.', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
        # The number is a decimal
        return int(value)
    if v == 'nan':
        # If nan is in the list, just say nothing
        return value
    elif v == 'false':
        # Also give false: If nan is in the list, it's possible false is
        # too close to something else in the list
        return value
    # Search in integer_ranges for the number
    for r in integer_ranges:
        # If it's closer than the value on the list, return it and break
        if abs(r - value) < abs(int(v) - number):