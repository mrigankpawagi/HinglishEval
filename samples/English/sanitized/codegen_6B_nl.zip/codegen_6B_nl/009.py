from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    # https://en.wikipedia.org/wiki/Yanking_problem
    # https://en.wikipedia.org/wiki/Pipeline_(Unix)
    # https://en.wikipedia.org/wiki/Pipelining_%28control_systems%29
    if not numbers: return []
    if numbers[1:] not in numbers[0:-1]: return numbers[1:]
    return numbers[:-1]