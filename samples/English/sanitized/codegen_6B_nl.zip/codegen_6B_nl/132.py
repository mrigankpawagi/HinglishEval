
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.
    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    nested = 0
    def nested_brackets(string):
        # We get into infinite recursion if there is more than one nested level
        # However, we set recursion depth to something big to avoid infinite loop
        nested = len_of(string)
        for i in range(nested):
            for j in [k for k in range(nested - i - 1) if (not (string[i].startswith(string[j][0])) and not (string[i].endswith(string[j][-1])))]
                yield True
            yield False
    def recursive_is_nested(string):
        # As we've decided to recurse on the entire string, we can now go ahead and start looping through it.
        for i in range(len(string)):
            if len_of(string[i]) > 1:
                # We'll check to see that we're at the beginning of the string and the substring is valid.