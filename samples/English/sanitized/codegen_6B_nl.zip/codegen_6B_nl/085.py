
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..
    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    odd_ids = [lst[i] for i in range(1, len(lst) + 1) if lst[i] % 2!= 0]
    even = list(filter(lambda e: lst[e] % 2 == 0, odd_ids))
    for element in even:
        lst.insert(len(lst) / 2, element)
    return sorted(lst)