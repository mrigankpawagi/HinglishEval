
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    is_prime = True
    count_max = prime_length_method(string, 2, 10)
    """I didn't want to do this with for-loops. However I didn't have another
     chance to write a function that took string as input and returns True"""
    for n in range(2, abs(count_max)):
        for d in range(2, n):
            is_prime = is_prime and prime_length_method(string, d, n) #this works for
                                                                        #testing the
                                                                        #method to ensure
                                                                        #that any prime
                                                                        #was less than
                                                                        #the end of
                                                                        #calculating
        if is_prime: #return the true for the is prime
            return True
    return False