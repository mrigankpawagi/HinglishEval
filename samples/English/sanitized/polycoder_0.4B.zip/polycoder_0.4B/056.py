

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    braces = []
    for bt in brackets:
        if bt.group(1)!= "":
            braces.append("[{}]".format(bt))

    if braces:
        braces.sort(itemgetter(len))
        return braces == ["[{}], "]", "[{}]".format(b[:2]
                                                   [b[2] for b in braces])
    return False

