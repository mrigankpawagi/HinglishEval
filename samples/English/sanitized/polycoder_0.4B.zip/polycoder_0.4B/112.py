
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    s_length = len(s)
    if s_length > 2000:
        return False, len(s)==1
    if s==c: # case 1:
        return ((s.lower(),True),len(s.lower()))
    else: # case 2:
        result, index = s.index(c), -1  # -1 means match
        back = min(len(s),index-1)
        front = min(len(s),index+1)
        for i,k in enumerate(reversed(s)):
            if i==index:
                if not back:  # back = front
                    return (False,len(s))
                else:
                    return ((s.lower(),True),len(s.lower()))
            else:
                if