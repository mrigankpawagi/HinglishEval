

def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    divisor: int
    for _ in range(1, min(15, n + 1)):
        divisor = divisor << 1

    if divisor & 1:
        return divisor

    return divide_up(2, divisor)

