

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
   n = len(xs)
    derv = np.zeros(n)

    for i in range(n-1, -1, -1):
        diff_i = 0
        for j in range(i + 1, n):
            diff_j = (xs[i] - xs[j]) % (2 * j)
            if (diff_j > 0):
                derv[diff_j] += diff_j
            if (diff_j < 0):
                derv[diff_j + n] += diff_j
            if (diff_i == 0):
                derv[n - diff_i] += diff_i

    return derv

