

def flip_case(string: str) -> str:
    """ For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello')
    'hELLO'
    """
    string = string.lower()
    if len(string) == 1 and string[-1] == 'H':
        string = string[:-1]
    return string
