
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    pairs = nums if isinstance(nums, (list, tuple)) else []

    def sorter(x):
        for i in x:
            if i!=-1:
                pair = sorted(pairs, key=lambda pair: (
                        ord(ord(pair[1])+len(ord(point(pair[0])))) & digit_mask),
                        reverse=True)
            else:
                pair = sorted(pairs, key=lambda pair: (1, ord(ord(pair[0]))) | digit_mask)
        return pair

    return [[sorter(x) for x in z.args if not z.is_list_of(z[0], z[1])]
             for z in nums]
