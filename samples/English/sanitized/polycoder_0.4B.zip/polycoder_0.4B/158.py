
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """
   for word, chars in words:
        max = 0
        for c, i in chars:
            if i < len(word):
                if i and word[i] in word:
                    max = max + 1
                    continue
                if c!= word.rfind(word, i):
                    max = max + 1
            else:
                max = max + 1
        if max == len(word):
            return word
    return word
