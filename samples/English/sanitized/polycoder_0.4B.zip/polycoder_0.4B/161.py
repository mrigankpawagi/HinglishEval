
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    for num in s:
        if num == '\0':
            return s[0:-1]
        a, b = s[:num.index('a'), :], s[num.index('@'):]
        c, d = s[:num.index('c'), :], s[num.index('@'):]
        res = (a + 1) * d + b + c
        if not res:
            return s[0:-1]  # reverse the string

    else:
        return s

