
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    assert isinstance(n, int)
    assert n > 0 and n % 2 == 0
    odd_ints = list(range(n//2))
    if n % 2 == 1:
        odd_ints.insert(0, n//2+n%2)
    if n & 1:
        odd_ints.insert(0, n//2+n%2)
    sum_odd = set()
    for i in odd_ints:
        sum_odd.update(i)
        if sum_odd == set([n]):
            return [False, True], True
    sum_even = set()
    for i in even_ints:
        sum_even.update(i)
        if sum_even == set([n]):
            return [False, True], True
    sum_even = list(sum_even)
    sum_odd = list(sum_odd)
    return [True, True, False], is_equal_to_sum_even(sum_even, sum_odd)