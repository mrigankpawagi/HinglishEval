

def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    from.monotonic import MonotonicDict
    ret = {}
    for elem in l:
        if elem not in MonotonicDict.MONRICAL_KEYS:
            ret.update({elem: None})
            continue
        if ret.get(elem) is not None:
            raise TypeError("MonotonicDict must implement Monotonic")
        ret[elem] = True
    return ret

