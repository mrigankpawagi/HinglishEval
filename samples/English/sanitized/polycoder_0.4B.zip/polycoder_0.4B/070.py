
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    if not lst:
        return []
    elif isinstance(lst, str) or isinstance(lst, numbers.Number):
        lst = lst.strip()
        if lst:
            lst = lst.split()
        if not lst:
            return []
        return list(set(lst))
    elif not isinstance(lst, int):
        lst = lst.strip()
        if lst:
            lst = [lst]
        if not lst:
            return []
        return lst
    else:
        # It's necessary to return a list that is always a string.
        sorted_lst = sorted(lst, key=lambda x: x[0], reverse=True)
        if not sorted_lst:
            return []
        order = ['<', '<=', '>', '< >']
        for i in reversed(sorted_lst):
            order[i[0]] = i[1]

        if isinstance