from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    if delimeter == len(numbers):
        return intersperse(numbers[0])[0]
    l = len(numbers)
    if delimeter > 0:
        result = []
        for i in range(0, l):
            result.append(numbers[i])
            delimeters = delimeter - 1
            result.extend(intersperse(numbers[i : i + 1], delimeter - delimeters))
            delimeters = delimeter + 1
            result.extend(intersperse(numbers[i + 1 : l], delimeters))
        return list(result)
    else:
        return intersperse(numbers[0])[0:0]
