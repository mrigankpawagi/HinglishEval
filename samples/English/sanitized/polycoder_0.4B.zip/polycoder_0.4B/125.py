
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
   
    def _split_words(s):
        words = [ e.strip() for e in s.split() ]
        return words[: len(words) // 2 + 1] if len(words) >= 2 else str(w) for w in words
    
    return [ _split_words(x) for x in txt.split() ]

