from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    # Reverse the string
    # Swap the elements
    a = a[::-1]
    b = b[::-1]
    # Convert the results
    result = ''
    for char in a:
        result += chr(ord(char) ^ ord(b[0]))
    return result

