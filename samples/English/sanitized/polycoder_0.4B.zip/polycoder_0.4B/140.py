
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    text_length = len(text)
    num_spaces = 0
    for i in range(0, text_length - 2):
        num_spaces = max(num_spaces, text_length - 3 - i)
    text = "\n".join(text[i:num_spaces+1])
    return text

