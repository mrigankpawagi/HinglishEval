
def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    a_angle_deg    = math.arcdegrees(a)
    b_angle_deg    = math.arcdegrees(b)
    c_angle_deg    = math.arcdegrees(c)

    return a_angle_deg - math.degrees(math.atan2(-b_angle_deg, a_angle_deg)) < 0
