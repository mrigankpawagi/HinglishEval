
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    assert "u" in word
    assert "Yogurt" in word
    assert "FULL" in word
    assert "quick" not in word
    
    for index, ch in enumerate(word):
        word[index] = word[index].upper()
        word[index] = re.sub(r'([a-zA-Z0-9])', r'([a-zA-Z0-9_\.])', word[index])
        word[index] = re.sub(r'([a-zA-Z0-9][^\.]+)', r'([a-zA-Z0-9][^\.]+)', word[index])

        
    vowels = re.findall("(-| [a-zA-Z0-9]|) (.*)", word[0])

    if len(vowels) <= 1:
        return word
    # print(vowels[1])
    # print(get_closest_vowel(ch))
    # print("\n".join(itertools.product(word, itertools.repeat(word))))
    return word[0]
