
def double_the_difference(lst):
    sum_of_squares = 0
    for num in lst:
        if num.isdigit() and num.isdigit() and num >= 0:
            if num % 2 != 0:
                sum_of_squares += int(num) ** 2
    return sum_of_squares * 2