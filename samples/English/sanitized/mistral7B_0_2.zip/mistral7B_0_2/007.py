
from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    :param strings: List of strings to be filtered
    :type strings: List[str]
    :param substring: Substring to be searched in strings
    :type substring: str
    :return: List of strings that contain the given substring
    :rtype: List[str]
    """
    return [s for s in strings if substring in s]