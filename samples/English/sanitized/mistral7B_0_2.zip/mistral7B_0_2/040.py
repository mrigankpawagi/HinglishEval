
def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.
    """
    return len(set(x for x in set(l) if not set(l)[::].pop(l.index(x), None) or sum([x, set(l)[::].pop(l.index(x), None), set(l)[::].pop(l.index(x), None)]) == 0)) > 0