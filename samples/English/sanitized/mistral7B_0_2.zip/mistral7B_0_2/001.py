
from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    """
    def is_open_paren(char):
        return char in "([{"
    def is_close_paren(char, stack):
        if not stack:
            return False
        return stack.pop() == '(' if char == ')' else char == ']' and stack.pop() == '['
    def process_paren_group(paren_string):
        stack = []
        result = []
        for char in paren_string:
            if is_open_paren(char):
                stack.append(char)
            elif is_close_paren(char, stack):
                result.append(''.join(stack[::-1]))
                stack.pop()
        if stack:
            result.append(''.join(stack[::-1]))
        return result
    return process_paren_group(paren_string.translate(str.maketrans('', '', ' ')))