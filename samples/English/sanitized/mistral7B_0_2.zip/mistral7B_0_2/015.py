
def string_sequence(n: int) -> str:
    return " ".join(map(str, range(n+1)))