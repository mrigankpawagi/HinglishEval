
def next_smallest(lst):
    if len(lst) < 2:
        return None
    else:
        return min(lst[1:]) if min(lst) != min(lst[1:]) else next_smallest(lst[1:])