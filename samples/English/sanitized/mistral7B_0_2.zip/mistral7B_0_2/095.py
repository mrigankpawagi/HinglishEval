
def check_dict_case(dict):
    if not dict:
        return False
    if all(isinstance(key, str) and (key.islower() if type(dict[key]) is str else key.isupper()) for key in dict):
        return True
    return False