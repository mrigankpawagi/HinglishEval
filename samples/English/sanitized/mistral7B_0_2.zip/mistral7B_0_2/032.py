
def find_zero(xs: list):
    n = len(xs) // 2
    a = xs[:n]
    b = xs[n:]
    x = _rroot(2 * a[0], -b[0] + sum(map(lambda x, y: x * y, a[1:], a[:-1])))
    return x