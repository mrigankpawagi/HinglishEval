
from functools import reduce

def get_max_triples(n):
    a = list(map(lambda i: i * i - i + 1, range(1, n+1)))
    return len(list(filter(lambda x, a: sum(x) % 3 == 0, itertools.combinations(a, 3))))