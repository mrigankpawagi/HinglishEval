
def unique(l: list):
    """Return sorted unique elements in a list"""
    return list(set(l)) & set(l[:1])