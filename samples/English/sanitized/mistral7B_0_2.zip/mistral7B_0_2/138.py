
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    def _is_equal_to_sum_even_helper(target, current_sum, current_num, used):
        if current_sum > target:
            return False
        if current_sum == target:
            return True
        for i in range(current_num, n // 2, 2):
            if i in used:
                continue
            if _is_equal_to_sum_even_helper(target, current_sum + i, i + 1, used | {i}):
                return True
        return False
    return _is_equal_to_sum_even_helper(n, 0, 2, set())