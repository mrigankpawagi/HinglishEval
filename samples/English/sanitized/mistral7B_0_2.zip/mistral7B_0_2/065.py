
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    """
    num_str = str(abs(x))
    num_len = len(num_str)
    shift = shift % num_len
    if shift > 0:
        return num_str[shift:] + num_str[:shift]
    else:
        return num_str[-shift:] + num_str[:-shift]