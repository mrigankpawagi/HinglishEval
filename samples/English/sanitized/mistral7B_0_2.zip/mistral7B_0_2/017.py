
def parse_music(music_string: str) -> List[int]:
    notes = music_string.split(' ')
    beats = [4 if note[0] == 'o' else (2 if note[0] == 'o' else 1) for note in notes]
    return beats