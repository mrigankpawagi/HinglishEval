
def below_zero(operations: List[int]) -> bool:
    account_balance = 0
    for operation in operations:
        account_balance += operation
        if account_balance < 0:
            return True
    return False