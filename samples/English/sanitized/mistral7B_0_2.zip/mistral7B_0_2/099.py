
def closest_integer(value):
    value = float(value)
    return int(math.floor(value if value > 0 else ceil(value)))