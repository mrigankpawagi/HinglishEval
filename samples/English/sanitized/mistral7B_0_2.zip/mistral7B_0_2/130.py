
def tri(n):
    sequence = [3]
    if n <= 0:
        return sequence
    elif n % 2 == 0:
        sequence.append(sequence[-1] + (n / 2))
    else:
        sequence.append(sequence[-1] + sequence[-2])
        sequence.append(sequence[-1] + sequence[-3])
    for _ in range(n - len(sequence)):
        sequence.append(sequence[-1] + sequence[-2] + sequence[-3])
    return sequence