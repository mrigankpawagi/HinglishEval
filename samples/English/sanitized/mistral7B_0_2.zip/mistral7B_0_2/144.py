
from fractions import Fraction

def simplify(x, n):
    """Your task is to implement a function that will simplify the expression x * n.
    The function returns True if x * n evaluates to a whole number and False otherwise.
    Args:
        x (str): A string representation of a fraction in the format <numerator>/<denominator>.
        n (str): A string representation of a fraction in the format <numerator>/<denominator>.
    Returns:
        bool: True if x * n evaluates to a whole number, False otherwise.
    """
    x_fraction = Fraction(map(int, x.split('/')))
    n_fraction = Fraction(map(int, n.split('/')))
    return x_fraction * n_fraction == int(x_fraction * n_fraction)