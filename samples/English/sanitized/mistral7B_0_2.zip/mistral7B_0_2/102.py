
def choose_num(x, y):
    if x % 2 == 0 and y % 2 == 0:
        return min(x, y) if x <= y else y
    else:
        even_x = x if x % 2 == 0 else x + 1
        for num in range(even_x, y + 1, 2):
            if num % 2 == 0:
                return num
        return -1