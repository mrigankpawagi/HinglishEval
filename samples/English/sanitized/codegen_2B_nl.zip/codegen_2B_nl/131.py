
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    n = abs(n)
    if n % 2:
        return 0
    prod = 1
    for i in range(2, n//2 + 1):
        prod *= (n % 2 == 0 and i % 3 or i % 5 or i % 7)
    return prod % 3