
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    nA = len(nums)
    l = len(nums[0])
    count1, count2 = 0, 0
    for i in xrange(nA - 1):
        last = nums[i][l-1]
        if int(last) == i:
            count1 += 1
        if last % 2 == 0 and int(nums[i][0]) % 2 == 1:
            count2 += 1
        elif last % 2 == 0 and last < 0:
            count2 += 1
        pass
    return count1, count2