
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    if not nums:  # input empty, return 0 as a singleton subset sum
        return 0
    # nums = sorted(nums)
    minSum = 1
    for i in nums:
        for j in nums[i:] if nums[j]:
            continue
        minSum = max(minSum, i + nums[i]) 
        return minSum