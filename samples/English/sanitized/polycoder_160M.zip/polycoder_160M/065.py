
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    if shift >= len(x):
        raise ValueError('Invalid shift')
    new_width = len(x) - shift
    if new_width >= len(x[0]):
        # No point in trying to rotate a digit
        return x[0][::-1]
    while shift:
        shift &= 9 - 1
        new_digits = []
        i = min(len(x[0])-shift+1, len(x))
        while shift > 0:
            new_digits.append((x.index) % len(x))
            shift = new_digits.pop()
        old_digits = set(x)
        new_digits_from_shift = old_digits - new_digits
        new_digits -= set(x[i:i+1])
        x[new_digits] = new_digits
        x[i+1] = new_digits_from_shift
        shift -= 1
    return x[shift-1:shift]
