
def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    for d in range(len(s) + 1, len(s)) * 2:
        a = ord(s[d])
        b = ord(s[d + 1])
        if a - b > 0:
            return a + b

