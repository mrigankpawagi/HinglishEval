
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    sorted_arr = [arr]

    while sorted_arr:
        # make the binary representation of sort array with zeros
        arr = sorted_arr[::-1]
        sorted_arr.remove(0)

        arr = arr[1:]

        # perform the sorting
        for i in range(len(arr)):
            arr_binary = array_binary(arr, i)
            arr_binary_sum = array_sum(arr_binary)
            arr_binary_bin = array_bin_arrayize_binary(arr_binary_sum,
                                                      arr_binary.get_int_dtype())
            arr_binary = sorted_array(arr_binary, key=i + 1)

            arr = arr_binary_bin[~array_binary_sum.get_int_