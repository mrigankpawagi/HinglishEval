

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    x, y = max(x, y), max(x, y)
    i = next(filter(lambda x: x < x + 1, xrange(x)))
    try:
        x += xrange(x[i])
    except TypeError:
        pass  # x must be > 1

    y = add(1, 1)
    y.inc()
    return x, y

