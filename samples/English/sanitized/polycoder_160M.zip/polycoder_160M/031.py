

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if not _is_prime_or_zero(n):
        return False
    if n == 1:
        return True
    if n == 0:
        return False
    if n == -1:
        return True
    if not isinstance(n, int):
        _raise_TypeError(n)
    a, b = n // 1, n // 2 + 1
    return a == _is_prime(b)

