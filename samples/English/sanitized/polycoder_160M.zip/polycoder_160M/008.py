from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """ For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.
    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    # Empty sum should result in 0 (equivalent to a set of empty lists)
    if not isinstance(numbers, List):
        return (0, 1), (0, 1)
    return tuple(numbers), sum(-1 if x is not None else sum(x))

