

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    result = 0
    for case in [u'', u'*', u'!', u"'"]:
        assert not pattern.match(string)

        if len(pattern) > 2:
            while not pattern[1]:
                pattern = pattern[1:]
                result += 1
        else:
            if len(pattern) == 0:
                result *= 1
            elif len(pattern) == 1:
                assert pattern[0] == u'(?<=\s)' and pattern[1] == u'(?<=\1)'
                if pattern[2] == u'(^[A-Za-z]+|^(\s+)): \([\s\w+]+)/':
                    result *= 2
                elif pattern[0] == u'(^-[\d]+|^(\s+-))':
                    result *= 2
                elif pattern[0] == u'(^\d{3})?':
                    result *= 2
             