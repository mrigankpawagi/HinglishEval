
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    if n % 4:
        return 0
    elif n >= 0:
        digits = 100 - ceil(n * ((1 - n) / (10 ** n)) * floor(n * (10 ** n)))
    else:
        digits = 0
    return digits

