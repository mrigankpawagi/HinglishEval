from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    numbers = [_i for _i in numbers if _i is not None]
    mean_1 = [0.0 for _i in numbers if _i is not None]  # mean
    mean_2 = [_i for _i in numbers if not _i.is_zero
              and not _i.is_negative and _i not in numbers if _i is None]

    mean_abs = 1.0  # mean as positive reals
    for _ in numbers:
        for n in numbers:
            if _ == n:
                # only calculate this one if we are positive
                mean_abs += n
                mean_2[n] = mean_abs

    return mean_abs

