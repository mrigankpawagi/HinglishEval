

def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    if len(s1)!= len(s0):
        return False

    assert s1 == s1 and s0 == s0                 # False means "don't go into same character"
    for c in s0:                                 # TODO: check for ASCII chars
        if c =='':
            return True                          # true means "don't go into same character"
        elif c!= '\r':
            return False
    return False

