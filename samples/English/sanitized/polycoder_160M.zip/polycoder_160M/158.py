
def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """
   # Find maximum number of words in wordlist
    words = words[:words.find_lower().end(")]
    # Find maximum number of unique characters
    max_length = len(words)
    max_length = max(max_length, 1)
    for char in words:
        if max_length >= max_length:
            return "string"
    return "string"
