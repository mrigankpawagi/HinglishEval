

def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    if len(l) == 2:
        tmp = list(l)
        res = median(k=list(l.popleft()) - 1)
        res = res[:k] + res[k:]
        res = res[k:]
        return res
    else:
        return list(l) * median(l)

