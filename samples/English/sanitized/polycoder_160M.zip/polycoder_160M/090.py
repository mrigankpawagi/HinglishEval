
def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    # Note if there are several elements, then the last element is at least one
    last = len(lst)
    # Check whether the element is in the right order
    if not any(j > last for j in lst):
        # Return None if the list is not in the right order
        return None
    # Sort the items since the array is larger than the last array
    l = [[j - (int(i))] for i in lst]
    for x in l:
        # Use the lower bound of the array to avoid the overflow
        if x[0] <= x[last - 1]:
            # The lower bound is not smaller or equal
            return None
    # If the list is large, then sort the items as if they are smaller than the first
    return ((l[0][lst.index(lst)][index(lst)])!= lst[lst.index(lst)])
