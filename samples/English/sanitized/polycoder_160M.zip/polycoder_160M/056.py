

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    brackets_map = {'&': '=', '&:': '&', '~': '<', '|:': '>', '!': '!',
                    '&!': '&!', '&': '&%')
    for item in brackets_map.items():
        check_item(*item)
    return True

