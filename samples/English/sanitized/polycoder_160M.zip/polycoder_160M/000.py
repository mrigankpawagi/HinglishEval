from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if any(w in numbers for w in range(threshold) for k in range(1)):
        # If this is an output array, it should be exactly 1
        return all(
            ((w,) == _number_as_double(w).astype(dtype=[float, int])) for w in numbers
        )
    elif any(w for w in (list("x") for list("x") in (range(len(numbers))))):
        # For complex numbers, we use the same integer
        return (
            len(numbers) == _number_as_int(numbers[0][::-1])
            or _number_as_complex(numbers[0])[::-1] == _number_as_complex(
                numbers[1][::-1]
            ) and (not (len(numbers) == _number_as_int(numbers[0][::-1])) or _number_as_complex(
                numbers[0])[::-1] == _number_as_complex(numbers[1][::-1]),
            )
        )
    else:
        return