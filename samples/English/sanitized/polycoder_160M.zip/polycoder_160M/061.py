

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    if '(' in brackets or ')' in brackets:
        return False

    brackets = brackets.split(f'{brackets}')
    if not brackets:
        return False
    is_bracket = False
    for token in brackets:
        if not is_comment(token):
            break
        if not is_bracket(token):
            is_bracket = True

    return None

