
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    if number == 0:
        return "0"

    if int.from_base_of(number) == 17:
        return "19x16"
    if int.from_base_of(number) == 15:
        return "149x16"
    if int.from_base_of(number) == 13:
        return "100x16"
    if int.from_base_of(number) == 11:
        return "13x16"
    if int.from_base_of(number) == 9:
        return "9x8"
    if int.from_base_of(number) == 8:
        return "8x4"
    return "0x8"
