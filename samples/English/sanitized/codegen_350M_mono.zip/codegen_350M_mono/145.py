
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.
    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    for numbers in range(1, len(nums)):
        current_sum = 0
        for i in str(nums[numbers]):
            current_sum += int(i)
        if current_sum > -10:
            print(nums[numbers])
            nums[numbers] = str(current_sum)
        elif current_sum < -1:
            print("Please sort the numbers in ascending order!")
            break