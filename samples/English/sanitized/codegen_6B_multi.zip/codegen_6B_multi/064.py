
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.
    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    # TODO - replace this function with a list comprehension
    # This is a bit faster, because strings may be in this domain
    # Create a list containing 0 for each vowel, 1 for each non-vowel
    # and fill in the vowel count.
    vowels_dict = list(dict.fromkeys([ord(char) for char in vowels], 1))
    # Only look if we are at the end and if the next letter is also vowel
    vowels_dict[-1] += (ord(s[-1]) - 32) in vowels_dict
    # Add up all the counts, then get the sum minus the number of vowels,
    # which is the size of the list.
    return sum(vowels_dict) - len(vowels_dict)