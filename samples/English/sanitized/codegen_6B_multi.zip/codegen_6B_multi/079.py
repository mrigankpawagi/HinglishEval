
def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.
    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.
    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    # first make our base 10 number into a string, we will put binary digits in this string
    string = str(decimal)
    # we will be looping through the decimal number
    while string!= "" and len(string) > 1:
        # if the remaining number is less than 10, then the corresponding '0 will be in the number
        if decimal < 10:
            # move the binary number to the right, shift 3 digits to the right and insert the 0 in the
            # middle of the string
            string = string[0:3] + '0' + string[3:]
            # we decremented the decimal number which needs to decremented again, so we decrease the number
            # that we are shifting
            decimal -= 1
        # we will run through the entire string and decrement the decimal number, then the number is
        # smaller than ten, we will shift it down
        else:
            # move the string to the right, shift the remaining string and put 0 in the middle of the string
            string = string[0:3] + string[4:7] + '0' + string[7:]
            # remove one from the decimal number and decrease the number of the previous shift
            decimal -= 1
    # now in case there was a remaining number < 10, now we will just append the one remaining char
    # string will now look like '000db' instead of '00000'
    string = string[0:3] + string[3:]
    # now there is only one 1 left, we need to pad with '00' and get a string like '00db'