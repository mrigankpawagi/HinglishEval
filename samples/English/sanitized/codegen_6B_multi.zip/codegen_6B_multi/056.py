

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.
    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    stack = []
    for (opening_bracket, closing_bracket) in brackets:
        stack.append(opening_bracket)
        if closing_bracket!= opening_bracket:
            return False
    if not stack:
        return False
    for stack_item in stack[::-1]:
        stack.pop()
        if stack:
            return False
    return True