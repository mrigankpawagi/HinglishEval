
def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    #print(string)
    lower_string = string.lower()
    #print(lower_string)
    n = len(lower_string)
    i = 1
    while i * 2 <= n:
        if lower_string[i] == 'o':  # in case there's a letter in front
            if lower_string[i+1] == 'e' or lower_string[i+1] == \
               lower(string[i+1]):
                #print(i)
                return False
    return True