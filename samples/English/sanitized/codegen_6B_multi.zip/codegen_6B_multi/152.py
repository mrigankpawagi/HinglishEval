
def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    example:
    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    sum_of_scores = sum(score for score in game)
    # We should normalize this array.
    # We'll be passing the score array
    # as a parameter to the comparator function.
    # The comparator function won't work on our 
    # original numbers, so we'll just have to write
    # a function to do the necessary normalization...
    if sum_of_scores == 0:
        return [0,0,0,0,0,0]
    x = [round((guess - score) / score) for score in game]
    scores = [0]*len(guess)
    for row in x:
        # Check to see if any score has exceeded the maximum
        # amount of error allowed.
        if (sum(x[i] for i in range(row)) > MAX_ERROR) or (sum(x[i] for i in range(row, len(x))) + 1 > MAX_ERROR):
            return [0,0,0,0,0,0]
        scores[row] = 1
    # We want the result of this function to show up
    #