

def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    prime_factor = None
    d_counter = 0
    for d in prime_factors(n):
        if all(p > n >> i for i in range(d_counter + 1, d)):
            prime_factor = d
            d_counter = 0
        else:
            d_counter = d_counter + 1
    return prime_factor