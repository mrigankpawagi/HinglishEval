
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    return reduce(lambda x,y:x[::-1]+y, [''.join(i) for i in itertools.permutations((lambda x:x in vowels)*2)])+' '+''.join(i for i in xrange(26) if x not in vowels)+''.join(i for i in xrange(26) if x in vowels)[:8]+''.join(i for i in xrange(26) if x not in vowels)+''.join(i for i in xrange(26) if x is not None)