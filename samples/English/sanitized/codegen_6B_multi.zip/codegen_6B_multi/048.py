

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if not isinstance(text, str):
        raise TypeError('Can only compare string instances')
    if len(text) <= 1; return True
    else:
        return text[::-1] == text[1::-1]