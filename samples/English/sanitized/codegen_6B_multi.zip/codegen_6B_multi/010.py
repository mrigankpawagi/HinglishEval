

def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """ Find the shortest palindrome that begins with a supplied string.
    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes before the palindromic suffix.
    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    str_len = len(string)
    if not str_len:  # Zero-length strings are palindromes
        return string
    longest = [0] * str_len
    # Find the longest palindrome prefix that we can
    # apply to the string
    longest_prefix = longest_palindrome_prefix(string)
    longest_prefix_length = len(longest_prefix)
    if longest_prefix == string:  # If supplied string was a palindrome
        return string[::-1]
    # Find the longest palindrome suffix that we can
    # apply to the string
    longest_suffix = longest_palindrome_suffix(string)
    longest_suffix_length = len(longest_suffix)
    if longest_suffix == string:  # If supplied string was a palindrome
        return string[longest_prefix_length::-1]
    # This string is not a palindrome as the prefix and suffix were not the longest found.
    return None