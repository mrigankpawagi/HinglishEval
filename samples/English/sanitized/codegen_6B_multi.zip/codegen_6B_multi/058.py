

def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]
    """
    l1, l2 = sorted(l1), sorted(l2)
    _l1, _l2 = [], []
    for i_l1, i_l2 in zip(l1, l2):
        if i_l1 not in _l1:
            _l1.append(i_l1)
            if i_l2 not in _l2:
                _l2.append(i_l2)
    return sorted(_l1), sorted(_l2)