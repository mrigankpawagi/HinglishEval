
def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    Variables:
        @N integer
             Constraints: 0 ≤ N ≤ 10000.
    Output:
         a string of binary number
    """
    if sum(N) == N:
        N = str(N)
        digits = [int(digit) for digit in N]
        sum_of_digits = sum([digit for digit in digits])
        return intToBin(sum_of_digits)
    elif sum(N) == 0:
        N = str(N)
        digits = [int(digit) for digit in N]
        sum_of_digits = sum([digit for digit in digits])
        return intToBin(sum_of_digits)
    else:
        N = numpy.array(N)
        max_sum = -1
        for i in xrange(N.shape[0]-1):
            # Calculating sum of digits of every pair of the array
            sum_of_digits = [0,0,0,0,0,0]
            sum_of_digits[i] = sum([digits[ii][digits[jj][::-1][ii]] for ii in xrange(i,N.shape[0]) for jj in xrange(i,N.shape[0])])
            # If sum of digits for every pair of array are not equal then print them in binary
            if sum_of_digits[i]!= sum_of_digits[i+1]:
                for ii in xrange(6):
                    max_sum = max(max_sum, sum_of_digits[i][ii])
                print '{}{}'.format(intToBin(sum_of_digits[i]), '{}   {}'.format(intToBin(