
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000
    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    number = abs(number)
    if number > 1000 or number < 1:
        raise ValueError('Input must be within range [1, 1000]')
    if number < 10:
        res = 'i'
    elif number < 20:
        res = 'x'
    else:
        res = ['xii', 'xxi', 'cxii', 'lxii', 'dxxii','mxxii'][
        number / 100 - 1]  # get index for m xx
    if number % 10 == 0:
        return res + res[:number % 10 + 1]
    else:
        return res + res[:number % 10 + 1] + 'x'