
def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.
    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    # Check argument and exit when there are not enough arguments
    if len(operator) < 2:
        print('You must give at least two operators to do basic algebra.')
        return
    if len(operator) > len(operand) - 1:
        print('The number of operator does not match the length of the operand list.')
        return
    # Return result of the basic algebra operations
    return do_basic_algebra(operator, operand)