
def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    i = len(s) -1
    while i>=0:
        if s[i].isalpha():
            break
        elif i == 0:
            return s[::-1]
        i-=1
    for char in reversed(s[i+1:]):
        if char.isalpha():
            s = s[:i+1]
            break
        else:
            s = char.lower()
    s = s[:i+1].upper() + s[i+1:]
    return s