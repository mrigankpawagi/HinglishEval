
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..
    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """
    start = 0
    evens = []
    for i in range(1, len(lst)):
        if (i%2 == 1):
            evens.append(lst[i])
        else:
            start += 1
    return start