from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """ For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.
    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |
    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    num_values = len(numbers)
    # Mean is taken over entire collection of numbers
    mean = sum(numbers) / num_values
    # Calculate each element and subtract from mean
    # to put in deviation. Only calculate the difference to the mean
    # once in the list for efficiency.
    deviations = []
    for number in numbers:
        deviations.append(abs(number - mean))
    return sum(deviations) / num_values