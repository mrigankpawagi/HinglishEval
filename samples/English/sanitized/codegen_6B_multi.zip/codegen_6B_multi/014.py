from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    output = []
    length = 0
    for position in range(len(string)):
        substring = string[:position + 1]
        if substring is not string:
            length = len(string) - position
            output.append(substring)
    return output