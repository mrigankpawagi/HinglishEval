
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 *... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    list_of_factors = []
    for i in range(1, n + 1):
        new_factors = [1, 1]
        is_factors = [False] * (n + 1)
        for j in range((i // 2) + 1):
           is_factors[j] = True
        if i < (n + 1) // 2:
            is_factors[0] = False
        for index in range(2, n + 1): # for each factor, i from 1
            is_factor = False
            for j in is_factors:
                if j == index:
                    is_factor = True
            if is_factor:
                new_factors.append(index)
        list_of_factors.append(new_factors)
    return list_of_factors