
def multiply(a, b):
    """Complete the function that takes two integers and returns 
    the product of their unit digits.
    Assume the input is always valid.
    Examples:
    multiply(148, 412) should return 16.
    multiply(19, 28) should return 72.
    multiply(2020, 1851) should return 0.
    multiply(14,-15) should return 20.
    """
    # Base case
    if a < 1:
        return 0
    if b < 1:
        return 0
    if a == -1 or b == -1:
        return 0
    if a == 0:
        return b
    if b == 0:
        return a
    for i in range(min(a, b)):
        a = multiply(a, a)
    for i in reversed(range(min(a, b))):
        b = multiply(b, b)
    if a > b:
        return a - b
    elif b > a:
        return b - a