

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    m = power_of_two(base)
    digit_sum = x if base == _base else x % m
    rep = []
    while digit_sum > 0:
        digit = digit_sum % base
        digit_sum -= digit
        rep.append(digit)
    rep = ''.join(reversed(rep))
    if base == _base:
        return str_to_int(rep)
    return base*str_to_int(rep)