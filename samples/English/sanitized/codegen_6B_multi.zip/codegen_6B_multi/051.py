

def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    vowels = 'abcdefghijklmnopqrstuvwxyzAEIOU'
    result = ''
    c = 0
    while c < len(text) -1:
        if text.count('a') <= 1 or text.count('E') <= 1 or text.count('o') <= 1  or text.count('o') == text.count('u') or  text.count('A') <= 1 or text.count('e') <= 1:
            result += text[c]
        else:
            break
        c +=1
    return result