
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.
    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    from bisect import bisect_left
    # use bisect_left to maintain an ordered list of all indices greater than
    # a
    indices = [i for i in range(b) if i > a]
    return [i for i in indices if i % 2 == 0]