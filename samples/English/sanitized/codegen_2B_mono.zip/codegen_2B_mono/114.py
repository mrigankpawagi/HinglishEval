
def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # n = len(nums)
    # if not nums:
    #     return 0
    # start, end = 0, 0
    # min = float('inf')
    # sum = 0
    # while end < len(nums):
    #     while end < len(nums):
    #         sum += nums[end]
    #         end += 1
    #         if sum < min:
    #             min = sum
    #     start += 1
    # return min
    max_sum = float('-inf')
    sum = 0
    for i in range(len(nums)):
        sum += nums[i]
        while sum <= max_sum:
            sum -= nums[i]
        max_sum = max(max_sum, sum)
    return max_sum